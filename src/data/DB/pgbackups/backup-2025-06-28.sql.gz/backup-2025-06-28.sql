--
-- PostgreSQL database dump
--

-- Dumped from database version 17.5
-- Dumped by pg_dump version 17.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: channel; Type: TABLE; Schema: public; Owner: usergameplay
--

CREATE TABLE public.channel (
    id_channel integer NOT NULL,
    id_youtube character varying(50) NOT NULL,
    url character varying(100) NOT NULL,
    title character varying(50) NOT NULL,
    description character varying(1000),
    description_snippet character varying(500),
    handle_name character varying(50) NOT NULL,
    handle character varying(50) NOT NULL,
    id_game integer,
    country character varying(30),
    register_date date,
    my_channel boolean DEFAULT false NOT NULL
);


ALTER TABLE public.channel OWNER TO usergameplay;

--
-- Name: channel_games; Type: TABLE; Schema: public; Owner: usergameplay
--

CREATE TABLE public.channel_games (
    id_youtube character varying(50) NOT NULL,
    id_game integer NOT NULL
);


ALTER TABLE public.channel_games OWNER TO usergameplay;

--
-- Name: channel_historic; Type: TABLE; Schema: public; Owner: usergameplay
--

CREATE TABLE public.channel_historic (
    id_youtube character varying(50) NOT NULL,
    views integer NOT NULL,
    subscribers integer NOT NULL,
    register_date date NOT NULL
);


ALTER TABLE public.channel_historic OWNER TO usergameplay;

--
-- Name: channel_id_channel_seq; Type: SEQUENCE; Schema: public; Owner: usergameplay
--

CREATE SEQUENCE public.channel_id_channel_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.channel_id_channel_seq OWNER TO usergameplay;

--
-- Name: channel_id_channel_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: usergameplay
--

ALTER SEQUENCE public.channel_id_channel_seq OWNED BY public.channel.id_channel;


--
-- Name: channel_images; Type: TABLE; Schema: public; Owner: usergameplay
--

CREATE TABLE public.channel_images (
    id_youtube character varying(50) NOT NULL,
    logo bytea,
    banner bytea,
    vanity bytea
);


ALTER TABLE public.channel_images OWNER TO usergameplay;

--
-- Name: events; Type: TABLE; Schema: public; Owner: usergameplay
--

CREATE TABLE public.events (
    id_event integer NOT NULL,
    name character varying(50) NOT NULL,
    id_game integer NOT NULL,
    date_start date,
    date_end date
);


ALTER TABLE public.events OWNER TO usergameplay;

--
-- Name: events_id_event_seq; Type: SEQUENCE; Schema: public; Owner: usergameplay
--

CREATE SEQUENCE public.events_id_event_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.events_id_event_seq OWNER TO usergameplay;

--
-- Name: events_id_event_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: usergameplay
--

ALTER SEQUENCE public.events_id_event_seq OWNED BY public.events.id_event;


--
-- Name: games; Type: TABLE; Schema: public; Owner: usergameplay
--

CREATE TABLE public.games (
    id_game integer NOT NULL,
    name character varying(50) NOT NULL,
    game character varying(25) NOT NULL,
    ico bytea
);


ALTER TABLE public.games OWNER TO usergameplay;

--
-- Name: games_id_game_seq; Type: SEQUENCE; Schema: public; Owner: usergameplay
--

CREATE SEQUENCE public.games_id_game_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.games_id_game_seq OWNER TO usergameplay;

--
-- Name: games_id_game_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: usergameplay
--

ALTER SEQUENCE public.games_id_game_seq OWNED BY public.games.id_game;


--
-- Name: heroes; Type: TABLE; Schema: public; Owner: usergameplay
--

CREATE TABLE public.heroes (
    id_hero integer NOT NULL,
    name character varying(50) NOT NULL,
    id_game integer NOT NULL,
    description character varying(1000),
    image bytea
);


ALTER TABLE public.heroes OWNER TO usergameplay;

--
-- Name: heroes_id_hero_seq; Type: SEQUENCE; Schema: public; Owner: usergameplay
--

CREATE SEQUENCE public.heroes_id_hero_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.heroes_id_hero_seq OWNER TO usergameplay;

--
-- Name: heroes_id_hero_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: usergameplay
--

ALTER SEQUENCE public.heroes_id_hero_seq OWNED BY public.heroes.id_hero;


--
-- Name: itens; Type: TABLE; Schema: public; Owner: usergameplay
--

CREATE TABLE public.itens (
    id_item integer NOT NULL,
    name character varying(50) NOT NULL,
    id_game integer NOT NULL,
    description character varying(1000),
    "VALUE" integer NOT NULL
);


ALTER TABLE public.itens OWNER TO usergameplay;

--
-- Name: itens_id_item_seq; Type: SEQUENCE; Schema: public; Owner: usergameplay
--

CREATE SEQUENCE public.itens_id_item_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.itens_id_item_seq OWNER TO usergameplay;

--
-- Name: itens_id_item_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: usergameplay
--

ALTER SEQUENCE public.itens_id_item_seq OWNED BY public.itens.id_item;


--
-- Name: itens_images; Type: TABLE; Schema: public; Owner: usergameplay
--

CREATE TABLE public.itens_images (
    id_item integer NOT NULL,
    image bytea
);


ALTER TABLE public.itens_images OWNER TO usergameplay;

--
-- Name: playlist; Type: TABLE; Schema: public; Owner: usergameplay
--

CREATE TABLE public.playlist (
    id_playlist character varying(50) NOT NULL,
    id_youtube character varying(50) NOT NULL,
    id_game integer,
    title character varying(100) NOT NULL,
    description character varying(1000),
    register_date date NOT NULL
);


ALTER TABLE public.playlist OWNER TO usergameplay;

--
-- Name: playlist_movie; Type: TABLE; Schema: public; Owner: usergameplay
--

CREATE TABLE public.playlist_movie (
    id_movie integer NOT NULL,
    id_video character varying(50) NOT NULL,
    url character varying(100) NOT NULL,
    id_playlist character varying(50) NOT NULL,
    id_game integer NOT NULL,
    id_proplayer integer NOT NULL,
    id_hero integer NOT NULL,
    time_movie integer NOT NULL,
    register_date date NOT NULL
);


ALTER TABLE public.playlist_movie OWNER TO usergameplay;

--
-- Name: playlist_movie_historic; Type: TABLE; Schema: public; Owner: usergameplay
--

CREATE TABLE public.playlist_movie_historic (
    id_movie integer NOT NULL,
    titulo character varying(50) NOT NULL,
    description character varying(1000),
    likes integer NOT NULL,
    date_start date NOT NULL,
    register_date date NOT NULL,
    date_end date NOT NULL
);


ALTER TABLE public.playlist_movie_historic OWNER TO usergameplay;

--
-- Name: playlist_movie_id_movie_seq; Type: SEQUENCE; Schema: public; Owner: usergameplay
--

CREATE SEQUENCE public.playlist_movie_id_movie_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.playlist_movie_id_movie_seq OWNER TO usergameplay;

--
-- Name: playlist_movie_id_movie_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: usergameplay
--

ALTER SEQUENCE public.playlist_movie_id_movie_seq OWNED BY public.playlist_movie.id_movie;


--
-- Name: playlist_movie_tumblr; Type: TABLE; Schema: public; Owner: usergameplay
--

CREATE TABLE public.playlist_movie_tumblr (
    id_movie integer NOT NULL,
    hash_tumblr character varying(64) NOT NULL,
    tumblr bytea NOT NULL,
    register_date date NOT NULL
);


ALTER TABLE public.playlist_movie_tumblr OWNER TO usergameplay;

--
-- Name: proplayers; Type: TABLE; Schema: public; Owner: usergameplay
--

CREATE TABLE public.proplayers (
    id_proplayer integer NOT NULL,
    "NOME" character varying(50) NOT NULL,
    description character varying(1000),
    register_date date NOT NULL
);


ALTER TABLE public.proplayers OWNER TO usergameplay;

--
-- Name: proplayers_games; Type: TABLE; Schema: public; Owner: usergameplay
--

CREATE TABLE public.proplayers_games (
    id_proplayer integer NOT NULL,
    id_game integer NOT NULL,
    register_date date NOT NULL
);


ALTER TABLE public.proplayers_games OWNER TO usergameplay;

--
-- Name: proplayers_heroes; Type: TABLE; Schema: public; Owner: usergameplay
--

CREATE TABLE public.proplayers_heroes (
    id_proplayer integer NOT NULL,
    id_hero integer NOT NULL,
    register_date date NOT NULL
);


ALTER TABLE public.proplayers_heroes OWNER TO usergameplay;

--
-- Name: proplayers_heroes_build; Type: TABLE; Schema: public; Owner: usergameplay
--

CREATE TABLE public.proplayers_heroes_build (
    id_proplayer integer NOT NULL,
    id_hero integer NOT NULL,
    id_item_1 integer,
    id_item_2 integer,
    id_item_3 integer,
    id_item_4 integer,
    id_item_5 integer,
    id_item_6 integer,
    id_item_7 integer,
    id_item_8 integer,
    id_item_9 integer,
    register_date date NOT NULL
);


ALTER TABLE public.proplayers_heroes_build OWNER TO usergameplay;

--
-- Name: proplayers_id_proplayer_seq; Type: SEQUENCE; Schema: public; Owner: usergameplay
--

CREATE SEQUENCE public.proplayers_id_proplayer_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.proplayers_id_proplayer_seq OWNER TO usergameplay;

--
-- Name: proplayers_id_proplayer_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: usergameplay
--

ALTER SEQUENCE public.proplayers_id_proplayer_seq OWNED BY public.proplayers.id_proplayer;


--
-- Name: proplayers_images; Type: TABLE; Schema: public; Owner: usergameplay
--

CREATE TABLE public.proplayers_images (
    id_proplayer integer NOT NULL,
    hash_tumblr character varying(64) NOT NULL,
    image bytea
);


ALTER TABLE public.proplayers_images OWNER TO usergameplay;

--
-- Name: teams; Type: TABLE; Schema: public; Owner: usergameplay
--

CREATE TABLE public.teams (
    id_team integer NOT NULL,
    team character varying(50) NOT NULL,
    logo bytea
);


ALTER TABLE public.teams OWNER TO usergameplay;

--
-- Name: teams_game; Type: TABLE; Schema: public; Owner: usergameplay
--

CREATE TABLE public.teams_game (
    id_team integer NOT NULL,
    id_game integer NOT NULL,
    banner bytea
);


ALTER TABLE public.teams_game OWNER TO usergameplay;

--
-- Name: teams_id_team_seq; Type: SEQUENCE; Schema: public; Owner: usergameplay
--

CREATE SEQUENCE public.teams_id_team_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.teams_id_team_seq OWNER TO usergameplay;

--
-- Name: teams_id_team_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: usergameplay
--

ALTER SEQUENCE public.teams_id_team_seq OWNED BY public.teams.id_team;


--
-- Name: tumblr; Type: TABLE; Schema: public; Owner: usergameplay
--

CREATE TABLE public.tumblr (
    id_hero integer NOT NULL,
    description character varying(1000),
    hash_tumblr character varying(64) NOT NULL,
    image bytea
);


ALTER TABLE public.tumblr OWNER TO usergameplay;

--
-- Name: channel id_channel; Type: DEFAULT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.channel ALTER COLUMN id_channel SET DEFAULT nextval('public.channel_id_channel_seq'::regclass);


--
-- Name: events id_event; Type: DEFAULT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.events ALTER COLUMN id_event SET DEFAULT nextval('public.events_id_event_seq'::regclass);


--
-- Name: games id_game; Type: DEFAULT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.games ALTER COLUMN id_game SET DEFAULT nextval('public.games_id_game_seq'::regclass);


--
-- Name: heroes id_hero; Type: DEFAULT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.heroes ALTER COLUMN id_hero SET DEFAULT nextval('public.heroes_id_hero_seq'::regclass);


--
-- Name: itens id_item; Type: DEFAULT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.itens ALTER COLUMN id_item SET DEFAULT nextval('public.itens_id_item_seq'::regclass);


--
-- Name: playlist_movie id_movie; Type: DEFAULT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.playlist_movie ALTER COLUMN id_movie SET DEFAULT nextval('public.playlist_movie_id_movie_seq'::regclass);


--
-- Name: proplayers id_proplayer; Type: DEFAULT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.proplayers ALTER COLUMN id_proplayer SET DEFAULT nextval('public.proplayers_id_proplayer_seq'::regclass);


--
-- Name: teams id_team; Type: DEFAULT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.teams ALTER COLUMN id_team SET DEFAULT nextval('public.teams_id_team_seq'::regclass);


--
-- Data for Name: channel; Type: TABLE DATA; Schema: public; Owner: usergameplay
--

COPY public.channel (id_channel, id_youtube, url, title, description, description_snippet, handle_name, handle, id_game, country, register_date, my_channel) FROM stdin;
1	UCznPSdnBofe1ONMO0m2GSQQ	https://www.youtube.com/channel/UCznPSdnBofe1ONMO0m2GSQQ	Dota 2 Old School Show	Where legends shine and nostalgia is immortal!\n\nEN-US\nWelcome to the Dota 2 Old School Show!\n\nHere, you relive the greatest moments of Dota 2s golden era with legendary pro player gameplays, classic strategies, and historic plays.\nGet ready for an epic journey with the most iconic heroes and the builds that shaped the meta.\n\n🎮 Daily videos with epic matches\n🏆 Tributes to the legends of the competitive scene\n📅 New videos every week\n💬 Comment the next player or team youd like to see!\n\nOnde as lendas brilham e a nostalgia é imortal!\n\nPT-BR\nBem-vindo ao Dota 2 Old School Show!\n\nAqui você revive os melhores momentos da era dourada do Dota 2 com gameplays lendárias de pro players, estratégias clássicas e jogadas que marcaram história.\nPrepare-se para uma viagem épica com os heróis mais icônicos e as builds que moldaram o meta.\n\n🎮 Vídeos diários com partidas épicas\n🏆 Homenagens às lendas do cenário competitivo\n📅 Novos vídeos toda semana\n💬 Comente o próximo jogador ou time que quer ver!\n	Where legends shine and nostalgia is immortal! 	Dota2OldSchoolShow	@Dota2OldSchoolShow	1	\N	2025-06-23	t
3	UCDztxdy54wmTB17z9Vh8b3A	https://www.youtube.com/channel/UCDztxdy54wmTB17z9Vh8b3A	Dota Persona	Dota 2 Pro Support Gameplay Channel\n\nMostly support role gameplay from Pub and Tournament\n\nYou can request anything just comment on my video!\n\nTHANKS FOR COMING !\n\nVALVE VIDEO POLICY\nhttps://store.steampowered.com/video_policy\n	Dota 2 Pro Support Gameplay Channel 	DotaSupport	@DotaSupport	1	\N	2025-06-23	f
4	UCHZ7buu1amKXgpqCVsox1aA	https://www.youtube.com/channel/UCHZ7buu1amKXgpqCVsox1aA	Dota Gameplay	Welcome to Kardel Dota 2! Home of the best & updated Dota 2 gameplays!\n\nDont forget to like and subscribe as it helps the channel very much.\n\nLOOK FOR THE BEST GAMEPLAYS HERE:\nhttps://www.youtube.com/playlist?list=PLKJ2kg9FdH3rPQesQ1nep6sE-PvkuYEnR\n\nMY OTHER CHANNEL (Kardel Highlights) :\nhttps://www.youtube.com/channel/UCicDjmMP4Rw3mg-tWYVu7Fg \n\n	Welcome to Kardel Dota 2! Home of the best & updated Dota 2 gameplays! 	DotaGameplay	@DotaGameplay	1	\N	2025-06-23	f
5	UCwI9DhoGEziLUxTpK8H77jw	https://www.youtube.com/channel/UCwI9DhoGEziLUxTpK8H77jw	Dota 2 Pro Gameplay [Watch & Learn]	Top MMR Plays / Dota 2 Pro Gameplay is Educational Channel about e-sport Dota 2 competitive scene. Watch replays of professional players, highest MMR battles and LEARN from you favourite Pro players!\n\n► Remember to subscribe to be notified when we release new #Dota2 videos! \n\nWatch Pro, Learn from Pro, Play like Pro!\n\nVALVE VIDEO POLICY\nhttps://store.steampowered.com/video_policy\n	Top MMR Plays / Dota 2 Pro Gameplay is Educational Channel about e-sport Dota 2 competitive scene. Watch replays of professional players, highest MMR battles and LEARN from you favourite Pro players! 	ProGameplayDota2	@ProGameplayDota2	1	\N	2025-06-23	f
6	UC18NaGQLruOEw65eQE3bNbg	https://www.youtube.com/channel/UC18NaGQLruOEw65eQE3bNbg	Dota Watafak	We collect clips from thousands of dota players to show them to you. \n\nIf you want to be in one of the videos, send your WTF moment here:\nhttps://dotawatafak.com/category/sube-tu-jugada/\n\nOr click on the "Submit your Play" button below. GLHF!\n	We collect clips from thousands of dota players to show them to you. 	DotaWatafak	@DotaWatafak	1	\N	2025-06-23	f
7	UCTXCACeuoZJggkbuJ0w7_bg	https://www.youtube.com/channel/UCTXCACeuoZJggkbuJ0w7_bg	Rizpol	Welcome to Rizpol Dota\nIve always loved playing Dota and do some silly build, memes, or meta things. \n\nI used to only make dota 2 educational content (in bahasa), but now I make English content about SEA server. \nI also active on other social media Instagram and Facebook.	Welcome to Rizpol Dota 	Rizpol	@Rizpol	1	\N	2025-06-23	f
8	UC1YCxISkweN5vLsOJ0zElZQ	https://www.youtube.com/channel/UC1YCxISkweN5vLsOJ0zElZQ	hOlyhexOr	Official YouTube-Channel of hOlyhexOr, a professional Dota 2 movie maker and ex-professional Dota 2 player. Creating Dota 2 Videos with Passion.\n\n►► Currently searching for new Dota 2 Video Editors! Send over an E-Mail if youre interested!\n► For Business Inquiries + if you want any kind of video production, please contact: hexor@artofdota2.com\n\n►► Send me your BEST Dota 2 clips here: hexordota2clips@artofdota2.com\n\n► Become a VIP now and enjoy exclusive benefits:\nhttps://metafy.gg/@holyhexor\n\nImpressum\nDominik Buhmann, hOlyhexOr\nGetHero\nc/o Webedia GmbH\nCuvrystr. 3-4\n10997 Berlin\nE-Mail: hexor@artofdota2.com\nGeschäftsführer: Marc-Andreas Albert\nHRB 114531\n\nBusiness inquiries & E-Mail: hexor@artofdota2.com\nUmsatzsteuer-Identifikationsnummer: DE297797430\n\nVerantwortlich für den Inhalt iSv. § 18 Abs.2 MStV: Buhmann, Dominik\n	Official YouTube-Channel of hOlyhexOr, a professional Dota 2 movie maker and ex-professional Dota 2 player. Creating Dota 2 Videos with Passion. 	hOlyhexOr	@hOlyhexOr	1	\N	2025-06-23	f
9	UCYWvw17IQl_prkX93IhjuKQ	https://www.youtube.com/channel/UCYWvw17IQl_prkX93IhjuKQ	Dota 2 Enjoyer	Just a fellow Dota 2 Enjoyer	Just a fellow Dota 2 Enjoyer 	Dota2Enjoyer	@Dota2Enjoyer	1	\N	2025-06-23	f
10	UCdk_9kcWld5UvflPR3W7A2w	https://www.youtube.com/channel/UCdk_9kcWld5UvflPR3W7A2w	Dota2 HighSchool	Welcome to HighSchool of Dota 2.\nThanks for watching!!! Love you 9000 (MMR)	Welcome to HighSchool of Dota 2. 	Dota2HighSchool	@Dota2HighSchool	1	\N	2025-06-23	f
11	UCaYLBJfw6d8XqmNlL204lNg	https://www.youtube.com/channel/UCaYLBJfw6d8XqmNlL204lNg	ESL Dota 2	Welcome to the home of ESL Dota 2 on YouTube! Be sure to subscribe to keep up to date with all of the lates Dota 2 action from around the world.	Welcome to the home of ESL Dota 2 on YouTube! Be sure to subscribe to keep up to date with all of the lates Dota 2 action from around the world. 	ESLDota2	@ESLDota2	1	\N	2025-06-23	f
12	UC7sgoyC1VbMNlS1n7ChsBPQ	https://www.youtube.com/channel/UC7sgoyC1VbMNlS1n7ChsBPQ	Dota2 Galaxy	\n	More about this channel 	dota2galaxy	@dota2galaxy	1	\N	2025-06-23	f
14	UCfsOfLvadg89Bx8Sv_6WERg	https://www.youtube.com/channel/UCfsOfLvadg89Bx8Sv_6WERg	NoobFromUA	Dota 2 Channel NoobFromUA. \nDendi Pudge, Miracle-, SingSing and 2 ez 4 Arteezy.\n\nVALVE VIDEO POLICY► https://store.steampowered.com/video_policy\n\nDota 2 Best And Most EPIC GAME EVER!	Dota 2 Channel NoobFromUA. 	NoobFromUA	@NoobFromUA	1	\N	2025-06-23	f
17	UCPkaARl89RCckNE_D7tj-aA	https://www.youtube.com/channel/UCPkaARl89RCckNE_D7tj-aA	Gorgc	Official channel of Gorgc - professional Dota 2 player, streamer for OG, Midas Mode 2 Winner.\nHere you can find the highlights from streams as well as original content.	Official channel of Gorgc - professional Dota 2 player, streamer for OG, Midas Mode 2 Winner. 	Gorgc	@Gorgc	1	\N	2025-06-23	f
18	UCZsM8MOy0VC9blj_wBkbo-g	https://www.youtube.com/channel/UCZsM8MOy0VC9blj_wBkbo-g	Purge	Thanks for checking out my Dota 2 content! If you have any questions, the best way to get a hold of me is to tweet me!\n\nBusiness Inquiry: business@purgegamers.com	Thanks for checking out my Dota 2 content! If you have any questions, the best way to get a hold of me is to tweet me! 	PurgeGamers	@PurgeGamers	1	\N	2025-06-23	f
19	UCy0-ftAwxMHzZc74OhYT3PA	https://www.youtube.com/channel/UCy0-ftAwxMHzZc74OhYT3PA	GameLeap Dota 2 Pro Guides	For Business Inquiries, email support@game-leap.com\nGameLeap is the proven step-by-step platform to help you become a better gamer. You will learn directly from the best players in the world in hundreds of curated video courses. Visit our website at https://www.gameleap.com/	For Business Inquiries, email support@game-leap.com 	gameleapdota2	@gameleapdota2	1	\N	2025-06-23	f
21	UCI2vFNmkaj22Om3qO5J7qOg	https://www.youtube.com/channel/UCI2vFNmkaj22Om3qO5J7qOg	Kryptonill Gaming	👋Hello Guys. Im Kryptonill, a professional video editor and an old time Dota 2 player since 2014 with over 12500 hours total playtime on steam & decided to create this channel in 2017 with passion.\n\n► I only make fully edited educational videos that you cant find on other Channel such as item build, skill build, tips, tricks, how to play, map awareness and every single detail you should know to be a better player in DotA\nI also changed the terrain of the game to make it look better.\nDota 2 has over 124 heroes, its not easy to learn, so be sure to focus every move in my videos.\n\n► What do i record and edit videos with? I record with OBS studio and edit the video with Premier, Resolve, Sony Vegas Pro 15, Adobe After Effect and of course thumbnails with Photoshop.\nI spend hours and hours to edit each video, You better leave a like.\n\n    ⏰Upload Schedule⏰\n➤7:00AM \n➤11:00AM \n➤3:00PM\n➤7:00PM \n➤11:00PM\n\n  🙏PLEASE GIVE ME STRENGTH🙏\n           😜SUBSCRIBE NOW😜\n  💖Lets Make DotA Great Again💖	👋Hello Guys. Im Kryptonill, a professional video editor and an old time Dota 2 player since 2014 with over 12500 hours total playtime on steam & decided to create this channel in 2017 with passion. 	KryptonillGaming	@KryptonillGaming	1	\N	2025-06-23	f
23	UCKCC6yRZor2qsGbO_x7LpuA	https://www.youtube.com/channel/UCKCC6yRZor2qsGbO_x7LpuA	Dota 2 Meta	Meta - Uploading Only Professional Evolution Videos	Meta - Uploading Only Professional Evolution Videos 	metagamesevolution	@metagamesevolution	1	\N	2025-06-23	f
24	UCiR9IHCurqVHpC821NVcW6g	https://www.youtube.com/channel/UCiR9IHCurqVHpC821NVcW6g	Dota 2 Divine	Welcome to Dota 2 Divine! Have Fun when playing Dota.\n\nDota2 Gameplay, Highlight, Epic Moment, Amazing Build, Funny Stream moment\nDIVINE Idol: Dendi, Miracle-, Singsing, Arteezy, Admiralbulldog, w33, ABED, Puppey, Kuroky, Sumail\nDIVINE Favorite Hero: Invoker, Pudge, Meepo, Legion Commander, Phantom Assassin, Alchemist, Monkey King\n\nLooking for Sponsorship, inbox me if you are interested in DIVINE DOTA	Welcome to Dota 2 Divine! Have Fun when playing Dota. 	Dota2Divine	@Dota2Divine	1	\N	2025-06-23	f
25	UC72LSerSpu1y9y_BlDHWLGA	https://www.youtube.com/channel/UC72LSerSpu1y9y_BlDHWLGA	Dota 2 Tips	Dota 2 MOBA videos + gaming tips, gameplay, strategy, proplayer guides, tips and tricks! \nHeroes with their abilities, itembuilds, gameanalysis, gamebreaking bugs, gamechanging strategies, winningstrategies, mapawareness, farming, laning about teamfight, herocontrol, warding, smoke of deceit, ganking, pushingstrategies etc!\n	Dota 2 MOBA videos + gaming tips, gameplay, strategy, proplayer guides, tips and tricks! 	Dota2Tips	@Dota2Tips	1	\N	2025-06-23	f
26	UCMZwHuSN9ZqRXucscC_hnKA	https://www.youtube.com/channel/UCMZwHuSN9ZqRXucscC_hnKA	LeagueOfDota	Hello guys, welcome back to LeagueOfDota Youtube channel.\nThis channel provide most recent highlights with high quality stats preview before the match like head to head team, standings bracket, players heroes performances and etc. \nHope you enjoy the videos. Thank you.\n\n\nVALVE VIDEO POLICY https://store.steampowered.com/video_policy	Hello guys, welcome back to LeagueOfDota Youtube channel. 	LeagueOfDota	@LeagueOfDota	1	\N	2025-06-23	f
108	UCpLgMe1mjvvTrNgSQ28PHnw	https://www.youtube.com/channel/UCpLgMe1mjvvTrNgSQ28PHnw	Dota 2 Gameplay [Pro Leagues]	More about this channel 	More about this channel 	dota2proleagues	@dota2proleagues	1	\N	2025-06-23	f
27	UCrrZzgPvpLdp0g285JPb7GQ	https://www.youtube.com/channel/UCrrZzgPvpLdp0g285JPb7GQ	Holy E	😎 Who am I?\n\nIm Holy E, a Dota 2 player with 16 years of experience!!! but NOT a pro player!😁. Ive started with Dota 1 (6.43 patch) and Ive seen lots of builds, gameplays, and a mindset of playing Dota!\nIt brings me here to make Dota 2 funny videos, including educational tips!\n	😎 Who am I? 	HolyE	@HolyE	1	\N	2025-06-23	f
28	UCJOpcUMBPnayED1xGFlvQCg	https://www.youtube.com/channel/UCJOpcUMBPnayED1xGFlvQCg	Dota Shaman	Arteezy Positive Mental Atitude (PMA) and more Dota 2 stream moments!\n\nSubscribe for some laugh moments.\nHave fun guys ^^	Arteezy Positive Mental Atitude (PMA) and more Dota 2 stream moments! 	dotashaman	@dotashaman	1	\N	2025-06-23	f
29	UC4M1snKkcGvEVOBGC5LnGdQ	https://www.youtube.com/channel/UC4M1snKkcGvEVOBGC5LnGdQ	Qojqva	Dota 2 gameplay, tips, and strategies. Improve your skills and enjoy exciting matches!\n	Dota 2 gameplay, tips, and strategies. Improve your skills and enjoy exciting matches! 	qojqva6094	@qojqva6094	1	\N	2025-06-23	f
30	UCiqBeZx-Jez6J6WK6-PXrew	https://www.youtube.com/channel/UCiqBeZx-Jez6J6WK6-PXrew	WillDS	mungkin channel gaming\n\n	mungkin channel gaming 	WillDarkestSystem	@WillDarkestSystem	1	\N	2025-06-23	f
31	UC4HfMLhNP7oVmF0wJMAU_1g	https://www.youtube.com/channel/UC4HfMLhNP7oVmF0wJMAU_1g	Dota 2 Invoker	******  THIS CHANNEL IS ALL ABOUT INVOKER DOTA 2 ******\n\n****************************\n\nSUPPORT US BY SUBSCRIBE CHANNEL: https://www.youtube.com/@Dota2InvokerOfficial\n     \n****************************\n\n\n	******  THIS CHANNEL IS ALL ABOUT INVOKER DOTA 2 ****** 	Dota2InvokerOfficial	@Dota2InvokerOfficial	1	\N	2025-06-23	f
32	UCeaSnulFHX9xqkKejnIvyxA	https://www.youtube.com/channel/UCeaSnulFHX9xqkKejnIvyxA	PLAYER PERSPECTIVE DOTA 2	Hello guys, welcome to my channel!\n\nVALVE VIDEO POLICY: https://store.steampowered.com/video_policy\n	Hello guys, welcome to my channel! 	PPDota2	@PPDota2	1	\N	2025-06-23	f
33	UCr6cJRQ6EBchbTI-NlLBwww	https://www.youtube.com/channel/UCr6cJRQ6EBchbTI-NlLBwww	Deadlock Pro Gameplay [Watch & Learn]	We post spectacular Deadlock professional e-sport players gameplay. Watch pro players to improve your personal skill!\n\nVALVE VIDEO POLICY\nhttps://store.steampowered.com/video_policy\n	We post spectacular Deadlock professional e-sport players gameplay. Watch pro players to improve your personal skill! 	ProGameplayDeadlock	@ProGameplayDeadlock	1	\N	2025-06-23	f
34	UCXjx9yYZ55-kl2J54efE8bg	https://www.youtube.com/channel/UCXjx9yYZ55-kl2J54efE8bg	WagaGaming	Im Wagamama,  Dota 2 streamer!\n\nI play dota2 fulltime and I try to provide some fun and educational content on my stream and youtube!\nFollow me on twitter or facebook and youll know what Im up to :)	Im Wagamama,  Dota 2 streamer! 	WagaGaming	@WagaGaming	1	\N	2025-06-23	f
35	UCrRlDvN5Ea2OauDLtNBMyfw	https://www.youtube.com/channel/UCrRlDvN5Ea2OauDLtNBMyfw	DATOHLEONG	I make really cool dota 2 videos :D\n\nBased: Singapore\n\nContact me: contactdatohleong@gmail.com\nFor all Business Inquiries, please contact elizaah@emerge-esports.com\n	I make really cool dota 2 videos :D 	datohleonggez	@datohleonggez	1	\N	2025-06-23	f
36	UCokHQ6IhiqeYuy-TqQthi4w	https://www.youtube.com/channel/UCokHQ6IhiqeYuy-TqQthi4w	Dota 2 Pango	We capturing the best moments so you dont have to\n	We capturing the best moments so you dont have to 	Dota2Pango	@Dota2Pango	1	\N	2025-06-23	f
37	UC4aVD0WIvfFsiICZy5Wo22w	https://www.youtube.com/channel/UC4aVD0WIvfFsiICZy5Wo22w	DOTA empire	Dota 2  Gameplay Channel\n\nMostly offlane role gameplay from Pub and Tournament\n\nvalve credit: https://store.steampowered.com/video_policy\n\nif you own those videos and need to delete it just email me\n\nthanks for visiting here\n	Dota 2  Gameplay Channel 	dotaempire2505	@dotaempire2505	1	\N	2025-06-23	f
38	UCK2t7qm88e6ZsKS3Pbg-C3Q	https://www.youtube.com/channel/UCK2t7qm88e6ZsKS3Pbg-C3Q	Dota 2 Highlights & Guides TV	Welcome to your go-to educational channel for the competitive Dota 2 scene!\nDive into high-level gameplay, watch replays from top-ranked matches, and learn directly from the best professional players in the game.\n\n► Subscribe and stay updated with the latest #Dota2 videos!\nWatch the pros. Learn their moves. Play like a pro.\n\n🔗 Valve Video Policy:\nhttps://store.steampowered.com/video_policy\n	Welcome to your go-to educational channel for the competitive Dota 2 scene! 	Dota2HighlightsGuides	@Dota2HighlightsGuides	1	\N	2025-06-23	f
39	UCW2Ew5V3I2z1jXvsZEkKtUQ	https://www.youtube.com/channel/UCW2Ew5V3I2z1jXvsZEkKtUQ	Dota 2 Scepter	★Hey there! Welcome To Dota 2 Scepter. Its all about Dota 2.\n►We Uploading Highlight Dota 2 videos with passion.\n★My channel includes tips and tricks, guide, gameplay, and how to get better at Dota 2.\n★Everything about Dota 2, You can find it here on this channel.\n\n★How I Edit My Videos ? 100% Unique And Original Contents:\n1. Take replay from dotabuff.com or opendota.com\n2. Analytics which gameplays are interesting.\n3. Record in game client with Nvidia Shadowplay.\n4. Edit with adobe premiere pro cc 2018 and thumbnail create with adobe photoshop cc 2018.\n★We spent more than 15 hours everyday for uploading dota 2 videos with passion.\n\n►Valve - Dota 2 monetize video policy: https://store.steampowered.com/video_policy\n\n                          👊Need More Power👊\n                            😇Subscribe Now😇\n                                💖Lets Do It!💖\n	★Hey there! Welcome To Dota 2 Scepter. Its all about Dota 2. 	Dota2Scepter	@Dota2Scepter	1	\N	2025-06-23	f
40	UCS3_m4V1yExUC18ejJnd1IQ	https://www.youtube.com/channel/UCS3_m4V1yExUC18ejJnd1IQ	ZQuixotix	Hello friends, Im Zach. I mostly make Dota 2 videos about how to play the support roles, currently ~6.7K, Rank 1000ish in NA.\n\nIf some of the videos seem too long for you, check out the video descriptions! I try to add brief summaries/timestamps to important points (including a summary at the end of most videos). \n	Hello friends, Im Zach. I mostly make Dota 2 videos about how to play the support roles, currently ~6.7K, Rank 1000ish in NA. 	ZQuixotix	@ZQuixotix	1	\N	2025-06-23	f
41	UC8rWMk2o4KHkoMWybi0rVlA	https://www.youtube.com/channel/UC8rWMk2o4KHkoMWybi0rVlA	PainDota	10K MMR, Education Dota 2 Content. Coaching videos & Analysis on Pro Players. 	10K MMR, Education Dota 2 Content. Coaching videos & Analysis on Pro Players. 	PainDota	@PainDota	1	\N	2025-06-23	f
42	UCpCG__ifmbaTPaQnpixkB4w	https://www.youtube.com/channel/UCpCG__ifmbaTPaQnpixkB4w	evanescent dota 2	\n	More about this channel 	EvanescentDota2	@EvanescentDota2	1	\N	2025-06-23	f
70	UCWZSOq7SJedArFyc3SNRVvw	https://www.youtube.com/channel/UCWZSOq7SJedArFyc3SNRVvw	Spotnet Dota2	Spotnet Dota 2 Channel for Tournament gameplay and Top Plays\n\nI provide commentary for educational and entertain.\nWatching live non Official streaming Tournament with English Freelance Caster\n\nAll Gameplays are from Dota 2 Game produced by Valve\nValve, the Valve logo, Dota, the Dota 2 logo, and Defense of the Ancients are trademarks and/or registered trademarks of Valve Corporation. All other trademarks are property of their respective owners.\n\nValve video policy / License https://store.steampowered.com/video_policy\nDotaTV License : https://www.dota2.com/dotatv\n\n	Spotnet Dota 2 Channel for Tournament gameplay and Top Plays 	SpotnetDota2	@SpotnetDota2	1	\N	2025-06-23	f
43	UCHky6L8_p73ujg9II9La_6A	https://www.youtube.com/channel/UCHky6L8_p73ujg9II9La_6A	Dota 2 Adventure 	💖Welcome to Dota 2 Adventure! Its All About DOTA 2💖\nIf Youre DotA Lover Congratulations! Youre in The Right Place.\nIn Here You Can Relax and Enjoy Pro Player Perspective Gameplay.\nTHANK FOR WATCHING GUY. I HOPE YOU ENJOY THIS VIDEO.\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n⏰Upload Schedule⏰ 3Videos Every Single Day\n➤5:00PM \n➤7:00PM \n➤9:00PM\n\n     👊Need More Power👊\n        😇Subscribe Now😇\n            💖Lets Do It!💖\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\nDota2 is a multiplayer online battle arena (MOBA) video game in which two teams of five players compete to collectively destroy a large structure defended by the opposing team known as the "Ancient", whilst defending their own.\n\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n#Dota #Dota2 #Dota2Aventure\n	💖Welcome to Dota 2 Adventure! Its All About DOTA 2💖 	Dota2Adventure	@Dota2Adventure	1	\N	2025-06-23	f
44	UCqsQG398BFcxNojHLg26L9g	https://www.youtube.com/channel/UCqsQG398BFcxNojHLg26L9g	Dota 2 Pro Ranked Gameplay 	Welcome to Dota 2 Pro Ranked Gameplay!\n\nHi, I am one of the most commended players (14K) in Dota 2 Community. I am a commentator, entertainer, & video creator. \n\nThis channel is an Educational + Gaming Channel all about the e-sport game “Dota 2”.\n\nI will explain to you all the basic skills, guides, tips, & tricks, related to the latest meta, updates, & how pro players (at the top MMR) play through my commentary & highlight videos.\n\nBest way to increase your skills in any game is by watching & learning from pro players replays. So here, you can learn a lot from my daily videos, in which I explain my analysis of players perspectives. To win consecutively, and reach the Top MMR stages, you need to know the pro strategies like denying creeps, last hits, map control, items build, play style, and many more.\n\nMy Mission!\nWatch Pro, Learn from Pro, & Play like Pro!\n\nDont forget to like and subscribe as it helps the channel! \n\nVALVE VIDEO POLICY: https://store.steampowered.com/video_policy\n	Welcome to Dota 2 Pro Ranked Gameplay! 	dota2prorankedgameplay	@dota2prorankedgameplay	1	\N	2025-06-23	f
45	UCdO3EenGrBpD7KCePa13c2A	https://www.youtube.com/channel/UCdO3EenGrBpD7KCePa13c2A	Dota RollerCoaster	More about this channel 	More about this channel 	dotarollercoaster	@dotarollercoaster	1	\N	2025-06-23	f
46	UCAi2SCg-RMzEB1sap7UKlvw	https://www.youtube.com/channel/UCAi2SCg-RMzEB1sap7UKlvw	iAnnihilate	12k MMR mid player making educational content for Dota 2!	12k MMR mid player making educational content for Dota 2! 	iAnnihilate	@iAnnihilate	1	\N	2025-06-23	f
48	UCWBWm89MmoSHEXLoEeUbVTw	https://www.youtube.com/channel/UCWBWm89MmoSHEXLoEeUbVTw	DOTA 2 Immortal Plays	Dota 2 Replays of High MMR Matches\n\nUpload Every Single Day\n\nThank You for Watching!\n\n►Valve Video Policy: https://store.steampowered.com/video_policy\n	Dota 2 Replays of High MMR Matches 	dota2immortalplays661	@dota2immortalplays661	1	\N	2025-06-23	f
49	UCIE4fk1t6sXYqszHLU-Tk5g	https://www.youtube.com/channel/UCIE4fk1t6sXYqszHLU-Tk5g	Elacrity	I like to dota and sometimes other games to, relax, and have a good time.	I like to dota and sometimes other games to, relax, and have a good time. 	elacrityd2	@elacrityd2	1	\N	2025-06-23	f
51	UCL7w4AbdEGE3UjzHI3AjXOg	https://www.youtube.com/channel/UCL7w4AbdEGE3UjzHI3AjXOg	Tip Worthy - Dota 2	Gameplay videos for various heroes in Dota 2 played by lwaal (https://steamcommunity.com/profiles/76561198080681732/)	Gameplay videos for various heroes in Dota 2 played by lwaal (https://steamcommunity.com/profiles/76561198080681732/) 	tipworthy-dota2	@tipworthy-dota2	1	\N	2025-06-23	f
52	UCWAVnD2zizRENkqEnSC-I_A	https://www.youtube.com/channel/UCWAVnD2zizRENkqEnSC-I_A	SlashStrike	Hey hey 👋 Trying to improve at the fascinating game that is Dota 2?\n\nIm here to help you do exactly that! \n\nIve played competitively with big names such as MinD_ControL and Seleri, Ive coached over a thousand players with MMRs ranging from 50 to 9000, and now Im creating content to deliver all the knowledge Ive gathered over the years to you, in the form of:\n\n📜 Articles & In-depth Hero Guides\n\n✨ Infographics, Item Builds & Hero Grids\n\n🎧 Coaching, Replay Reviews & Interactive Courses\n\nIf you have any questions, dont hesitate to join my discord and ask me directly!\n	Hey hey 👋 Trying to improve at the fascinating game that is Dota 2? 	SlashStrikeDota	@SlashStrikeDota	1	\N	2025-06-23	f
53	UCwD_AqoRMwOX6w0AiGWr4jA	https://www.youtube.com/channel/UCwD_AqoRMwOX6w0AiGWr4jA	DOTA 2 -50a -A LEARNER  GAMEPLAY BY HAXY	TEAM GAME PLAYER -TEAMGAMER\nEA SPORTS-ELECTRONIC ARTS\nHOPE INDAN TEAM WILL  BE PARTICIPATE IN DOTA 2 TOURNAMENT\n\n DOTA 2 PLAYER WHO IS LEARNER \nFULL GAME PLAY \nWIN OR LOSS DOES NOT MATTER YOU LEARN EVERYTIME SOMETHING NEW\n\n Give me suggestions if you want any changes in my gameplay so I can understand and improve my self \nthank you for love and support 😊 	TEAM GAME PLAYER -TEAMGAMER 	50adota2LEARNER	@50adota2LEARNER	1	\N	2025-06-23	f
54	UC8Rv6PXWZ5ERqoLlUsIyQ8w	https://www.youtube.com/channel/UC8Rv6PXWZ5ERqoLlUsIyQ8w	Carbonyl DotA	Im Carbonyl DotA and Im a 7k mmr North American DotA player and coach. On this channel I post coaching VODs, educational videos, and other DotA related content.	Im Carbonyl DotA and Im a 7k mmr North American DotA player and coach. On this channel I post coaching VODs, educational videos, and other DotA related content. 	CarbonylDotA	@CarbonylDotA	1	\N	2025-06-23	f
55	UCXHp2CSy2pYGC9Ede8qvMpg	https://www.youtube.com/channel/UCXHp2CSy2pYGC9Ede8qvMpg	JFKs Unique Dota 2 Finds: Rare Items Showcase	Showcasing Dota 2 cosmetics, doing my best to stick to rare and exclusive unique items. feelsbadman for not recording all the stuff I ever owned. \n\nYou can easily reach me at: https://steamcommunity.com/id/ultimatejfk/\n	Showcasing Dota 2 cosmetics, doing my best to stick to rare and exclusive unique items. feelsbadman for not recording all the stuff I ever owned. 	JFK_Dota	@JFK_Dota	1	\N	2025-06-23	f
71	UCBzrhVhJUaOI0dtpZqGeB2Q	https://www.youtube.com/channel/UCBzrhVhJUaOI0dtpZqGeB2Q	4fun	Cinematic artist\n\n	Cinematic artist 	4fun911	@4fun911	1	\N	2025-06-23	f
56	UCnUgUdncVcxVaqMvQSD_DuA	https://www.youtube.com/channel/UCnUgUdncVcxVaqMvQSD_DuA	Gios Dota Experience	Greetings, my name is Cornelius, 7,6k mmr peak, I am from germany and  study Theology, enjoy dota, music and fitness.\nMy goal is to share parts of my journy as a player and as a coach and to give away some insights I made over the years.\nMy  foucs will be on the wonderfull world of  Dota 2 and will include philosophies both in game and in life, psychological apporaches to manipulate what we call "fate"  towards our own favor, a overall positive and optimistic but hopefully not naive  view on life, and of course many, many dota specific mechanics. \n\nIf you are lookig to get coached, to share Ideas, to get in touch, you can email directly.\nEmail: cornelius21doll@icloud.com\n	Greetings, my name is Cornelius, 7,6k mmr peak, I am from germany and  study Theology, enjoy dota, music and fitness. 	giosdotaexperience4833	@giosdotaexperience4833	1	\N	2025-06-23	f
57	UCK7aWn0h70vqc4QGExA3BBw	https://www.youtube.com/channel/UCK7aWn0h70vqc4QGExA3BBw	Henry Dota 2 - 2nd Channel	This is Henrys second channel mostly focused on personal content and gameplay. For guides and tips please check out his main channel.\n\nHenry is a renowned coach of over 1000 students and educator in the Dota 2 space. \n	This is Henrys second channel mostly focused on personal content and gameplay. For guides and tips please check out his main channel. 	Henrydota2	@Henrydota2	1	\N	2025-06-23	f
58	UCTQKT5QqO3h7y32G8VzuySQ	https://www.youtube.com/channel/UCTQKT5QqO3h7y32G8VzuySQ	dota2	Dota 2 is a competitive game of action and strategy, played both professionally and casually by millions of passionate fans worldwide. \n\nAvailable on Steam: http://store.steampowered.com/app/570/\n	Dota 2 is a competitive game of action and strategy, played both professionally and casually by millions of passionate fans worldwide. 	dota2	@dota2	1	\N	2025-06-23	f
59	UCyJfe8BMWqA2vJuYQ4PDOvw	https://www.youtube.com/channel/UCyJfe8BMWqA2vJuYQ4PDOvw	dotatvru	We love Dota 	We love Dota 	dotatvru	@dotatvru	1	\N	2025-06-23	f
60	UCcJFzYP0f9ZVDILH7HVyLcg	https://www.youtube.com/channel/UCcJFzYP0f9ZVDILH7HVyLcg	justwan	More about this channel 	More about this channel 	justwan	@justwan	1	\N	2025-06-23	f
61	UCUqLL4VcEy4mXcQL0O_H_bg	https://www.youtube.com/channel/UCUqLL4VcEy4mXcQL0O_H_bg	DotA Digest	DotA Digest - Dota 2 Highlights of Elite League 2024 and Dota 2 Tournaments 2024.\n\n⏺️ All videos on the DotA Digest channel are recorded by me in the game client Dota 2 with a unique camera work.\n\nVALVE VIDEO POLICY ► https://store.steampowered.com/video_policy\n"You are free to monetize your videos via the YouTube partner program and similar programs on other video sharing sites. Please dont ask us to write YouTube and tell them its fine with us to post a particular video using Valve content. Its not possible to respond to each such request. Point them to this page."\n	DotA Digest - Dota 2 Highlights of Elite League 2024 and Dota 2 Tournaments 2024. 	DotADigestDD	@DotADigestDD	1	\N	2025-06-23	f
62	UCzghsdg33rhnu-0CLhx_ttA	https://www.youtube.com/channel/UCzghsdg33rhnu-0CLhx_ttA	Dota 2 Regeneration	If you want to watch your interesting games here, you can send us GAME ID. https://www.instagram.com/dota2_abilitydraft/\n dota2abilitydraft11@gmail.com 	If you want to watch your interesting games here, you can send us GAME ID. https://www.instagram.com/dota2_abilitydraft/ 	DOTA2Regeneration	@DOTA2Regeneration	1	\N	2025-06-23	f
63	UCqmJgdqMIWlrGCUdlEZBawg	https://www.youtube.com/channel/UCqmJgdqMIWlrGCUdlEZBawg	Miracle-	Professional Dota 2 player currently playing for Nigma\nWinner of The International 2017.	Professional Dota 2 player currently playing for Nigma 	Miracledoto	@Miracledoto	1	\N	2025-06-23	f
64	UCcwSIU_DxgUFjOXPRaztATw	https://www.youtube.com/channel/UCcwSIU_DxgUFjOXPRaztATw	Metafy Dota 2	On Metafy you can get 1:1 online coaching from the best players in the world and watch amazing content about gaming. \n\nWebsite: https://metafy.gg\nDiscord: https://discord.gg/metafy\nTwitter: https://twitter.com/TryMetafy\nInstagram: https://www.instagram.com/trymetafy/\nFacebook: https://www.facebook.com/metafy.gg\nLinkedIn: https://www.linkedin.com/company/trymetafy/\nYouTube MetafyDota2: https://www.youtube.com/@MetafyDota2\nSnapChat: https://www.snapchat.com/add/metafy.gg\n\n---\n\nMetafy is the premier destination for learning about and improving at your favorite games. You can book 1-on-1 sessions with the top players in gaming, or send in pre-recorded footage and get detailed feedback from an Expert of your choice. You can also sign up for a Metafy Membership and access a mountain of content ranging from educational content, documentaries about pivotal moments in the scene, podcasts, and lots more. \n	On Metafy you can get 1:1 online coaching from the best players in the world and watch amazing content about gaming. 	MetafyDota2	@MetafyDota2	1	\N	2025-06-23	f
65	UCy7O1t8ZD5qe77sdkfBJ76A	https://www.youtube.com/channel/UCy7O1t8ZD5qe77sdkfBJ76A	EpulzeGaming	Follow your favorite teams across our pro-divisions and immerse yourself in the latest livestream productions.\n	Follow your favorite teams across our pro-divisions and immerse yourself in the latest livestream productions. 	EpulzeGaming	@EpulzeGaming	1	\N	2025-06-23	f
66	UCCUR--YxwSYJ4QzuKsaAABw	https://www.youtube.com/channel/UCCUR--YxwSYJ4QzuKsaAABw	Dota 2 Pro	Dota 2 Pro\nI provide commentary for educational and entertain.\nThis the right place to watch gameplay dota 2 from professional player\t\t\t\t\nYou can learn how to play like a pro :)\n\n\n	Dota 2 Pro 	Dota2Pro	@Dota2Pro	1	\N	2025-06-23	f
67	UCbUX71arfjbI8R3jhgncwxg	https://www.youtube.com/channel/UCbUX71arfjbI8R3jhgncwxg	Dota 2 Carry	🔥Welcome to Dota 2 Carry! This`s All About DOTA 2🔥\n\nEveryday we upload video gameplay of the Top Immortal Rank Like \nSumail, Arteezy, Abed, Miracle, Topson, Ana and many more.\n\nIf You`re Dota Lover Congratulations! You`re in The Right Place.\nIn Here You Can Relax and Enjoy Pro Player Perspective Gameplay. \n\nWhat do i record and edit videos with? \nI record with OBS studio and edit the video with Sony Vegas Pro 15, Adobe After Effect and of course thumbnails with Photoshop.\nI spend hours and hours to edit each video, You better leave a like.\n\nRemember to subscribe to be notified when we publish new videos or highlights!	🔥Welcome to Dota 2 Carry! This`s All About DOTA 2🔥 	Dota2Carry	@Dota2Carry	1	\N	2025-06-23	f
68	UC7l_lqR3T5Pkrjp2Uyc2dKQ	https://www.youtube.com/channel/UC7l_lqR3T5Pkrjp2Uyc2dKQ	VIFOR Dota 2	Best Dota 2 Content.	Best Dota 2 Content. 	VIFORDota2	@VIFORDota2	1	\N	2025-06-23	f
69	UCkkKxVIv_6EJsfRMJ-7ILaQ	https://www.youtube.com/channel/UCkkKxVIv_6EJsfRMJ-7ILaQ	DOTAKU	A Channel for Dota 2 Enjoyer!😁\nSUBSCRIBE TO KNOW ALL INFO ABOUT DOTA 2\n\nemail : dotakuchannel@gmail.com\n\n	A Channel for Dota 2 Enjoyer!😁 	dotakuu	@dotakuu	1	\N	2025-06-23	f
72	UCk0Ns16byYxp5P4aJ6C_AQQ	https://www.youtube.com/channel/UCk0Ns16byYxp5P4aJ6C_AQQ	Invoker Dota 2 7.36	#dota #dota2 #Invoker\n\nHello Dota fans and welcome to the Invoker Dota Channel. We provide the best Invoker Dota Gameplay, Invoker Dota 2 Highlights, Invoker Dota Guide and Invoker Dota Tutorials.\n\nThis game is played on this patch: Dota 2 7.36\n\nAccording to https://dota2.fandom.com/wiki/Invoker , A competent wizard knows perhaps two spells; an exceptional one, three or four. Wielding the elements of Quas, Wex and Exort, the Invoker surpasses them all. Forging Spirits of ice and fire to melt away the armor of enemies with great Alacrity while Snapping their heat-deprived cold bodies.\n	#dota #dota2 #Invoker 	invoker_dota_	@invoker_dota_	1	\N	2025-06-23	f
73	UC75nwKcny3G8YzDQDbRQGxA	https://www.youtube.com/channel/UC75nwKcny3G8YzDQDbRQGxA	Dota 2 Scrim	Home of extreme game highlights and entertainment.\n\nFor business inquiries please contact us at scrimesports.gg@gmail.com	Home of extreme game highlights and entertainment. 	Dota2Scrim	@Dota2Scrim	1	\N	2025-06-23	f
74	UCxhHKJ5gk0WE0hSXJ-cvdOA	https://www.youtube.com/channel/UCxhHKJ5gk0WE0hSXJ-cvdOA	Dota 2 Hub	Everything about Dota2\nSubscribe Please! :)\nDONT CLICK HERE: https://bit.ly/3nE967q\nValves video policy: https://store.steampowered.com/video_policy\n	Everything about Dota2 	Dota2Hub7	@Dota2Hub7	1	\N	2025-06-23	f
95	UC3v9jm_gJl80V7D1bXSQUbg	https://www.youtube.com/channel/UC3v9jm_gJl80V7D1bXSQUbg	LboyAx Gaming	Welcome to my Channel\nIn this channel i talk about the games i play, mostly about Dota\nI make guides, lore and theory videos, predictions and more.\n	Welcome to my Channel 	UnyQkXzGaming	@UnyQkXzGaming	1	\N	2025-06-23	f
96	UCbEKR2sUvjXpCv9bHdeu_kA	https://www.youtube.com/channel/UCbEKR2sUvjXpCv9bHdeu_kA	Meanwhile in Dota 2	Dota 2 Highlights, Dota 2 Pro Gameplays and Dota 2 Events and Updates.	Dota 2 Highlights, Dota 2 Pro Gameplays and Dota 2 Events and Updates. 	MeanwhileinDota2	@MeanwhileinDota2	1	\N	2025-06-23	f
97	UCN3TsZ85XxxJWVjOd3Au7Tg	https://www.youtube.com/channel/UCN3TsZ85XxxJWVjOd3Au7Tg	Dota 2 Documentary	I do storytelling and documentary-type videos for Dota 2.\nAll the script writing, thumbnail, and video editing are all done by me.\n\nOpen for sponsorship, contact on my email below.\n	I do storytelling and documentary-type videos for Dota 2. 	Dota2Documentary	@Dota2Documentary	1	\N	2025-06-23	f
98	UCPInitFCnCdPeXhYTtu_1Mg	https://www.youtube.com/channel/UCPInitFCnCdPeXhYTtu_1Mg	Dota 2 Legend	Dota 2 Legend - Dota 2 Highlights and Best videos of Dota 2 Tournaments	Dota 2 Legend - Dota 2 Highlights and Best videos of Dota 2 Tournaments 	dota2legend941	@dota2legend941	1	\N	2025-06-23	f
99	UCUo_5VlcTiq3-UJn57xbRRA	https://www.youtube.com/channel/UCUo_5VlcTiq3-UJn57xbRRA	Spirit of Dota 2	We post Dota 2 clips from streamers and replays of pro players.\nSubscribe if youre a Chad!\n\n►►► What is Dota 2 ?\nDota 2 is a multiplayer online battle arena video game developed and published by Valve Corporation. The game is a sequel to Defense of the Ancients, which was a community-created mod for Blizzard Entertainments Warcraft III: Reign of Chaos and its expansion pack, The Frozen Throne.\nInitial release date: July 9, 2013\nDeveloper: Valve Corporation\nDesigner: IceFrog\nGenre: Multiplayer online battle arena\nPublisher: Valve Corporation\nEngine: Source 2\n\nAll rights go to the original video owners, no copyright infringement intended. If you want to removed your clips, please send an email to spiritofdota2@gmail.com\n\nValve video policy ► https://store.steampowered.com/video_policy\n	We post Dota 2 clips from streamers and replays of pro players. 	spiritofdota2	@spiritofdota2	1	\N	2025-06-23	f
100	UCKQVOWuuZB0ZGViUHSIbRgg	https://www.youtube.com/channel/UCKQVOWuuZB0ZGViUHSIbRgg	STILL DOTA 2	Welcome guys, Im Still, a Dota 2 player with years of experience but still a god damn noob...\n\n-Subscribe to see more Dota2 Meme Content!\n	Welcome guys, Im Still, a Dota 2 player with years of experience but still a god damn noob... 	stilldota2	@stilldota2	1	\N	2025-06-23	f
101	UC37QwXQO8jF_b7QUOWASYPw	https://www.youtube.com/channel/UC37QwXQO8jF_b7QUOWASYPw	TouchMyAghs	✔ Original videos of an immortal ranked potato player\n✔ Tutorial, TIPS & TRICKS\n✔ Guides to Get Better at Dota\n✔ MEMES & Funny Clips\n\n	✔ Original videos of an immortal ranked potato player 	TouchMyAghs	@TouchMyAghs	1	\N	2025-06-23	f
102	UCM05DDwIjT7rbTStUiDtDKQ	https://www.youtube.com/channel/UCM05DDwIjT7rbTStUiDtDKQ	Dota 2 Pro Players	\n	More about this channel 	Dota2ProPlayers	@Dota2ProPlayers	1	\N	2025-06-23	f
103	UCAsJY3XcyPLePV-m-SGBPdQ	https://www.youtube.com/channel/UCAsJY3XcyPLePV-m-SGBPdQ	Dota 2 Thug Life	We upload dota 2 gameplay videos from pro players every day	We upload dota 2 gameplay videos from pro players every day 	dota2thuglife917	@dota2thuglife917	1	\N	2025-06-23	f
104	UCgfMMDA5Am2fuAyoFXGQoYA	https://www.youtube.com/channel/UCgfMMDA5Am2fuAyoFXGQoYA	Krevs Dota 2	More about this channel 	More about this channel 	krevsdota2	@krevsdota2	1	\N	2025-06-23	f
105	UCKz9sZPT4AvbdhkLWyHJIIA	https://www.youtube.com/channel/UCKz9sZPT4AvbdhkLWyHJIIA	Butcher Channel Dota 2 TV	Hello! This channel will collect the coolest moments of the Dota 2 game, most importantly, by professional players of this discipline. Good mood to everyone and a peaceful sky above your head!\nI will be very grateful for a like, comment and subscription.\n\nIf you want to support me. \nMy Patreon - https://www.patreon.com/ButcherChannelDota2TV\n	Hello! This channel will collect the coolest moments of the Dota 2 game, most importantly, by professional players of this discipline. Good mood to everyone and a peaceful sky above your head! 	bcd2tv	@bcd2tv	1	\N	2025-06-23	f
106	UCgT3aLbI2qNYcYFWtmntxZQ	https://www.youtube.com/channel/UCgT3aLbI2qNYcYFWtmntxZQ	Dota 2 Gameplay live	Welcome to Dota 2 Gameplay live! Have Fun when playing Dota 2.\n\nDota2 Gameplay live, Highlight, Epic Moment, Amazing Build, Funny Stream moment\nDIVINE Idol: Dendi, Miracle-, Singsing, Arteezy, Admiralbulldog, w33, ABED, Puppey, Kuroky, Sumail\nDIVINE Favorite Hero: Invoker, Pudge, Meepo, Legion Commander, Phantom Assassin, Alchemist, Monkey King\n\nLooking for Sponsorship, inbox me if you are interested in DIVINE DOTA	Welcome to Dota 2 Gameplay live! Have Fun when playing Dota 2. 	dota2gameplaylive	@dota2gameplaylive	1	\N	2025-06-23	f
107	UClxwL5BvlIBT0aSygQV1OBw	https://www.youtube.com/channel/UClxwL5BvlIBT0aSygQV1OBw	Unseen Dota 2 Pro Gameplay	Subscribe or -25 mmr\n\nhi im a dota lover 18 years and counting. please subscribe to support me tq.\n#dota2 #dota2highlights #dotawtf	Subscribe or -25 mmr 	unseendota8645	@unseendota8645	1	\N	2025-06-23	f
110	UC-M63nj_uaArEQyR11DQinA	https://www.youtube.com/channel/UC-M63nj_uaArEQyR11DQinA	Dota 2 Storm Spirit	More about this channel 	More about this channel 	dota2stormspirit214	@dota2stormspirit214	1	\N	2025-06-23	f
111	UCAY7ezW5YwDjJc9HZsphZjg	https://www.youtube.com/channel/UCAY7ezW5YwDjJc9HZsphZjg	Fradoz Dota 2	Hello guys !! I hope you guys happy and love watching my videos. Dont forget to like and leave a comment for any suggestion. Stay home and stay safe everyone. 	Hello guys !! I hope you guys happy and love watching my videos. Dont forget to like and leave a comment for any suggestion. Stay home and stay safe everyone. 	FradozDota2	@FradozDota2	1	\N	2025-06-23	f
112	UCZcEr35xjy8kRtYxwsGksDA	https://www.youtube.com/channel/UCZcEr35xjy8kRtYxwsGksDA	Dota 2 Live	Dota 2 Live\nAll about tournament dota 2 live streaming in Dota Pro Circuit and The International\n	Dota 2 Live 	dota2lives	@dota2lives	1	\N	2025-06-23	f
113	UCq1SlO7vuzA1Rr1UbsVX1Cw	https://www.youtube.com/channel/UCq1SlO7vuzA1Rr1UbsVX1Cw	Dota 2 Mastery	Official YouTube-Channel of Dota2Mastery professional Dota 2 movie maker and ex-professional Dota 2 player.\n\n► Creating Dota 2 Videos with Top songs.\n\n►► Currently searching for new Dota 2 gameplay replays! Send if youre interested!\n\n► For Business Inquiries please contact: dota2masteryy@gmail.com\n\nBusiness inquiries & E-Mail: dota2masteryy@gmail.come\n	Official YouTube-Channel of Dota2Mastery professional Dota 2 movie maker and ex-professional Dota 2 player. 	dota2mastery144	@dota2mastery144	1	\N	2025-06-23	f
114	UCHJL5WGh4KXyWs7zxcb8fRw	https://www.youtube.com/channel/UCHJL5WGh4KXyWs7zxcb8fRw	Dota 2 : Hero Chase	Welcome to Dota 2 : Hero Chase Channel\n--------------------------------------------------------------------------------------------------\n\nJust call me Roy! Im content creator for Dota2 lovers\nHere you can see some highlight of Dota2 gameplay from Pro player or something amazing youre rarely seen in Dota2 that im serving only the best clip of it.\nPlease subscribe, like and share if youre enjoy watching my video.\n\n--------------------------------------------------------------------------------------------------\nInstagram : https://www.instagram.com/dota2herochase/\nMy Instagram : @royhan_aldy\ncatch me up aldykuzut@gmail.com\n	Welcome to Dota 2 : Hero Chase Channel 	dota2herochase	@dota2herochase	1	\N	2025-06-23	f
115	UCLA23mWwgSH8Co3ApS7JGyg	https://www.youtube.com/channel/UCLA23mWwgSH8Co3ApS7JGyg	Dota 2 Rocks	More about this channel 	More about this channel 	dotarocks	@dotarocks	1	\N	2025-06-23	f
116	UCcns7kcCEC2p8CJ3bfYQoog	https://www.youtube.com/channel/UCcns7kcCEC2p8CJ3bfYQoog	Dota 2 How to Safelane	Were building an encyclopedia of resources for Dota 2 safelane matchups and gameplay using specific replay sections from pro safelane player games. Every featured player is a Dota 2 pro playing at the top level (high immortal pubs).\n\nHow to use this channel:\nPick a playlist for the hero youre trying to learn, then play through the videos at the preferred playback speed.\n\nOur partners:\nDota 2 How to Mid: https://www.youtube.com/channel/UC65QddVO1zGnePbcoQKJzXw\nDota 2 How to Offlane: https://www.youtube.com/channel/UC4Vy0bSRfaI2Qlz4id9WS6g\n\n	Were building an encyclopedia of resources for Dota 2 safelane matchups and gameplay using specific replay sections from pro safelane player games. Every featured player is a Dota 2 pro playing at the top level (high immortal pubs). 	dota2howtosafelane892	@dota2howtosafelane892	1	\N	2025-06-23	f
117	UC4Vy0bSRfaI2Qlz4id9WS6g	https://www.youtube.com/channel/UC4Vy0bSRfaI2Qlz4id9WS6g	Dota 2 How to Offlane	Were building an encyclopedia of resources for Dota 2 offlane matchups and gameplay using specific replay sections from pro offlane player games. Every featured player is a Dota 2 pro playing at the top level (high immortal pubs).\n\nHow to use this channel:\nPick a playlist for the hero youre trying to learn, then play through the videos at the preferred playback speed.\n\nOur partners:\nDota 2 How to Safelane: https://www.youtube.com/channel/UCcns7kcCEC2p8CJ3bfYQoog\nDota 2 How to Mid: https://www.youtube.com/channel/UC65QddVO1zGnePbcoQKJzXw\n\n	Were building an encyclopedia of resources for Dota 2 offlane matchups and gameplay using specific replay sections from pro offlane player games. Every featured player is a Dota 2 pro playing at the top level (high immortal pubs). 	dota2howtoofflane585	@dota2howtoofflane585	1	\N	2025-06-23	f
118	UClLLxh4LXkDEeQVd7qJkI4A	https://www.youtube.com/channel/UClLLxh4LXkDEeQVd7qJkI4A	Dota Dice	Welcome to Dota Dice channel. Dota 2 is a multiplayer online battle arena (MOBA) video game produced by IceFrog and Valve Corporation. On Dota Dice channel you can find highlights from the best Dota 2 pro players, some cool compilation, make epic YouTube shots and more.\n\nIf you have cool Dota 2 moment and want to be in some future video, submit your replay here - https://bit.ly/3K7EFQ4\n\nPermission from content owner \nhttps://store.steampowered.com/video_policy\n\nRemember to subscribe and hit the bell to be notified when we publish new videos or highlights!\n\n	Welcome to Dota Dice channel. Dota 2 is a multiplayer online battle arena (MOBA) video game produced by IceFrog and Valve Corporation. On Dota Dice channel you can find highlights from the best Dota 2 pro players, some cool compilation, make epic YouTube shots and more. 	DotaDiceTV	@DotaDiceTV	1	\N	2025-06-23	f
119	UC65QddVO1zGnePbcoQKJzXw	https://www.youtube.com/channel/UC65QddVO1zGnePbcoQKJzXw	Dota 2 How to Mid	Were building an encyclopedia of resources for Dota 2 mid matchups and gameplay using specific replay sections from pro mid player games. Every featured player is a Dota 2 pro playing at the top level (high immortal pubs).\n\nHow to use this channel:\nPick a playlist for the hero youre trying to learn, then play through the videos at the preferred playback speed.\n\nOur partners:\nDota 2 How to Safelane: https://www.youtube.com/channel/UCcns7kcCEC2p8CJ3bfYQoog\nDota 2 How to Offlane: https://www.youtube.com/channel/UC4Vy0bSRfaI2Qlz4id9WS6g\n	Were building an encyclopedia of resources for Dota 2 mid matchups and gameplay using specific replay sections from pro mid player games. Every featured player is a Dota 2 pro playing at the top level (high immortal pubs). 	dota2howtomid244	@dota2howtomid244	1	\N	2025-06-23	f
120	UC0NM4tKT5s9szqnK3jp6dEw	https://www.youtube.com/channel/UC0NM4tKT5s9szqnK3jp6dEw	Dota 2 Rapier	Hi there! Im Minh, the manager of the dota2rapier.com channel. Here you can watch the best Dota matches with commentary of my caster. I need to spend money to hire them to cast the game so hope you can support me by watch the video. \n\nSome great caster that co-op with me to release dota content for free of charge: TeaGuvnor, MrVenzetti, JohnxFire, Fluke \nhttps://www.twitch.tv/teaguvnor\nhttps://www.twitch.tv/johnxfire\nhttps://www.twitch.tv/mrvenzetti\nThank you!\n\nDota 2 Rapier TV channel with daily dota clips\nVisit my website for more information: https://dota2rapier.com/\n\n	Hi there! Im Minh, the manager of the dota2rapier.com channel. Here you can watch the best Dota matches with commentary of my caster. I need to spend money to hire them to cast the game so hope you can support me by watch the video. 	Dota2Rapier	@Dota2Rapier	1	\N	2025-06-23	f
121	UClC3oNbnI-zYTOWuyfmfNpg	https://www.youtube.com/channel/UClC3oNbnI-zYTOWuyfmfNpg	Dota 2 Pills	Hello! Welcome from "Dota 2 Pills" Youtube Channel.We upload the best moments of Dota 2 gamers on twitch and other platforms.We describe the link,the original source of those players, in the description of each video.You can support and watch those players on their original platforms.We upload only best,different and up to date moments of Dota 2.Subscribe for more best clips and videos.Thank you.	Hello! Welcome from "Dota 2 Pills" Youtube Channel.We upload the best moments of Dota 2 gamers on twitch and other platforms.We describe the link,the original source of those players, in the description of each video.You can support and watch those players on their original platforms.We upload only best,different and up to date moments of Dota 2.Subscribe for more best clips and videos.Thank you. 	dota2pills495	@dota2pills495	1	\N	2025-06-23	f
122	UCCMnUQ2whiAs2xZDPFECMuQ	https://www.youtube.com/channel/UCCMnUQ2whiAs2xZDPFECMuQ	DOTA 2 - SCHOOL OF PERSPECTIVE	This channel will be mainly about videos from the DOTA 2 professional players perspective gameplays. There are a lot of players out there who will find these gameplays beneficial for them and thus the existence of this channel. If you want to get better at this game, you need to watch from the pros perspective, learn and copy what they do and then you will improve. Your continuous support to this channel means a lot and ensure the survivability of it.\n\nVideos will be out in the following orders:\nMonday - Pos 1 (Hard Carry/Carry)\nTuesday - Pos 2 (Mid)\nWednesday - Pos 3 (Offlane)\nThursday - Pos 4 (Soft Support/Roam)\nFriday - Pos 5 (Hard Support/Support)\n***Saturday & Sunday - Handpicked pros perspective gameplays in tournaments (any positions)/more pros perspective gameplays (any positions)***\n\nLast but not least, your views and supports really mean a lot! Do subscribe for contents which will make you get better at DOTA 2. Lets keep grinding!	This channel will be mainly about videos from the DOTA 2 professional players perspective gameplays. There are a lot of players out there who will find these gameplays beneficial for them and thus the existence of this channel. If you want to get better at this game, you need to watch from the pros perspective, learn and copy what they do and then you will improve. Your continuous support to this channel means a lot and ensure the survivability of it. 	dota2sop	@dota2sop	1	\N	2025-06-23	f
124	UCbfRmqP0RKbrcYO_3DkC4aw	https://www.youtube.com/channel/UCbfRmqP0RKbrcYO_3DkC4aw	Dota on Demand!	Dota On Demand is Dota 2 Tournament videos on demand (vods) from the top Dota 2 tournaments with spotlight gameplay of pros and their best games. Top including Star Ladder Season 11 & 12, The International 2015, i-League Season 1 & 2, Dota Pit 1 & 3, The Summit 2 & 3,Asia Championship 2015, ESL One Frankfurt 2015, Dota 2 Champions League Season 6 and many more from the 2014 and 2015 Dota 2 season.\n\nThe channel showcases the top Dota 2 teams in the world including: Team Secret, Natus Vincere, Team Tinkerino, Team Malysia, Newbee, Vici Gaming, Evil Geniuses, LGD, Invictus Gaming, Virtus Pro, Team DK, Sneaky Nyx Assassins, Alliance, Kompass Gaming, Invasion eSports, Hell Raisers, ASUS Polar, NoT Today, Leviathan, Ninjas In Pyjamas, Rave Gaming, MVP Phoenix and many more.	Dota On Demand is Dota 2 Tournament videos on demand (vods) from the top Dota 2 tournaments with spotlight gameplay of pros and their best games. Top including Star Ladder Season 11 & 12, The International 2015, i-League Season 1 & 2, Dota Pit 1 & 3, The Summit 2 & 3,Asia Championship 2015, ESL One Frankfurt 2015, Dota 2 Champions League Season 6 and many more from the 2014 and 2015 Dota 2 season. 	dota2pros	@dota2pros	1	\N	2025-06-23	f
125	UCV_VKaOKtp_P-a85nk8OAVw	https://www.youtube.com/channel/UCV_VKaOKtp_P-a85nk8OAVw	DOTA 2 APEX	Welcome to DOTA 2 APEX, your go-to destination for epic Dota 2 highlights! Here, we showcase the most thrilling plays, clutch moments, and jaw-dropping strategies from the world of Dota 2. Be sure to hit subscribe button, like, comment, and share with your friends to stay updated on all the action. Your support helps us keep delivering the best Dota 2 content, so dont miss out!\n\nBe sure to subscribe, like, comment, and share with your friends. Your support is what keeps us going and allows us to keep bringing you the content you enjoy!\n\nPermission from content owner \nhttps://store.steampowered.com/video_policy\n\nMusic provided by \nhttps://www.epidemicsound.com/\n\n50 Subs ----------------------------- 8.7.2022.\n100 Subs --------------------------- 2.8.2022.\n\n	Welcome to DOTA 2 APEX, your go-to destination for epic Dota 2 highlights! Here, we showcase the most thrilling plays, clutch moments, and jaw-dropping strategies from the world of Dota 2. Be sure to hit subscribe button, like, comment, and share with your friends to stay updated on all the action. Your support helps us keep delivering the best Dota 2 content, so dont miss out! 	dota2apex	@dota2apex	1	\N	2025-06-23	f
126	UCPS3VX1sNiPnpPOXb8EBZ-A	https://www.youtube.com/channel/UCPS3VX1sNiPnpPOXb8EBZ-A	AnyaRoblox	Hi guys,welcome to AnyaRoblox channel! And on this channel, youll find thrilling gameplay videos, gaming tutorials, and entertaining commentary. Dive into a world of action, adventure, and strategy as we explore the latest releases and classic favorites. Subscribe now for regular updates and join our gaming community!\n	Hi guys,welcome to AnyaRoblox channel! And on this channel, youll find thrilling gameplay videos, gaming tutorials, and entertaining commentary. Dive into a world of action, adventure, and strategy as we explore the latest releases and classic favorites. Subscribe now for regular updates and join our gaming community! 	AnyaRoblox00	@AnyaRoblox00	1	\N	2025-06-23	f
\.


--
-- Data for Name: channel_games; Type: TABLE DATA; Schema: public; Owner: usergameplay
--

COPY public.channel_games (id_youtube, id_game) FROM stdin;
\.


--
-- Data for Name: channel_historic; Type: TABLE DATA; Schema: public; Owner: usergameplay
--

COPY public.channel_historic (id_youtube, views, subscribers, register_date) FROM stdin;
\.


--
-- Data for Name: channel_images; Type: TABLE DATA; Schema: public; Owner: usergameplay
--

COPY public.channel_images (id_youtube, logo, banner, vanity) FROM stdin;
\.


--
-- Data for Name: events; Type: TABLE DATA; Schema: public; Owner: usergameplay
--

COPY public.events (id_event, name, id_game, date_start, date_end) FROM stdin;
\.


--
-- Data for Name: games; Type: TABLE DATA; Schema: public; Owner: usergameplay
--

COPY public.games (id_game, name, game, ico) FROM stdin;
1	Dota 2	Dota 2	\N
2	Counter-Strike: Global Offensive	CS:GO	\N
3	League of Legends	LOL	\N
\.


--
-- Data for Name: heroes; Type: TABLE DATA; Schema: public; Owner: usergameplay
--

COPY public.heroes (id_hero, name, id_game, description, image) FROM stdin;
\.


--
-- Data for Name: itens; Type: TABLE DATA; Schema: public; Owner: usergameplay
--

COPY public.itens (id_item, name, id_game, description, "VALUE") FROM stdin;
\.


--
-- Data for Name: itens_images; Type: TABLE DATA; Schema: public; Owner: usergameplay
--

COPY public.itens_images (id_item, image) FROM stdin;
\.


--
-- Data for Name: playlist; Type: TABLE DATA; Schema: public; Owner: usergameplay
--

COPY public.playlist (id_playlist, id_youtube, id_game, title, description, register_date) FROM stdin;
PLHTUaf0P2lYLblD2RS5rMTvwRxfzUoUz8	UCDztxdy54wmTB17z9Vh8b3A	1	Puck		2025-06-28
PLHTUaf0P2lYJLQYpmgJt8qtgV1r9sKEIw	UCDztxdy54wmTB17z9Vh8b3A	1	Templar Assassin		2025-06-28
PLHTUaf0P2lYLlQ9ztowR5qkQfDNiP9C65	UCDztxdy54wmTB17z9Vh8b3A	1	Shadow Fiend		2025-06-28
PLHTUaf0P2lYIqm42wz6kgJfWUIsU_lnxO	UCDztxdy54wmTB17z9Vh8b3A	1	Night Stalker		2025-06-28
PLHTUaf0P2lYJoqQNkjxvHInTZuDNMczcx	UCDztxdy54wmTB17z9Vh8b3A	1	Lycan		2025-06-28
PLHTUaf0P2lYKVDLF6fECeHMdZ0z-7Jokv	UCDztxdy54wmTB17z9Vh8b3A	1	Razor		2025-06-28
PLHTUaf0P2lYJro1y8a7ZUK1QQOaWGJlJO	UCDztxdy54wmTB17z9Vh8b3A	1	Tidehunter		2025-06-28
PLHTUaf0P2lYKVEWEjA-ZtZyW4P2NBrRM-	UCDztxdy54wmTB17z9Vh8b3A	1	Kez		2025-06-28
PLHTUaf0P2lYIO7_w4KFlfaF1mtIexMWg8	UCDztxdy54wmTB17z9Vh8b3A	1	Mars		2025-06-28
PLHTUaf0P2lYJz0cn400p6B2TMtIbykPKU	UCDztxdy54wmTB17z9Vh8b3A	1	Arc Warden		2025-06-28
PLHTUaf0P2lYIeiyx20D946jwdrjW97uez	UCDztxdy54wmTB17z9Vh8b3A	1	Bristleback		2025-06-28
PLHTUaf0P2lYLwBCT7dzXiip9rStpYTXYT	UCDztxdy54wmTB17z9Vh8b3A	1	Troll Warlord		2025-06-28
PLHTUaf0P2lYLkMaSH2QVlpRXOUrkDcERp	UCDztxdy54wmTB17z9Vh8b3A	1	Ringmaster		2025-06-28
PLHTUaf0P2lYJVFgwhlATz9c5jLDGHCL3Y	UCDztxdy54wmTB17z9Vh8b3A	1	Sniper		2025-06-28
PLHTUaf0P2lYKBo1n5yrfW7Jm5yYKSmK8i	UCDztxdy54wmTB17z9Vh8b3A	1	Medusa		2025-06-28
PLHTUaf0P2lYLLwCtxSjG7u5KFi_d9lhEv	UCDztxdy54wmTB17z9Vh8b3A	1	Morphling		2025-06-28
PLHTUaf0P2lYLbLKO5wY6RxgXzK1iImZAV	UCDztxdy54wmTB17z9Vh8b3A	1	Sven		2025-06-28
PLHTUaf0P2lYIZi_9ExIrU2tvwAxGuPeI0	UCDztxdy54wmTB17z9Vh8b3A	1	Chaos Knight		2025-06-28
PLHTUaf0P2lYItBWfMB7kFN-Kw99h1M2pE	UCDztxdy54wmTB17z9Vh8b3A	1	Slardar		2025-06-28
PLHTUaf0P2lYKrVtRqNGbqF6mZN5if-b5C	UCDztxdy54wmTB17z9Vh8b3A	1	Death Prophet		2025-06-28
PLHTUaf0P2lYIMTL3BfglzLwtDDo5M3idA	UCDztxdy54wmTB17z9Vh8b3A	1	Sand King		2025-06-28
PLHTUaf0P2lYLu0VXZgSDW2yea_OEzCs4Q	UCDztxdy54wmTB17z9Vh8b3A	1	Tinker		2025-06-28
PLHTUaf0P2lYJfooWN-gAh6lDaGRunriTU	UCDztxdy54wmTB17z9Vh8b3A	1	Puck		2025-06-28
PLHTUaf0P2lYJPcE9XRGRJtHeq9ZUaKCL1	UCDztxdy54wmTB17z9Vh8b3A	1	Kunkka		2025-06-28
PLHTUaf0P2lYITGw35waglWm7aznfOF-aS	UCDztxdy54wmTB17z9Vh8b3A	1	Alchemist		2025-06-28
PLHTUaf0P2lYJ6unlr1iWQE0Cs3vqVBltp	UCDztxdy54wmTB17z9Vh8b3A	1	Anti Mage		2025-06-28
PLHTUaf0P2lYKiomc0m_s_1vHjckZw4Rxw	UCDztxdy54wmTB17z9Vh8b3A	1	Viper		2025-06-28
PLHTUaf0P2lYLkJp3Xod6arxc-Z6brfh4g	UCDztxdy54wmTB17z9Vh8b3A	1	Omniknight		2025-06-28
PLHTUaf0P2lYKLubGGiFoZKfzG_Ff9QrGL	UCDztxdy54wmTB17z9Vh8b3A	1	Huskar		2025-06-28
PLHTUaf0P2lYIbh84vYTnBJFhVTupmjs_u	UCDztxdy54wmTB17z9Vh8b3A	1	Visage		2025-06-28
PLHTUaf0P2lYJmlzelaE2aazGg_lP714g4	UCDztxdy54wmTB17z9Vh8b3A	1	Ember Spirit		2025-06-28
PLHTUaf0P2lYKHONCP1H0D2zEoWVtRiV2Q	UCDztxdy54wmTB17z9Vh8b3A	1	Centaur Warrunner		2025-06-28
PLHTUaf0P2lYIcb92K_blenvAmDXDnwI8e	UCDztxdy54wmTB17z9Vh8b3A	1	Gyrocopter		2025-06-28
PLHTUaf0P2lYKLJbWS8Ci6twyxJ5C8z0Vb	UCDztxdy54wmTB17z9Vh8b3A	1	Ursa		2025-06-28
PLHTUaf0P2lYLHFQkiurKvLP8g4rn_Btju	UCDztxdy54wmTB17z9Vh8b3A	1	Muerta		2025-06-28
PLHTUaf0P2lYJbuMRYpch9poI3eJBts14s	UCDztxdy54wmTB17z9Vh8b3A	1	Brewmaster		2025-06-28
PLHTUaf0P2lYJZN5wMDTBzxGh8uec6UtAH	UCDztxdy54wmTB17z9Vh8b3A	1	Faceless Void		2025-06-28
PLHTUaf0P2lYInb2ksHqBZE9ARk-1mQmQC	UCDztxdy54wmTB17z9Vh8b3A	1	Magnus		2025-06-28
PLHTUaf0P2lYKYGr9BJ1mOBIC0i2XXAA7j	UCDztxdy54wmTB17z9Vh8b3A	1	Invoker		2025-06-28
PLHTUaf0P2lYJH96KvUp3gzNLf6PLLUbbM	UCDztxdy54wmTB17z9Vh8b3A	1	Zeus		2025-06-28
PLHTUaf0P2lYIE_zqZj6QW1h8ulTysnd_m	UCDztxdy54wmTB17z9Vh8b3A	1	Dragon Knight		2025-06-28
PLHTUaf0P2lYKcXjzS5aBQ4eaLTxq16bvT	UCDztxdy54wmTB17z9Vh8b3A	1	Naga Siren		2025-06-28
PLHTUaf0P2lYKue-CVvLwPR30miDFiITnR	UCDztxdy54wmTB17z9Vh8b3A	1	Riki		2025-06-28
PLHTUaf0P2lYJWDo8U19wUQc-DTIG6JZJc	UCDztxdy54wmTB17z9Vh8b3A	1	Dawnbreaker		2025-06-28
PLHTUaf0P2lYI2GPYfLA9YIe37qgPIQxNe	UCDztxdy54wmTB17z9Vh8b3A	1	Slark		2025-06-28
PLHTUaf0P2lYLIzLYp1S9RtEEURA9lL8XO	UCDztxdy54wmTB17z9Vh8b3A	1	Leshrac		2025-06-28
PLHTUaf0P2lYIBcrvjwXZwwQAPw9atAgMf	UCDztxdy54wmTB17z9Vh8b3A	1	EXCLUSIVE		2025-06-28
PLHTUaf0P2lYJmekEWB2KbLGQHR6eEvG1c	UCDztxdy54wmTB17z9Vh8b3A	1	Axe		2025-06-28
PLHTUaf0P2lYLi4my4zW8NBPVvqxdjYCGv	UCDztxdy54wmTB17z9Vh8b3A	1	Warlock		2025-06-28
PLHTUaf0P2lYJxNPd9-00_q_x9GoHZkbLs	UCDztxdy54wmTB17z9Vh8b3A	1	Hoodwink		2025-06-28
PLHTUaf0P2lYJ2HY4xi9qRKlcvNQIlZxeZ	UCDztxdy54wmTB17z9Vh8b3A	1	Dark Willow		2025-06-28
PLHTUaf0P2lYKxGcFKhifu-oAAhXPJBTPe	UCDztxdy54wmTB17z9Vh8b3A	1	Weaver		2025-06-28
PLHTUaf0P2lYJEMmUerK7uuPL2sSszXOez	UCDztxdy54wmTB17z9Vh8b3A	1	Marci		2025-06-28
PLHTUaf0P2lYIxB7eaB6pe8GTTps-XwGzK	UCDztxdy54wmTB17z9Vh8b3A	1	Keeper Of The Light		2025-06-28
PLHTUaf0P2lYKr2E7vcGOL-j10Kbf5ImK4	UCDztxdy54wmTB17z9Vh8b3A	1	Primal Beast		2025-06-28
PLHTUaf0P2lYLlXyLJqFsYlEAA10aP6fXi	UCDztxdy54wmTB17z9Vh8b3A	1	Doom		2025-06-28
PLHTUaf0P2lYKO_DHpy7tHLjyYp3AvoCRx	UCDztxdy54wmTB17z9Vh8b3A	1	Bane		2025-06-28
PLHTUaf0P2lYLGCTbOZHr4QFBZ6WjZRzbr	UCDztxdy54wmTB17z9Vh8b3A	1	Tusk		2025-06-28
PLHTUaf0P2lYIyDPAKVKzjNhRAbK56ezaS	UCDztxdy54wmTB17z9Vh8b3A	1	Dazzle		2025-06-28
PLHTUaf0P2lYJ9SxrSLWQ8v8DDk-VSJ9fU	UCDztxdy54wmTB17z9Vh8b3A	1	Terrorblade		2025-06-28
PLHTUaf0P2lYIqrfxwGsao-LSZuHExHqX-	UCDztxdy54wmTB17z9Vh8b3A	1	Techies		2025-06-28
PLHTUaf0P2lYJgWNcc5_YM44546GhtKFzF	UCDztxdy54wmTB17z9Vh8b3A	1	Nature Prophet		2025-06-28
PLHTUaf0P2lYJYROpidQjWcsd2Zvmpc7p_	UCDztxdy54wmTB17z9Vh8b3A	1	Shadow Demon		2025-06-28
PLHTUaf0P2lYIdensRPhas1RVuVHYiFGS7	UCDztxdy54wmTB17z9Vh8b3A	1	Phoenix		2025-06-28
PLHTUaf0P2lYI_F-B7Rcwb99_IbeWkFJjw	UCDztxdy54wmTB17z9Vh8b3A	1	Jakiro		2025-06-28
PLHTUaf0P2lYKGO5tM5R8m38FVUOpFTo-8	UCDztxdy54wmTB17z9Vh8b3A	1	Shadow Shaman		2025-06-28
PLHTUaf0P2lYIlbCEmgOpCcPTIeEB92_tK	UCDztxdy54wmTB17z9Vh8b3A	1	Pudge		2025-06-28
PLHTUaf0P2lYJRvcePc0hT6usdMUzh7XHH	UCDztxdy54wmTB17z9Vh8b3A	1	Batrider		2025-06-28
PLHTUaf0P2lYJVTf1-LxKiyww5HvRFu3iY	UCDztxdy54wmTB17z9Vh8b3A	1	Windranger		2025-06-28
PLHTUaf0P2lYLNX8Nqy4-T3nHvJG5VcRkx	UCDztxdy54wmTB17z9Vh8b3A	1	Ogre Magi		2025-06-28
PLHTUaf0P2lYIMqvum8GBO0ESaKMy3fjss	UCDztxdy54wmTB17z9Vh8b3A	1	Winter Wyvern		2025-06-28
PLHTUaf0P2lYJ_EpCMqhtK8D_EPW__mHsr	UCDztxdy54wmTB17z9Vh8b3A	1	Silencer		2025-06-28
PLHTUaf0P2lYI-kvn_PEnaGlsK_6rlQp1U	UCDztxdy54wmTB17z9Vh8b3A	1	Lina		2025-06-28
PLHTUaf0P2lYKoQ5OmRF4SFBhtTKsgs83L	UCDztxdy54wmTB17z9Vh8b3A	1	Undying		2025-06-28
PLHTUaf0P2lYJ9uGL20GBQynAcFkSwP_oq	UCDztxdy54wmTB17z9Vh8b3A	1	Enigma		2025-06-28
PLHTUaf0P2lYIe2NizPGJA-S2giacYaMk9	UCDztxdy54wmTB17z9Vh8b3A	1	Enchantress		2025-06-28
PLHTUaf0P2lYKMCkIpvasXVVrnLtisIhv4	UCDztxdy54wmTB17z9Vh8b3A	1	Ancient Apparition		2025-06-28
PLHTUaf0P2lYJjJbJrICnzsyWGFblW4n6i	UCDztxdy54wmTB17z9Vh8b3A	1	Earthshaker		2025-06-28
PLHTUaf0P2lYLjBIJw2j_LwV5J9mi-KjZ6	UCDztxdy54wmTB17z9Vh8b3A	1	Lion		2025-06-28
PLHTUaf0P2lYIDRdq4JqsE6rR14lXE8J5H	UCDztxdy54wmTB17z9Vh8b3A	1	Clinkz		2025-06-28
PLHTUaf0P2lYLrdeRwCkV6mYQEem6UBuvu	UCDztxdy54wmTB17z9Vh8b3A	1	Earth Spirit		2025-06-28
PLHTUaf0P2lYKVDpfBCQTYFJu2qWPa-rTL	UCDztxdy54wmTB17z9Vh8b3A	1	Pugna		2025-06-28
PLHTUaf0P2lYKXNXQKF3gI-y7Tv6u3ARlu	UCDztxdy54wmTB17z9Vh8b3A	1	Rubick		2025-06-28
PLHTUaf0P2lYJ1loG2cr7ZJdbznXxY-N31	UCDztxdy54wmTB17z9Vh8b3A	1	Elder Titan		2025-06-28
PLHTUaf0P2lYLZ5sKwdYs6yIYbbfKD69AK	UCDztxdy54wmTB17z9Vh8b3A	1	Monkey King		2025-06-28
PLHTUaf0P2lYJ_zo81Q6sfLhLIWHsHcaFG	UCDztxdy54wmTB17z9Vh8b3A	1	Grimstroke		2025-06-28
PLHTUaf0P2lYKzz7QDL6Wkt2B7FaDcUfpl	UCDztxdy54wmTB17z9Vh8b3A	1	Nyx Assassin		2025-06-28
PLHTUaf0P2lYJEr_PkF3RN2PJiEIEPyYuK	UCDztxdy54wmTB17z9Vh8b3A	1	Tiny		2025-06-28
PLHTUaf0P2lYLxFP-SbTrfXrXMmVQrsdkc	UCDztxdy54wmTB17z9Vh8b3A	1	Clockwerk		2025-06-28
PLHTUaf0P2lYKFhjA7Zy7LQqdnon1koDqQ	UCDztxdy54wmTB17z9Vh8b3A	1	Io		2025-06-28
PLHTUaf0P2lYI9xR9MM4KBV6cfoH60ZzBq	UCDztxdy54wmTB17z9Vh8b3A	1	Snapfire		2025-06-28
PLHTUaf0P2lYL-fIN9A5UVXwKsXxWKuVjQ	UCDztxdy54wmTB17z9Vh8b3A	1	Crystal Maiden		2025-06-28
PLHTUaf0P2lYImTjZxQsod0yhGa69QyEt_	UCDztxdy54wmTB17z9Vh8b3A	1	Mirana		2025-06-28
PLHTUaf0P2lYLiXOKn7u4k6J9MYroheU7n	UCDztxdy54wmTB17z9Vh8b3A	1	Witch Doctor		2025-06-28
PLHTUaf0P2lYJ4-YWop3_kPBgtmdHvrcQQ	UCDztxdy54wmTB17z9Vh8b3A	1	Disruptor		2025-06-28
PLHTUaf0P2lYKtOApc3F7UP9jKb94i_H8z	UCDztxdy54wmTB17z9Vh8b3A	1	Chen		2025-06-28
PLHTUaf0P2lYKUc6eP6nQtaB2X8n8uiaA9	UCDztxdy54wmTB17z9Vh8b3A	1	Venomancer		2025-06-28
PLHTUaf0P2lYJ18PqBuaojbyUdtUXldrzq	UCDztxdy54wmTB17z9Vh8b3A	1	Oracle		2025-06-28
PLHTUaf0P2lYLvrRuVBLw93PJv-ZTrvWYL	UCDztxdy54wmTB17z9Vh8b3A	1	Spirit Breaker		2025-06-28
PLHTUaf0P2lYLkRAiPhS7EyVDaAt0sP92w	UCDztxdy54wmTB17z9Vh8b3A	1	Lich		2025-06-28
PLHTUaf0P2lYJysWdIcWDYyzsJODu6CVFt	UCDztxdy54wmTB17z9Vh8b3A	1	Treant Protector		2025-06-28
PLHTUaf0P2lYJvICBZaOPFJ_QtcIDaoBLC	UCDztxdy54wmTB17z9Vh8b3A	1	Bounty Hunter		2025-06-28
PLHTUaf0P2lYJs49_E11hmOAKU-YSAV1WS	UCDztxdy54wmTB17z9Vh8b3A	1	Abaddon		2025-06-28
PLHTUaf0P2lYIJV_M0gPcpJwwzAKqZ_O3c	UCDztxdy54wmTB17z9Vh8b3A	1	Queen Of Pain		2025-06-28
PLHTUaf0P2lYKUgq2g1RdRIVCrTK--sRu_	UCDztxdy54wmTB17z9Vh8b3A	1	Silencer		2025-06-28
PLHTUaf0P2lYJ1pptrZ1jEQIQM8n0BAGHB	UCDztxdy54wmTB17z9Vh8b3A	1	Vengeful Spirit		2025-06-28
PLHTUaf0P2lYJVkjF4G9BSI0jJFn3ipMud	UCDztxdy54wmTB17z9Vh8b3A	1	Skywrath Mage		2025-06-28
PLTeNOoyLCmVU7XGNtZYOb7w7saTJSxIdN	UCK2t7qm88e6ZsKS3Pbg-C3Q	1	Legion Commander		2025-06-28
PLTeNOoyLCmVVqOJbTH4To2GqZlZLNFsOm	UCK2t7qm88e6ZsKS3Pbg-C3Q	1	Pure		2025-06-28
PLTeNOoyLCmVVSKrV_JgpdaFFqCJarRFOL	UCK2t7qm88e6ZsKS3Pbg-C3Q	1	Lifestealer		2025-06-28
PLTeNOoyLCmVUj_ul4fd33KrFyAR4JO3xO	UCK2t7qm88e6ZsKS3Pbg-C3Q	1	Medusa		2025-06-28
PLTeNOoyLCmVU8nbV1r8WsZTqQYgRXTMwo	UCK2t7qm88e6ZsKS3Pbg-C3Q	1	Nightfall		2025-06-28
PLTeNOoyLCmVUBDRjMMdqWznBt645bZV5-	UCK2t7qm88e6ZsKS3Pbg-C3Q	1	Abaddon		2025-06-28
PLTeNOoyLCmVUUZYDf4CAxcCSz-pQTuZli	UCK2t7qm88e6ZsKS3Pbg-C3Q	1	Satanic		2025-06-28
PLTeNOoyLCmVXiSxX1r27niHnu4SdCZp5Q	UCK2t7qm88e6ZsKS3Pbg-C3Q	1	Troll Warlord		2025-06-28
PLTeNOoyLCmVWXVRYZiuA_TZZrPFaaB8NX	UCK2t7qm88e6ZsKS3Pbg-C3Q	1	Night Stalker		2025-06-28
PLTeNOoyLCmVXPnwUM8tZc4dJgBL5Ssg98	UCK2t7qm88e6ZsKS3Pbg-C3Q	1	Slark		2025-06-28
PLTeNOoyLCmVUrPTA-H_zLeC02uwonKlm-	UCK2t7qm88e6ZsKS3Pbg-C3Q	1	Snapfire		2025-06-28
PLTeNOoyLCmVWQWIWjEnmSdV3Ad2dZv41Z	UCK2t7qm88e6ZsKS3Pbg-C3Q	1	Marci		2025-06-28
PLTeNOoyLCmVVEIH66PqUX1WVSzLqxywCm	UCK2t7qm88e6ZsKS3Pbg-C3Q	1	Drow Ranger		2025-06-28
PLTeNOoyLCmVWPs9CwiFof6vSaRYPULGkz	UCK2t7qm88e6ZsKS3Pbg-C3Q	1	Razor		2025-06-28
PLTeNOoyLCmVXjIW7GPJTUxhvrKQIj711_	UCK2t7qm88e6ZsKS3Pbg-C3Q	1	Tinker		2025-06-28
PLTeNOoyLCmVUy2dD_vLhNvZhTeFb9f8_t	UCK2t7qm88e6ZsKS3Pbg-C3Q	1	Pudge		2025-06-28
PLTeNOoyLCmVXjZVJyEM-4cy8D2ckZJntV	UCK2t7qm88e6ZsKS3Pbg-C3Q	1	Crystal Maiden		2025-06-28
PLTeNOoyLCmVX7yjo8BS57EDGZSIIDF6Yq	UCK2t7qm88e6ZsKS3Pbg-C3Q	1	Venomancer		2025-06-28
PLTeNOoyLCmVXiKFHUDrfbe7AUIJ5hCEiC	UCK2t7qm88e6ZsKS3Pbg-C3Q	1	Lion		2025-06-28
PLTeNOoyLCmVUjbc9LUZC5pXcbKIe4Z8do	UCK2t7qm88e6ZsKS3Pbg-C3Q	1	Bristleback		2025-06-28
PLTeNOoyLCmVVFVotfOqU1m3L7NOas5fcV	UCK2t7qm88e6ZsKS3Pbg-C3Q	1	Witch Doctor		2025-06-28
PLTeNOoyLCmVW5vPXJ906kRC9MPOJdPcxK	UCK2t7qm88e6ZsKS3Pbg-C3Q	1	Kunkka		2025-06-28
PLTeNOoyLCmVU5VQjCQOOLKJtjh30h-TuF	UCK2t7qm88e6ZsKS3Pbg-C3Q	1	Sven		2025-06-28
PLTeNOoyLCmVWv6hZwKHioa_WePKipn5MG	UCK2t7qm88e6ZsKS3Pbg-C3Q	1	Templar Assassin		2025-06-28
PLTeNOoyLCmVVxdnuLq4gKzdI3Rni143FM	UCK2t7qm88e6ZsKS3Pbg-C3Q	1	Sniper		2025-06-28
PLTeNOoyLCmVVXf_4VuSWQTpVmEcbguWCY	UCK2t7qm88e6ZsKS3Pbg-C3Q	1	Nature Prophet		2025-06-28
PLTeNOoyLCmVUnBzqaqYozE-tV9X26hlgc	UCK2t7qm88e6ZsKS3Pbg-C3Q	1	Morphling		2025-06-28
PLTeNOoyLCmVVaoNPh41ExWmq_7OZua9oq	UCK2t7qm88e6ZsKS3Pbg-C3Q	1	Ame		2025-06-28
PLTeNOoyLCmVVyqAU2rfhnsUuqmnO07vcJ	UCK2t7qm88e6ZsKS3Pbg-C3Q	1	Wraith King		2025-06-28
PLTeNOoyLCmVW_uzCbFGsox8RL3pHH8ODC	UCK2t7qm88e6ZsKS3Pbg-C3Q	1	Yatoro\\Raddan		2025-06-28
PLTeNOoyLCmVUkw1eZ2_9jbYBPZen2rYxY	UCK2t7qm88e6ZsKS3Pbg-C3Q	1	Yuragi		2025-06-28
PLTeNOoyLCmVX9fCsDZifEm-ywEo4nsxAw	UCK2t7qm88e6ZsKS3Pbg-C3Q	1	Phantom Assassin		2025-06-28
PLTeNOoyLCmVVsEh2J4pttQSbWHpb1gefb	UCK2t7qm88e6ZsKS3Pbg-C3Q	1	Dawnbreake		2025-06-28
PL_VZG27b_Lzxj8472PP1sVVoRNN5klMRe	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Marci Dota 2 Matches		2025-06-28
PL_VZG27b_LzwIgnWCVWQ4vkx4Hb7XySfl	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Dawnbreaker Dota 2 Matches		2025-06-28
PL_VZG27b_LzzWsXRL-qPHDU1JR5QmDJmn	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Spectre Dota 2 Matches		2025-06-28
PL_VZG27b_LzzCTnEP60e-vB6SUzcp-c1f	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Mars Dota 2 Matches		2025-06-28
PL_VZG27b_Lzyu_y5jTnh1ZzIPDuxNfkHS	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Snapfire Dota 2 Matches		2025-06-28
PL_VZG27b_LzyEwN8Gb2rKi2xfhTwuMUmo	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Dark Willow Dota 2 Matches		2025-06-28
PL_VZG27b_Lzx0eNvNF98j5eJGdih0gbtN	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Monkey King Dota 2 Matches		2025-06-28
PL_VZG27b_LzzKxvLMmHu0zRDJWBaJTFZd	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Oracle Dota 2 Matches		2025-06-28
PL_VZG27b_Lzx_7jsfUscITUTi7Xb0MQYo	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Phoenix Dota 2 Matches		2025-06-28
PL_VZG27b_LzzQMnzz-3fwPqXk5uvqdEj-	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Earth Spirit Dota 2 Matches		2025-06-28
PL_VZG27b_Lzx66SFO1GgxAMuUsf7J_7Ue	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Ember Spirit Dota 2 Matches		2025-06-28
PL_VZG27b_LzzMBUtlr8tAMZC7whDAMizp	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Legion Commander Dota 2 Matches		2025-06-28
PL_VZG27b_LzzDGUppumNqkYvtTjnyE3C_	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Bristleback Dota 2 Matches		2025-06-28
PL_VZG27b_Lzw2TgJq946owlG9k_tj0H8_	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Magnus Dota 2 Matches		2025-06-28
PL_VZG27b_LzxW-DAuzw_BUM8UWhNTPzmi	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Centaur Warrunner Dota 2 Matches		2025-06-28
PL_VZG27b_Lzz3EcVRkc4saYwQ4Yi5FEKO	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Terrorblade Dota 2 Matches		2025-06-28
PL_VZG27b_Lzydlox1-6sVdTdk4FwVTIMn	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Underlord Dota 2 Matches		2025-06-28
PL_VZG27b_Lzyqr4XE45pvspIBBoNZpLWj	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Techies Dota 2 Matches		2025-06-28
PL_VZG27b_Lzyw2A2W1QOpYmilYWvnHCEq	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Elder Titan Dota 2 Matches		2025-06-28
PL_VZG27b_LzwTRR6chxXDaJ6wXhbnFXLb	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Abaddon Dota 2 Matches		2025-06-28
PL_VZG27b_LzwfnkB7akUsNyYZ5Ee0WA3b	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Skywrath Mage Dota 2 Matches		2025-06-28
PL_VZG27b_LzxzIPxlcu-OCXHnttkoIgSo	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Winter Wyvern Dota 2 Matches		2025-06-28
PL_VZG27b_Lzw89bMAYtaVZW5wJys4cT8j	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Arc Warden Dota 2 Matches		2025-06-28
PL_VZG27b_LzwDgojFOs0-nV3IqA7cp-su	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Troll Warlord Dota 2 Matches		2025-06-28
PL_VZG27b_LzwyEto8OZl8dEEZEdIEw4sH	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Medusa Dota 2 Matches		2025-06-28
PL_VZG27b_LzyOjVEaEOFySh9t5G4j3WFX	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Slark Dota 2 Matches		2025-06-28
PL_VZG27b_LzyV-pS11uerIKYDe-vE6S3K	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Visage Dota 2 Matches		2025-06-28
PL_VZG27b_LzyTCbFdDGZWGAufMnss7Lg3	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Naga Siren Dota 2 Matches		2025-06-28
PL_VZG27b_Lzwrl1SJukqsFw-Cc4VsCz5O	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Nyx Assassin Dota 2 Matches		2025-06-28
PL_VZG27b_LzyeweNCAfe6tEgvYUtmdA72	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Disruptor Dota 2 Matches		2025-06-28
PL_VZG27b_Lzx8NfzjnSGNySAWbzKFk9nO	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Rubick Dota 2 Matches		2025-06-28
PL_VZG27b_Lzxhxqxio4_ElaqhL-ifR2UH	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Undying Dota 2 Matches		2025-06-28
PL_VZG27b_LzwpfGB7VjP884o8yoM6qGbP	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Ogre Magi Dota 2 Matches		2025-06-28
PL_VZG27b_Lzzm0Yf7q3KOPn6ECKH75Zrq	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Treant Protector Dota 2 Matches		2025-06-28
PL_VZG27b_Lzx0jCbefA6ZuTerfRnPnqZT	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Meepo Dota 2 Matches		2025-06-28
PL_VZG27b_LzwTfSCuTEUvnRX_cvEp413T	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Chaos Knight Dota 2 Matches		2025-06-28
PL_VZG27b_LzySFPAAX2TqO_913UyEbE_G	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Lone Druid Dota 2 Matches		2025-06-28
PL_VZG27b_LzzgHH7oWUq1uyyHlF3nt2BI	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Shadow Demon Dota 2 Matches		2025-06-28
PL_VZG27b_Lzx4NG67jUzuzTtzRFpqeT7M	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Brewmaster Dota 2 Matches		2025-06-28
PL_VZG27b_LzyZ9XXveMES2bJmi7zX5uHZ	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Lycan Dota 2 Matches		2025-06-28
PL_VZG27b_Lzy1-tw7ryZ3gAW_ENaUUNCz	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Outworld Destroyer Dota 2 Matches		2025-06-28
PL_VZG27b_LzyKy0-Rigg-9Sq7fMhkv9YJ	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Silencer Dota 2 Matches		2025-06-28
PL_VZG27b_LzxmTc1cBH7R9Jtq-pfm3Hwx	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Invoker Dota 2 Matches		2025-06-28
PL_VZG27b_Lzw5-io4a2ly6QfFjVTsOKAl	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Alchemist Dota 2 Matches		2025-06-28
PL_VZG27b_LzzFFBOwDdeksXtsYgT_3sMK	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Gyrocopter Dota 2 Matches		2025-06-28
PL_VZG27b_LzyYyMkXCCo41-hHYZInuhl7	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Spirit Breaker Dota 2 Matches		2025-06-28
PL_VZG27b_LzyM47st0r3ZKHoIPJ4Y7lu3	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Ursa Dota 2 Matches		2025-06-28
PL_VZG27b_LzxXTD-_GtnUwRPSAH4RMeZN	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Doom Dota 2 Matches		2025-06-28
PL_VZG27b_Lzy83vy42np0BHlSNa8_iMBn	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Ancient Apparition Dota 2 Matches		2025-06-28
PL_VZG27b_LzxOnT-66DuxjTm-resMlGOa	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Chen Dota 2 Matches		2025-06-28
PL_VZG27b_LzzmpBXozzxMZ-0rVAu2Kscw	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Batrider Dota 2 Matches		2025-06-28
PL_VZG27b_Lzy3iLy_8nPOxt-xHUbW-8h7	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Jakiro Dota 2 Matches		2025-06-28
PL_VZG27b_LzyR6qkNZh-y3k9KpH4z8gdV	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Weaver Dota 2 Matches		2025-06-28
PL_VZG27b_LzzMv2LuqMA24l6-51T8PPSg	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Bounty Hunter Dota 2 Matches		2025-06-28
PL_VZG27b_LzwEpcfwn7oZCAxMP4CgIneH	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Broodmother Dota 2 Matches		2025-06-28
PL_VZG27b_Lzwp9tsBXZNx26qA3tF2pRc8	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Huskar Dota 2 Matches		2025-06-28
PL_VZG27b_LzxGPnJdo0QHs7sghz8EJj31	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Enchantress Dota 2 Matches		2025-06-28
PL_VZG27b_LzzE6toSj-tsSGIcda9vjRAB	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Omniknight Dota 2 Matches		2025-06-28
PL_VZG27b_LzzPu7IXrLxxVLZbUKQmC_T_	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Clinkz Dota 2 Matches		2025-06-28
PL_VZG27b_Lzz5jAb5uObUUg6HaSpMhi1N	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Dark Seer Dota 2 Matches		2025-06-28
PL_VZG27b_LzwmocWsfphCddF2ueDk_-Ln	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Lifestealer Dota 2 Matches		2025-06-28
PL_VZG27b_LzzVRMS-SXMVsel0mQ7GpJ97	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Leshrac Dota 2 Matches		2025-06-28
PL_VZG27b_LzwzNnMSe1441a_hE7HIBaIF	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Clockwerk Dota 2 Matches		2025-06-28
PL_VZG27b_LzysfLkZxLVxjKuFvO-57kip	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Dazzle Dota 2 Matches		2025-06-28
PL_VZG27b_LzzPfuLZqmKAFNkDisrkCAUf	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Dragon Knight Dota 2 Matches		2025-06-28
PL_VZG27b_Lzxf-x46JKJ_L_T-8idm7xc7	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Viper Dota 2 Matches		2025-06-28
PL_VZG27b_LzwgdIDduhDWbX7sgDD6bl4o	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Pugna Dota 2 Matches		2025-06-28
PL_VZG27b_Lzzd4UOINzgBpltm8noNUhXh	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Faceless Void Dota 2 Matches		2025-06-28
PL_VZG27b_LzzeXjNLZYHevkaQrgbpkM2f	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Venomancer Dota 2 Matches		2025-06-28
PL_VZG27b_LzyCfJaVfLwivSDYvJxCPYYI	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Beastmaster Dota 2 Matches		2025-06-28
PL_VZG27b_LzwtoPrrBaasNE9ZjAWepiMj	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Warlock Dota 2 Matches		2025-06-28
PL_VZG27b_LzyXgk-nE9amq80lNzKhIYa0	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Necrophos Dota 2 Matches		2025-06-28
PL_VZG27b_LzzhXga1oWsQz-1TumC57IJp	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Sniper Dota 2 Matches		2025-06-28
PL_VZG27b_LzzabR5oJB0D2iDxyEHrPis6	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Tinker Dota 2 Matches		2025-06-28
PL_VZG27b_Lzy0FBdH4q9NK6Bc6kY_EwQV	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Luna Dota 2 Matches		2025-06-28
PL_VZG27b_LzyZXaHSWIkfFIlKLSQvWPCi	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Timbersaw Dota 2 Matches		2025-06-28
PL_VZG27b_LzyO_KYIdjWAfu01V7dSP5ie	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Keeper of the Light Dota 2 Matches		2025-06-28
PL_VZG27b_Lzxr2j1MKyQfIdXRSnOP1B_K	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Queen of Pain Dota 2 Matches		2025-06-28
PL_VZG27b_LzzqO8RVfMJ4MGoGdOrj9Ja6	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Wraith King Dota 2 Matches		2025-06-28
PL_VZG27b_LzwcIfUAdnZY9eQ8fp0kKWiD	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Hoodwink Dota 2 Matches		2025-06-28
PL_VZG27b_LzwldofIFkwwpUQj8dMuOiel	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Night Stalker Dota 2 Matches		2025-06-28
PL_VZG27b_LzwIRxd92WZzE598974Q0hcD	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Templar Assassin Dota 2 Matches		2025-06-28
PL_VZG27b_LzxklHQ7sLjNdeFdFqJqyHfL	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Io Dota 2 Matches		2025-06-28
PL_VZG27b_LzxI6R1yLsBE0cBV7sD621wN	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Death Prophet Dota 2 Matches		2025-06-28
PL_VZG27b_LzxOfcAlMi9k5JopikzQ2r7H	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Phantom Assassin Dota 2 Matches		2025-06-28
PL_VZG27b_LzyT2bZEjERFBSWjmhhdNjrQ	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Void Spirit Dota 2 Matches		2025-06-28
PL_VZG27b_LzzpQqqlXi3iJ5DAHM7iAQu-	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Grimstroke Dota 2 Matches		2025-06-28
PL_VZG27b_LzzXdbn9uXEhO5pqGm2cVukp	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Tusk Dota 2 Matches		2025-06-28
PL_VZG27b_LzyoxsyIl7aAXfDXr1wBvXyO	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Enigma Dota 2 Matches		2025-06-28
PL_VZG27b_Lzx9sIb_1Js9CJyWZ-dHtliS	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Pangolier Dota 2 Matches		2025-06-28
PL_VZG27b_LzwWv93sajbjqjUHTtrvyehG	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Riki Dota 2 Matches		2025-06-28
PL_VZG27b_LzwqW7app9MAKZm_mkMbpENe	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Lich Dota 2 Matches		2025-06-28
PL_VZG27b_LzzRahN93jKzcTBOfvuBXBiB	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Witch Doctor Dota 2 Matches		2025-06-28
PL_VZG27b_LzxKTJuLU0tfBYccUoc61v8v	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Tidehunter Dota 2 Matches		2025-06-28
PL_VZG27b_Lzwq8bJ8XZ9vJPs8-V6xfZcQ	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Slardar Dota 2 Matches		2025-06-28
PL_VZG27b_Lzxtn8SGPS4DdMD4IEZ3omWl	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Shadow Shaman Dota 2 Matches		2025-06-28
PL_VZG27b_LzzWUs7WeKZbBBKT8B5oza2k	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Lion Dota 2 Matches		2025-06-28
PL_VZG27b_Lzwns_quzmnrPjAViC8J9ToZ	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Lina Dota 2 Matches		2025-06-28
PL_VZG27b_LzzjA-DrAv9nhihhDbNXvH1Y	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Kunkka Dota 2 Matches		2025-06-28
PL_VZG27b_LzwahOcCXdbr9Netocl7aqbI	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Zeus Dota 2 Matches		2025-06-28
PL_VZG27b_LzxL2h__gHKMaowpdqhYVEoO	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Windranger Dota 2 Matches		2025-06-28
PL_VZG27b_LzwcFb1A8UMyk4mxGQ9ljm_x	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Vengeful Spirit Dota 2 Matches		2025-06-28
PL_VZG27b_Lzy8WxnLuDyuan1WlN8PNEeV	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Tiny Dota 2 Matches		2025-06-28
PL_VZG27b_LzxP0iOsm1z_uDPYm3vkMyJV	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Sven Dota 2 Matches		2025-06-28
PL_VZG27b_LzybZ8SvkynN_IGkwda7zE5p	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Storm Spirit Dota 2 Matches		2025-06-28
PL_VZG27b_LzwPQu3ETKqK_1R5bwnshpUz	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Sand King Dota 2 Matches		2025-06-28
PL_VZG27b_LzztASyOP_HzyrFUUi-gVw2N	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Razor Dota 2 Matches		2025-06-28
PL_VZG27b_LzwVfPZAtsdGS67vY2D96TQ_	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Pudge Dota 2 Matches		2025-06-28
PL_VZG27b_LzywrCN35jQ20hDPuZHX5fbp	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Puck Dota 2 Matches		2025-06-28
PL_VZG27b_Lzx1Ibxi9sJC002xaOlGo3aG	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Phantom Lancer Dota 2 Matches		2025-06-28
PL_VZG27b_Lzw6qzXpbN19rVFqBQPQm1AH	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Shadow Fiend Dota 2 Matches		2025-06-28
PL_VZG27b_LzyOwL9AVBDiOsweSIb2wPlC	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Morphling Dota 2 Matches		2025-06-28
PL_VZG27b_LzzUe__baU-qaj5rYaBSddIi	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Mirana Dota 2 Matches		2025-06-28
PL_VZG27b_LzyE2yazjnAUlcmBYmkdgJee	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Juggernaut Dota 2 Matches		2025-06-28
PL_VZG27b_LzxzDNsv6oA3kxs2R1O96GpE	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Earthshaker Dota 2 Matches		2025-06-28
PL_VZG27b_LzwVk5az816NrYUdA-SbKoeY	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Drow Ranger Dota 2 Matches		2025-06-28
PL_VZG27b_LzwXTBj1iaUTc-YwEFuwU7oH	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Crystal Maiden Dota 2 Matches		2025-06-28
PL_VZG27b_LzxQFAMFtaHE_FcXprQEKIBA	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Bloodseeker Dota 2 Matches		2025-06-28
PL_VZG27b_LzwUqvUstDL8bteal2Xq8Eun	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Bane Dota 2 Matches		2025-06-28
PL_VZG27b_LzwGv5X3Nv2yKFUQWyv98wqA	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Axe Dota 2 Matches		2025-06-28
PL_VZG27b_LzxmEaSW906jKgZA8-MLOZA0	UCznPSdnBofe1ONMO0m2GSQQ	1	Pro Anti-Mage Dota 2 Matches		2025-06-28
PLTeNOoyLCmVUqJZ0BYMr8SdkszJypAHcJ	UCK2t7qm88e6ZsKS3Pbg-C3Q	1	Otaker		2025-06-28
PLTeNOoyLCmVWnW8lhXhu937uI9ccfNLnv	UCK2t7qm88e6ZsKS3Pbg-C3Q	1	Phantom Lancer		2025-06-28
PLTeNOoyLCmVVOO-5xQL3YLXiFRl0SE3Do	UCK2t7qm88e6ZsKS3Pbg-C3Q	1	Bounty Hunter		2025-06-28
PLTeNOoyLCmVV8XwWn9Yh0KLbE7YR0qcvz	UCK2t7qm88e6ZsKS3Pbg-C3Q	1	LL!!!		2025-06-28
PLTeNOoyLCmVUqODM0xi9kIlwbwy5nsb2s	UCK2t7qm88e6ZsKS3Pbg-C3Q	1	Pangolier		2025-06-28
PLTeNOoyLCmVVWybK-ZBgSZA-77cJwtdVO	UCK2t7qm88e6ZsKS3Pbg-C3Q	1	Rubick		2025-06-28
PLTeNOoyLCmVWYqgV1whO4lPLxuAke-VLX	UCK2t7qm88e6ZsKS3Pbg-C3Q	1	Faceless Void		2025-06-28
PLTeNOoyLCmVVPiJ1QeCZjvJQjU2SUHztN	UCK2t7qm88e6ZsKS3Pbg-C3Q	1	Shadow Fiend		2025-06-28
PLTeNOoyLCmVUD2z0eT1fZQmQ-2F_JKbYb	UCK2t7qm88e6ZsKS3Pbg-C3Q	1	Magnus		2025-06-28
PLTeNOoyLCmVXt5-Qg3fa0Su_vlTZ95yO2	UCK2t7qm88e6ZsKS3Pbg-C3Q	1	Beastmaster		2025-06-28
PLTeNOoyLCmVWRBH6g7o6LRkoecMhLBZLM	UCK2t7qm88e6ZsKS3Pbg-C3Q	1	TA2000		2025-06-28
PLTeNOoyLCmVUanB5-jnR-XBu2GjeXXbUZ	UCK2t7qm88e6ZsKS3Pbg-C3Q	1	Juggernaut		2025-06-28
PLTeNOoyLCmVX3Mfyh3IT0_mgffNp-t2_7	UCK2t7qm88e6ZsKS3Pbg-C3Q	1	Ogre Magi		2025-06-28
PLTeNOoyLCmVW5hzvhHrdIKpd_pKcyDWI8	UCK2t7qm88e6ZsKS3Pbg-C3Q	1	Sand King		2025-06-28
PLTeNOoyLCmVUtdh0GQi8kSmkUBzfopMd4	UCK2t7qm88e6ZsKS3Pbg-C3Q	1	Dazzle		2025-06-28
PLTeNOoyLCmVVIC7mCL9L7EVZt66YGtMS7	UCK2t7qm88e6ZsKS3Pbg-C3Q	1	Huskar		2025-06-28
PLTeNOoyLCmVVZuD78fXSBap8-tp_-8LjJ	UCK2t7qm88e6ZsKS3Pbg-C3Q	1	Anti-Mage		2025-06-28
PLTeNOoyLCmVX_48vrneyReGXlNvo5cb3D	UCK2t7qm88e6ZsKS3Pbg-C3Q	1	Spirit Breaker		2025-06-28
PLTeNOoyLCmVWmfmh6eY6huLfecXFpJZCj	UCK2t7qm88e6ZsKS3Pbg-C3Q	1	Dancing Dragon		2025-06-28
PLTeNOoyLCmVWJLl_xwKMTEJoLZet02TrT	UCK2t7qm88e6ZsKS3Pbg-C3Q	1	Hoodwink		2025-06-28
PLTeNOoyLCmVVb7Aoz41RHhqvH2u9RXXM4	UCK2t7qm88e6ZsKS3Pbg-C3Q	1	Axe		2025-06-28
PLTeNOoyLCmVWrWH06Z4zc12jmKF_Zh1W3	UCK2t7qm88e6ZsKS3Pbg-C3Q	1	Crayon		2025-06-28
PLTeNOoyLCmVXEPMrgv8JwhfjHZTkAXEGG	UCK2t7qm88e6ZsKS3Pbg-C3Q	1	Invoker		2025-06-28
PLTeNOoyLCmVXbnEqOUi5ImPezHSU9i2zZ	UCK2t7qm88e6ZsKS3Pbg-C3Q	1	Sumiya		2025-06-28
PLhm-DtnIjs6s6rq7cJ2tPO9cJtc7rMOdm	UCW2Ew5V3I2z1jXvsZEkKtUQ	1	Mogul Khan, the Axe		2025-06-28
PLhm-DtnIjs6vZqu9vb3cj1fqt5Aw598Y1	UCW2Ew5V3I2z1jXvsZEkKtUQ	1	Lyralei, the Windranger		2025-06-28
PLhm-DtnIjs6tjGauyvvVZp1u3R7WbyIPn	UCW2Ew5V3I2z1jXvsZEkKtUQ	1	Inai, the Void Spirit		2025-06-28
PLhm-DtnIjs6tzKBbw_f9_aY500nCfODpr	UCW2Ew5V3I2z1jXvsZEkKtUQ	1	Barathrum, the Spirit Breaker		2025-06-28
PLhm-DtnIjs6tdCUakR0eP5rQ9rjSoY31Y	UCW2Ew5V3I2z1jXvsZEkKtUQ	1	Pudge, the Butcher		2025-06-28
PLhm-DtnIjs6tmkoYV5uwoxvzY74L58V_I	UCW2Ew5V3I2z1jXvsZEkKtUQ	1	Nyx Assassin		2025-06-28
PLKJ2kg9FdH3qSCklZPssHDBph0bCSdQQ7	UCHZ7buu1amKXgpqCVsox1aA	1	Dota 7.39		2025-06-28
PLKJ2kg9FdH3qWLGZQlDkQb_faGGkSoHvG	UCHZ7buu1amKXgpqCVsox1aA	1	Dota 7.38		2025-06-28
PLKJ2kg9FdH3rGupSX1mMJR7_fS4HV0TEh	UCHZ7buu1amKXgpqCVsox1aA	1	Kez Dota 2		2025-06-28
PLKJ2kg9FdH3qG7hRPMLIzn962IXiWiRDO	UCHZ7buu1amKXgpqCVsox1aA	1	Dota 2 7.37		2025-06-28
PLKJ2kg9FdH3pbUAqsIYvww7lYSl9mgvSm	UCHZ7buu1amKXgpqCVsox1aA	1	Witch Doctor Dota Gameplay		2025-06-28
PLKJ2kg9FdH3qqFdjQ4-Szyhkan_DBV8im	UCHZ7buu1amKXgpqCVsox1aA	1	Phoenix Dota Gameplay		2025-06-28
PLKJ2kg9FdH3oRhECPRb4iXmItjP7SxJob	UCHZ7buu1amKXgpqCVsox1aA	1	Dota Lycan Gameplay		2025-06-28
PLKJ2kg9FdH3oCeBVhrIwME8-QWwh-qP2Q	UCHZ7buu1amKXgpqCVsox1aA	1	Dota Sand King Gameplay		2025-06-28
PLKJ2kg9FdH3reKuLkEV6MxcCs1r0LNgpn	UCHZ7buu1amKXgpqCVsox1aA	1	Dota 2 7.36		2025-06-28
PLKJ2kg9FdH3pDHecstJfGAJo4sFATWmBq	UCHZ7buu1amKXgpqCVsox1aA	1	Dota Dragon Knight Gameplay		2025-06-28
PLKJ2kg9FdH3oDFEwZkdXMXS9bLgb-P-fj	UCHZ7buu1amKXgpqCVsox1aA	1	Dota Wraith King Gameplay		2025-06-28
PLKJ2kg9FdH3oHt7qRbf9ucNPnFDUY8lCi	UCHZ7buu1amKXgpqCVsox1aA	1	Dota Weaver Gameplay		2025-06-28
PLKJ2kg9FdH3pKjGE6rnufKvseIdH9eX3V	UCHZ7buu1amKXgpqCVsox1aA	1	Dota Ember Spirit Gameplay		2025-06-28
PLKJ2kg9FdH3qWAwCfu1OloBPlDwmilwRA	UCHZ7buu1amKXgpqCVsox1aA	1	Dota Ursa Gameplay		2025-06-28
PLKJ2kg9FdH3q4HK1dFktA0Rp8pEcMS9MH	UCHZ7buu1amKXgpqCVsox1aA	1	Dota Queen of Pain Gameplay		2025-06-28
PLKJ2kg9FdH3otVWcb7_laRHUK4SrKDVFH	UCHZ7buu1amKXgpqCVsox1aA	1	Dota Naga Siren Gameplay		2025-06-28
PLKJ2kg9FdH3qD1gEGCoZj8i6mEwbtCJFQ	UCHZ7buu1amKXgpqCVsox1aA	1	Dota Marci Gameplay		2025-06-28
PLKJ2kg9FdH3olkv0TDh0MAE-WXamt1jEg	UCHZ7buu1amKXgpqCVsox1aA	1	Dota Lifestealer Gameplay		2025-06-28
PLKJ2kg9FdH3on5n3VnKutWfG0_1Vv3snF	UCHZ7buu1amKXgpqCVsox1aA	1	Dota Centaur Gameplay		2025-06-28
PLKJ2kg9FdH3qvFGxoQerjkVdHmNqnvkar	UCHZ7buu1amKXgpqCVsox1aA	1	Dota Bounty Hunter Gameplay		2025-06-28
PLKJ2kg9FdH3rV5s4zUgFPea8a2C9D4C5x	UCHZ7buu1amKXgpqCVsox1aA	1	Dota Arc Warden Gameplay		2025-06-28
PLKJ2kg9FdH3qCi5fqxakQxJAFoZS25tQc	UCHZ7buu1amKXgpqCVsox1aA	1	Dota Phantom Lancer Gameplay		2025-06-28
PLKJ2kg9FdH3rk_0gXmKqJ1AE66BNGdtPo	UCHZ7buu1amKXgpqCVsox1aA	1	Dota Legion Commander Gameplay		2025-06-28
PLKJ2kg9FdH3oVHLVH4jw_Cz3JVmLSeBhK	UCHZ7buu1amKXgpqCVsox1aA	1	Dota Omniknight Gameplay		2025-06-28
PLKJ2kg9FdH3rusDNbUHWEM0faqgWuLlY6	UCHZ7buu1amKXgpqCVsox1aA	1	Dota Abaddon Gameplay		2025-06-28
PLKJ2kg9FdH3qJZQs6ebJvn5GQ6GPkHqfV	UCHZ7buu1amKXgpqCVsox1aA	1	Dota Snapfire Gameplay		2025-06-28
PLKJ2kg9FdH3or-vFFL9I-7sczNkN6M3EP	UCHZ7buu1amKXgpqCVsox1aA	1	Dota Riki Gameplay		2025-06-28
PLKJ2kg9FdH3pOUQMz-Z1-2qMCH_VQkT4h	UCHZ7buu1amKXgpqCVsox1aA	1	Dota Storm Spirit Gameplay		2025-06-28
PLKJ2kg9FdH3pbtPcOJEJFh0XIvgkrgnx-	UCHZ7buu1amKXgpqCVsox1aA	1	Dota Sniper Gameplay		2025-06-28
PLKJ2kg9FdH3pnwWQqLMTRDylW-MYWrGnF	UCHZ7buu1amKXgpqCVsox1aA	1	Dota Dazzle Gameplay		2025-06-28
PLKJ2kg9FdH3ocCGXWzCg2ru8e6XLAbvXw	UCHZ7buu1amKXgpqCVsox1aA	1	Dota Lina Gameplay		2025-06-28
PLKJ2kg9FdH3rfemyHO18Kr0Gpwu7Kx5l6	UCHZ7buu1amKXgpqCVsox1aA	1	Dota Meepo Gameplay		2025-06-28
PLKJ2kg9FdH3qIlzr4rRZa-1uw69aY7ILe	UCHZ7buu1amKXgpqCVsox1aA	1	Dota Medusa Gameplay		2025-06-28
PLKJ2kg9FdH3rSCsr7Sxx85WqY8RG_nhuQ	UCHZ7buu1amKXgpqCVsox1aA	1	Dota Anti-Mage Gameplay		2025-06-28
PLKJ2kg9FdH3okNlRoyYeXIhASJuSkofNp	UCHZ7buu1amKXgpqCVsox1aA	1	Dota Huskar Gameplay		2025-06-28
PLKJ2kg9FdH3rW4xrvj8RPgzDIDwPhchLx	UCHZ7buu1amKXgpqCVsox1aA	1	Dota Elder Titan Gameplay		2025-06-28
PLKJ2kg9FdH3q_vDui1KMV1hju24HS4V6J	UCHZ7buu1amKXgpqCVsox1aA	1	Dota Phantom Assassin Gameplay		2025-06-28
PLKJ2kg9FdH3p6Ax5wQdHlmEA25bVcElEM	UCHZ7buu1amKXgpqCVsox1aA	1	Dota Morphling Gameplay		2025-06-28
PLKJ2kg9FdH3plfpCNzydtZy_AhxA84yXj	UCHZ7buu1amKXgpqCVsox1aA	1	Dota Slark Gameplay		2025-06-28
PLKJ2kg9FdH3q2KyhqxQ-qvb-TJKXOz06q	UCHZ7buu1amKXgpqCVsox1aA	1	Dota Hoodwink Gameplay		2025-06-28
PLKJ2kg9FdH3oGNDOuA0mR-0TluD6QVQ1x	UCHZ7buu1amKXgpqCVsox1aA	1	Dota Luna Gameplay		2025-06-28
PLKJ2kg9FdH3pQxGgBJt7JWIsGcJa35Sej	UCHZ7buu1amKXgpqCVsox1aA	1	Dota Monkey King Gameplay		2025-06-28
PLKJ2kg9FdH3qDPUvpWZ0epVONZc_3dmx6	UCHZ7buu1amKXgpqCVsox1aA	1	Dota Alchemist Gameplay		2025-06-28
PLKJ2kg9FdH3oW3GNfmlukT36OiEeXJIDc	UCHZ7buu1amKXgpqCVsox1aA	1	Dota Troll Gameplay		2025-06-28
PLKJ2kg9FdH3rOTrKa3w2hPFI3okXbNWbU	UCHZ7buu1amKXgpqCVsox1aA	1	Dota Faceless Void Gameplay		2025-06-28
PLKJ2kg9FdH3rj-LTH8jKUbtkbufCy-v6N	UCHZ7buu1amKXgpqCVsox1aA	1	Dota Spirit Breaker Gameplay		2025-06-28
PLKJ2kg9FdH3rafLucaVFWeL-hvYXFAaAn	UCHZ7buu1amKXgpqCVsox1aA	1	Dota Templar Assassin Gameplay		2025-06-28
PLKJ2kg9FdH3q1l56Hcknjlo6r0jYUdUY-	UCHZ7buu1amKXgpqCVsox1aA	1	Dota Drow Ranger Gameplay		2025-06-28
PLKJ2kg9FdH3obVAUmfqPMX-ROQpBiJWGR	UCHZ7buu1amKXgpqCVsox1aA	1	Dota Spectre Gameplay		2025-06-28
PLKJ2kg9FdH3oWjVcTrv2ZNip6mcRy6J6r	UCHZ7buu1amKXgpqCVsox1aA	1	Dota Windranger Gameplay		2025-06-28
PLKJ2kg9FdH3ormSWOefs6-icu-pj1B5qT	UCHZ7buu1amKXgpqCVsox1aA	1	Dota Invoker Gameplay		2025-06-28
PLKJ2kg9FdH3rlwubXOzBVms5OhHMc1bRS	UCHZ7buu1amKXgpqCVsox1aA	1	Dota Puck Gameplay		2025-06-28
PLKJ2kg9FdH3oKGLbgbRKsHhpUn88zSZSj	UCHZ7buu1amKXgpqCVsox1aA	1	Dota Clinkz Gameplay		2025-06-28
PLKJ2kg9FdH3pssvyoO5a2fIKNRYOsEM_6	UCHZ7buu1amKXgpqCVsox1aA	1	Dota Tinker Gameplay		2025-06-28
PLKJ2kg9FdH3oCBnl-1hJqkcxjD2C_-9Am	UCHZ7buu1amKXgpqCVsox1aA	1	Dota Juggernaut Gameplay		2025-06-28
PLKJ2kg9FdH3qG2yD4KCI-L7TKyG6Eq7ZM	UCHZ7buu1amKXgpqCVsox1aA	1	Dota Shadow Fiend Gameplay		2025-06-28
PLKJ2kg9FdH3pyHWXL6WokspE8il4Im5jk	UCHZ7buu1amKXgpqCVsox1aA	1	Dota Pudge Gameplay		2025-06-28
PLKJ2kg9FdH3p_alf2oebRfBQYtexSZBWH	UCHZ7buu1amKXgpqCVsox1aA	1	Tidehunter Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3rxDQ6N3k-onYSIAGvcbJBg	UCHZ7buu1amKXgpqCVsox1aA	1	DOTA 2 7.35		2025-06-28
PLKJ2kg9FdH3oF8KGF6x3toBJIW3K6jvx1	UCHZ7buu1amKXgpqCVsox1aA	1	Io Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3oXfavRkKXLcUp8SAQhkB9h	UCHZ7buu1amKXgpqCVsox1aA	1	Ringmaster Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3rAYhDiLmDcF99rQA4TGU8b	UCHZ7buu1amKXgpqCVsox1aA	1	Silencer Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3qyzTPGqGNjJcjHJ0xxUCyQ	UCHZ7buu1amKXgpqCVsox1aA	1	Pugna Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3otBireUUzG5gcWRS1ewwVY	UCHZ7buu1amKXgpqCVsox1aA	1	DOTA 2 7.34		2025-06-28
PLKJ2kg9FdH3rid7eWvb9PkjVWmQ5Q9bHF	UCHZ7buu1amKXgpqCVsox1aA	1	Winter Wyvern Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3plKSt2uEMmkRM9_CVkbn0z	UCHZ7buu1amKXgpqCVsox1aA	1	Lycan Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3paqeQ-sjVzF_t2KxXqsqeD	UCHZ7buu1amKXgpqCVsox1aA	1	DOTA 2 GAMEPLAY 2023		2025-06-28
PLKJ2kg9FdH3rjuGCNa26vINMznNF93B1e	UCHZ7buu1amKXgpqCVsox1aA	1	23savage Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3q0ioZl_jTGMrKUVEja01ka	UCHZ7buu1amKXgpqCVsox1aA	1	Micke Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3oz3p5ThuR2THmjmJlcPKt4	UCHZ7buu1amKXgpqCVsox1aA	1	Magnus Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3pMoYYOzdCmSsgaNCGLtrEp	UCHZ7buu1amKXgpqCVsox1aA	1	Keeper of the Light Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3riRTkfH_n_vUPLLKIo_iab	UCHZ7buu1amKXgpqCVsox1aA	1	Ogre Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3p5D4FkybereKogvlnQ1SMF	UCHZ7buu1amKXgpqCVsox1aA	1	Necrophos Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3rbA0Ah9c8AjZZBUE9l7aUO	UCHZ7buu1amKXgpqCVsox1aA	1	Nyx Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3oTHzqpTDuMTT21a7uvtpkU	UCHZ7buu1amKXgpqCVsox1aA	1	Nightstalker Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3p_bi0DoyjU4oup5HxLJNhy	UCHZ7buu1amKXgpqCVsox1aA	1	Dota 2 Gameplay Pure		2025-06-28
PLKJ2kg9FdH3rH9-SXRK6MdcEi79rG_22A	UCHZ7buu1amKXgpqCVsox1aA	1	Oracle Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3pWZt1EgxEe3hoMd7mjNV17	UCHZ7buu1amKXgpqCVsox1aA	1	Skywrath Mage Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3qge6yRKTxxeSOkNX-I7ilQ	UCHZ7buu1amKXgpqCVsox1aA	1	Dota 2 Gameplay Raven		2025-06-28
PLKJ2kg9FdH3pY5erLmBjB6kx9CjbmH82-	UCHZ7buu1amKXgpqCVsox1aA	1	Dota 2 Gameplay Nisha		2025-06-28
PLKJ2kg9FdH3qknHvTzE_3ta_q-aKgpQUr	UCHZ7buu1amKXgpqCVsox1aA	1	Medusa Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3r83OwXIOdC99sea6eED87-	UCHZ7buu1amKXgpqCVsox1aA	1	Phantom Lancer Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3pOahWsrM11zIoVCTh3qRKR	UCHZ7buu1amKXgpqCVsox1aA	1	Dota 2 Gameplay Ceb		2025-06-28
PLKJ2kg9FdH3oCgXn7ZKD_komxMdYyiX1j	UCHZ7buu1amKXgpqCVsox1aA	1	Noone Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3pi0NuUNdPeOw3WtChMxOaQ	UCHZ7buu1amKXgpqCVsox1aA	1	Dota 2 Gameplay ATF		2025-06-28
PLKJ2kg9FdH3oFdsZeNU6J0YCZn2VQj05G	UCHZ7buu1amKXgpqCVsox1aA	1	Wraith King Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3plxFEyBFfs2bqPbFljlu6J	UCHZ7buu1amKXgpqCVsox1aA	1	Viper Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3oMVVJ2jSFL47XQhbGAGmm1	UCHZ7buu1amKXgpqCVsox1aA	1	Muerta Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3odctFfOLETPIgyOkjp9K9g	UCHZ7buu1amKXgpqCVsox1aA	1	Lion Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3rIyHUEvCOZ5GKvfkpXJIsH	UCHZ7buu1amKXgpqCVsox1aA	1	Puck Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3qLJXhBJRWx_YElYmAK23H0	UCHZ7buu1amKXgpqCVsox1aA	1	Razor Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3r7z2gWqHinoEw0O4mrkXvF	UCHZ7buu1amKXgpqCVsox1aA	1	Outworld Destroyer Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3pPT1vdgtGmx-UGMSKWreDf	UCHZ7buu1amKXgpqCVsox1aA	1	Windranger Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3ppnZmo_iGxCh9imTE-KxDt	UCHZ7buu1amKXgpqCVsox1aA	1	Queen of Pain Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3rhmaluc8hc08-q8OHE8aoU	UCHZ7buu1amKXgpqCVsox1aA	1	Templar Assassin Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3pGFRCVmJTHn-fu4rPpRoef	UCHZ7buu1amKXgpqCVsox1aA	1	Pangolier Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3q-iQ4cSOT3aYekm6Qe1k6N	UCHZ7buu1amKXgpqCVsox1aA	1	Storm Spirit Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3r9LIL42Lxin_uhndsQd7mF	UCHZ7buu1amKXgpqCVsox1aA	1	Mars Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3qn6ZCAWGVEujProjrx90XG	UCHZ7buu1amKXgpqCVsox1aA	1	Ursa Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3rewwyHHokeY53On6pJcbIt	UCHZ7buu1amKXgpqCVsox1aA	1	Spirit Breaker Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3oP01TRdE-6IdRyyMsmf0jH	UCHZ7buu1amKXgpqCVsox1aA	1	Tusk Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3pjVWGv5Rr_3wVVgXs8sGlO	UCHZ7buu1amKXgpqCVsox1aA	1	Lina Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3qVZrt2n5YNTZFNSf181lWX	UCHZ7buu1amKXgpqCVsox1aA	1	Void Spirit Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3oNuU43dlHqP2_KDLUdKw9t	UCHZ7buu1amKXgpqCVsox1aA	1	Weaver Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3rkhpzmAmMMJLezqX90cNfj	UCHZ7buu1amKXgpqCVsox1aA	1	Leshrac Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3pUec4dW0emwhCXRraHn2H4	UCHZ7buu1amKXgpqCVsox1aA	1	Zeus Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3pSzyNX43CKePTzUE6Ildyq	UCHZ7buu1amKXgpqCVsox1aA	1	Terrorblade Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3qc2STvq2L7ODMi5NE9kmcr	UCHZ7buu1amKXgpqCVsox1aA	1	Tiny Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3p7paarjdzR1Qr3-xcPp2ea	UCHZ7buu1amKXgpqCVsox1aA	1	Techies Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3oudtCsJ_-6P2ZKDdwOPaAk	UCHZ7buu1amKXgpqCVsox1aA	1	Dota 2 Gameplay Nine		2025-06-28
PLKJ2kg9FdH3qBVsXOl1bKvEUIonfyMkwB	UCHZ7buu1amKXgpqCVsox1aA	1	Dota 2 Gameplay Skiter		2025-06-28
PLKJ2kg9FdH3pmmnrhXD8zmxVEP_tWRmb8	UCHZ7buu1amKXgpqCVsox1aA	1	Kunkka Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3rtpoKY-DMp_cpEHdl75hEv	UCHZ7buu1amKXgpqCVsox1aA	1	Dota 2 Gameplay Pakazs		2025-06-28
PLKJ2kg9FdH3rqJ9nanLUw_HD-yTpzD7Vj	UCHZ7buu1amKXgpqCVsox1aA	1	Primal Beast Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3r9LO2zVw05y5KupXgkJreQ	UCHZ7buu1amKXgpqCVsox1aA	1	Dota 2 Gameplay Crystallis		2025-06-28
PLKJ2kg9FdH3pkvZ_hBP6pwoz9M2ZqZisH	UCHZ7buu1amKXgpqCVsox1aA	1	Dota 2 Gameplay Rubick		2025-06-28
PLKJ2kg9FdH3ojigsbBTmhQRNbp9-HJ8f3	UCHZ7buu1amKXgpqCVsox1aA	1	Troll Warlord Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3oHnTJIJG16a5SFyQ4_lcjU	UCHZ7buu1amKXgpqCVsox1aA	1	Mirana Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3qfuy6-YBXbMdUodaR8SxXL	UCHZ7buu1amKXgpqCVsox1aA	1	Dota 2 Gameplay Marci		2025-06-28
PLKJ2kg9FdH3qRnfyWyF5TlSqvcmQdqLgL	UCHZ7buu1amKXgpqCVsox1aA	1	Dota 2 Gameplay Morphling		2025-06-28
PLKJ2kg9FdH3ri3fnHpkDJOQztdPjqc2A-	UCHZ7buu1amKXgpqCVsox1aA	1	Dota 2 Gameplay Slardar		2025-06-28
PLKJ2kg9FdH3pIM5-YRilPy2VZkediKLdj	UCHZ7buu1amKXgpqCVsox1aA	1	Dota 2 Gameplay Abed		2025-06-28
PLKJ2kg9FdH3q6FBRGjwcko9hsvRzH2VVx	UCHZ7buu1amKXgpqCVsox1aA	1	Dota 2 Gameplay Sven		2025-06-28
PLKJ2kg9FdH3osx4wCITGdhdqFWcpMe7PM	UCHZ7buu1amKXgpqCVsox1aA	1	Dota 2 Gameplay Luna		2025-06-28
PLKJ2kg9FdH3oL-loKuaXk4JYVqod7PasK	UCHZ7buu1amKXgpqCVsox1aA	1	Dota 2 Gameplay Huskar		2025-06-28
PLKJ2kg9FdH3paw3ifQ9Qc0TLHqVlD7mdA	UCHZ7buu1amKXgpqCVsox1aA	1	Slardar Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3pkMKPOyEg66Aoy6wUsw6GS	UCHZ7buu1amKXgpqCVsox1aA	1	Dota 2 Gameplay Monkey King		2025-06-28
PLKJ2kg9FdH3qeDtGr5bqQrTsW13VQnoyK	UCHZ7buu1amKXgpqCVsox1aA	1	Dota 2 Gameplay Ame		2025-06-28
PLKJ2kg9FdH3rLG9GQzSTbUFmq2_H7ESxF	UCHZ7buu1amKXgpqCVsox1aA	1	Dota 2 Gameplay Yuragi		2025-06-28
PLKJ2kg9FdH3oH0CRA_O992Vf4BVQajJzf	UCHZ7buu1amKXgpqCVsox1aA	1	Dota 2 Gameplay Ame		2025-06-28
PLKJ2kg9FdH3p3SPciyBcOsLjL4FaL-Fmx	UCHZ7buu1amKXgpqCVsox1aA	1	Dota 2 Gameplay BZM		2025-06-28
PLKJ2kg9FdH3pGZLTyQ5N3thzoia28xLCR	UCHZ7buu1amKXgpqCVsox1aA	1	Dota 2 Gameplay Arteezy		2025-06-28
PLKJ2kg9FdH3qmgsEQ_lIccooCb-d4bQ2s	UCHZ7buu1amKXgpqCVsox1aA	1	Dota 2 Gameplay Topson		2025-06-28
PLKJ2kg9FdH3p13Pr0t047GiP24SSJbDO0	UCHZ7buu1amKXgpqCVsox1aA	1	Dota 2 Gameplay Sumail		2025-06-28
PLKJ2kg9FdH3pPFin0jV5qWdQR_2os4mfC	UCHZ7buu1amKXgpqCVsox1aA	1	Dota 2 Gameplay Yatoro		2025-06-28
PLKJ2kg9FdH3rSxBmjqm0RIxODYiZWM5WV	UCHZ7buu1amKXgpqCVsox1aA	1	Dota 2 Gameplay Miracle		2025-06-28
PLKJ2kg9FdH3qU5glSjVLvVtX88VIoTUri	UCHZ7buu1amKXgpqCVsox1aA	1	Dota 2 Gameplay Ana		2025-06-28
PLKJ2kg9FdH3p5_oKPp5XwNdMZh_kdjGC2	UCHZ7buu1amKXgpqCVsox1aA	1	Tinker Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3pHovqGTG4bg00RWS0FvSKY	UCHZ7buu1amKXgpqCVsox1aA	1	Spectre Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3rh4uj3N6_2oIpcGl65-uj7	UCHZ7buu1amKXgpqCVsox1aA	1	Sniper Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3pVrp8CbjxSlhEeVm26eROO	UCHZ7buu1amKXgpqCVsox1aA	1	Slark Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3obBYVzYQCiM4ShoMX3Gtd-	UCHZ7buu1amKXgpqCVsox1aA	1	Shadow Fiend Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3pxHaPweBJrTAGxFKf6Q-Xz	UCHZ7buu1amKXgpqCVsox1aA	1	Riki Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3ol3IkMZpDpYZvV9gI3Jz0m	UCHZ7buu1amKXgpqCVsox1aA	1	Pudge Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3p-RVUyfABgQTadPZEbwkJ9	UCHZ7buu1amKXgpqCVsox1aA	1	Phantom Assassin Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3p6WkDkaoDWya_iMyy1pAOy	UCHZ7buu1amKXgpqCVsox1aA	1	Meepo Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3pTFLNlfM3z4yj5xZrn89u0	UCHZ7buu1amKXgpqCVsox1aA	1	Legion Commander Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3qGdW6ZU6vo7flK-cFSOAEw	UCHZ7buu1amKXgpqCVsox1aA	1	Juggernaut Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3qlhUzZFbhfanDLMEwiI-qE	UCHZ7buu1amKXgpqCVsox1aA	1	Invoker Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3p0sVXp--hyek5FrPFZ59eJ	UCHZ7buu1amKXgpqCVsox1aA	1	Hoodwink Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3rvs4jjOaFRzKjOa97N6qbp	UCHZ7buu1amKXgpqCVsox1aA	1	Gyrocopter Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3qaxJdV4FJAeFxP1IFnLMER	UCHZ7buu1amKXgpqCVsox1aA	1	Grimstroke Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3qAf5gLkjs_HPe_itXg8MWi	UCHZ7buu1amKXgpqCVsox1aA	1	Faceless Void Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3pQ3h4Z60ex1Ve_wmwAx_We	UCHZ7buu1amKXgpqCVsox1aA	1	Enigma Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3r6gYrh6CaqvzL0DvWSUiRD	UCHZ7buu1amKXgpqCVsox1aA	1	Enchantress Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3pP5hr9ieOTnISDZIPfefvj	UCHZ7buu1amKXgpqCVsox1aA	1	Ember Spirit Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3owpoVixPjBCL7e-zsB5REU	UCHZ7buu1amKXgpqCVsox1aA	1	Elder Titan Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3om2b0MfbTszP3Z-Tiuttq2	UCHZ7buu1amKXgpqCVsox1aA	1	Earthshaker Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3pfTcUGyLIiOuEIcZVkoGdW	UCHZ7buu1amKXgpqCVsox1aA	1	Earth Spirit Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3piuSaYN_hh2BSY7cD9ibZx	UCHZ7buu1amKXgpqCVsox1aA	1	Drow Ranger Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3p_j_5nrEZLtaX36knrsjAa	UCHZ7buu1amKXgpqCVsox1aA	1	Dragon Knight Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3rDsnS6J3CYImMmWfiTzpCU	UCHZ7buu1amKXgpqCVsox1aA	1	Doom Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3rDNkB5cNUdm47g8ZzGtJrv	UCHZ7buu1amKXgpqCVsox1aA	1	Disruptor Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3rEC_8RsuQGPzQr-tBqNQQy	UCHZ7buu1amKXgpqCVsox1aA	1	Death Prophet Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3pSmkBRu3rmyI0ebJGM5DbW	UCHZ7buu1amKXgpqCVsox1aA	1	Dawnbreaker Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3rIGl2IoNy90piU8J5kPOdc	UCHZ7buu1amKXgpqCVsox1aA	1	Dark Willow Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3qt6NqBcqI6GBXS93i4yBv2	UCHZ7buu1amKXgpqCVsox1aA	1	Dark Seer Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3q8AZVidHgCd4MK6noaFRM8	UCHZ7buu1amKXgpqCVsox1aA	1	Crystal Maiden Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3oMjr-AXFkmOKnviANY4QjH	UCHZ7buu1amKXgpqCVsox1aA	1	Clockwerk Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3occgKlIeepIw9pYOqOE7vn	UCHZ7buu1amKXgpqCVsox1aA	1	Clinkz Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3rUNeUrJ9qyd1lJVOTRUIaz	UCHZ7buu1amKXgpqCVsox1aA	1	Chaos Knight Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3rP5jNDX75mfiJ7Y00OhZWL	UCHZ7buu1amKXgpqCVsox1aA	1	Centaur Warrunner Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3qR-5HjGof38AOfbpIga4cM	UCHZ7buu1amKXgpqCVsox1aA	1	Broodmother Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3pbqG8dwTj6jagAqF8wOZYQ	UCHZ7buu1amKXgpqCVsox1aA	1	Bristleback Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3rpfV--UqsspzfmdSW6Mzcq	UCHZ7buu1amKXgpqCVsox1aA	1	Brewmaster Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3rnf9YmyL9dtCak8sfAj2Hg	UCHZ7buu1amKXgpqCVsox1aA	1	Bounty Hunter Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3pKEIBkGILfHjgbP6mYjJ68	UCHZ7buu1amKXgpqCVsox1aA	1	Bloodseeker Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3psBI5fHDOKXWKidLhbwQOs	UCHZ7buu1amKXgpqCVsox1aA	1	Beastmaster Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3p8FXwdiHSpt-8PIRlfChxo	UCHZ7buu1amKXgpqCVsox1aA	1	Batrider Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3qyNW9GF-lKdbpuM0a2W7Cp	UCHZ7buu1amKXgpqCVsox1aA	1	Bane Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3qstYwN0BQy6O6FvZb3N1fl	UCHZ7buu1amKXgpqCVsox1aA	1	Axe Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3pUBEL-jJjXJgnBaAT8ifbx	UCHZ7buu1amKXgpqCVsox1aA	1	Arc Warden Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3ojrefnNHTnDQEvv_4T-Py8	UCHZ7buu1amKXgpqCVsox1aA	1	Ancient Apparition Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3rhXd3R_9NS52shpZPJ-dom	UCHZ7buu1amKXgpqCVsox1aA	1	Anti-Mage Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3oeDrNujcrOb-sOYILVtpIk	UCHZ7buu1amKXgpqCVsox1aA	1	Alchemist Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3rhGDAqaQaNAkGO3RZ0fJCU	UCHZ7buu1amKXgpqCVsox1aA	1	Abaddon Dota 2 Gameplay		2025-06-28
PLKJ2kg9FdH3qjuEuoAd3ClRMPUlPt6m9s	UCHZ7buu1amKXgpqCVsox1aA	1	DOTA 2 PRO GAMEPLAY		2025-06-28
PLKJ2kg9FdH3pYrJm56eIUReyKk9HRN2rQ	UCHZ7buu1amKXgpqCVsox1aA	1	KARDEL LIVE		2025-06-28
PLKJ2kg9FdH3phLwco-4BAl0HLXkntKEnG	UCHZ7buu1amKXgpqCVsox1aA	1	MUSIC		2025-06-28
PLKJ2kg9FdH3rPQesQ1nep6sE-PvkuYEnR	UCHZ7buu1amKXgpqCVsox1aA	1	DOTA 2 GAMEPLAY		2025-06-28
PLKJ2kg9FdH3r-h-MPfL80vvieXUfUdBFU	UCHZ7buu1amKXgpqCVsox1aA	1	Execration VS Mineski | ESL One Genting Finals		2025-06-28
PLKJ2kg9FdH3o4W7o2jNU9jTMO1wOyTTTZ	UCHZ7buu1amKXgpqCVsox1aA	1	SingSing | Full Game		2025-06-28
PLKJ2kg9FdH3rwMVWE26VwlXBWXP5_pHlU	UCHZ7buu1amKXgpqCVsox1aA	1	Execration VS Rave | ESL One Genting Full Game		2025-06-28
PLKJ2kg9FdH3q3y367iQ-NsIOLvgm9qKiV	UCHZ7buu1amKXgpqCVsox1aA	1	Execration VS Next Gen Vietnam | ESL One Genting Full Game		2025-06-28
PLKJ2kg9FdH3oD3FXR23rrXjYON8MM1zhR	UCHZ7buu1amKXgpqCVsox1aA	1	MVP Phoenix VS Team EVOS | ESL One Genting Highlights		2025-06-28
PLKJ2kg9FdH3pMbEIhPhMHG_joaOF97j-K	UCHZ7buu1amKXgpqCVsox1aA	1	MVP Phoenix VS Team EVOS | ESL One Genting Full Game		2025-06-28
PLKJ2kg9FdH3qBz1xhexWP_6dmk2DMfdsg	UCHZ7buu1amKXgpqCVsox1aA	1	Team NP VS Wings Gaming | Northern Arena Beat Invitational Grand Finals		2025-06-28
PLKJ2kg9FdH3qNDgtiHRC2UbEoFCFlN_Q3	UCHZ7buu1amKXgpqCVsox1aA	1	Team NP VS EHOME | Northern Arena Beat International		2025-06-28
PLKJ2kg9FdH3qmAahu3-859XWUa8JAh61a	UCHZ7buu1amKXgpqCVsox1aA	1	Wings Gaming VS EHOME | Northern Arena Beat Invitational		2025-06-28
PLKJ2kg9FdH3pUduuPkJyLUaEmPFHdcKCD	UCHZ7buu1amKXgpqCVsox1aA	1	EG VS EHOME | Northern Arena Beat Invitational		2025-06-28
PLKJ2kg9FdH3rbY4TRfabhE5xdxl9j9740	UCHZ7buu1amKXgpqCVsox1aA	1	EG VS Alliance | Northern Arena Beat Invitational		2025-06-28
PLKJ2kg9FdH3q7-8XlHdIfbS5Xmf1YZDd4	UCHZ7buu1amKXgpqCVsox1aA	1	EHOME VS Complexity Gaming | Northern Arena Beat Invitational		2025-06-28
PLKJ2kg9FdH3qRv5SFruWDFISFqyyfwF3i	UCHZ7buu1amKXgpqCVsox1aA	1	Wings Gaming VS FDL | Northern Arena Beat Invitational		2025-06-28
PLKJ2kg9FdH3rym_OhfTX_nfb0T2-5aqfz	UCHZ7buu1amKXgpqCVsox1aA	1	Team NP VS Ad Finem | Northern Arena Beat Invitational		2025-06-28
PLKJ2kg9FdH3rduO9psvXjVmwdrGEINs3S	UCHZ7buu1amKXgpqCVsox1aA	1	Northern Arena Beat Invitational		2025-06-28
PLKJ2kg9FdH3rjVzXQU4IPkIXtHWmSkTTA	UCHZ7buu1amKXgpqCVsox1aA	1	Faceless VS MVP | Dota Pit League SEA Finals		2025-06-28
PLKJ2kg9FdH3rvBc2l0FIUDh10DPPvewr5	UCHZ7buu1amKXgpqCVsox1aA	1	Mineski VS MVP | Dota Pit League Season 5		2025-06-28
PLKJ2kg9FdH3ql1VFAaBNOP0xUhlBTIsm2	UCHZ7buu1amKXgpqCVsox1aA	1	Team Liquid VS Escape Gaming | Elimination Mode 2.0		2025-06-28
PLKJ2kg9FdH3obVUgperaABT0aYV8WASZJ	UCHZ7buu1amKXgpqCVsox1aA	1	OG Dota2 VS Fantastic Five | ESL One Genting		2025-06-28
PLKJ2kg9FdH3od22R_H-SJlRHrO71VLx-G	UCHZ7buu1amKXgpqCVsox1aA	1	Team Liquid VS Ad Finem Highlights | ESL One Genting		2025-06-28
PLKJ2kg9FdH3qqti6kPMCVk33wW-mSHUh1	UCHZ7buu1amKXgpqCVsox1aA	1	Team Liquid VS Ad Finem | ESL One Genting		2025-06-28
PLKJ2kg9FdH3r1wshFcVhXby3VVdb4QJcN	UCHZ7buu1amKXgpqCVsox1aA	1	Team Liquid VS The Imperial | Asus Dreamleague Season 6		2025-06-28
PLKJ2kg9FdH3rrkVts0TB-gUlVmtNCRFrg	UCHZ7buu1amKXgpqCVsox1aA	1	EG VS Team NP | Elimination Mode 2.0		2025-06-28
PLKJ2kg9FdH3okeAsSaFfjff8CCKxBN8bW	UCHZ7buu1amKXgpqCVsox1aA	1	Dota Pit League SEA Qualifiers		2025-06-28
PLKJ2kg9FdH3q27o63GrErD3gtP8-CUALW	UCHZ7buu1amKXgpqCVsox1aA	1	Mineski VS Faceless | Dota Pit League Season 5		2025-06-28
PLKJ2kg9FdH3oIkSs7_D6j1ZGZYK-Bsbo4	UCHZ7buu1amKXgpqCVsox1aA	1	EG VS Team NP | Dota Pit League Season 5		2025-06-28
PLKJ2kg9FdH3rukG6CuaWw_CmDFsBi2_hz	UCHZ7buu1amKXgpqCVsox1aA	1	Team Liquid VS Ad Finem | Asus Dream League Season 6		2025-06-28
PLKJ2kg9FdH3qfbajD9ibLKawnh8LhRJMk	UCHZ7buu1amKXgpqCVsox1aA	1	ESL One Genting		2025-06-28
PLKJ2kg9FdH3qHp3a1BEQTI3Rw0A2-q7gi	UCHZ7buu1amKXgpqCVsox1aA	1	Dota Pit League Americas Qualifier		2025-06-28
PLKJ2kg9FdH3rMzpYzIt3F-9GdvHctK_Qs	UCHZ7buu1amKXgpqCVsox1aA	1	EG VS Complexity Gaming | Dota Pit League Season 5		2025-06-28
PLKJ2kg9FdH3rm1d_4pr3terbf5MG14Wok	UCHZ7buu1amKXgpqCVsox1aA	1	OG Dota2 VS Escape Gaming #1 | Elimination Mode 2.0		2025-06-28
PLKJ2kg9FdH3r4lEB6_4QSjnzak4T-4Epx	UCHZ7buu1amKXgpqCVsox1aA	1	Team Liquid VS Kaipi | Elimination Mode 2.0		2025-06-28
PLKJ2kg9FdH3ouNnHtC3eU9FDKNXDnHAFN	UCHZ7buu1amKXgpqCVsox1aA	1	Fantastic Five VS Vega Squadron | ESL One Genting		2025-06-28
PLKJ2kg9FdH3pP3wJnRasOjqs98mIxwAMG	UCHZ7buu1amKXgpqCVsox1aA	1	ESL One Genting | EU Qualifiers		2025-06-28
PLKJ2kg9FdH3rqdXUYqRvem1us9vvTyqwD	UCHZ7buu1amKXgpqCVsox1aA	1	Boston Major EU Playoffs		2025-06-28
PLKJ2kg9FdH3qsMk7gBgTTfkkY3BQO9PdO	UCHZ7buu1amKXgpqCVsox1aA	1	Boston Major SEA Playoffs		2025-06-28
PLKJ2kg9FdH3qvjbu79uWqZjH1imbZ5z0w	UCHZ7buu1amKXgpqCVsox1aA	1	Boston Major EU Qualifiers		2025-06-28
PLKJ2kg9FdH3plI5aziv0LlwxGnG1zxuoe	UCHZ7buu1amKXgpqCVsox1aA	1	Boston Major SEA Qualifiers		2025-06-28
PLKJ2kg9FdH3q1JHle2bBR_UkaTC2c9HYR	UCHZ7buu1amKXgpqCVsox1aA	1	Natus Vincere VS Alliance | Asus Dreamleague Season 6		2025-06-28
PLKJ2kg9FdH3pWMP-J5cNlGcmb0d0tVsYM	UCHZ7buu1amKXgpqCVsox1aA	1	Team Liquid VS Escape Gaming | Asus Dreamleague Season 6		2025-06-28
PLKJ2kg9FdH3r8zMWgm47jCT3Xij96F1nB	UCHZ7buu1amKXgpqCVsox1aA	1	Dota Pit Season 5 Highlights		2025-06-28
PLKJ2kg9FdH3o8_rnIJja9BRT-TD5pg8pj	UCHZ7buu1amKXgpqCVsox1aA	1	Natus Vincere VS Virtus Pro | Dota Pit League Season 5		2025-06-28
PLKJ2kg9FdH3pkiONkxmr18FdYzcgDz0Kv	UCHZ7buu1amKXgpqCVsox1aA	1	Team Secret VS FlipSid3 Tactics | Dota Pit League Season 5		2025-06-28
PLKJ2kg9FdH3rycxCLs9QO8OqHxoJSwMp9	UCHZ7buu1amKXgpqCVsox1aA	1	Team Liquid VS FlipSid3 Tactics | Dota Pit League Season 5 EU Semi Finals		2025-06-28
PLKJ2kg9FdH3rx_e-CJIRVnqLv1ygCCkVO	UCHZ7buu1amKXgpqCVsox1aA	1	Team Liquid VS Alliance | Asus Dreamleague Season 6		2025-06-28
PLKJ2kg9FdH3rv4qQGKT9i9TK6KBLz76EM	UCHZ7buu1amKXgpqCVsox1aA	1	Team Liquid VS Team Secret | Dota Pit League Season 5		2025-06-28
PLKJ2kg9FdH3oz_C3SgF9Lyb-9gbdJOhTm	UCHZ7buu1amKXgpqCVsox1aA	1	Team Liquid VS Team NP | Asus Dream League Season 6		2025-06-28
PLKJ2kg9FdH3pYzYZg721OPJhpHw-YFeHz	UCHZ7buu1amKXgpqCVsox1aA	1	Team Secret VS Ad Finem | Dota 2 Pit League Season 5		2025-06-28
PLKJ2kg9FdH3p9YQJe5KgchA2rdFBoex1M	UCHZ7buu1amKXgpqCVsox1aA	1	Dota Pit League EU #1 Qualifiers		2025-06-28
PLKJ2kg9FdH3qkk3wS7Fexqc_PK4yViTzR	UCHZ7buu1amKXgpqCVsox1aA	1	Team Liquid VS Flipsid3 Tactics | Dota Pit League Season 5		2025-06-28
PLKJ2kg9FdH3ob3GwJErH-wyr0vmKp_7fg	UCHZ7buu1amKXgpqCVsox1aA	1	Team NP VS Alliance | Asus Dreamleague Season 6		2025-06-28
PLKJ2kg9FdH3ppMtWikEXiS7QFKxJ37oZt	UCHZ7buu1amKXgpqCVsox1aA	1	Alliance VS Escape Gaming | Asus Dreamleague Season 6		2025-06-28
PLKJ2kg9FdH3odwfph0wT1FZk1WzR4KNzw	UCHZ7buu1amKXgpqCVsox1aA	1	Team Empire VS Vega Squadron | Dota Pit League Season 5		2025-06-28
PLKJ2kg9FdH3osyFFnej-eNHds3G1GJHQ1	UCHZ7buu1amKXgpqCVsox1aA	1	Natus Vincere VS Team Empire | Dota Pit League Season 5		2025-06-28
PLKJ2kg9FdH3qFmlD-_06iQ5gmBJ6Us6ND	UCHZ7buu1amKXgpqCVsox1aA	1	Dota Pit League CIS Qualifiers		2025-06-28
PLKJ2kg9FdH3oBo2IB4WgM72jT7RF0p8MG	UCHZ7buu1amKXgpqCVsox1aA	1	The Summit 6		2025-06-28
PLKJ2kg9FdH3qplUitWzbdDzjMEtcUn1MB	UCHZ7buu1amKXgpqCVsox1aA	1	The Summit 5 | SEA Qualifiers		2025-06-28
PLKJ2kg9FdH3o7uoPIc3UFc7JyOaS6BPNd	UCHZ7buu1amKXgpqCVsox1aA	1	Team Empire VS OG | The Manila Major Group Stage		2025-06-28
PLKJ2kg9FdH3r-6ioOGjAhgvEJPBFLYAk5	UCHZ7buu1amKXgpqCVsox1aA	1	The Manila Major 2016		2025-06-28
PLKJ2kg9FdH3peWjtzv9r47JYqXzieXdXP	UCHZ7buu1amKXgpqCVsox1aA	1	Abed | Dota 2 Highlights		2025-06-28
PLKJ2kg9FdH3phsvNwmWiaPl99TsjUDEe6	UCHZ7buu1amKXgpqCVsox1aA	1	EG VS Newbee | MDL 2016 GRAND FINALS		2025-06-28
PLKJ2kg9FdH3o_ZqipUrUa1bL6Pw1lAaFi	UCHZ7buu1amKXgpqCVsox1aA	1	EG VS OG | MDL 2016 Semi-Finals		2025-06-28
PLKJ2kg9FdH3qsXvIZw9aap8TNs7ZQNK1F	UCHZ7buu1amKXgpqCVsox1aA	1	EG VS Newbee | MDL 2016 Upper Bracket		2025-06-28
PLKJ2kg9FdH3pdA1Q3NPJuUXVnT3R-cV5A	UCHZ7buu1amKXgpqCVsox1aA	1	OG VS Secret | MDL 2016 DAY 4		2025-06-28
PLKJ2kg9FdH3pzrTFOrr29B7V2JdOk57Mm	UCHZ7buu1amKXgpqCVsox1aA	1	Secret VS LGD.FY | MDL 2016 DAY 4		2025-06-28
PLKJ2kg9FdH3o6MGN8GGuTxTGIIncbPLil	UCHZ7buu1amKXgpqCVsox1aA	1	OG VS VG | MDL 2016 Day 3		2025-06-28
PLKJ2kg9FdH3pqFcYxF4a-GKZ3nT8HZvUg	UCHZ7buu1amKXgpqCVsox1aA	1	MarsTV Dota 2 League 2016		2025-06-28
PLExmYUSx9mYB83WVS9t9BAxrIta_UPrKU	UCwI9DhoGEziLUxTpK8H77jw	1	Kez - New Hero Dota 2		2025-06-28
PLExmYUSx9mYDtrRTGrdw4bFafZqtF8bh1	UCwI9DhoGEziLUxTpK8H77jw	1	Nightfall		2025-06-28
PLExmYUSx9mYC7fe8CuA4fqN3OT3aqwy9-	UCwI9DhoGEziLUxTpK8H77jw	1	Satanic		2025-06-28
PLExmYUSx9mYCzMgSx9JxfDZ7cec9znz-1	UCwI9DhoGEziLUxTpK8H77jw	1	Ringmaster		2025-06-28
PLExmYUSx9mYBmMkKqH6v1O9eg_cE-DTwH	UCwI9DhoGEziLUxTpK8H77jw	1	The International 2023		2025-06-28
PLExmYUSx9mYCI_s0yOa-WsYwxejZjyScX	UCwI9DhoGEziLUxTpK8H77jw	1	7.33		2025-06-28
PLExmYUSx9mYDFrFzyz92Y5YrDiP3oz1tl	UCwI9DhoGEziLUxTpK8H77jw	1	The International 2022		2025-06-28
PLExmYUSx9mYATXSdYLfHA0NVW-FazNrr3	UCwI9DhoGEziLUxTpK8H77jw	1	OG.ATF		2025-06-28
PLExmYUSx9mYDLhWtGuKZtM7udEOfeeJZ7	UCwI9DhoGEziLUxTpK8H77jw	1	OG.Yuragi		2025-06-28
PLExmYUSx9mYCZdj_ZlFEUkX-MLuKz7wcu	UCwI9DhoGEziLUxTpK8H77jw	1	OG.bzm		2025-06-28
PLExmYUSx9mYB1MYsK9KrveACpGTvhwPa6	UCwI9DhoGEziLUxTpK8H77jw	1	Dota 2 The International 10		2025-06-28
PLExmYUSx9mYAcrO_g12PGQX0LIXN1hrOI	UCwI9DhoGEziLUxTpK8H77jw	1	MUST WATCH! / Best Games		2025-06-28
PLExmYUSx9mYC97aBk3Tq8zrkJNEkpcLZW	UCwI9DhoGEziLUxTpK8H77jw	1	GoodWIN		2025-06-28
PLExmYUSx9mYAJb7d7owW7vcPQF824YvGG	UCwI9DhoGEziLUxTpK8H77jw	1	LL!!!		2025-06-28
PLExmYUSx9mYD1WbaIw_mNFAgiVmKh85H7	UCwI9DhoGEziLUxTpK8H77jw	1	yatoro		2025-06-28
PLExmYUSx9mYAULJ50T5cUZl8IF_AGI2b2	UCwI9DhoGEziLUxTpK8H77jw	1	Pro Highlights		2025-06-28
PLExmYUSx9mYB3rfWyleCiFklARbX7qBMs	UCwI9DhoGEziLUxTpK8H77jw	1	Gabbi		2025-06-28
PLExmYUSx9mYAXfMWcHR0J1m_JAmdaBnNc	UCwI9DhoGEziLUxTpK8H77jw	1	gpk		2025-06-28
PLExmYUSx9mYD0L1hztouD3F-aubuiFQ-A	UCwI9DhoGEziLUxTpK8H77jw	1	epileptick1d		2025-06-28
PLExmYUSx9mYBzYdNeJU-qrKEcRaXXWhet	UCwI9DhoGEziLUxTpK8H77jw	1	23savage		2025-06-28
PLExmYUSx9mYDklWc79ATm1SwDM-b5x_39	UCwI9DhoGEziLUxTpK8H77jw	1	Faith_bian		2025-06-28
PLExmYUSx9mYBSXr7gC0eYnTXDTOeMjTHR	UCwI9DhoGEziLUxTpK8H77jw	1	Nikobaby		2025-06-28
PLExmYUSx9mYAKpLkZd1n83G2qe6B1FRvy	UCwI9DhoGEziLUxTpK8H77jw	1	iLTW		2025-06-28
PLExmYUSx9mYAywTfkLJf-5_OBZeJ0b-O4	UCwI9DhoGEziLUxTpK8H77jw	1	Jabz		2025-06-28
PLExmYUSx9mYAsKr5irbWcPQUbr-sIZ0Fq	UCwI9DhoGEziLUxTpK8H77jw	1	MagicaL		2025-06-28
PLExmYUSx9mYBZs3q2wxXZ5AajyUHWgdUI	UCwI9DhoGEziLUxTpK8H77jw	1	YawaR		2025-06-28
PLExmYUSx9mYDdG01_qz6RZ1vXHdd_CF0Z	UCwI9DhoGEziLUxTpK8H77jw	1	Nisha		2025-06-28
PLExmYUSx9mYBc5RzmVjZLT_pGSaUoUPbK	UCwI9DhoGEziLUxTpK8H77jw	1	Qupe		2025-06-28
PLExmYUSx9mYDFtqjUYNDa9bOTW_sO_9TR	UCwI9DhoGEziLUxTpK8H77jw	1	Topson		2025-06-28
PLExmYUSx9mYDXANacz1wA39oCS2XjcTYU	UCwI9DhoGEziLUxTpK8H77jw	1	Iceberg		2025-06-28
PLExmYUSx9mYCef7VnzL62_4zBTpP5H3LK	UCwI9DhoGEziLUxTpK8H77jw	1	7Mad		2025-06-28
PLExmYUSx9mYBXMlA3s4bo1yvV0zMLmkHo	UCwI9DhoGEziLUxTpK8H77jw	1	ZIP FILE		2025-06-28
PLExmYUSx9mYArnox6mmE62GxwwnNGaG4J	UCwI9DhoGEziLUxTpK8H77jw	1	Armel		2025-06-28
PLExmYUSx9mYAFSp9R9vJYTfefbjXfMune	UCwI9DhoGEziLUxTpK8H77jw	1	Roaming/Jungle		2025-06-28
PLExmYUSx9mYD-GA1e3v1m1FBeQH9v_YFW	UCwI9DhoGEziLUxTpK8H77jw	1	Support		2025-06-28
PLExmYUSx9mYCQ0rjiYWMiuRbN60N0NTtn	UCwI9DhoGEziLUxTpK8H77jw	1	Offlane		2025-06-28
PLExmYUSx9mYDmOHT8xGuSoEQjxj2aPdKN	UCwI9DhoGEziLUxTpK8H77jw	1	Safelane		2025-06-28
PLExmYUSx9mYCpw65aaRLRSTVEPkPlnAR0	UCwI9DhoGEziLUxTpK8H77jw	1	Mid		2025-06-28
PLExmYUSx9mYBGBVsWqRFn8Ntvzz_CPxuM	UCwI9DhoGEziLUxTpK8H77jw	1	EviLVerGiL		2025-06-28
PLExmYUSx9mYDoVTP3aTwfWdkPNqTgZxqk	UCwI9DhoGEziLUxTpK8H77jw	1	Chorão		2025-06-28
PLExmYUSx9mYDdWI7jqVN0vIHz8etGuKJn	UCwI9DhoGEziLUxTpK8H77jw	1	Dread		2025-06-28
PLExmYUSx9mYAGOHRzD2OgPDH-jl0co3y6	UCwI9DhoGEziLUxTpK8H77jw	1	Tavo		2025-06-28
PLExmYUSx9mYCsmElvDTdQFxZkN7F5CDo_	UCwI9DhoGEziLUxTpK8H77jw	1	Freeze		2025-06-28
PLExmYUSx9mYBOnAKup6FFkCc-9HBaHIKf	UCwI9DhoGEziLUxTpK8H77jw	1	Ori		2025-06-28
PLExmYUSx9mYD28Iw5Uqy3LqFXTiv0Xvx-	UCwI9DhoGEziLUxTpK8H77jw	1	BabyKnight		2025-06-28
PLExmYUSx9mYDL8K23BYxKi5tcnA8v3i0A	UCwI9DhoGEziLUxTpK8H77jw	1	KINGRD		2025-06-28
PLExmYUSx9mYAx-MJT3ATPJMuQhDREB-LE	UCwI9DhoGEziLUxTpK8H77jw	1	Timado		2025-06-28
PLExmYUSx9mYCdpKTC6NoRTMZYnR_FPu-a	UCwI9DhoGEziLUxTpK8H77jw	1	Nexus		2025-06-28
PLExmYUSx9mYCONBBE-ROCgfqX2blsvzwA	UCwI9DhoGEziLUxTpK8H77jw	1	kaka		2025-06-28
PLExmYUSx9mYBv2syJPhsR4zrZxGn1yB6b	UCwI9DhoGEziLUxTpK8H77jw	1	CCnC		2025-06-28
PLExmYUSx9mYAy32kfpht_hxhbEXUpmt7c	UCwI9DhoGEziLUxTpK8H77jw	1	Crystallize		2025-06-28
PLExmYUSx9mYAOCg_weVRWDK_FbdlXjaUh	UCwI9DhoGEziLUxTpK8H77jw	1	Ace		2025-06-28
PLExmYUSx9mYBuZVmPpA4ja3BY6pMPD8I1	UCwI9DhoGEziLUxTpK8H77jw	1	ninjaboogie		2025-06-28
PLExmYUSx9mYAD50w0DDsqXoyGiAQIicK4	UCwI9DhoGEziLUxTpK8H77jw	1	Saksa		2025-06-28
PLExmYUSx9mYD2LgOJnySt24tDl3EX-UsI	UCwI9DhoGEziLUxTpK8H77jw	1	KingR		2025-06-28
PLExmYUSx9mYAbAuM0MXilpcU2oVz7I0i6	UCwI9DhoGEziLUxTpK8H77jw	1	Levkan		2025-06-28
PLExmYUSx9mYDDQtXfcu8pF6-TtJJFIBTX	UCwI9DhoGEziLUxTpK8H77jw	1	@dogf1ghts		2025-06-28
PLExmYUSx9mYC4loAtXgYmw9h239a6CR2C	UCwI9DhoGEziLUxTpK8H77jw	1	SumiYa		2025-06-28
PLExmYUSx9mYDTLaQdLPpiVQMJ2uxQd8NC	UCwI9DhoGEziLUxTpK8H77jw	1	NutZ		2025-06-28
PLExmYUSx9mYDfxCIs5SkE523cYLb_L7ym	UCwI9DhoGEziLUxTpK8H77jw	1	Merlini		2025-06-28
PLExmYUSx9mYDA3lcdmydobJEXSD3DSIaY	UCwI9DhoGEziLUxTpK8H77jw	1	SsaSpartan		2025-06-28
PLExmYUSx9mYA2Br7-NjRDHFI0sw9bMvAK	UCwI9DhoGEziLUxTpK8H77jw	1	BoBoKa		2025-06-28
PLExmYUSx9mYBEVTVNj7u-BeRVO8N4ycZl	UCwI9DhoGEziLUxTpK8H77jw	1	Paparazi		2025-06-28
PLExmYUSx9mYC5-iLBJs4zI8H_F5k8Vbgz	UCwI9DhoGEziLUxTpK8H77jw	1	Xxs		2025-06-28
PLExmYUSx9mYBg-II7gDMoS-Swj_9owGuG	UCwI9DhoGEziLUxTpK8H77jw	1	Op		2025-06-28
PLExmYUSx9mYAcr2_QHHffK1ZJjj-bCCoa	UCwI9DhoGEziLUxTpK8H77jw	1	Dota 2 Asia Championships 2017		2025-06-28
PLExmYUSx9mYA1lIEWJLsuzPtXPKP-GlyE	UCwI9DhoGEziLUxTpK8H77jw	1	Raven		2025-06-28
PLExmYUSx9mYCKntN2jBNSj0G9oeMkImBq	UCwI9DhoGEziLUxTpK8H77jw	1	WinteR		2025-06-28
PLExmYUSx9mYDNwQjjsMSB0Z4YucEXWT4c	UCwI9DhoGEziLUxTpK8H77jw	1	Axx		2025-06-28
PLExmYUSx9mYA0FaLC9y-8sUR4nZDPov0k	UCwI9DhoGEziLUxTpK8H77jw	1	rmN		2025-06-28
PLExmYUSx9mYB2ftGKXJNbaijDDNbKpDDv	UCwI9DhoGEziLUxTpK8H77jw	1	MSS		2025-06-28
PLExmYUSx9mYBPw16Qog4_s1HUaIRa8TsC	UCwI9DhoGEziLUxTpK8H77jw	1	DeMoN		2025-06-28
PLExmYUSx9mYCo7T4ut21G-0bwBwFFx3zS	UCwI9DhoGEziLUxTpK8H77jw	1	Reisen		2025-06-28
PLExmYUSx9mYDOcP1hCgXvIHlOUTYJ5nNY	UCwI9DhoGEziLUxTpK8H77jw	1	June		2025-06-28
PLExmYUSx9mYD3235tZQ3Rbfy7c2LXIfAU	UCwI9DhoGEziLUxTpK8H77jw	1	zai		2025-06-28
PLExmYUSx9mYCQfxp6YVyS0nUW8ng_ki0d	UCwI9DhoGEziLUxTpK8H77jw	1	GH-GOD		2025-06-28
PLExmYUSx9mYAm7ci7ZO3IZgl-AKy_03Xm	UCwI9DhoGEziLUxTpK8H77jw	1	KheZu		2025-06-28
PLExmYUSx9mYCzpzgThkMCPGFjEFjAcIOr	UCwI9DhoGEziLUxTpK8H77jw	1	Inflame		2025-06-28
PLExmYUSx9mYAJr0wz4jEpYkb9BOuOvv5a	UCwI9DhoGEziLUxTpK8H77jw	1	XtiNcT		2025-06-28
PLExmYUSx9mYCqU9PSJ5UyQrtKIHBmSb0-	UCwI9DhoGEziLUxTpK8H77jw	1	33		2025-06-28
PLExmYUSx9mYDQlrmhTMFl9zft7VVcXmix	UCwI9DhoGEziLUxTpK8H77jw	1	NaNa		2025-06-28
PLExmYUSx9mYAOVUlGdvIpJhLGq0r6jqH_	UCwI9DhoGEziLUxTpK8H77jw	1	ThuG		2025-06-28
PLExmYUSx9mYDWbFJB-9_yId-dmD6N1Zne	UCwI9DhoGEziLUxTpK8H77jw	1	Ah Jit		2025-06-28
PLExmYUSx9mYDcj69ljtN3oZMEuKoNYabL	UCwI9DhoGEziLUxTpK8H77jw	1	canceL		2025-06-28
PLExmYUSx9mYAE8dXrtAyze2Ka4dlNU-60	UCwI9DhoGEziLUxTpK8H77jw	1	Yao		2025-06-28
PLExmYUSx9mYBUfvZAWa6TvI4B1agSp8me	UCwI9DhoGEziLUxTpK8H77jw	1	GeneRaL		2025-06-28
PLExmYUSx9mYB17vbv_uYFv0VjosFs3upk	UCwI9DhoGEziLUxTpK8H77jw	1	iceice		2025-06-28
PLExmYUSx9mYBXqFicXQG_O61ksrngwyR-	UCwI9DhoGEziLUxTpK8H77jw	1	YapzOr		2025-06-28
PLExmYUSx9mYBJDkkeKiNvGnxHdL5-kfrj	UCwI9DhoGEziLUxTpK8H77jw	1	uuu9		2025-06-28
PLExmYUSx9mYDEkHdLwGWJn_mP-RDc0gq_	UCwI9DhoGEziLUxTpK8H77jw	1	Velo		2025-06-28
PLExmYUSx9mYBJAjfOl3YEB0sE72Kgfl0N	UCwI9DhoGEziLUxTpK8H77jw	1	Ame		2025-06-28
PLExmYUSx9mYCwVWlrTvOm4bCTW8xjfT_K	UCwI9DhoGEziLUxTpK8H77jw	1	Monet		2025-06-28
PLExmYUSx9mYBz60ui7AZ7UPdyyGKlovXe	UCwI9DhoGEziLUxTpK8H77jw	1	747		2025-06-28
PLExmYUSx9mYCkR28i4Ez1yCYCdxo9fUVm	UCwI9DhoGEziLUxTpK8H77jw	1	Nono		2025-06-28
PLExmYUSx9mYDaO1sEwl5pXsMGN3OwXCIo	UCwI9DhoGEziLUxTpK8H77jw	1	Sccc		2025-06-28
PLExmYUSx9mYDl1yVhly9jCOiY-d_Xh7Ri	UCwI9DhoGEziLUxTpK8H77jw	1	September		2025-06-28
PLExmYUSx9mYBMmRuDk0ATihzNluN2Hye2	UCwI9DhoGEziLUxTpK8H77jw	1	ShiKi		2025-06-28
PLExmYUSx9mYCEHLNKepGb3oQBCEeknXmS	UCwI9DhoGEziLUxTpK8H77jw	1	ana		2025-06-28
PLExmYUSx9mYAdWsP8VP4jVbG3XCbwdZOY	UCwI9DhoGEziLUxTpK8H77jw	1	shadow		2025-06-28
PLExmYUSx9mYA8xZMcFZJ024cTRe4RY2Tx	UCwI9DhoGEziLUxTpK8H77jw	1	Moo		2025-06-28
PLExmYUSx9mYCudVBFfXDBaBKiaoPcKmSp	UCwI9DhoGEziLUxTpK8H77jw	1	Kuku		2025-06-28
PLExmYUSx9mYC7xvw3YW9K1FSA8YdCP2pD	UCwI9DhoGEziLUxTpK8H77jw	1	MinD_ContRoL		2025-06-28
PLExmYUSx9mYD4bk88apUnO8TQ4-7_f2Cz	UCwI9DhoGEziLUxTpK8H77jw	1	bLink		2025-06-28
PLExmYUSx9mYAXFcgO4vXAc-I7lAt3CieG	UCwI9DhoGEziLUxTpK8H77jw	1	AfterLife		2025-06-28
PLExmYUSx9mYABnPXB7ipiutmyhDM5q-js	UCwI9DhoGEziLUxTpK8H77jw	1	Abed		2025-06-28
PLExmYUSx9mYBe9RvluavmlFwpUU-JvZo9	UCwI9DhoGEziLUxTpK8H77jw	1	Nando		2025-06-28
PLExmYUSx9mYAYwDE_Czj8hqEK4Mk2h0Ar	UCwI9DhoGEziLUxTpK8H77jw	1	The International 2016		2025-06-28
PLExmYUSx9mYCZmtS8l-4Oph3xyK-nev2w	UCwI9DhoGEziLUxTpK8H77jw	1	Fenrir		2025-06-28
PLExmYUSx9mYBi4MTWNMwhsbYD0oh7yced	UCwI9DhoGEziLUxTpK8H77jw	1	Handsken		2025-06-28
PLExmYUSx9mYABg8M32ZVM6PwC43tI6gvN	UCwI9DhoGEziLUxTpK8H77jw	1	MiSeRy		2025-06-28
PLExmYUSx9mYCPPoDhuNS9E6m5fCkH9nZM	UCwI9DhoGEziLUxTpK8H77jw	1	syndereN		2025-06-28
PLExmYUSx9mYCkUMvZhRh6kOtmbXyFZDYN	UCwI9DhoGEziLUxTpK8H77jw	1	JerAx		2025-06-28
PLExmYUSx9mYBUVVmWVTKeLGrJeHQD4Ro5	UCwI9DhoGEziLUxTpK8H77jw	1	Yang		2025-06-28
PLExmYUSx9mYARFr6T90eFez5w-dSoEEc0	UCwI9DhoGEziLUxTpK8H77jw	1	Moon		2025-06-28
PLExmYUSx9mYDH_9VFsrAiA9l2RVP17gHb	UCwI9DhoGEziLUxTpK8H77jw	1	DJ		2025-06-28
PLExmYUSx9mYBje-GlYavrKuNJIImOQ19r	UCwI9DhoGEziLUxTpK8H77jw	1	END		2025-06-28
PLExmYUSx9mYAJSq9xO2oG3QKVJb4Ha4PE	UCwI9DhoGEziLUxTpK8H77jw	1	Febby		2025-06-28
PLExmYUSx9mYAZ5WmKAHnYzCa9cxUsCt8T	UCwI9DhoGEziLUxTpK8H77jw	1	fn		2025-06-28
PLExmYUSx9mYCc1wS78oSo0ZCP3AfM_5yt	UCwI9DhoGEziLUxTpK8H77jw	1	fy		2025-06-28
PLExmYUSx9mYBshShG7_IQ5-Mtz7Xb3TUr	UCwI9DhoGEziLUxTpK8H77jw	1	MP		2025-06-28
PLExmYUSx9mYBaklH2_dJsoxPvM6_9XGGB	UCwI9DhoGEziLUxTpK8H77jw	1	QO		2025-06-28
PLExmYUSx9mYBz8nuVrMu2VwzF4Gfsz4T6	UCwI9DhoGEziLUxTpK8H77jw	1	LaNm		2025-06-28
PLExmYUSx9mYBApfmeqAHnBXSW858olHFU	UCwI9DhoGEziLUxTpK8H77jw	1	EGM		2025-06-28
PLExmYUSx9mYC3w9UKCfAd1oPxY4yKBA45	UCwI9DhoGEziLUxTpK8H77jw	1	MATUMBAMAN		2025-06-28
PLExmYUSx9mYATL1Dr7-2J6AQ6ZfvqHDIS	UCwI9DhoGEziLUxTpK8H77jw	1	Badman		2025-06-28
PLExmYUSx9mYA8A974mnHu8mjeMgfPzY9t	UCwI9DhoGEziLUxTpK8H77jw	1	Fly		2025-06-28
PLExmYUSx9mYCLwX-byFiiGSipJ6jbU0jn	UCwI9DhoGEziLUxTpK8H77jw	1	ppd		2025-06-28
PLExmYUSx9mYDZ5A49SP7Lcq5efi6c60sl	UCwI9DhoGEziLUxTpK8H77jw	1	CemaTheSlayeR		2025-06-28
PLExmYUSx9mYB5ggEPeQ7GgrygR7-6XU3q	UCwI9DhoGEziLUxTpK8H77jw	1	RAMZES666		2025-06-28
PLExmYUSx9mYBlIIZdCfOROkJjhbmZYZDi	UCwI9DhoGEziLUxTpK8H77jw	1	UNiVeRsE		2025-06-28
PLExmYUSx9mYC1Bz56wCeVYWDDKQ6kRCst	UCwI9DhoGEziLUxTpK8H77jw	1	Cty		2025-06-28
PLExmYUSx9mYDMsBJs2B--nB6O4L_x77OZ	UCwI9DhoGEziLUxTpK8H77jw	1	MidOne		2025-06-28
PLExmYUSx9mYAZEMpaRAsMlUGRW1lZKAtQ	UCwI9DhoGEziLUxTpK8H77jw	1	Aui_2000		2025-06-28
PLExmYUSx9mYDzWfLtOXSqLdSDH1S0TjMT	UCwI9DhoGEziLUxTpK8H77jw	1	ChuaN		2025-06-28
PLExmYUSx9mYAXxF74t4pXjMwoYQeyIOUF	UCwI9DhoGEziLUxTpK8H77jw	1	Attacker		2025-06-28
PLExmYUSx9mYAgd18SmVt0hf-P7tQ64BEZ	UCwI9DhoGEziLUxTpK8H77jw	1	old chicken		2025-06-28
PLExmYUSx9mYABkRjExfH16vZa4H8mBT0J	UCwI9DhoGEziLUxTpK8H77jw	1	No[o]ne		2025-06-28
PLExmYUSx9mYDdjxSveZBHijnljM7BWmNJ	UCwI9DhoGEziLUxTpK8H77jw	1	Mynuts		2025-06-28
PLExmYUSx9mYAUjv1Yg-GsYamjfnjGB2kr	UCwI9DhoGEziLUxTpK8H77jw	1	Atun		2025-06-28
PLExmYUSx9mYA829ZL-1rYRAp0zZZlOJBS	UCwI9DhoGEziLUxTpK8H77jw	1	ALOHADANCE		2025-06-28
PLExmYUSx9mYDn5kIV00xogRQzfmGxX5uA	UCwI9DhoGEziLUxTpK8H77jw	1	ELeVeN		2025-06-28
PLExmYUSx9mYBSnc9YuvORK_dDzAZLZn5B	UCwI9DhoGEziLUxTpK8H77jw	1	Cr1t		2025-06-28
PLExmYUSx9mYDmgewaFF4RkUoQsrZd8TDp	UCwI9DhoGEziLUxTpK8H77jw	1	Arise		2025-06-28
PLExmYUSx9mYD2Rn2NXhtu0ExRnKinFT_5	UCwI9DhoGEziLUxTpK8H77jw	1	Limmp		2025-06-28
PLExmYUSx9mYC7fjE_H6AXfxYS0XV2QaHW	UCwI9DhoGEziLUxTpK8H77jw	1	Ohaiyo		2025-06-28
PLExmYUSx9mYA10HDcbYNLt2TF94lrKQM0	UCwI9DhoGEziLUxTpK8H77jw	1	xy		2025-06-28
PLExmYUSx9mYDV-5Ro0LKrLtycYLrf2JHu	UCwI9DhoGEziLUxTpK8H77jw	1	Solo		2025-06-28
PLExmYUSx9mYDdo0aq4Zvi-qq4YVpdwF6_	UCwI9DhoGEziLUxTpK8H77jw	1	kpii		2025-06-28
PLExmYUSx9mYBN8zEvvR2WBJpRly7_35fn	UCwI9DhoGEziLUxTpK8H77jw	1	Faith		2025-06-28
PLExmYUSx9mYCHeXzLNIkDubuROo-zoM4X	UCwI9DhoGEziLUxTpK8H77jw	1	Artstyle		2025-06-28
PLExmYUSx9mYAn9tU6xWXqIcnpJ1J0TErf	UCwI9DhoGEziLUxTpK8H77jw	1	Lil		2025-06-28
PLExmYUSx9mYBfpWKcKuWcHe6yMNJf_7dG	UCwI9DhoGEziLUxTpK8H77jw	1	Agressif		2025-06-28
PLExmYUSx9mYAKP2_QOBy5sjbSFfS9hg8o	UCwI9DhoGEziLUxTpK8H77jw	1	CWM		2025-06-28
PLExmYUSx9mYBZywOjsmXiCMDEzlPzwLMu	UCwI9DhoGEziLUxTpK8H77jw	1	SoNNeikO		2025-06-28
PLExmYUSx9mYDmnSu53L9EiQmKakKMJE1d	UCwI9DhoGEziLUxTpK8H77jw	1	Miracle-		2025-06-28
PLExmYUSx9mYDeGudrBL3HzH0td_hPbDLh	UCwI9DhoGEziLUxTpK8H77jw	1	FoREV		2025-06-28
PLExmYUSx9mYAqZsABhgZ4YSww3x23EUxn	UCwI9DhoGEziLUxTpK8H77jw	1	Blitz		2025-06-28
PLExmYUSx9mYAzTJhDarubAfkQbI-dlNbI	UCwI9DhoGEziLUxTpK8H77jw	1	The International 2015		2025-06-28
PLExmYUSx9mYBjxorSt_-iBfXNWpHTAVr6	UCwI9DhoGEziLUxTpK8H77jw	1	AdmiralBulldog		2025-06-28
PLExmYUSx9mYC4SU6vgqByEktAiYk_cr8m	UCwI9DhoGEziLUxTpK8H77jw	1	Xiao8		2025-06-28
PLExmYUSx9mYAZaUOM98bZgFZ_7Xm_pC9p	UCwI9DhoGEziLUxTpK8H77jw	1	ZSMJ		2025-06-28
PLExmYUSx9mYBzLZXgqOBtABnl38vk7xW9	UCwI9DhoGEziLUxTpK8H77jw	1	Wagamama		2025-06-28
PLExmYUSx9mYCxC1LPPo3mSWDgKsFjgoLO	UCwI9DhoGEziLUxTpK8H77jw	1	DeviLisH		2025-06-28
PLExmYUSx9mYC8ONImxcTNkhbx9wWt9PDc	UCwI9DhoGEziLUxTpK8H77jw	1	SumaiL		2025-06-28
PLExmYUSx9mYC_uY-mNySVIF8XBq8iTeGX	UCwI9DhoGEziLUxTpK8H77jw	1	yoky		2025-06-28
PLExmYUSx9mYAFGnCBVpgrXUHLgjpLgHss	UCwI9DhoGEziLUxTpK8H77jw	1	Mushi		2025-06-28
PLExmYUSx9mYBpJ-UqKzCP4M3Xe8tAleao	UCwI9DhoGEziLUxTpK8H77jw	1	Ditya Ra		2025-06-28
PLExmYUSx9mYDIkbwQ28oKBzL28n0x2Wqz	UCwI9DhoGEziLUxTpK8H77jw	1	DkPhobos		2025-06-28
PLExmYUSx9mYAdVlCBb44jjAiBysT9dD6P	UCwI9DhoGEziLUxTpK8H77jw	1	Resolut1on		2025-06-28
PLExmYUSx9mYANqxG6JDBpWiyMSrFBggS0	UCwI9DhoGEziLUxTpK8H77jw	1	Maybe		2025-06-28
PLExmYUSx9mYCxmdWfkJsxp8QbxKglhBkF	UCwI9DhoGEziLUxTpK8H77jw	1	Puppey		2025-06-28
PLExmYUSx9mYCQFhh0bCZdbHQbXpt-qyDA	UCwI9DhoGEziLUxTpK8H77jw	1	Sedoy		2025-06-28
PLExmYUSx9mYCoiAimlHhxWswE7fMxQA4n	UCwI9DhoGEziLUxTpK8H77jw	1	Era		2025-06-28
PLExmYUSx9mYCF6KIk9yCkWAoti0en_vjc	UCwI9DhoGEziLUxTpK8H77jw	1	Meracle		2025-06-28
PLExmYUSx9mYA5nsMRIrnbfuuMvkuBrpeQ	UCwI9DhoGEziLUxTpK8H77jw	1	Super		2025-06-28
PLExmYUSx9mYClOQS1ixo3KQGHrTp55yko	UCwI9DhoGEziLUxTpK8H77jw	1	BzzIsPerfect		2025-06-28
PLExmYUSx9mYAUc6Vu1N3qLI6WI1rkb4Qa	UCwI9DhoGEziLUxTpK8H77jw	1	Xcalibur		2025-06-28
PLExmYUSx9mYA31akkiJD7LGZfSRGlK-RD	UCwI9DhoGEziLUxTpK8H77jw	1	hyhy		2025-06-28
PLExmYUSx9mYDjTcuyyz_UByhNO50pn1KK	UCwI9DhoGEziLUxTpK8H77jw	1	BurNIng		2025-06-28
PLExmYUSx9mYA5sL8kIpG1BLONY3buB3qH	UCwI9DhoGEziLUxTpK8H77jw	1	Sylar		2025-06-28
PLExmYUSx9mYCAScNlCJbuZH1Owso9M276	UCwI9DhoGEziLUxTpK8H77jw	1	God		2025-06-28
PLExmYUSx9mYBxl_OQWGI2BmWen5Gx90Eg	UCwI9DhoGEziLUxTpK8H77jw	1	fng		2025-06-28
PLExmYUSx9mYB6cA-v5A5KJ_JodyTrdQR0	UCwI9DhoGEziLUxTpK8H77jw	1	Hao		2025-06-28
PLExmYUSx9mYAebz3ZvAmcRFg-YjAHa2yW	UCwI9DhoGEziLUxTpK8H77jw	1	Mag		2025-06-28
PLExmYUSx9mYB8BMAUd5xw-uzUiWSyd2YB	UCwI9DhoGEziLUxTpK8H77jw	1	YamateH		2025-06-28
PLExmYUSx9mYCMm_VYDBMVGVPM0BIkTDGT	UCwI9DhoGEziLUxTpK8H77jw	1	XtiNcT		2025-06-28
PLExmYUSx9mYD7UrL6ovdUX5KvgxlX3jwh	UCwI9DhoGEziLUxTpK8H77jw	1	SexyBamboe		2025-06-28
PLExmYUSx9mYBqjDkBrjWzqdaFMgFwgYP2	UCwI9DhoGEziLUxTpK8H77jw	1	Trixi		2025-06-28
PLExmYUSx9mYCb1horQiX3OvhC1eLT6JnP	UCwI9DhoGEziLUxTpK8H77jw	1	bOne7		2025-06-28
PLExmYUSx9mYDcsc92HZOarn1B7uQM8xD2	UCwI9DhoGEziLUxTpK8H77jw	1	Akke		2025-06-28
PLExmYUSx9mYDe_fAbuibgKGIND0yTzgr9	UCwI9DhoGEziLUxTpK8H77jw	1	SingSing		2025-06-28
PLExmYUSx9mYC4Bpt1VAmvC61M4zpvx7HL	UCwI9DhoGEziLUxTpK8H77jw	1	H4nn1		2025-06-28
PLExmYUSx9mYByglImLmpoW3VE0JLDV_-v	UCwI9DhoGEziLUxTpK8H77jw	1	Korok		2025-06-28
PLExmYUSx9mYCMg8xfxc7WMPPaT5TvyWhZ	UCwI9DhoGEziLUxTpK8H77jw	1	BigDaddy		2025-06-28
PLExmYUSx9mYAKZyBW9NMHLjm1EdxQ4KJ7	UCwI9DhoGEziLUxTpK8H77jw	1	Pajkatt		2025-06-28
PLExmYUSx9mYDBo0H7t94Luk32c9GV-qKI	UCwI9DhoGEziLUxTpK8H77jw	1	Ferrari_430		2025-06-28
PLExmYUSx9mYC6qH_n4-yXUNBWQmq78Qfb	UCwI9DhoGEziLUxTpK8H77jw	1	s4		2025-06-28
PLExmYUSx9mYA_JaZF4DEbZRLvMQ2CGnJs	UCwI9DhoGEziLUxTpK8H77jw	1	Black^		2025-06-28
PLExmYUSx9mYC6m9GoMgnc3U5xGo55Gtly	UCwI9DhoGEziLUxTpK8H77jw	1	qojqva		2025-06-28
PLExmYUSx9mYCmMZfQhOdtmgD92rzEocZt	UCwI9DhoGEziLUxTpK8H77jw	1	FATA-		2025-06-28
PLExmYUSx9mYBGNnMdRKnc1yNcH1X6RhMW	UCwI9DhoGEziLUxTpK8H77jw	1	Funn1k		2025-06-28
PLExmYUSx9mYBxUXbVqn_XA123FSmBcGYR	UCwI9DhoGEziLUxTpK8H77jw	1	Fear		2025-06-28
PLExmYUSx9mYCTgEBxcj0kLx0Gf-pi_2mS	UCwI9DhoGEziLUxTpK8H77jw	1	Silent		2025-06-28
PLExmYUSx9mYBs759TKc1fNp86BxDZJ7N9	UCwI9DhoGEziLUxTpK8H77jw	1	XBOCT		2025-06-28
PLExmYUSx9mYBdYItu3xWwJIx_8cQvcvY5	UCwI9DhoGEziLUxTpK8H77jw	1	kky		2025-06-28
PLExmYUSx9mYAc4ET0lGYE0C95nhCXpq9i	UCwI9DhoGEziLUxTpK8H77jw	1	Loda		2025-06-28
PLExmYUSx9mYARExOzrwqT47Q5sPD8kkqy	UCwI9DhoGEziLUxTpK8H77jw	1	Arteezy		2025-06-28
PLExmYUSx9mYAnmes-SKbL8cqmjAA_aGdO	UCwI9DhoGEziLUxTpK8H77jw	1	EternaLEnVy		2025-06-28
PLExmYUSx9mYCQf2e3Xb30xOBN1pOuiEWo	UCwI9DhoGEziLUxTpK8H77jw	1	Illidan		2025-06-28
PLExmYUSx9mYB6TMA0NwWpLwmiLhGhhnoD	UCwI9DhoGEziLUxTpK8H77jw	1	SmAsH		2025-06-28
PLExmYUSx9mYAfq1mpNWnfGjHKIrxj-XjC	UCwI9DhoGEziLUxTpK8H77jw	1	w33		2025-06-28
PLExmYUSx9mYDNa24Rms0rNy8PTfNMoDVh	UCwI9DhoGEziLUxTpK8H77jw	1	Dendi		2025-06-28
PLmqdK5_Qu7DKBH722l2ab0rQbPxmpqk0k	UC18NaGQLruOEw65eQE3bNbg	1	Dailys		2025-06-28
PLmqdK5_Qu7DJvgYDsj7kUZFgTsZR6RU4M	UC18NaGQLruOEw65eQE3bNbg	1	WTF Moments		2025-06-28
PLBAd6BNbYbHpaHllxr2icZfyRhcpb8PpG	UCTXCACeuoZJggkbuJ0w7_bg	1	SEA RANKED DIARY		2025-06-28
PLBAd6BNbYbHpxnUEr4p1_CKC9hIYQrZbd	UCTXCACeuoZJggkbuJ0w7_bg	1	THIS IS SEA SERVER		2025-06-28
PL37CzvwiWXoiETMsGeqh_3PNwnuekl9nP	UC1YCxISkweN5vLsOJ0zElZQ	1	The International 2024 - Dota 2 TI13 #TI13		2025-06-28
PL37CzvwiWXoi-Yo9SIcHvey9KPBG8e_Yy	UC1YCxISkweN5vLsOJ0zElZQ	1	The International 2023 - Dota 2 TI12		2025-06-28
PL37CzvwiWXog8m5REFk0zSCaxoAuSI6No	UC1YCxISkweN5vLsOJ0zElZQ	1	The International 2022 - Dota 2 TI11		2025-06-28
PL37CzvwiWXoiWNzx-RwCknXR9hsNyRpdF	UC1YCxISkweN5vLsOJ0zElZQ	1	Dota 2 - The 2022 Battle Pass - TI11 The International 2022		2025-06-28
PL37CzvwiWXohQFIYfj0o3bNnbRMVdEFTf	UC1YCxISkweN5vLsOJ0zElZQ	1	BEST OF 2021 DOTA 2		2025-06-28
PL37CzvwiWXojXh33hyy7o8eapi3srA3dK	UC1YCxISkweN5vLsOJ0zElZQ	1	The International 10 - Dota 2 TI10		2025-06-28
PL37CzvwiWXog09iShA_n49Okk2NRgG7Np	UC1YCxISkweN5vLsOJ0zElZQ	1	BEST Dota 2 TOP Lists (MOST Epic Moments in Dota 2 History)		2025-06-28
PL37CzvwiWXoiPfwL8SxTDMPUzlBRHS7di	UC1YCxISkweN5vLsOJ0zElZQ	1	The International 10 (BEST Plays, Moments & Games, Teams Introduction, BEST of Tributes & more!)		2025-06-28
PL37CzvwiWXoi58HW5Bwo2B9AI44zZSq67	UC1YCxISkweN5vLsOJ0zElZQ	1	ESL One Summer 2021		2025-06-28
PL37CzvwiWXohqvl2ewKACYgCrvbeSRSJ0	UC1YCxISkweN5vLsOJ0zElZQ	1	WePlay AniMajor Dota 2		2025-06-28
PL37CzvwiWXoiREv1SJdUljhDtROa4blHG	UC1YCxISkweN5vLsOJ0zElZQ	1	Pinnacle Cup Dota 2 - $100.000 Tournament		2025-06-28
PL37CzvwiWXojA6O2gQ6gOI_JA5OWKWfnj	UC1YCxISkweN5vLsOJ0zElZQ	1	Dota Pro Circuit 2021: Season 2		2025-06-28
PL37CzvwiWXogYGuN3iv4eLI-K8mszHI0U	UC1YCxISkweN5vLsOJ0zElZQ	1	ONE Esports Singapore Major 2021		2025-06-28
PL37CzvwiWXog9WVM_Pz9TH7iXqI9yZKKh	UC1YCxISkweN5vLsOJ0zElZQ	1	The Dota Pro Circuit Winter 2021 Season		2025-06-28
PL37CzvwiWXohCf9-PkNafzXoASaDO52WE	UC1YCxISkweN5vLsOJ0zElZQ	1	BEST OF 2020 DOTA 2		2025-06-28
PL37CzvwiWXojiueigm7IdyUTmyTfqu42e	UC1YCxISkweN5vLsOJ0zElZQ	1	EPIC League Division 1 - BEST Plays, BEST Moments, BEST Highlights		2025-06-28
PL37CzvwiWXogW-w9QroA3M_FESOuR6q8S	UC1YCxISkweN5vLsOJ0zElZQ	1	ESL One Germany 2020 - Best Plays, MOST EPIC Moments		2025-06-28
PL37CzvwiWXoi8oW_KHO2JZgmgwQKQfUXx	UC1YCxISkweN5vLsOJ0zElZQ	1	OMEGA League Europe Immortal by WePlay!		2025-06-28
PL37CzvwiWXogFM18ho0nq96qqzAC0b7CY	UC1YCxISkweN5vLsOJ0zElZQ	1	The International 2020 - BATTLE PASS COMPENDIUM, GAMEPLAY & MORE!		2025-06-28
PL37CzvwiWXoiMxdsq-waYlGDeQ9AsZkRQ	UC1YCxISkweN5vLsOJ0zElZQ	1	ESL One Birmingham 2020		2025-06-28
PL37CzvwiWXohGj3CZeqWmLM8vf37F7WAj	UC1YCxISkweN5vLsOJ0zElZQ	1	ESL One Los Angeles 2020		2025-06-28
PL37CzvwiWXogLoWlNFnaRwL9kHQmuZezr	UC1YCxISkweN5vLsOJ0zElZQ	1	7.25 PATCH - GAMEPLAY, UPDATES, TIPS, TRICKS & WOMBO COMBOS !!		2025-06-28
PL37CzvwiWXojkbftrCJwWxDzCoVDD6C9Q	UC1YCxISkweN5vLsOJ0zElZQ	1	LEIPZIG MAJOR DreamLeague 13 Dota 2		2025-06-28
PL37CzvwiWXoix7VwaWJRtOu0ORv-Uz9z0	UC1YCxISkweN5vLsOJ0zElZQ	1	DOTA 2 - WHEN PROS ENTER 200 IQ MODE!		2025-06-28
PL37CzvwiWXoievPVStdsgoAgGlHsnoSd4	UC1YCxISkweN5vLsOJ0zElZQ	1	BEST OF 2019 DOTA 2		2025-06-28
PL37CzvwiWXohNXoZreLEL2NxM6XTqIElP	UC1YCxISkweN5vLsOJ0zElZQ	1	Dota 2 NEW 7.23 Patch Gameplay Update + NEW HEROS		2025-06-28
PL37CzvwiWXohbc53UC89ZaWNGumhZSjuA	UC1YCxISkweN5vLsOJ0zElZQ	1	MDL Chengdu Major by Mars Media		2025-06-28
PL37CzvwiWXogT3IVPpJlNxrcxjUi4hkZr	UC1YCxISkweN5vLsOJ0zElZQ	1	The International 2019 - Dota 2 (BEST Plays, BEST Moments)		2025-06-28
PL37CzvwiWXohL8va30SZk4h6uV6CIgRTv	UC1YCxISkweN5vLsOJ0zElZQ	1	Dota 2 NEW 7.22 Patch Gameplay Update		2025-06-28
PL37CzvwiWXohIEPh8ChLVE_If90TDJul1	UC1YCxISkweN5vLsOJ0zElZQ	1	MDL Disneyland® Paris Major Dota 2		2025-06-28
PL37CzvwiWXohTlcCIOpjPPizDUnsSS9_U	UC1YCxISkweN5vLsOJ0zElZQ	1	Dota 2 - Fails of the Week: Season 1		2025-06-28
PL37CzvwiWXoiipa_O4zrFtCu1glz7Kmog	UC1YCxISkweN5vLsOJ0zElZQ	1	Dota 2 - Fails of the Week: Season 1		2025-06-28
PL37CzvwiWXoisvQu159RdM24dbo3MPBPS	UC1YCxISkweN5vLsOJ0zElZQ	1	Dota 2 Weekly - The Art of hexOr: Season 1		2025-06-28
PL37CzvwiWXojNKoLNimlS5ch76sMeeZeQ	UC1YCxISkweN5vLsOJ0zElZQ	1	BEST OF 2018 - DOTA 2		2025-06-28
PL37CzvwiWXohoiO8E-t0avXn2vYA43n1T	UC1YCxISkweN5vLsOJ0zElZQ	1	Dota 2 NEW 7.20 Patch Gameplay Update		2025-06-28
PL37CzvwiWXoiE_bMMqUvhU_Y9FMizzuVL	UC1YCxISkweN5vLsOJ0zElZQ	1	The International 2018 - Dota 2		2025-06-28
PL37CzvwiWXoiei2ffH_zm8Eusg7GChtk9	UC1YCxISkweN5vLsOJ0zElZQ	1	7.07 Dueling Fates Patch Update - Dota 2		2025-06-28
PL37CzvwiWXohxeL8yPnUDpDIr85h99p3Z	UC1YCxISkweN5vLsOJ0zElZQ	1	The International 2017 - Dota 2		2025-06-28
PL37CzvwiWXojvnt1MVn6SRmY1dYDf-hqH	UC1YCxISkweN5vLsOJ0zElZQ	1	7.06 PATCH UPDATE Dota 2 - ALL CHANGES!		2025-06-28
PL37CzvwiWXoj_4wzyXjOE_9NiofqHn1Ts	UC1YCxISkweN5vLsOJ0zElZQ	1	Dota 2 EPIC Reddit Series		2025-06-28
PL37CzvwiWXoglrBfCksKbeZQcXHYRYof1	UC1YCxISkweN5vLsOJ0zElZQ	1	Dota 2 - Kiev Major 2017		2025-06-28
PL37CzvwiWXoicPyE5N-HefmZJIA2W2C4h	UC1YCxISkweN5vLsOJ0zElZQ	1	7.00 PATCH UPDATE Dota 2 - ALL CHANGES!		2025-06-28
PL37CzvwiWXog4JXAtB2omZTjW2P8-Bdf-	UC1YCxISkweN5vLsOJ0zElZQ	1	The Boston Major 2016		2025-06-28
PL37CzvwiWXoi7IRayTSzhExL9yMZYCprb	UC1YCxISkweN5vLsOJ0zElZQ	1	DOTA 2 - THE BEST MOVIES ON YOUTUBE		2025-06-28
PL37CzvwiWXoj--wgBRTzGJAMPHPGo6Ssu	UC1YCxISkweN5vLsOJ0zElZQ	1	DOTA 2 - PRO RAMPAGES		2025-06-28
PL37CzvwiWXogKIUMOizH0imsrRvd6JUku	UC1YCxISkweN5vLsOJ0zElZQ	1	DOTA 2 - THE ART OF / COMMUNITY SERIES		2025-06-28
PL37CzvwiWXoiGWUeOQ1vY4fIwT5dQrbGd	UC1YCxISkweN5vLsOJ0zElZQ	1	DOTA 2 - THE INTERNATIONAL 2016 - PLAYLIST		2025-06-28
PL37CzvwiWXohg5pULHZtem_-aX46_ek0E	UC1YCxISkweN5vLsOJ0zElZQ	1	ESL One Frankfurt 2016		2025-06-28
PL37CzvwiWXogUWxflHZEFG99S_tpe26vK	UC1YCxISkweN5vLsOJ0zElZQ	1	6.87 Patch Changes Dota 2		2025-06-28
PL37CzvwiWXogGAhnk8IVREROzyAvXwu8s	UC1YCxISkweN5vLsOJ0zElZQ	1	MOST EPIC PLAYS in Dota 2 History + BEST 2017 Compilations		2025-06-28
PL37CzvwiWXoj8JtUAKb-lPZ7YgKn6_A8n	UC1YCxISkweN5vLsOJ0zElZQ	1	6.86 Patch Changes Dota 2 Update		2025-06-28
PL37CzvwiWXoitpXzJpvRqO8ifwPViUiKZ	UC1YCxISkweN5vLsOJ0zElZQ	1	Dota 2 - Top 10 Pro Rampage		2025-06-28
PL37CzvwiWXois67KHDE7LMZ-jOC5PW2u-	UC1YCxISkweN5vLsOJ0zElZQ	1	The Frankfurt Major 2015 Dota 2		2025-06-28
PL37CzvwiWXog5plmTtisKvzlZ7EY4ozdH	UC1YCxISkweN5vLsOJ0zElZQ	1	Dota 2 Short Film Contest Entry		2025-06-28
PL37CzvwiWXohusbSYM6D35j5X1zoEHoBy	UC1YCxISkweN5vLsOJ0zElZQ	1	Dota 2 - The Art of Invoker & The Art of Rubick		2025-06-28
PL37CzvwiWXojOUOpjE4TiuOfIxtJxYIZS	UC1YCxISkweN5vLsOJ0zElZQ	1	Dota 2 - The International 2015		2025-06-28
PL37CzvwiWXoj56hv5ymwVTm3NAqAOd0v5	UC1YCxISkweN5vLsOJ0zElZQ	1	Dota 2 - The Art of Pudge & The Art of hexOr		2025-06-28
PL37CzvwiWXogGYPci5QossGQTYskU-2ys	UC1YCxISkweN5vLsOJ0zElZQ	1	6.84 Patch Changes Dota 2 Update		2025-06-28
PL37CzvwiWXojfc62SJJGey3te8erihbCP	UC1YCxISkweN5vLsOJ0zElZQ	1	Dota 2 - Rampage Friday &  PRO Rampages		2025-06-28
PL37CzvwiWXoirtQ9v_Aeuonb226yVpiXr	UC1YCxISkweN5vLsOJ0zElZQ	1	Dota 2 - hexOr playing Pudge - Gameplay Highlights		2025-06-28
PL37CzvwiWXoiV42LD-PpbVJMabgQU5Egp	UC1YCxISkweN5vLsOJ0zElZQ	1	6.82 Changes Dota 2 Patch Update		2025-06-28
PL37CzvwiWXohCxqv80zlfT2BnbFBNaJv_	UC1YCxISkweN5vLsOJ0zElZQ	1	Dota 2 High Five & The Art of Rubick [Red Bull Weekly]		2025-06-28
PL37CzvwiWXog5B6V-DhUDhZhmD58rl8n8	UC1YCxISkweN5vLsOJ0zElZQ	1	Dota 2 - Tutorials, Guides & Tricks		2025-06-28
PL37CzvwiWXog33PfLHvbbfJ5uNlWwIUgk	UC1YCxISkweN5vLsOJ0zElZQ	1	Dota 2 - Big Plays Weekly & Wombo Combo		2025-06-28
PL37CzvwiWXogRmzznhjKIbuifD8FkL_6Z	UC1YCxISkweN5vLsOJ0zElZQ	1	Dota 2 - Failing Time! (Fun stuff)		2025-06-28
PL37CzvwiWXoj_TC_Hy7osfxCXEUGc2tdw	UC1YCxISkweN5vLsOJ0zElZQ	1	Dota 2 - Pro Player Tributes		2025-06-28
PL37CzvwiWXojOFa4mh8QE61HNQRPpiLW7	UC1YCxISkweN5vLsOJ0zElZQ	1	Dota 2 - Pro Team Movies		2025-06-28
PL37CzvwiWXoiUT9IZ6UVyAcxTXvcT7m54	UC1YCxISkweN5vLsOJ0zElZQ	1	Dota 2 - The International 2,3 & 4 -  Tournament Movies / Gameplay Movies / Mini-Clips		2025-06-28
PL37CzvwiWXogpR95PD-h6G7kOExmvwXtc	UC1YCxISkweN5vLsOJ0zElZQ	1	DotA Movies		2025-06-28
PL37CzvwiWXoi_57V6ES0UX14bI9GqlCI8	UC1YCxISkweN5vLsOJ0zElZQ	1	Dota 2 - Pudge by hexOr		2025-06-28
PL37CzvwiWXoh6_omRsq6w9bd8CciUbKfL	UC1YCxISkweN5vLsOJ0zElZQ	1	Dota 2 - The International 2		2025-06-28
PL37CzvwiWXoiA171-Aq-okeltJpjuu7te	UC1YCxISkweN5vLsOJ0zElZQ	1	Dota 2 - SFM Movies		2025-06-28
PL37CzvwiWXoiFESSd19H6PRr9HZTiieB9	UC1YCxISkweN5vLsOJ0zElZQ	1	Dota 2 Movies & Trailers		2025-06-28
PL37CzvwiWXoi7tYNzf0g_yzCz4AgEU_h-	UC1YCxISkweN5vLsOJ0zElZQ	1	Dota 2 - Luck is no Excuse Series		2025-06-28
PL37CzvwiWXoij0gxbvrlUd_uOMcPp48DY	UC1YCxISkweN5vLsOJ0zElZQ	1	Dota 2 Highlights, Live Footage, Trailers, Mini Clips, SFM & Miscellaneous Dota 2 Stuff		2025-06-28
PL37CzvwiWXohz8CEyi_-gTZAwiUkuTUij	UC1YCxISkweN5vLsOJ0zElZQ	1	Dubai Tour 2012		2025-06-28
PLFD0BA4B8E3F91F54	UC1YCxISkweN5vLsOJ0zElZQ	1	Dota 2 Weekly - The Art of Juking / The Art of hexOr		2025-06-28
PLeU5--flcXCD9t6I-rgfDVCp5e6HLmwo3	UCYWvw17IQl_prkX93IhjuKQ	1	Dota 2 fun builds		2025-06-28
PLeU5--flcXCAYuyXgCFRwzfD9vux0UT7g	UCYWvw17IQl_prkX93IhjuKQ	1	Dota 2 Moments		2025-06-28
PLeU5--flcXCAm9IlHNElaUgq2rsEPrWo1	UCYWvw17IQl_prkX93IhjuKQ	1	Dota 2 Clips		2025-06-28
PLeU5--flcXCBYZg4-AFQRcjW8wtiy4hD6	UCYWvw17IQl_prkX93IhjuKQ	1	Dota 2 1v1		2025-06-28
PLMGd3JHzJBId135yFJkTYlJjJE-DvA7_y	UCdk_9kcWld5UvflPR3W7A2w	1	Immortal Game		2025-06-28
PLMGd3JHzJBId09IE5oNC8W2rF8-69ZSQJ	UCdk_9kcWld5UvflPR3W7A2w	1	Anti Mage		2025-06-28
PLMGd3JHzJBIeKTUa2uqDV6zlW1h6MZpXd	UCdk_9kcWld5UvflPR3W7A2w	1	Pure		2025-06-28
PLMGd3JHzJBIf0pNOFTZo5TLnxiMvTRe22	UCdk_9kcWld5UvflPR3W7A2w	1	Parker		2025-06-28
PLMGd3JHzJBId5YYZENtIwkky9KMriQZd_	UCdk_9kcWld5UvflPR3W7A2w	1	Satanic		2025-06-28
PLMGd3JHzJBIdFbOfCMf0G_cHi9mI1KvNd	UCdk_9kcWld5UvflPR3W7A2w	1	Malr1ne		2025-06-28
PLMGd3JHzJBIcNXHHl0OEVJv3TkGPglvtV	UCdk_9kcWld5UvflPR3W7A2w	1	WS		2025-06-28
PLMGd3JHzJBIcKwGYpB0BEna_usRKw9mk9	UCdk_9kcWld5UvflPR3W7A2w	1	LARL		2025-06-28
PLMGd3JHzJBIcqAYak8KK1bir7ZothphT7	UCdk_9kcWld5UvflPR3W7A2w	1	KIYOTAKA		2025-06-28
PLMGd3JHzJBIewlwnnnCy77XeoXmwtx0ef	UCdk_9kcWld5UvflPR3W7A2w	1	MIKEY		2025-06-28
PLMGd3JHzJBIc6wUkYNsjorTZ3EWd5-cnC	UCdk_9kcWld5UvflPR3W7A2w	1	SKITER		2025-06-28
PLMGd3JHzJBIckWOZupVsTM1mIjsANuiiJ	UCdk_9kcWld5UvflPR3W7A2w	1	Shorts		2025-06-28
PLMGd3JHzJBIdee65YZXZgczAkY-rgUdzU	UCdk_9kcWld5UvflPR3W7A2w	1	WATSON		2025-06-28
PLMGd3JHzJBIdWsuiGj286gtw837sxrNF3	UCdk_9kcWld5UvflPR3W7A2w	1	YURAGI		2025-06-28
PLMGd3JHzJBIcHs5PJDQzs7cL9vBK5XRgM	UCdk_9kcWld5UvflPR3W7A2w	1	PAKAZS		2025-06-28
PLMGd3JHzJBIczKOPeGnqFqJpenRQH7dzb	UCdk_9kcWld5UvflPR3W7A2w	1	miCKe		2025-06-28
PLMGd3JHzJBIe0g4huS1FLiOsJ9Fu_yD2l	UCdk_9kcWld5UvflPR3W7A2w	1	Faith Bian		2025-06-28
PLMGd3JHzJBIdzhPQopUgBDnJ6RSiCi2oW	UCdk_9kcWld5UvflPR3W7A2w	1	ATF		2025-06-28
PLMGd3JHzJBIeqqMUy9nd5lLVVNr8oQC4_	UCdk_9kcWld5UvflPR3W7A2w	1	BZM		2025-06-28
PLMGd3JHzJBIfOjtNEdKc6WP10L6tP2r24	UCdk_9kcWld5UvflPR3W7A2w	1	GOD KING		2025-06-28
PLMGd3JHzJBIeTaG1AqDO7jcxGVPJbMNGO	UCdk_9kcWld5UvflPR3W7A2w	1	MIKOTO		2025-06-28
PLMGd3JHzJBIf5Q0UqAh827VqQ0atGjV-x	UCdk_9kcWld5UvflPR3W7A2w	1	COLLAPSE		2025-06-28
PLMGd3JHzJBIcTCF5_TCu2FKR98zEe9491	UCdk_9kcWld5UvflPR3W7A2w	1	BIZIEM		2025-06-28
PLMGd3JHzJBIf7IxVj_JUA2ddRNJHokAC8	UCdk_9kcWld5UvflPR3W7A2w	1	MONET		2025-06-28
PLMGd3JHzJBId1qXsRCPGAwb1oIbPExjJM	UCdk_9kcWld5UvflPR3W7A2w	1	XinQ		2025-06-28
PLMGd3JHzJBIe64sOgbMdiaB9RZUVXtIAM	UCdk_9kcWld5UvflPR3W7A2w	1	Xiao8		2025-06-28
PLMGd3JHzJBIdmlRw74UnG2mjrHbWrdRp6	UCdk_9kcWld5UvflPR3W7A2w	1	Yatoro		2025-06-28
PLMGd3JHzJBIcc5snrPopvWgsjeOtua0PG	UCdk_9kcWld5UvflPR3W7A2w	1	EMO		2025-06-28
PLMGd3JHzJBIcoaEj7QCQEIDePNsZaq2KW	UCdk_9kcWld5UvflPR3W7A2w	1	NothingToSay		2025-06-28
PLMGd3JHzJBIcKkG2huLnXGHSO6i2Nwyd6	UCdk_9kcWld5UvflPR3W7A2w	1	SaberLight		2025-06-28
PLMGd3JHzJBIf5YkxeOQjy58gQJ03DAbxN	UCdk_9kcWld5UvflPR3W7A2w	1	GPK		2025-06-28
PLMGd3JHzJBIcs5qezfvUgta9e2d7eM8SP	UCdk_9kcWld5UvflPR3W7A2w	1	COOMAN		2025-06-28
PLMGd3JHzJBIf9D-HQ57MxAZjwzKuzj8MW	UCdk_9kcWld5UvflPR3W7A2w	1	Chris Luck		2025-06-28
PLMGd3JHzJBIf_7EnHqhf2nTIjM7m-MSGi	UCdk_9kcWld5UvflPR3W7A2w	1	NIKOBABY		2025-06-28
PLMGd3JHzJBIdvWEwov3tP1yI5MaGQw3Ck	UCdk_9kcWld5UvflPR3W7A2w	1	NightFall		2025-06-28
PLMGd3JHzJBIezBgvFwJM0mID2NtT4jS95	UCdk_9kcWld5UvflPR3W7A2w	1	CHALICE		2025-06-28
PLMGd3JHzJBIfE-2O4MrDqQUAzwzHVH3QO	UCdk_9kcWld5UvflPR3W7A2w	1	The International 2019		2025-06-28
PLMGd3JHzJBIfWHXWrkG9LbGP9mQt3sSNb	UCdk_9kcWld5UvflPR3W7A2w	1	Gunnar		2025-06-28
PLMGd3JHzJBIeQhglN5Nl5PLdQUJjV9Y1_	UCdk_9kcWld5UvflPR3W7A2w	1	DeMon		2025-06-28
PLMGd3JHzJBIfBrtNrJrhuqBZw4i1QrvmY	UCdk_9kcWld5UvflPR3W7A2w	1	23savage		2025-06-28
PLMGd3JHzJBIdA409GVUi-JsDWqlE9FR9X	UCdk_9kcWld5UvflPR3W7A2w	1	Ceb		2025-06-28
PLMGd3JHzJBId--GawLRV2_U0IRYNUwKK1	UCdk_9kcWld5UvflPR3W7A2w	1	Bryle		2025-06-28
PLMGd3JHzJBIePTMLCztbuPnhLr8PwSW-u	UCdk_9kcWld5UvflPR3W7A2w	1	Mage-		2025-06-28
PLMGd3JHzJBIeioVnmffVA2xJE59DTW6TR	UCdk_9kcWld5UvflPR3W7A2w	1	Nine		2025-06-28
PLMGd3JHzJBIflPjvj8Z3sAkd8qTFKkUqh	UCdk_9kcWld5UvflPR3W7A2w	1	CCnC		2025-06-28
PLMGd3JHzJBId0o9yAmENIDGT48drd3n6g	UCdk_9kcWld5UvflPR3W7A2w	1	Nisha		2025-06-28
PLMGd3JHzJBIelHFuQn5wuf71H3hlEfrIV	UCdk_9kcWld5UvflPR3W7A2w	1	TOPSON		2025-06-28
PLMGd3JHzJBIdr2kScWrFBl5Li2E7UOMmI	UCdk_9kcWld5UvflPR3W7A2w	1	Qupe		2025-06-28
PLMGd3JHzJBIdYirAOgw5WO3Q0vJS6lZz4	UCdk_9kcWld5UvflPR3W7A2w	1	Funn1k		2025-06-28
PLMGd3JHzJBIdjpg5d8PeF_-6slKpTgr98	UCdk_9kcWld5UvflPR3W7A2w	1	7ckngMad		2025-06-28
PLMGd3JHzJBIeF7QHtt47u4PjK8DHAG9xs	UCdk_9kcWld5UvflPR3W7A2w	1	Agressif		2025-06-28
PLMGd3JHzJBIdgd77ZRB1I-ToGw84VzPiu	UCdk_9kcWld5UvflPR3W7A2w	1	SOLO 1v1 DAC 2018		2025-06-28
PLMGd3JHzJBIcpVGcZymRzwmGhkbT74E9l	UCdk_9kcWld5UvflPR3W7A2w	1	Sylar		2025-06-28
PLMGd3JHzJBIceegt1ACoqXlVR5xI--YhQ	UCdk_9kcWld5UvflPR3W7A2w	1	Gorgc		2025-06-28
PLMGd3JHzJBIfWJONdadaXUV9YnSsSlvTE	UCdk_9kcWld5UvflPR3W7A2w	1	Armel		2025-06-28
PLMGd3JHzJBIdvULtkXgxJwBZfhH8XU9NE	UCdk_9kcWld5UvflPR3W7A2w	1	The Bucharest Major		2025-06-28
PLMGd3JHzJBIfEHvvqdq9J2WEzChz5bCNX	UCdk_9kcWld5UvflPR3W7A2w	1	Raven		2025-06-28
PLMGd3JHzJBIeA01NqoAGrMhnnJP1xe4UQ	UCdk_9kcWld5UvflPR3W7A2w	1	ESL One Genting 2018		2025-06-28
PLMGd3JHzJBIe9-i_YQe0wVBFUAsMGtrGm	UCdk_9kcWld5UvflPR3W7A2w	1	Ori		2025-06-28
PLMGd3JHzJBIduAxnI-3aSwLWqKCur_VOQ	UCdk_9kcWld5UvflPR3W7A2w	1	kingr		2025-06-28
PLMGd3JHzJBIdghyjlmBmG4weiKPisVmXl	UCdk_9kcWld5UvflPR3W7A2w	1	iltw		2025-06-28
PLMGd3JHzJBIc3E2_oCt2EtZXDLuCoe7aj	UCdk_9kcWld5UvflPR3W7A2w	1	syndereN		2025-06-28
PLMGd3JHzJBIcK0fvGPx-mPbMayxobdeW8	UCdk_9kcWld5UvflPR3W7A2w	1	Crystallize		2025-06-28
PLMGd3JHzJBIdos4Tax3o1nyglxiPkB8BO	UCdk_9kcWld5UvflPR3W7A2w	1	DREAMLEAGUE SEASON 8 MAJOR		2025-06-28
PLMGd3JHzJBIff1r0IgyIWQ1VJxq_y0-Kk	UCdk_9kcWld5UvflPR3W7A2w	1	TIMADO		2025-06-28
PLMGd3JHzJBIdFoVSnDMv4EscGU0IGVxby	UCdk_9kcWld5UvflPR3W7A2w	1	MIDAS MODE 2017		2025-06-28
PLMGd3JHzJBIc4hQP6ARqqIambPKHE5Xfs	UCdk_9kcWld5UvflPR3W7A2w	1	AME		2025-06-28
PLMGd3JHzJBIcIKWCrq2TrjPwyeiRbAOIn	UCdk_9kcWld5UvflPR3W7A2w	1	Scandal		2025-06-28
PLMGd3JHzJBIcuCLIu2nD1qeQkV7ia-Lx4	UCdk_9kcWld5UvflPR3W7A2w	1	Ah Jit		2025-06-28
PLMGd3JHzJBIcwahLDTxd4m9D1RJULBCqi	UCdk_9kcWld5UvflPR3W7A2w	1	The International 2017		2025-06-28
PLMGd3JHzJBIe6Cwkq-BpyXMbQ-Qpl3T3B	UCdk_9kcWld5UvflPR3W7A2w	1	Event Siltbreaker		2025-06-28
PLMGd3JHzJBIeomYBkzh2qhB2S2uWNWpNl	UCdk_9kcWld5UvflPR3W7A2w	1	Epicenter Season 2		2025-06-28
PLMGd3JHzJBIels8K741ESkYoaW7wu7Zxm	UCdk_9kcWld5UvflPR3W7A2w	1	Loda		2025-06-28
PLMGd3JHzJBIepATag7jzyoX-QwSaA0sFR	UCdk_9kcWld5UvflPR3W7A2w	1	DreamLeague 7		2025-06-28
PLMGd3JHzJBIfWSCimjOF7R9LLJKl4ki74	UCdk_9kcWld5UvflPR3W7A2w	1	Kiev Major 2017		2025-06-28
PLMGd3JHzJBIeriHA-dabdmHyVmVar--Zq	UCdk_9kcWld5UvflPR3W7A2w	1	Sumiya		2025-06-28
PLMGd3JHzJBIdes4rNFSfAL2JS7tWfAnfw	UCdk_9kcWld5UvflPR3W7A2w	1	Arise		2025-06-28
PLMGd3JHzJBIcj9q2VmTNM28ljZcoEuXxs	UCdk_9kcWld5UvflPR3W7A2w	1	Mind_Control		2025-06-28
PLMGd3JHzJBIdi7WQXpTNYSS7cprXgwJm_	UCdk_9kcWld5UvflPR3W7A2w	1	Jabz		2025-06-28
PLMGd3JHzJBId4NmA_SZder5sdPXQWs-1F	UCdk_9kcWld5UvflPR3W7A2w	1	Dota 2 Asia Championships 2017		2025-06-28
PLMGd3JHzJBIe40ecjrW_-78_T6eUdxiIu	UCdk_9kcWld5UvflPR3W7A2w	1	ZSMJ		2025-06-28
PLMGd3JHzJBIfOBsHL6qApOdc0kbry_fBD	UCdk_9kcWld5UvflPR3W7A2w	1	9k SEA inYourdreaM		2025-06-28
PLMGd3JHzJBIeBAO0o2bicxDsZrUYEK0SA	UCdk_9kcWld5UvflPR3W7A2w	1	GeneRaL		2025-06-28
PLMGd3JHzJBIfKRPCHWqS9WFGPvg-UmPb_	UCdk_9kcWld5UvflPR3W7A2w	1	Ace		2025-06-28
PLMGd3JHzJBIcJfhgdyLLvEmmVv0v5FYnj	UCdk_9kcWld5UvflPR3W7A2w	1	BabyKnight		2025-06-28
PLMGd3JHzJBIeSDZE2E4HYAWoG3KekGUrm	UCdk_9kcWld5UvflPR3W7A2w	1	MSS		2025-06-28
PLMGd3JHzJBIeTyG8026W6hXYAumwaKF0Z	UCdk_9kcWld5UvflPR3W7A2w	1	Yapzor		2025-06-28
PLMGd3JHzJBId_FSkEbXutQRvJf2eFr0bq	UCdk_9kcWld5UvflPR3W7A2w	1	KheZu		2025-06-28
PLMGd3JHzJBIeiCnp9SEgSKS_cy9U8Mrmo	UCdk_9kcWld5UvflPR3W7A2w	1	GH.GOD		2025-06-28
PLMGd3JHzJBIcOjJolA94N4u6xQ6xxq-Yr	UCdk_9kcWld5UvflPR3W7A2w	1	CemaTheSlayer		2025-06-28
PLMGd3JHzJBIccPmuM3HSpss0goTM_PuvM	UCdk_9kcWld5UvflPR3W7A2w	1	Lil		2025-06-28
PLMGd3JHzJBIfE-3gev2Z2ZemYazGgTnNY	UCdk_9kcWld5UvflPR3W7A2w	1	Zai		2025-06-28
PLMGd3JHzJBIcpwQvewKJML8Ubojc0H475	UCdk_9kcWld5UvflPR3W7A2w	1	Resolut1on		2025-06-28
PLMGd3JHzJBIe0K3D9dwwnzg_ePnRinRfn	UCdk_9kcWld5UvflPR3W7A2w	1	DreamLeague 6		2025-06-28
PLMGd3JHzJBIeQZEFpBZXbbpYHzx_XctFT	UCdk_9kcWld5UvflPR3W7A2w	1	Limmp		2025-06-28
PLMGd3JHzJBIfrI6TrnCQxQdkd2NqDl_Q1	UCdk_9kcWld5UvflPR3W7A2w	1	Puppey		2025-06-28
PLMGd3JHzJBIf1D0INpaOnGlPPmXSwP8pA	UCdk_9kcWld5UvflPR3W7A2w	1	Boston Major		2025-06-28
PLMGd3JHzJBIcGMo7dRazDPcNwigextsU5	UCdk_9kcWld5UvflPR3W7A2w	1	Ana		2025-06-28
PLMGd3JHzJBIeMkWmJUNf7H_SAZbZdaHqd	UCdk_9kcWld5UvflPR3W7A2w	1	Forev		2025-06-28
PLMGd3JHzJBIdU_VVvtjW1_jJ3D3qWqMcr	UCdk_9kcWld5UvflPR3W7A2w	1	Paparazi		2025-06-28
PLMGd3JHzJBIcPwUs0DSiWcvg-aXGJ-KMB	UCdk_9kcWld5UvflPR3W7A2w	1	Dota2 Allstar		2025-06-28
PLMGd3JHzJBIfCZh3BEKcR0XdCPMmSAVKI	UCdk_9kcWld5UvflPR3W7A2w	1	Yaphets		2025-06-28
PLMGd3JHzJBIfwLP6xyiLnNINS9xcVzXyS	UCdk_9kcWld5UvflPR3W7A2w	1	Yamateh		2025-06-28
PLMGd3JHzJBIc60vjWV5wtptRdQqITNjjI	UCdk_9kcWld5UvflPR3W7A2w	1	Sccc New Generation China Player !		2025-06-28
PLMGd3JHzJBIffRUw37BSokkvuoYg_Ymsk	UCdk_9kcWld5UvflPR3W7A2w	1	MOO		2025-06-28
PLMGd3JHzJBIfKpOBk359gqUnGTbZrAOZY	UCdk_9kcWld5UvflPR3W7A2w	1	Pajkatt		2025-06-28
PLMGd3JHzJBIdG5zmFhkiRgA6GcZt_PDRK	UCdk_9kcWld5UvflPR3W7A2w	1	Kuroky		2025-06-28
PLMGd3JHzJBIfw-OZIimD0uDtZrr1xmAWT	UCdk_9kcWld5UvflPR3W7A2w	1	Maybe		2025-06-28
PLMGd3JHzJBIfKEJLMhj1Uv6dBvG9zpF1C	UCdk_9kcWld5UvflPR3W7A2w	1	Smash		2025-06-28
PLMGd3JHzJBIeNSaQoVyCRKKWYsKRS9tqc	UCdk_9kcWld5UvflPR3W7A2w	1	ALOHADANCE		2025-06-28
PLMGd3JHzJBIdJXlYnhN3IXMz0nf4GiBGk	UCdk_9kcWld5UvflPR3W7A2w	1	Kpii		2025-06-28
PLMGd3JHzJBIdFgnHDB25M1JycITjZQ7ZE	UCdk_9kcWld5UvflPR3W7A2w	1	fn		2025-06-28
PLMGd3JHzJBIdEUD8W9ID4wHAO6JJ6OBd6	UCdk_9kcWld5UvflPR3W7A2w	1	Ti 6 Main Event		2025-06-28
PLMGd3JHzJBIcRSsJ_KBfqf6dTka-CjmLY	UCdk_9kcWld5UvflPR3W7A2w	1	Abed		2025-06-28
PLMGd3JHzJBIdoUXWncXuT9k93sgtqRrE8	UCdk_9kcWld5UvflPR3W7A2w	1	ChuaN		2025-06-28
PLMGd3JHzJBIdAv2dee-EdUM2weB2XPyEw	UCdk_9kcWld5UvflPR3W7A2w	1	Moon		2025-06-28
PLMGd3JHzJBIf5-GeSHJtEekq22Ske7KCT	UCdk_9kcWld5UvflPR3W7A2w	1	Ti 6 Group Stage		2025-06-28
PLMGd3JHzJBIcFuXrXYgrXo4RpJ078fqlm	UCdk_9kcWld5UvflPR3W7A2w	1	TI6 Wildcard Dota 2		2025-06-28
PLMGd3JHzJBIeclYCFyxl7XijRRFiKn_kp	UCdk_9kcWld5UvflPR3W7A2w	1	Xcalibur		2025-06-28
PLMGd3JHzJBIdUmPMh_VA_WXGay4ghnWCC	UCdk_9kcWld5UvflPR3W7A2w	1	Miracle- Professional Invoker		2025-06-28
PLMGd3JHzJBIdYhFnkXU9ZoUEUhwSWfOd8	UCdk_9kcWld5UvflPR3W7A2w	1	StarLadder i-League Season 2		2025-06-28
PLMGd3JHzJBIcIBUTrrIsKQV-zBgvKA2PO	UCdk_9kcWld5UvflPR3W7A2w	1	The Summit 5		2025-06-28
PLMGd3JHzJBIdYup_qlMG4sRdvO5suB1NW	UCdk_9kcWld5UvflPR3W7A2w	1	How to play with Dota2Highschool		2025-06-28
PLMGd3JHzJBIdGL-H8n_uIT6pcRpZiETj9	UCdk_9kcWld5UvflPR3W7A2w	1	Nanyang Championships		2025-06-28
PLMGd3JHzJBIc-eYW6GfSGAAbmtB4hRgys	UCdk_9kcWld5UvflPR3W7A2w	1	Madara		2025-06-28
PLMGd3JHzJBIdm17dceWFdE_yZ5I7My5tH	UCdk_9kcWld5UvflPR3W7A2w	1	TI6 OPEN QUALIFIER Dota 2		2025-06-28
PLMGd3JHzJBIdQbhkLNs8ymVpqfJ4B1gbm	UCdk_9kcWld5UvflPR3W7A2w	1	ESL One Frankfurt 2016		2025-06-28
PLMGd3JHzJBIeARU1Op4jUUYcA-yeWFfx9	UCdk_9kcWld5UvflPR3W7A2w	1	SingSing		2025-06-28
PLMGd3JHzJBIfFZixGM7SvxcmalY7AubjA	UCdk_9kcWld5UvflPR3W7A2w	1	633		2025-06-28
PLMGd3JHzJBIdAOo6EzYK508Tj7cKx6ppz	UCdk_9kcWld5UvflPR3W7A2w	1	BuLba		2025-06-28
PLMGd3JHzJBId5PyNCD7nCoUjTP28JBr2z	UCdk_9kcWld5UvflPR3W7A2w	1	Manila Major Dota 2		2025-06-28
PLMGd3JHzJBIfy4nBVj-Nvyt7aBJlz0O3r	UCdk_9kcWld5UvflPR3W7A2w	1	Aui_2000		2025-06-28
PLMGd3JHzJBIcD0RNYQ2kTd_UJNPim3_2R	UCdk_9kcWld5UvflPR3W7A2w	1	CanneL		2025-06-28
PLMGd3JHzJBIfPXZD0xTJ1BDkjjk0g-qho	UCdk_9kcWld5UvflPR3W7A2w	1	Meracle		2025-06-28
PLMGd3JHzJBIePAsl0sjxBqjVOPXACTRI0	UCdk_9kcWld5UvflPR3W7A2w	1	No[o]ne		2025-06-28
PLMGd3JHzJBIfkSeZHK_sJGJakgGp0gYGn	UCdk_9kcWld5UvflPR3W7A2w	1	s4		2025-06-28
PLMGd3JHzJBIev7cipZD5h6dBEu8v3Mkum	UCdk_9kcWld5UvflPR3W7A2w	1	Dota2 The Epic Battle		2025-06-28
PLMGd3JHzJBIcLzf5TKnYgZK54lAdYs8ID	UCdk_9kcWld5UvflPR3W7A2w	1	Crit-		2025-06-28
PLMGd3JHzJBIfSzI-qo-0emAhDlyQVQfX2	UCdk_9kcWld5UvflPR3W7A2w	1	!Attacker		2025-06-28
PLMGd3JHzJBIcguhnGayPeEz_lKTmjKtcu	UCdk_9kcWld5UvflPR3W7A2w	1	RAMZES666		2025-06-28
PLMGd3JHzJBIfDVxukrsTzQ7VF4dTjCRkp	UCdk_9kcWld5UvflPR3W7A2w	1	YawaR		2025-06-28
PLMGd3JHzJBIdnJSAhdItL45hCV0vpqxym	UCdk_9kcWld5UvflPR3W7A2w	1	10k MMR MidOne		2025-06-28
PLMGd3JHzJBIfyWLJMX7Vnqm7uIg_z843l	UCdk_9kcWld5UvflPR3W7A2w	1	MP		2025-06-28
PLMGd3JHzJBIeamFFDSC-J8YJQXA6bxtZL	UCdk_9kcWld5UvflPR3W7A2w	1	Black^		2025-06-28
PLMGd3JHzJBIfoCk--V8TOUfALfC2A6_af	UCdk_9kcWld5UvflPR3W7A2w	1	SoNNeikO		2025-06-28
PLMGd3JHzJBIcs2MJw3-Pi5cfRhKGQyH7w	UCdk_9kcWld5UvflPR3W7A2w	1	EnternalEnvy		2025-06-28
PLMGd3JHzJBIc2_ffEl3I2_9wYROCYShzH	UCdk_9kcWld5UvflPR3W7A2w	1	iceiceice		2025-06-28
PLMGd3JHzJBIeVuzPREH-q4OYf4LS72q_h	UCdk_9kcWld5UvflPR3W7A2w	1	Badman		2025-06-28
PLMGd3JHzJBIeHQaxfFU9ac00qjZHIXG--	UCdk_9kcWld5UvflPR3W7A2w	1	JerAx		2025-06-28
PLMGd3JHzJBIdN_nvW_e1vxZqrUTY_zTp8	UCdk_9kcWld5UvflPR3W7A2w	1	Oldman Fear		2025-06-28
PLMGd3JHzJBIdYlZGilzHmX9ufBf_MP_tC	UCdk_9kcWld5UvflPR3W7A2w	1	CTY		2025-06-28
PLMGd3JHzJBIcoFDXV97G7q4QjscyNuRj6	UCdk_9kcWld5UvflPR3W7A2w	1	Mushi-		2025-06-28
PLMGd3JHzJBIe2WC_60E9CShpV9VESbxPK	UCdk_9kcWld5UvflPR3W7A2w	1	Universe		2025-06-28
PLMGd3JHzJBIfW_zx19mmi4A9cod_U9ffs	UCdk_9kcWld5UvflPR3W7A2w	1	Teacher iG.Ferrari_430		2025-06-28
PLMGd3JHzJBIcul4WfIx0Yn0m7TiBgEPd-	UCdk_9kcWld5UvflPR3W7A2w	1	w33 Magical man!		2025-06-28
PLMGd3JHzJBIduGH6U9vnh1dOE9WHsUGay	UCdk_9kcWld5UvflPR3W7A2w	1	Teacher qojqva		2025-06-28
PLMGd3JHzJBIdGb1LsMMxhoz0jDXmGfMEF	UCdk_9kcWld5UvflPR3W7A2w	1	AdmiralBulldog TI WINNER!		2025-06-28
PLMGd3JHzJBIckrJ5MBFMfijFbCI_SLd-2	UCdk_9kcWld5UvflPR3W7A2w	1	BurNing		2025-06-28
PLMGd3JHzJBIedifl0FFk5iDOPLcqU2UnK	UCdk_9kcWld5UvflPR3W7A2w	1	Teacher Afoninje		2025-06-28
PLMGd3JHzJBIfGEFrzClUdnNZHebqdJQtJ	UCdk_9kcWld5UvflPR3W7A2w	1	Iceberg		2025-06-28
PLMGd3JHzJBIe8DL3MVlFnfmMjeD9ntfzK	UCdk_9kcWld5UvflPR3W7A2w	1	Teacher old chicken		2025-06-28
PLMGd3JHzJBIf5DS8kTCJuMUHX0LICaJKo	UCdk_9kcWld5UvflPR3W7A2w	1	Teacher SnithTV		2025-06-28
PLMGd3JHzJBIc8F_aM4fLrlu2D_9A4nVYy	UCdk_9kcWld5UvflPR3W7A2w	1	Teacher Solitude		2025-06-28
PLMGd3JHzJBIfYGoRHXOS9oWx7Cm4yPilV	UCdk_9kcWld5UvflPR3W7A2w	1	Teacher Lod[A]		2025-06-28
PLMGd3JHzJBId5hUeTmpov9XrizArvysfp	UCdk_9kcWld5UvflPR3W7A2w	1	QO		2025-06-28
PLMGd3JHzJBIfuzsPjSkHhZiyaOWutn2AZ	UCdk_9kcWld5UvflPR3W7A2w	1	Illidan Stormrage		2025-06-28
PLMGd3JHzJBIeeJqBTle8hdHtcd0c-oI4j	UCdk_9kcWld5UvflPR3W7A2w	1	Teacher Nofear		2025-06-28
PLMGd3JHzJBIfRRILJxoHGQh_GGpboMe9O	UCdk_9kcWld5UvflPR3W7A2w	1	SumaiL Surprised Boy		2025-06-28
PLMGd3JHzJBIfcCC9K_V_8aAmhaEXh3yKo	UCdk_9kcWld5UvflPR3W7A2w	1	Teacher Shachlo		2025-06-28
PLMGd3JHzJBIdxTUST8PUVXgEch1GDmCpV	UCdk_9kcWld5UvflPR3W7A2w	1	Saksa 10K MMR Support		2025-06-28
PLMGd3JHzJBIcjVTFoyb8e1NOA_BSPzi02	UCdk_9kcWld5UvflPR3W7A2w	1	Teacher Ditya-ra		2025-06-28
PLMGd3JHzJBIf0o1hj62dSrR701UfD9OoA	UCdk_9kcWld5UvflPR3W7A2w	1	Teacher Attacker!		2025-06-28
PLMGd3JHzJBIdd4sEA27Bf8ilADgWSwpbd	UCdk_9kcWld5UvflPR3W7A2w	1	Dendi, Oppa Legendary		2025-06-28
PLMGd3JHzJBIdArBgnk-gnEgNQ-Pnhg2Ui	UCdk_9kcWld5UvflPR3W7A2w	1	Wagamama TRYHARD EveryDay		2025-06-28
PLMGd3JHzJBIcr_l1e4WNwFrV2T7muVy2c	UCdk_9kcWld5UvflPR3W7A2w	1	NOTAIL - Bigdaddy		2025-06-28
PLMGd3JHzJBIcukoS8Xi4F3pc0ayDb9jma	UCdk_9kcWld5UvflPR3W7A2w	1	FATA-		2025-06-28
PLMGd3JHzJBIduYZzSvu2zU750ZdF67ON3	UCdk_9kcWld5UvflPR3W7A2w	1	Teacher Silent		2025-06-28
PLMGd3JHzJBIfpvBXSWBD5vBl_J0bgPtA1	UCdk_9kcWld5UvflPR3W7A2w	1	Teacher VP.G		2025-06-28
PLMGd3JHzJBIcEPGcSDhRaXpBxr4nIMfBu	UCdk_9kcWld5UvflPR3W7A2w	1	Miracle- 9k God !		2025-06-28
PLMGd3JHzJBIdwhKAI5vYyVTIl7LsfchdT	UCdk_9kcWld5UvflPR3W7A2w	1	MATUMBAMAN		2025-06-28
PLMGd3JHzJBIdn4lBAZtJ4ei-WOyVgIuRT	UCdk_9kcWld5UvflPR3W7A2w	1	Outworld Devourer		2025-06-28
PLMGd3JHzJBIfnyUWOiwo_Yc3clc2jYphV	UCdk_9kcWld5UvflPR3W7A2w	1	Arteezy SAD BOY - Baby RAGE		2025-06-28
PLpCDZUhRlepkdx_SMXbXWXALzvOnrk54x	UCaYLBJfw6d8XqmNlL204lNg	1	DreamLeague Season 26 Closed Qualifiers		2025-06-28
PLpCDZUhRleplcVlEmZnBhTaEz6C04FKzr	UCaYLBJfw6d8XqmNlL204lNg	1	ESL One: Unmuted		2025-06-28
PLpCDZUhRlepnbKW8xFbT0MCIueoHhL0g6	UCaYLBJfw6d8XqmNlL204lNg	1	ESL ONE BANGKOK 2024		2025-06-28
PLpCDZUhRlepkMPLRPXwUsOAOEdL3i9M4o	UCaYLBJfw6d8XqmNlL204lNg	1	DreamLeague Season 24		2025-06-28
PLpCDZUhRlepkbvdhSouJqbEyH_XOeoySR	UCaYLBJfw6d8XqmNlL204lNg	1	DreamLeague Season 24 Closed Qualifier		2025-06-28
PLpCDZUhRlepmuKuVIZPsIuOOpLGDXthsE	UCaYLBJfw6d8XqmNlL204lNg	1	ESL One Birmingham 2024		2025-06-28
PLpCDZUhRlepkyVew20dse9yIe-9eDDSJ8	UCaYLBJfw6d8XqmNlL204lNg	1	ESL DreamLeague S23		2025-06-28
PLpCDZUhRlepn4DybZa657P3oU8mBOhsFx	UCaYLBJfw6d8XqmNlL204lNg	1	ESL DreamLeague S22		2025-06-28
PLpCDZUhRlepmW2e4guzR2ub6eCy4T0JOd	UCaYLBJfw6d8XqmNlL204lNg	1	ESL One Birmingham 2024		2025-06-28
PLpCDZUhRleplZWfxjNFr33Iepy0BrQ9iD	UCaYLBJfw6d8XqmNlL204lNg	1	ESL One Kuala Lumpur 2023		2025-06-28
PLpCDZUhRlepm2I3TT6Q5gKgtqm879k9Up	UCaYLBJfw6d8XqmNlL204lNg	1	ESL DreamLeague S21		2025-06-28
PLpCDZUhRlepm4nvDbeba5QTjX2gMxgwb9	UCaYLBJfw6d8XqmNlL204lNg	1	ESL DreamLeague S20		2025-06-28
PLpCDZUhRlepkoLCsE8yNIVW_FsVyQpjk9	UCaYLBJfw6d8XqmNlL204lNg	1	NoobFromUA ESL Highlights		2025-06-28
PLpCDZUhRlepmYJApXsEa9XXU2Tuhn0bqm	UCaYLBJfw6d8XqmNlL204lNg	1	ESL One Berlin		2025-06-28
PLpCDZUhRlepkHnmxgQj_mQA-mP4BhHzUi	UCaYLBJfw6d8XqmNlL204lNg	1	1v1 hero duel		2025-06-28
PLpCDZUhRleplIq4ZRuPCSYM844Pa3vOOg	UCaYLBJfw6d8XqmNlL204lNg	1	ESL One Malaysia 2022		2025-06-28
PLpCDZUhRlepmklV_UYsOsuDKBoRmjDlLS	UCaYLBJfw6d8XqmNlL204lNg	1	Red Button Segments		2025-06-28
PLpCDZUhRlepnUlSpMPVKJkw41HmsU0N6s	UCaYLBJfw6d8XqmNlL204lNg	1	ESL One Stockholm 2022		2025-06-28
PLpCDZUhRlepkWPAijbTzQdoYsW0H-QX-N	UCaYLBJfw6d8XqmNlL204lNg	1	ESL One TL:DR Show (DPC Winter Tour 2021)		2025-06-28
PLpCDZUhRlepnRiqWoSJ72o-H56nSuxqwQ	UCaYLBJfw6d8XqmNlL204lNg	1	DHL Pro Tips		2025-06-28
PLpCDZUhRleplFAtWqJzzT7eyNXVEyfZ6O	UCaYLBJfw6d8XqmNlL204lNg	1	ESL One Summer		2025-06-28
PLpCDZUhRleplUWFfi8fcyVaDexlVWFfXb	UCaYLBJfw6d8XqmNlL204lNg	1	ESL One DPC CIS		2025-06-28
PLpCDZUhRlepl3VX_t4Ixy9bv5j9W98a9Y	UCaYLBJfw6d8XqmNlL204lNg	1	Mercedes-Benz Highlights for #ESLOne Germany 2020 Online		2025-06-28
PLpCDZUhRlepkk_pF_WSxxFF81lwp8wd6h	UCaYLBJfw6d8XqmNlL204lNg	1	Mercedes-Benz Contenders for #ESLOne Thailand 2020		2025-06-28
PLpCDZUhRlepnjiUQ4q2ReNgR8Rv3-YjQ1	UCaYLBJfw6d8XqmNlL204lNg	1	Mercedes-Benz Contenders for #ESLOne Birmingham 2020		2025-06-28
PLpCDZUhRlepnn-wpaMDTkzehYdtG8gCt2	UCaYLBJfw6d8XqmNlL204lNg	1	AT&T Pro Tips		2025-06-28
PLpCDZUhRlepnxBbqXSjMk0GppYPexuPPX	UCaYLBJfw6d8XqmNlL204lNg	1	Dota 2 - ESL One Hamburg 2019 Videos		2025-06-28
PLpCDZUhRlepkx6hEZDEoMlRVJxPL9Z5h2	UCaYLBJfw6d8XqmNlL204lNg	1	DHL feat. SirActionSlacks		2025-06-28
PLpCDZUhRleplVRGppqOnCQHj9iBvfeOfu	UCaYLBJfw6d8XqmNlL204lNg	1	Dota 2 - ESL One Birmingham 2019		2025-06-28
PLpCDZUhRleplgJ4xsyzRYzc0RYSi5-UbM	UCaYLBJfw6d8XqmNlL204lNg	1	Dota 2 - ESL One Mumbai 2019 - Power Plays		2025-06-28
PLpCDZUhRleplgs6OIrag1V4mOjUFxFpsF	UCaYLBJfw6d8XqmNlL204lNg	1	Dota 2 - Qualifiers | ESL One Mumbai 2019		2025-06-28
PLpCDZUhRleplJ2V1HPlDvY2ZSPRxg0rx4	UCaYLBJfw6d8XqmNlL204lNg	1	Dota 2 - ESL One Mumbai 2019		2025-06-28
PLpCDZUhRlepnVRC3fSFUkhzUm-tcsbwFe	UCaYLBJfw6d8XqmNlL204lNg	1	Dota 2 - ESL One Katowice 2019 - Power Plays		2025-06-28
PLpCDZUhRlepm4An2S3sH6gw-STHWfaVgU	UCaYLBJfw6d8XqmNlL204lNg	1	Dota 2 - Qualifiers | ESL One Katowice 2019		2025-06-28
PLpCDZUhRlepkvclZzxZBZRHlK5hpgWH_H	UCaYLBJfw6d8XqmNlL204lNg	1	Dota 2 | ESL One Katowice 2019		2025-06-28
PLpCDZUhRleplWFqutJ35hgekxV2rvfGYE	UCaYLBJfw6d8XqmNlL204lNg	1	Dota 2 - SEA Qualifier | ESL One Hamburg 2018		2025-06-28
PLpCDZUhRlepnOT-WJ67GccIqQJZySKT-K	UCaYLBJfw6d8XqmNlL204lNg	1	Dota 2 - EU Qualifier | ESL One Hamburg 2018		2025-06-28
PLpCDZUhRlepmHEq-RTdx9HoN-xQ8fcBz9	UCaYLBJfw6d8XqmNlL204lNg	1	Dota 2 - China Qualifier | ESL One Hamburg 2018		2025-06-28
PLpCDZUhRlepnUQ8Ps91rbWaegHm350L-1	UCaYLBJfw6d8XqmNlL204lNg	1	Dota 2 - NA Qualifier | ESL One Hamburg 2018		2025-06-28
PLpCDZUhRlepkNpIEmo8Ay-t9mJ7fvQB7I	UCaYLBJfw6d8XqmNlL204lNg	1	Dota 2 - ESL One Hamburg 2018		2025-06-28
PLpCDZUhRlepm1YPoD-XwyF6c7gQUhDlws	UCaYLBJfw6d8XqmNlL204lNg	1	Dota 2 - ESL One Birmingham 2018		2025-06-28
PLpCDZUhRlepkxEfCuauK9GHafJPph19mS	UCaYLBJfw6d8XqmNlL204lNg	1	Dota 2 - ESL One Katowice 2018		2025-06-28
PLpCDZUhRlepk0z6S1v_y-jhEtLItcGwGL	UCaYLBJfw6d8XqmNlL204lNg	1	Interviews & Backstage Fun		2025-06-28
PLpCDZUhRlepkU_CiyB8maarLhGjSEmXjZ	UCaYLBJfw6d8XqmNlL204lNg	1	Dota 2 - CN Qualifier - ESL One Katowice 2018		2025-06-28
PLpCDZUhRlepkgr-6w_zOXxhVJaC376Ecy	UCaYLBJfw6d8XqmNlL204lNg	1	Dota 2 - SA Qualifier - ESL One Katowice 2018		2025-06-28
PLpCDZUhRlepklADuurwIn1RMog2yf0jLy	UCaYLBJfw6d8XqmNlL204lNg	1	Dota 2 - NA Qualifier - ESL Katowice 2018		2025-06-28
PLpCDZUhRlepmkL2dwV8LjsULBfGoDdAia	UCaYLBJfw6d8XqmNlL204lNg	1	Dota 2 - CIS Qualifier - ESL Katowice 2018		2025-06-28
PLpCDZUhRlepnr9BMs8vYoYByhthZnAzFr	UCaYLBJfw6d8XqmNlL204lNg	1	Dota 2 - SEA Qualifier - ESL Katowice 2018		2025-06-28
PLpCDZUhRlepnMkqaWbSTSQwQ-H3jKV2D9	UCaYLBJfw6d8XqmNlL204lNg	1	Dota 2 - EU Qualifier - ESL One Katowice 2018		2025-06-28
PLpCDZUhRlepkWqUOlm7Mv2itr-pDjnteJ	UCaYLBJfw6d8XqmNlL204lNg	1	Dota 2 - CN Qualifier - ESL One Genting 2018		2025-06-28
PLpCDZUhRlepnXM_1ISofj-QK6L6Pgrvg3	UCaYLBJfw6d8XqmNlL204lNg	1	Dota 2 - NA Qualifier - ESL One Genting 2018		2025-06-28
PLpCDZUhRlepkaKXEzDJLA9mkIxxjgrEOO	UCaYLBJfw6d8XqmNlL204lNg	1	Dota 2 - EU Qualifier - ESL One Genting 2018		2025-06-28
PLpCDZUhRlepl4AlwLwyjuwBmZyH56y7Yj	UCaYLBJfw6d8XqmNlL204lNg	1	Dota 2 - SA Qualifier - ESL One Genting 2018		2025-06-28
PLpCDZUhRlepmSiPXjn7HyOlW_moB0GHb2	UCaYLBJfw6d8XqmNlL204lNg	1	Dota 2 - CIS Qualifier - ESL One Genting 2018		2025-06-28
PLpCDZUhRleplKHfwbuW1T2rP0bNQFzFNf	UCaYLBJfw6d8XqmNlL204lNg	1	Dota 2 - SEA Qualifier - ESL One Genting 2018		2025-06-28
PLpCDZUhRlepkVSX74--UGMgEGZ_ZlUjBC	UCaYLBJfw6d8XqmNlL204lNg	1	Dota 2 - Open Qualifier - ESL One Genting 2018		2025-06-28
PLpCDZUhRlepmh-GOAAvsBjccIDoWLE5D9	UCaYLBJfw6d8XqmNlL204lNg	1	Dota 2 - ESL One Hamburg Major 2017		2025-06-28
PLpCDZUhRleplo-YiESw9qhyj_Wx2xb40c	UCaYLBJfw6d8XqmNlL204lNg	1	Dota 2 - ESL One Katowice Major 2018		2025-06-28
PLpCDZUhRleplG589OWN7hBeR1MMbANXTc	UCaYLBJfw6d8XqmNlL204lNg	1	Dota 2 - ESL One Genting 2018		2025-06-28
PLpCDZUhRlepk25Y4YIFJUcqhuH1iX_S9G	UCaYLBJfw6d8XqmNlL204lNg	1	Dota 2 - CIS Qualifier | ESL One Hamburg 2017		2025-06-28
PLpCDZUhRlepnZhYLJTKtS62InbzxpQ8fw	UCaYLBJfw6d8XqmNlL204lNg	1	Dota 2 - SA Qualifier | ESL One Hamburg 2017		2025-06-28
PLpCDZUhRleplOTb4JjWuK1uTfGMdyisNg	UCaYLBJfw6d8XqmNlL204lNg	1	Dota 2 - NA Qualifier | ESL One Hamburg 2017		2025-06-28
PLpCDZUhRlepmGB_pyakkyQoaTGcr3ABDC	UCaYLBJfw6d8XqmNlL204lNg	1	Dota 2 - EU Qualifier | ESL One Hamburg 2017		2025-06-28
PLpCDZUhRleplz_slR8O8UT4RBo8bqTZ0W	UCaYLBJfw6d8XqmNlL204lNg	1	Dota 2 - SEA Qualifier | ESL One Hamburg 2017		2025-06-28
PLpCDZUhRlepl-D_ykwKiygH8dTa_InnL_	UCaYLBJfw6d8XqmNlL204lNg	1	Dota 2 - China Qualifier | ESL One Hamburg 2017		2025-06-28
PLpCDZUhRlepnia6GAtx3nPGlXAACGHu0J	UCaYLBJfw6d8XqmNlL204lNg	1	ESL One Hamburg 2017 - Qualifiers		2025-06-28
PLD-ZsSKclZfhKc8Blw4p8n5ut2kPJgb32	UCfsOfLvadg89Bx8Sv_6WERg	1	TI13 The International 2024 DOTA 2		2025-06-28
PLD-ZsSKclZfitqFtJZIP_W8Pl7LUHwbQt	UCfsOfLvadg89Bx8Sv_6WERg	1	Esports World Cup - Riyadh Masters 2024		2025-06-28
PLD-ZsSKclZfi1Ci1U5K04SJCsgy_FNyrC	UCfsOfLvadg89Bx8Sv_6WERg	1	ONE Esports Dota 2		2025-06-28
PLD-ZsSKclZfjjE5ch4gjM413unVFCtOOO	UCfsOfLvadg89Bx8Sv_6WERg	1	BEYOND EPIC		2025-06-28
PLD-ZsSKclZfjv8ToKaleuqyVAkPqLynPC	UCfsOfLvadg89Bx8Sv_6WERg	1	MDL MACAU 2019 - DOTA 2		2025-06-28
PLD-ZsSKclZfgYKZ993K9oauwLTuDix3Ra	UCfsOfLvadg89Bx8Sv_6WERg	1	CHONGQING MAJOR - 2019 DOTA 2		2025-06-28
PLD-ZsSKclZfjokXLPY9CIztiC05yGGHIw	UCfsOfLvadg89Bx8Sv_6WERg	1	THE INTERNATIONAL 8 #TI8 DOTA 2		2025-06-28
PLD-ZsSKclZfiJWu4d7HeaN6IAEeLRb_zp	UCfsOfLvadg89Bx8Sv_6WERg	1	SUMMIT 9 DOTA 2		2025-06-28
PLD-ZsSKclZfj_-lVrei4CT_HBT_iiRVXR	UCfsOfLvadg89Bx8Sv_6WERg	1	Midas Mode Dota 2		2025-06-28
PLD-ZsSKclZfiRBSdhOrzGMTjp1n8LSwKn	UCfsOfLvadg89Bx8Sv_6WERg	1	DREAMLEAGUE 8 MAJOR DOTA 2		2025-06-28
PLD-ZsSKclZfhYl9L27SBfnWdNU-FED6mx	UCfsOfLvadg89Bx8Sv_6WERg	1	STARLADDER I-LEAGUE INVITATIONAL 3 MINOR		2025-06-28
PLD-ZsSKclZfjMRXGAddbuoIl-QqQiYkv_	UCfsOfLvadg89Bx8Sv_6WERg	1	MidOne Dota 2		2025-06-28
PLD-ZsSKclZfgPg868wrBDyLRPmf9XWXel	UCfsOfLvadg89Bx8Sv_6WERg	1	The International 7 Dota 2		2025-06-28
PLD-ZsSKclZfhMgZ9tGO1iCzc_HeObBMZX	UCfsOfLvadg89Bx8Sv_6WERg	1	VP - THE SUMMIT 7 ALL HERO CHALLENGE		2025-06-28
PLD-ZsSKclZfjFqn2Wlu9eUV1aW6fD5aAD	UCfsOfLvadg89Bx8Sv_6WERg	1	Dota 2 - Kiev Major		2025-06-28
PLD-ZsSKclZfgEsOz0JJVy8P3MlbJoG97s	UCfsOfLvadg89Bx8Sv_6WERg	1	Boston Major Dota 2		2025-06-28
PLD-ZsSKclZfhFKJhJKVzI57BbkaAEK10n	UCfsOfLvadg89Bx8Sv_6WERg	1	TI6 Dota 2		2025-06-28
PLD-ZsSKclZfhCnON9nEuf_HQyh_GYCZqI	UCfsOfLvadg89Bx8Sv_6WERg	1	Shanghai Major Dota 2		2025-06-28
PLD-ZsSKclZfgBYVb6aBHxiTQBsTrBT3y1	UCfsOfLvadg89Bx8Sv_6WERg	1	Dota 2 - Comeback is Real		2025-06-28
PLD-ZsSKclZfgykXXXBmssuEuNRwdW1tRi	UCfsOfLvadg89Bx8Sv_6WERg	1	Nanyang Championships Dota 2		2025-06-28
PLD-ZsSKclZfgz9dgDKEAKvG0_276OmdZm	UCfsOfLvadg89Bx8Sv_6WERg	1	Comeback Dota 2		2025-06-28
PLD-ZsSKclZfj5Rf1BWZ7kNmX_gKJkm3D4	UCfsOfLvadg89Bx8Sv_6WERg	1	Dota 2 Reborn Bug		2025-06-28
PLD-ZsSKclZfi7_WnioXDqoVyex1CuT2TK	UCfsOfLvadg89Bx8Sv_6WERg	1	Dota 2 Disaster		2025-06-28
PLD-ZsSKclZfiJorI97tDenNXaE4sdr5Yy	UCfsOfLvadg89Bx8Sv_6WERg	1	ESL One Frankfurt 2015 Dota 2		2025-06-28
PLD-ZsSKclZfjCEJTornHknQwAA_qYr6-a	UCfsOfLvadg89Bx8Sv_6WERg	1	Techies Dota 2		2025-06-28
PLD-ZsSKclZfhZED5oSndWRq0mForNQIUX	UCfsOfLvadg89Bx8Sv_6WERg	1	The International 5 Dota 2 TI5		2025-06-28
PLD-ZsSKclZfhUzejvmkgUZZBT8-wR8OD2	UCfsOfLvadg89Bx8Sv_6WERg	1	Dota 2 Grand Finals		2025-06-28
PLD-ZsSKclZfgvk1K-KV4Xo3Kp5Y5JmTy1	UCfsOfLvadg89Bx8Sv_6WERg	1	DOTA 2 EPIC Submissions		2025-06-28
PLD-ZsSKclZfj3ZNCCLSgoMlU_kRfeT5YJ	UCfsOfLvadg89Bx8Sv_6WERg	1	SumaiL Dota 2		2025-06-28
PLD-ZsSKclZfjT5V5Skqqq6GRwzy1SXMpV	UCfsOfLvadg89Bx8Sv_6WERg	1	Dota 2 All Star Match		2025-06-28
PLD-ZsSKclZfguYj1D7AfkRMeguzbqDhi3	UCfsOfLvadg89Bx8Sv_6WERg	1	Team Secret Dota 2		2025-06-28
PLD-ZsSKclZfjD0Yrt7qUdkrIxXzlOOyUG	UCfsOfLvadg89Bx8Sv_6WERg	1	DAC 2015 Dota 2		2025-06-28
PLD-ZsSKclZfhv7Cn_ruZICBrwxsunp2Kj	UCfsOfLvadg89Bx8Sv_6WERg	1	Dota 2 Longest Games		2025-06-28
PLD-ZsSKclZfhgiNU2s-f6ibESeCEAyTWr	UCfsOfLvadg89Bx8Sv_6WERg	1	JerAx Dota 2		2025-06-28
PLD-ZsSKclZfgv_dehdbPeCBV9MtYbqINp	UCfsOfLvadg89Bx8Sv_6WERg	1	Dota 2 The Summit 2		2025-06-28
PLD-ZsSKclZfho8YKFzhhsSDcNvUDBQI18	UCfsOfLvadg89Bx8Sv_6WERg	1	Starladder 10 Dota 2		2025-06-28
PLD-ZsSKclZfgVGNxgvImw4jUJnXl1LLB6	UCfsOfLvadg89Bx8Sv_6WERg	1	ESL One New York		2025-06-28
PLD-ZsSKclZfh38zRyadoMeVnc7r8009py	UCfsOfLvadg89Bx8Sv_6WERg	1	qojqva Dota 2		2025-06-28
PLD-ZsSKclZfjrRzRmAVqgP__Tj2Rq8kR4	UCfsOfLvadg89Bx8Sv_6WERg	1	Megacreeps Dota 2		2025-06-28
PLD-ZsSKclZfhE_YgpYoJxnLWvctMq_de7	UCfsOfLvadg89Bx8Sv_6WERg	1	Xcalibur Dota 2		2025-06-28
PLD-ZsSKclZfjFmKPtRJYrxj75VVjK5ijp	UCfsOfLvadg89Bx8Sv_6WERg	1	Team Na`Vi Dota 2		2025-06-28
PLD-ZsSKclZfhHANX49O_GJoTeKZ6iBCSm	UCfsOfLvadg89Bx8Sv_6WERg	1	Team Alliance Dota 2		2025-06-28
PLD-ZsSKclZfhxFMjWbtXIuJmwejaJjK8v	UCfsOfLvadg89Bx8Sv_6WERg	1	Dreamhack Summer 2014 Dota 2		2025-06-28
PLD-ZsSKclZfih9EsFSAXO82A9X5eYhaqm	UCfsOfLvadg89Bx8Sv_6WERg	1	Epic Dota 2		2025-06-28
PLD-ZsSKclZfi_1pnLURvdoseo7QcBa807	UCfsOfLvadg89Bx8Sv_6WERg	1	Ferrari_430 Dota 2		2025-06-28
PLD-ZsSKclZfibLvwUW7lU_7NlnZUERflV	UCfsOfLvadg89Bx8Sv_6WERg	1	SingSing Dota 2		2025-06-28
PLD-ZsSKclZfjCrC2gFkxoOxpCWwjfOMZz	UCfsOfLvadg89Bx8Sv_6WERg	1	Puppey Dota 2		2025-06-28
PLD-ZsSKclZfj3hi4dsHy7-vOGgsO8YdyZ	UCfsOfLvadg89Bx8Sv_6WERg	1	n0tail Dota 2		2025-06-28
PLD-ZsSKclZfiKuJTAX5A85cPhSfc2vjCC	UCfsOfLvadg89Bx8Sv_6WERg	1	Enigma Dota 2		2025-06-28
PLD-ZsSKclZfgDofAtKeObTYa6bNWDymcZ	UCfsOfLvadg89Bx8Sv_6WERg	1	Kunkka Dota 2		2025-06-28
PLD-ZsSKclZfgMHv79Utp1xhp88-B0lBWe	UCfsOfLvadg89Bx8Sv_6WERg	1	Roshan Dota 2		2025-06-28
PLD-ZsSKclZfgUCK_4qrEwY4j3vxk7oP4y	UCfsOfLvadg89Bx8Sv_6WERg	1	Meepo Dota 2		2025-06-28
PLD-ZsSKclZfjsuX9mCjbMXbwxfE6ALUoI	UCfsOfLvadg89Bx8Sv_6WERg	1	Puck Gameplay Dota 2		2025-06-28
PLD-ZsSKclZfj1lfXzdzN5IGRlenxX3rNO	UCfsOfLvadg89Bx8Sv_6WERg	1	Queen of Pain Dota 2 Gameplay		2025-06-28
PLD-ZsSKclZfh5PK5fcQ2qtxTCzwEgHOqT	UCfsOfLvadg89Bx8Sv_6WERg	1	Dota 2 Pro Fails		2025-06-28
PLD-ZsSKclZfiBsoRor-jk3O0otIP8LcZn	UCfsOfLvadg89Bx8Sv_6WERg	1	ddz Dota 2		2025-06-28
PLD-ZsSKclZfgzONeneHfcO9i8ar_Rf97f	UCfsOfLvadg89Bx8Sv_6WERg	1	The International 4 Dota 2		2025-06-28
PLD-ZsSKclZfiYFz2NJI_SiCrzFU0Agewv	UCfsOfLvadg89Bx8Sv_6WERg	1	Starladder 9 Dota 2		2025-06-28
PLD-ZsSKclZfhjqXdhPCA-uMqUDm8WjpJ7	UCfsOfLvadg89Bx8Sv_6WERg	1	2 ez 4 Arteezy Dota 2		2025-06-28
PLD-ZsSKclZfgyFJVPAkGxkEfnq2RyFz3o	UCfsOfLvadg89Bx8Sv_6WERg	1	Base Race Dota 2		2025-06-28
PLD-ZsSKclZfgb1IyTLdlFGnP9EDFZ83vt	UCfsOfLvadg89Bx8Sv_6WERg	1	Tinker Dota 2		2025-06-28
PLD-ZsSKclZfgOdsCcoK1570Xg00X8Ge7G	UCfsOfLvadg89Bx8Sv_6WERg	1	Templar Assassin Dota 2		2025-06-28
PLD-ZsSKclZfiYQDCok-L7mgdMuN4Yts_e	UCfsOfLvadg89Bx8Sv_6WERg	1	DotaCinema Dota 2		2025-06-28
PLD-ZsSKclZfi070a85xYvCjg8JaYTFa_s	UCfsOfLvadg89Bx8Sv_6WERg	1	Darude Sandstorm Grand Finals Dota 2		2025-06-28
PLD-ZsSKclZfiwZXHqQDC9EYN-dOt_RaGF	UCfsOfLvadg89Bx8Sv_6WERg	1	Dota 2 RAMPAGE		2025-06-28
PLD-ZsSKclZfjpCvGYfvsFfZ0Q-i_qkQDK	UCfsOfLvadg89Bx8Sv_6WERg	1	SingSing Heaviest Games		2025-06-28
PLD-ZsSKclZfjh9vXhtC2A18XaOQ8Jt8L2	UCfsOfLvadg89Bx8Sv_6WERg	1	Starladder 8 Dota 2		2025-06-28
PLD-ZsSKclZfgmNJU2ufadq0FpgIXhLABv	UCfsOfLvadg89Bx8Sv_6WERg	1	Wisp Pro Gameplay Dota 2		2025-06-28
PLD-ZsSKclZfgbgxevYjb_IQwnwTm7_4Vx	UCfsOfLvadg89Bx8Sv_6WERg	1	Chinese Doto Best Doto		2025-06-28
PLD-ZsSKclZfjp0TnLzejakK22OKg_QH0S	UCfsOfLvadg89Bx8Sv_6WERg	1	Dota2 RaidCall EMS One		2025-06-28
PLD-ZsSKclZfi7w9pNwNyF_PmX3uBVzbPZ	UCfsOfLvadg89Bx8Sv_6WERg	1	Dreamhack Winter 2013 Dota 2		2025-06-28
PLD-ZsSKclZfj_XJZzhVMQooUyHgHJlKaA	UCfsOfLvadg89Bx8Sv_6WERg	1	MLG Columbus 2013 Dota 2		2025-06-28
PLD-ZsSKclZfj6FHRRD3DmWya2xC_bV54D	UCfsOfLvadg89Bx8Sv_6WERg	1	Dota 2 pub Kills Records.		2025-06-28
PLD-ZsSKclZfgQsoav732pcET_AJ5WClZk	UCfsOfLvadg89Bx8Sv_6WERg	1	Invoker gameplay		2025-06-28
PLD-ZsSKclZfg7HB3ah-n-Rx2EmLjs1naO	UCfsOfLvadg89Bx8Sv_6WERg	1	pudge gameplay		2025-06-28
PLD-ZsSKclZfiQhpImRzp0j6PBkL0vxWVi	UCfsOfLvadg89Bx8Sv_6WERg	1	Mass Divine Rapier Dota 2		2025-06-28
PLD-ZsSKclZfjyYrCL--u2m2CitTy0peDl	UCfsOfLvadg89Bx8Sv_6WERg	1	iceiceice Dota 2		2025-06-28
PLD-ZsSKclZfi72-DYOiYkJABqYUhmgorw	UCfsOfLvadg89Bx8Sv_6WERg	1	Starladder 7 Dota 2		2025-06-28
PLD-ZsSKclZfjITbbzAEouwSgWJxQixNVI	UCfsOfLvadg89Bx8Sv_6WERg	1	The International 3		2025-06-28
PLD-ZsSKclZfiuZx7p30KF0DwmKC2wJr7K	UCfsOfLvadg89Bx8Sv_6WERg	1	Raidcall Summer 2013 Dota 2		2025-06-28
PLD-ZsSKclZfjzjP8V4KtqvVX4WnxS7Wc_	UCfsOfLvadg89Bx8Sv_6WERg	1	The International Dota 2		2025-06-28
PLD-ZsSKclZfgypJ7vY_yGbAf1g2kkcU6g	UCfsOfLvadg89Bx8Sv_6WERg	1	Dendi Pudge		2025-06-28
PLD-ZsSKclZfh-dWq2kyiCOlLKvtlHqIoN	UCfsOfLvadg89Bx8Sv_6WERg	1	Dota 2 Pro Fails Pub		2025-06-28
PLD-ZsSKclZfhXPJUfMTydENVS17YcJ7gV	UCfsOfLvadg89Bx8Sv_6WERg	1	Templar Assassin Dota 2 Gameplay		2025-06-28
PLD-ZsSKclZfgWLUe742QQ5F7ogVmqfFyU	UCfsOfLvadg89Bx8Sv_6WERg	1	Invoker Dota 2 Gameplay		2025-06-28
PLD-ZsSKclZfgZ66vR6FVLdMBTWNh7vw8E	UCfsOfLvadg89Bx8Sv_6WERg	1	Pudge Dota 2 Gameplay		2025-06-28
PLD-ZsSKclZfgLoyrJduGgPa2EjSvW61tz	UCfsOfLvadg89Bx8Sv_6WERg	1	SingSing Dota 2		2025-06-28
PLD-ZsSKclZfhVsN4sVrQC24i9Cb2QXDJk	UCfsOfLvadg89Bx8Sv_6WERg	1	Invictus Gaming Dota 2		2025-06-28
PLD-ZsSKclZfhS7BlUVWsV7G4E6W5uXsgd	UCfsOfLvadg89Bx8Sv_6WERg	1	WebGL		2025-06-28
PLD-ZsSKclZfgfycKIyoflER36hEa7kjxf	UCfsOfLvadg89Bx8Sv_6WERg	1	Far Cry 3		2025-06-28
PLD-ZsSKclZfiqq8LTboKs7rCa1sBfIffO	UCfsOfLvadg89Bx8Sv_6WERg	1	AutoHotKey Tutorial		2025-06-28
PLD-ZsSKclZfgul4xohvO0YFOxcOT-A3op	UCfsOfLvadg89Bx8Sv_6WERg	1	Hitman Absolution		2025-06-28
PLD-ZsSKclZfgBFAPcSVH68ZC2Ahi5eUto	UCfsOfLvadg89Bx8Sv_6WERg	1	Chrome Experiments		2025-06-28
PLD-ZsSKclZfhJpyMQ0FaZcU9CN6VWYYCj	UCfsOfLvadg89Bx8Sv_6WERg	1	Sony Vegas Tutorials		2025-06-28
PLD-ZsSKclZfhqfUF1pg23TBfT2am_Txic	UCfsOfLvadg89Bx8Sv_6WERg	1	Call of Duty Black Ops 2		2025-06-28
PLD-ZsSKclZfjwNDNLz_cpvBTSqy2znkh1	UCfsOfLvadg89Bx8Sv_6WERg	1	MS-DOS		2025-06-28
PLD-ZsSKclZfhPk1CPiS7YTCloUJQG7ZCQ	UCfsOfLvadg89Bx8Sv_6WERg	1	Battlefield 3		2025-06-28
PLD-ZsSKclZfiTZ2IEiGW8ttJjmSsIwhzM	UCfsOfLvadg89Bx8Sv_6WERg	1	Google		2025-06-28
PLD-ZsSKclZfhPI3PwgcOyWfrqLE2C1pxG	UCfsOfLvadg89Bx8Sv_6WERg	1	Project CARS		2025-06-28
PLD-ZsSKclZfjS9z_91StcLxC3nrnQ25zU	UCfsOfLvadg89Bx8Sv_6WERg	1	Diretide		2025-06-28
PLD-ZsSKclZfiwfxqd4NHcEzsEOvchJZuP	UCfsOfLvadg89Bx8Sv_6WERg	1	Starcraft		2025-06-28
PLD-ZsSKclZfi8ivr0VBIp4K71P0LGhcY8	UCfsOfLvadg89Bx8Sv_6WERg	1	GTX 560 Ti		2025-06-28
PLD-ZsSKclZfhfL-5j9IvNobOSMEGGnrCD	UCfsOfLvadg89Bx8Sv_6WERg	1	Serious Sam		2025-06-28
PLD-ZsSKclZfh5TeahqstuGGnbQtzPL70-	UCfsOfLvadg89Bx8Sv_6WERg	1	Dota 2		2025-06-28
PLD-ZsSKclZfgMmSKlunFHPTDLIDdkwgSS	UCfsOfLvadg89Bx8Sv_6WERg	1	liero		2025-06-28
PLD-ZsSKclZfgfOl2ciswxtdKyiWrpYxMd	UCfsOfLvadg89Bx8Sv_6WERg	1	World of Warcraft		2025-06-28
PLD-ZsSKclZfi1M4uZQTd6S9zSq_6RQePG	UCfsOfLvadg89Bx8Sv_6WERg	1	Crysis		2025-06-28
PLD-ZsSKclZfhr5SF_JRlBH3dr6Iy-LxH2	UCfsOfLvadg89Bx8Sv_6WERg	1	Alice: Madness Returns		2025-06-28
PLD-ZsSKclZfjMHuRuOQ63MbBSoTS-kmDY	UCfsOfLvadg89Bx8Sv_6WERg	1	Diablo 3		2025-06-28
PLD-ZsSKclZfgS-zO-ratkK72CAV3tNSKS	UCfsOfLvadg89Bx8Sv_6WERg	1	Witcher		2025-06-28
PLD-ZsSKclZfjpio1A99GGraLgyUofc0OA	UCfsOfLvadg89Bx8Sv_6WERg	1	Need for Speed		2025-06-28
PLCVVOiPHmZ0EfjRtrP_7GfdKnUjwkLOYb	UCPkaARl89RCckNE_D7tj-aA	1	Deadlock		2025-06-28
PLCVVOiPHmZ0H9vb-pMMF6sCKwB_f976Y6	UCPkaARl89RCckNE_D7tj-aA	1	I HAVE A DREAM		2025-06-28
PLCVVOiPHmZ0FobsatBbyG2E8X9pm-yJd2	UCPkaARl89RCckNE_D7tj-aA	1	Gorgc Hitman 3		2025-06-28
PLCVVOiPHmZ0HU6m3vryNq_jgZUmhAfpZG	UCPkaARl89RCckNE_D7tj-aA	1	Gorgc Resident Evil 8 Village		2025-06-28
PLCVVOiPHmZ0GILTIfesS6m4mgKicGbCfV	UCPkaARl89RCckNE_D7tj-aA	1	Gorgc Dota 2 Overwatch		2025-06-28
PLCVVOiPHmZ0HU1x5C9-Rz6n9szffumD5-	UCPkaARl89RCckNE_D7tj-aA	1	Gorgc Phasmophobia		2025-06-28
PLCVVOiPHmZ0Ey_EwJILcz8BdtEIfcD5Xg	UCPkaARl89RCckNE_D7tj-aA	1	Gorgc Among Us		2025-06-28
PLCVVOiPHmZ0G-MLfvHG1Aebw_Pq3WQxsQ	UCPkaARl89RCckNE_D7tj-aA	1	Gorgc Fall Guys		2025-06-28
PLCVVOiPHmZ0GF6x28jf0uHfDoAHsObJue	UCPkaARl89RCckNE_D7tj-aA	1	Gorgc Chess		2025-06-28
PLCVVOiPHmZ0HXH8xHeBmPlV-t9XbkGRPS	UCPkaARl89RCckNE_D7tj-aA	1	Gorgc Resident Evil 3		2025-06-28
PLCVVOiPHmZ0FC3DvStyLp1TimoghWHE1G	UCPkaARl89RCckNE_D7tj-aA	1	Super Seducer 2		2025-06-28
PLCVVOiPHmZ0FcUe7rcLQJW0vuY7PXde5z	UCPkaARl89RCckNE_D7tj-aA	1	Gorgc Sekiro		2025-06-28
PLCVVOiPHmZ0Eeit-XCFPZpeZypLLkyMxr	UCPkaARl89RCckNE_D7tj-aA	1	Gorgc Resident Evil 2		2025-06-28
PLCVVOiPHmZ0E0dPzn1cMwDDAa8RPgj9PW	UCPkaARl89RCckNE_D7tj-aA	1	Gorgc Resident Evil 7		2025-06-28
PLCVVOiPHmZ0GJLj1i_Wil5bZpdzwf1z6Z	UCPkaARl89RCckNE_D7tj-aA	1	Gorgc and Bubu Keep Talking and Nobody Explodes		2025-06-28
PLCVVOiPHmZ0HOR-16KusR1hCX5peLxfOj	UCPkaARl89RCckNE_D7tj-aA	1	Gorgc GTFO		2025-06-28
PLCVVOiPHmZ0GPnbGnIMR9cLkaaUn8K2s9	UCPkaARl89RCckNE_D7tj-aA	1	Gorgc Alien Isolation		2025-06-28
PLCVVOiPHmZ0F0BaJQVfWOqbaFkyIqPeom	UCPkaARl89RCckNE_D7tj-aA	1	Gorgc Untitled Goose Game		2025-06-28
PLCVVOiPHmZ0F_T0e3DAZOggepj9BRINCl	UCPkaARl89RCckNE_D7tj-aA	1	Gorgc Trine 4 with Sing Bamboe		2025-06-28
PLCVVOiPHmZ0GinY5OTDkOjE0_EI8Amv7p	UCPkaARl89RCckNE_D7tj-aA	1	Gorgc CS:GO		2025-06-28
PLCVVOiPHmZ0F-flYfZUbIKUYhLhm0OVsf	UCPkaARl89RCckNE_D7tj-aA	1	Gorgc Super Seducer		2025-06-28
PLCVVOiPHmZ0FOxSkjnxX4NmCm2nFB5A22	UCPkaARl89RCckNE_D7tj-aA	1	Gorgc Green Hell		2025-06-28
PLCVVOiPHmZ0EZuZcrLo7L8BtYUN-ccvtc	UCPkaARl89RCckNE_D7tj-aA	1	Gorgc Visage		2025-06-28
PLCVVOiPHmZ0HqWjj_Qxuln-odrwlUdnVO	UCPkaARl89RCckNE_D7tj-aA	1	Gorgc Watcher of Samsara		2025-06-28
PLCVVOiPHmZ0FQYYXvvBAwyRFsi7LbY9D9	UCPkaARl89RCckNE_D7tj-aA	1	Gorgc Cooking Simulator		2025-06-28
PLCVVOiPHmZ0F5Y2xjtPbndyOP2HX928oQ	UCPkaARl89RCckNE_D7tj-aA	1	Open Qualifiers to The International 2019		2025-06-28
PLCVVOiPHmZ0EoLfw0j1-lGDBtAEj0uCed	UCPkaARl89RCckNE_D7tj-aA	1	Gorgc Dota Underlords		2025-06-28
PLCVVOiPHmZ0EzH8NqOHejyRUZpxy7s8Cg	UCPkaARl89RCckNE_D7tj-aA	1	Gorgc Layers of Fear 2		2025-06-28
PLCVVOiPHmZ0FLsJX9M_izlwezX5r-iYTq	UCPkaARl89RCckNE_D7tj-aA	1	Gorgc Layers of Fear		2025-06-28
PLCVVOiPHmZ0GXzxMxtfu1BekpCCQabffn	UCPkaARl89RCckNE_D7tj-aA	1	Gorgc Outlast 2		2025-06-28
PLCVVOiPHmZ0GMZhpHZ6KcJWi8CYLFqcO4	UCPkaARl89RCckNE_D7tj-aA	1	Gorgc Auto Chess		2025-06-28
PLCVVOiPHmZ0F5OV0gaGtNxXnWGgcddVGs	UCPkaARl89RCckNE_D7tj-aA	1	Gorgc Dark Souls 3		2025-06-28
PLCVVOiPHmZ0FoOYhp5YWf3VNzpMssiiS1	UCPkaARl89RCckNE_D7tj-aA	1	Gorgc Life Is Strange		2025-06-28
PLCVVOiPHmZ0El4iRH_Lzbc6fPoY8aJHO5	UCPkaARl89RCckNE_D7tj-aA	1	Gorgc Outlast		2025-06-28
PLCVVOiPHmZ0GP9iUWO0Crs_dUn-M7wo2j	UCPkaARl89RCckNE_D7tj-aA	1	Gorgc Artifact Highlights		2025-06-28
PLCVVOiPHmZ0Ffn9JjBbyoCuDrKCyvTTAG	UCPkaARl89RCckNE_D7tj-aA	1	the process		2025-06-28
PLCVVOiPHmZ0HGysDvuq88_uyC7rngnGlq	UCPkaARl89RCckNE_D7tj-aA	1	Gorgc casting Dota		2025-06-28
PLCVVOiPHmZ0HVYkZF8lGXGR_9uEiBeFiw	UCPkaARl89RCckNE_D7tj-aA	1	Gorgc Battle Cup games		2025-06-28
PLCVVOiPHmZ0FoxPa3IUCrNFpEU70pgUkP	UCPkaARl89RCckNE_D7tj-aA	1	Gorgc Dota Danger Playlist		2025-06-28
PLCVVOiPHmZ0HAilIsWnQF0rI5CIjKdpPp	UCPkaARl89RCckNE_D7tj-aA	1	Gorgc Dota Highlights		2025-06-28
PLwL7E8fRVEdcShhj_Nn-CWCBf23ajqqPY	UCZsM8MOy0VC9blj_wBkbo-g	1	Livestreams		2025-06-28
PLwL7E8fRVEdcVBvmeUPpwD-dqV651CVBE	UCZsM8MOy0VC9blj_wBkbo-g	1	Purge Deadlock		2025-06-28
PLwL7E8fRVEdd_CMp9IbX08mXf7iBPnQFU	UCZsM8MOy0VC9blj_wBkbo-g	1	Purge Gameplay Shorts		2025-06-28
PLwL7E8fRVEde_gGCJ3fKac-wThiCeryP9	UCZsM8MOy0VC9blj_wBkbo-g	1	Purge Short Guides		2025-06-28
PLwL7E8fRVEdfWcC4PEVvISAjheEsoz4nk	UCZsM8MOy0VC9blj_wBkbo-g	1	Zephyr Dota Korea Vlogs		2025-06-28
PLwL7E8fRVEdcFoeb6V64SZWhiukCMUE0L	UCZsM8MOy0VC9blj_wBkbo-g	1	Dating App Vids		2025-06-28
PLwL7E8fRVEdcF2QbZH2XEwX2szsA7iQt_	UCZsM8MOy0VC9blj_wBkbo-g	1	Purge plays with Slacks		2025-06-28
PLwL7E8fRVEdf8jwc6-_QsD3e4kf6OMlCC	UCZsM8MOy0VC9blj_wBkbo-g	1	In-Game Coaching Random Players		2025-06-28
PLwL7E8fRVEdcamoRaMLz44quaFBtjuBTS	UCZsM8MOy0VC9blj_wBkbo-g	1	Matches w/ FrankieWard		2025-06-28
PLwL7E8fRVEdc9kfJBhu48fggBCku_kml_	UCZsM8MOy0VC9blj_wBkbo-g	1	Dota 2 Overwatch Cases		2025-06-28
PLwL7E8fRVEdcMUCypk-WOnsgB5U_-RlEf	UCZsM8MOy0VC9blj_wBkbo-g	1	Slay the Spire		2025-06-28
PLwL7E8fRVEddF4yPUWN695kTtCbUiY9a4	UCZsM8MOy0VC9blj_wBkbo-g	1	Pubs w/ Slacks		2025-06-28
PLwL7E8fRVEdd4Je1sK4jlfxb9MVa0NJvu	UCZsM8MOy0VC9blj_wBkbo-g	1	Pubs w/ Day9		2025-06-28
PLwL7E8fRVEdcKNYOLTnRXgw61Sgid-0Q5	UCZsM8MOy0VC9blj_wBkbo-g	1	Among Us w/ Dota people		2025-06-28
PLwL7E8fRVEdfhZd3JofLVjwCA2TTDhtLx	UCZsM8MOy0VC9blj_wBkbo-g	1	Aghs Lab		2025-06-28
PLwL7E8fRVEdeEEV3aLaC1wU1BfUHh4yYz	UCZsM8MOy0VC9blj_wBkbo-g	1	Learn Dota Snippets		2025-06-28
PLwL7E8fRVEdcDkVnLBUoz-AqqNI5MMRLv	UCZsM8MOy0VC9blj_wBkbo-g	1	Kennedy Space Center		2025-06-28
PLwL7E8fRVEdelnVADrjYoFJHgNc9BmRQb	UCZsM8MOy0VC9blj_wBkbo-g	1	Coaching Slacks to Immortal		2025-06-28
PLwL7E8fRVEdcAGqdYQDL1HH56cy_yctcs	UCZsM8MOy0VC9blj_wBkbo-g	1	Purge Coaches  a Pub		2025-06-28
PLwL7E8fRVEde383kcSQGVr-YYUJn_Uzik	UCZsM8MOy0VC9blj_wBkbo-g	1	Honda Head to Head		2025-06-28
PLwL7E8fRVEddpjPaG6ziyiQBj4JsNAdG9	UCZsM8MOy0VC9blj_wBkbo-g	1	Purge Plays Dota 2: Season 1		2025-06-28
PLwL7E8fRVEddotmOHgoDugCxYOyiwNTpk	UCZsM8MOy0VC9blj_wBkbo-g	1	Learn Artifact		2025-06-28
PLwL7E8fRVEdcbW1m5DuqY0QNqTIR0CyBe	UCZsM8MOy0VC9blj_wBkbo-g	1	Learn Dota		2025-06-28
PLwL7E8fRVEdc0tFJlm2AWYhu4ccMk_vDD	UCZsM8MOy0VC9blj_wBkbo-g	1	Learn Dota Basics		2025-06-28
PLwL7E8fRVEdcLDtRrSGOJTqGRWc3Ue-r0	UCZsM8MOy0VC9blj_wBkbo-g	1	Shortened Purge Plays		2025-06-28
PLwL7E8fRVEdeiLkPnic1m82dXiGExQ9AG	UCZsM8MOy0VC9blj_wBkbo-g	1	Teaching day9 Dota 2		2025-06-28
PLwL7E8fRVEddpQac4dvVEjtQHZz4K0ksc	UCZsM8MOy0VC9blj_wBkbo-g	1	Understanding Items		2025-06-28
PLwL7E8fRVEddpBkqD2rYbDLpJwtAoCYl7	UCZsM8MOy0VC9blj_wBkbo-g	1	Battle Cup Runs		2025-06-28
PLwL7E8fRVEdeX8BTjwkcfEIuSBw2bq2Wl	UCZsM8MOy0VC9blj_wBkbo-g	1	Brand new to Dota? Watch this playlist first.		2025-06-28
PLwL7E8fRVEdcHnlV71ItpBneGUZOjiIl0	UCZsM8MOy0VC9blj_wBkbo-g	1	Purge plays from Stream		2025-06-28
PLwL7E8fRVEdf-9b8nHk4tgwda4_SSmbK7	UCZsM8MOy0VC9blj_wBkbo-g	1	Recent Purge Pro-Casts on other Channels		2025-06-28
PLwL7E8fRVEdeBQk9Aun5tSshKO59KyV1H	UCZsM8MOy0VC9blj_wBkbo-g	1	Random Veggies games		2025-06-28
PLwL7E8fRVEdcb4R0bCL_28LmhD3bbVXkk	UCZsM8MOy0VC9blj_wBkbo-g	1	Gem TD		2025-06-28
PLwL7E8fRVEdfxKir8BJge5yUDFvJfM5Fa	UCZsM8MOy0VC9blj_wBkbo-g	1	Coaching from Replays		2025-06-28
PLwL7E8fRVEdfbMTFtsd-LIU9bEfGRVhGX	UCZsM8MOy0VC9blj_wBkbo-g	1	Coaching from Replays		2025-06-28
PLwL7E8fRVEdfvnQF0t7RGz1xH3Jjn4rtZ	UCZsM8MOy0VC9blj_wBkbo-g	1	10 v 10 Dota 2		2025-06-28
PLwL7E8fRVEddmKqGrEYCMAosbjH32hj9J	UCZsM8MOy0VC9blj_wBkbo-g	1	Purge plays Overthrow		2025-06-28
PLwL7E8fRVEddSdedGydW22qUzP8HG3W_u	UCZsM8MOy0VC9blj_wBkbo-g	1	Patch Notes Analysis		2025-06-28
PLwL7E8fRVEdcaaWaSLRaM4Y21bfV8fEli	UCZsM8MOy0VC9blj_wBkbo-g	1	Q+A with Purge		2025-06-28
PLwL7E8fRVEddYqyMAsH8ZiiakwVE6PdIz	UCZsM8MOy0VC9blj_wBkbo-g	1	Solo Ranked Matchmaking w/ Purge		2025-06-28
PLwL7E8fRVEddjI-Vt0Nxebw-tWk7hOnng	UCZsM8MOy0VC9blj_wBkbo-g	1	NEL Captains Mode games		2025-06-28
PLwL7E8fRVEddgVf9Uzs6GM6Rh3niOq916	UCZsM8MOy0VC9blj_wBkbo-g	1	Dota 2 for your Mom		2025-06-28
PLwL7E8fRVEdfURMX5pwBNeRuQ3-YQ8ZlO	UCZsM8MOy0VC9blj_wBkbo-g	1	All Random Death Match games with Purge!		2025-06-28
PLwL7E8fRVEde-y6_-H8n-aECaUabDu4xo	UCZsM8MOy0VC9blj_wBkbo-g	1	Ability Draft games with Purge		2025-06-28
PLwL7E8fRVEdezyj1bbqqPJX44Q-SvTItm	UCZsM8MOy0VC9blj_wBkbo-g	1	Lets Analyze Losses		2025-06-28
PLwL7E8fRVEddxA_SwKRfZqYWOOtnOBqnD	UCZsM8MOy0VC9blj_wBkbo-g	1	LANHAMMER 2013		2025-06-28
PLwL7E8fRVEdd9O38X7SP32AqrYK3XMmbX	UCZsM8MOy0VC9blj_wBkbo-g	1	TI3 videos!		2025-06-28
PLwL7E8fRVEde-RrsDFlkksR7LSb6HkA8x	UCZsM8MOy0VC9blj_wBkbo-g	1	Purge casts 2013		2025-06-28
PLwL7E8fRVEdensYHrrzsFn7gZSLlKsfsx	UCZsM8MOy0VC9blj_wBkbo-g	1	Midas/Fan Games!		2025-06-28
PLwL7E8fRVEde9MKNags2cV32vvZAJkzwV	UCZsM8MOy0VC9blj_wBkbo-g	1	Dota 2 Collaborations		2025-06-28
PLwL7E8fRVEdcm0hURdrdeT9rQdnmr9KLH	UCZsM8MOy0VC9blj_wBkbo-g	1	LANHAMMER August 2013		2025-06-28
PLwL7E8fRVEdf-0-OZwyjwi_x6TKFQ3z9B	UCZsM8MOy0VC9blj_wBkbo-g	1	Purge plays Same Hero Only Mid(SHOM)		2025-06-28
PLwL7E8fRVEdcpJxRkXhXhkR_cRhfjCWLF	UCZsM8MOy0VC9blj_wBkbo-g	1	Purge Live Hero Commentaries		2025-06-28
PLwL7E8fRVEdf6i2f1yRSz4_w6gUTQFuzB	UCZsM8MOy0VC9blj_wBkbo-g	1	Gamecom.Plantronics EU Dota 2 Tournament		2025-06-28
PLwL7E8fRVEddrJkabBEIHqqFZ9x9ha24a	UCZsM8MOy0VC9blj_wBkbo-g	1	Funny Dota 2 moments with Purge		2025-06-28
PLwL7E8fRVEdd0PS0z-ZVUfZJgtaZC2X6H	UCZsM8MOy0VC9blj_wBkbo-g	1	Purge Replay Commentaries		2025-06-28
PLwL7E8fRVEdfRb7iRksbiNRkBokNNG0VN	UCZsM8MOy0VC9blj_wBkbo-g	1	Purge casts a Pub		2025-06-28
PLwL7E8fRVEdd1hAX7m3jJCnxc2I9wqQE-	UCZsM8MOy0VC9blj_wBkbo-g	1	Purge plays with Friends		2025-06-28
PLwL7E8fRVEdcRx3kdl4N_ZxhD1VbGFWjA	UCZsM8MOy0VC9blj_wBkbo-g	1	Gamecom.Plantronics Dota 2 Tournament		2025-06-28
PLwL7E8fRVEdcEzF1TbWaiTu0DE6BGUSQX	UCZsM8MOy0VC9blj_wBkbo-g	1	UCSD LAN WB bo3 match		2025-06-28
PLwL7E8fRVEddHuIacImEULMFip-BQ64LL	UCZsM8MOy0VC9blj_wBkbo-g	1	Purge plays Greeviling		2025-06-28
PLwL7E8fRVEdfGoYlrNH4XC-TwnAfsNavg	UCZsM8MOy0VC9blj_wBkbo-g	1	Avermedia Cup		2025-06-28
PLwL7E8fRVEdfY5b9hkTiWeUZxY6z5FaDz	UCZsM8MOy0VC9blj_wBkbo-g	1	Purge opens Chests		2025-06-28
PLwL7E8fRVEddru5wN_so6SrB_zH-MKVZ9	UCZsM8MOy0VC9blj_wBkbo-g	1	Purge plays DireTide		2025-06-28
PLwL7E8fRVEdcQ1SI7lSu3dAqNzs_eeM66	UCZsM8MOy0VC9blj_wBkbo-g	1	Play with Purge		2025-06-28
PLwL7E8fRVEdfAkTWLjATV-rRXf24_hJ7W	UCZsM8MOy0VC9blj_wBkbo-g	1	ESWC North American Qualifier 2012		2025-06-28
PLwL7E8fRVEdf1kdKYITs1_4v1eCFs-IjR	UCZsM8MOy0VC9blj_wBkbo-g	1	GosuLeague Season 2 Matches		2025-06-28
PLAA3A7D1C91E6B4D2	UCZsM8MOy0VC9blj_wBkbo-g	1	ESWC Semi Finals		2025-06-28
PLAA2229E5778CFCD8	UCZsM8MOy0VC9blj_wBkbo-g	1	Epic Dota 2 Games casted by Purge		2025-06-28
PLD75FA1F04F682DBF	UCZsM8MOy0VC9blj_wBkbo-g	1	GosuLeague Qualifiers		2025-06-28
PL5A3530DD3B36B8C6	UCZsM8MOy0VC9blj_wBkbo-g	1	Star Series casts		2025-06-28
PL5BC243F3978377B7	UCZsM8MOy0VC9blj_wBkbo-g	1	The Defense Quantic vs aL bo3		2025-06-28
PL4851B43E34184908	UCZsM8MOy0VC9blj_wBkbo-g	1	reddit /r/dota2 Feb. Tournament Vods		2025-06-28
PLF97CDBAB3BD3F552	UCZsM8MOy0VC9blj_wBkbo-g	1	2v2 Couples Showmatch		2025-06-28
PL934090DC8D556FB4	UCZsM8MOy0VC9blj_wBkbo-g	1	Coaching Sessions		2025-06-28
PLE8BF94DE8B878FF0	UCZsM8MOy0VC9blj_wBkbo-g	1	Learn about Dota 2		2025-06-28
PLF8D70AD41C6B9CD2	UCZsM8MOy0VC9blj_wBkbo-g	1	Dota 2 Pro Casts		2025-06-28
PL5A258C5A549BABD3	UCZsM8MOy0VC9blj_wBkbo-g	1	Purge casts a Pub		2025-06-28
PL6F85ADD2F8B362E2	UCZsM8MOy0VC9blj_wBkbo-g	1	Purge Owning with Gyro		2025-06-28
PLBB3F1412888A1EAE	UCZsM8MOy0VC9blj_wBkbo-g	1	GGnet vs sTurtle		2025-06-28
PL9307F7F50B7D5B9D	UCZsM8MOy0VC9blj_wBkbo-g	1	Purge owns with Silencer mid		2025-06-28
PLABE0713AE3480FF3	UCZsM8MOy0VC9blj_wBkbo-g	1	Purge owns with Ogre Magi!		2025-06-28
PLFA4C40709D6DC4CF	UCZsM8MOy0VC9blj_wBkbo-g	1	M5 vs OSI		2025-06-28
PL8B9CD8DCE9D402BB	UCZsM8MOy0VC9blj_wBkbo-g	1	Purge owns fans with QoP		2025-06-28
PLF4B3341692BF4FF7	UCZsM8MOy0VC9blj_wBkbo-g	1	TR(PGG+4) vs nEph Farm4FAME 3.5 Qualifier		2025-06-28
PL8OxoJfRGX15oV3fo-CPDgjatsiPJ4tzV	UCy0-ftAwxMHzZc74OhYT3PA	1	Chaos Knight Guides		2025-06-28
PL8OxoJfRGX16dTOduAv93LEWWv5ll84Cg	UCy0-ftAwxMHzZc74OhYT3PA	1	The Support Role		2025-06-28
PL8OxoJfRGX17fWAywl8G5YBQmK1cVytJ5	UCy0-ftAwxMHzZc74OhYT3PA	1	Terrorblade Guides		2025-06-28
PL8OxoJfRGX16X_VDrPMogTY5f4oFHCZ_p	UCy0-ftAwxMHzZc74OhYT3PA	1	Dota 2 Game Theory and Mechanics		2025-06-28
PL8OxoJfRGX17i5V0eV91t_2cAwBNQ4M3V	UCy0-ftAwxMHzZc74OhYT3PA	1	The Roaming and Support Roles		2025-06-28
PL8OxoJfRGX167u0x0_w101iBYBZRZi-4F	UCy0-ftAwxMHzZc74OhYT3PA	1	The Offlane Role		2025-06-28
PL8OxoJfRGX14Jc0HonXRKO51N2CGFdu3w	UCy0-ftAwxMHzZc74OhYT3PA	1	The Mid Role		2025-06-28
PL8OxoJfRGX14iHDB8-OyBdCPDZg_EKSXR	UCy0-ftAwxMHzZc74OhYT3PA	1	The Carry Role		2025-06-28
PL8OxoJfRGX16RFsLlsf8jl62KEws0IeG3	UCy0-ftAwxMHzZc74OhYT3PA	1	Shadow Fiend Guides		2025-06-28
PL8OxoJfRGX17tolHso25TF4Tdidjpj6cr	UCy0-ftAwxMHzZc74OhYT3PA	1	Storm Spirit Guides		2025-06-28
PL8OxoJfRGX17PV7favnhXQ7wY5A1b8ITd	UCy0-ftAwxMHzZc74OhYT3PA	1	DotA2 Guides		2025-06-28
PL8OxoJfRGX15vtvQk04g7t18cqD_EsGPz	UCy0-ftAwxMHzZc74OhYT3PA	1	Queen of Pain Hero Guides		2025-06-28
PL8OxoJfRGX15O_TBFfuLmTfOtelo-N7zt	UCy0-ftAwxMHzZc74OhYT3PA	1	Tiny Hero Guides		2025-06-28
PLqbTQKjxS4upJrziCNYED9diN5C7wo6fE	UCI2vFNmkaj22Om3qO5J7qOg	1	Kryptonill Giveaway		2025-06-28
PLqbTQKjxS4uoMoN5cQXTb17nenyGXZPuI	UCI2vFNmkaj22Om3qO5J7qOg	1	How to Optimize Your Build		2025-06-28
PLqbTQKjxS4upJu8hrStykLNHbcgZVxa1N	UCI2vFNmkaj22Om3qO5J7qOg	1	How to Jungle Guide		2025-06-28
PLqbTQKjxS4uq7WNfr2iDpLPCDsEqdhKO4	UCI2vFNmkaj22Om3qO5J7qOg	1	Learn How to Play Like a Pro		2025-06-28
PLFIeRaJDXgRzs8YlrIbdTftLLeOqa2gMR	UCKCC6yRZor2qsGbO_x7LpuA	1	Yapzor Pro Gameplay Dota 2		2025-06-28
PLFIeRaJDXgRzy5_AlhihDHdWKlr8zojiP	UCKCC6yRZor2qsGbO_x7LpuA	1	SumiYa Pro Invoker Gameplay Dota 2		2025-06-28
PLFIeRaJDXgRxcnA96krpSnkBX5G6sqHSo	UCKCC6yRZor2qsGbO_x7LpuA	1	Miracle- Pro Gameplay Dota 2		2025-06-28
PLmo0yBiK8wAtik4YZLlliwWMhWMdVrrrt	UCiR9IHCurqVHpC821NVcW6g	1	Sumail		2025-06-28
PLmo0yBiK8wAs2py1e9LsJyKZx0sWe-EGN	UCiR9IHCurqVHpC821NVcW6g	1	The International 2023		2025-06-28
PLmo0yBiK8wAsHQo7K8xgnvwIuROFxFaU-	UCiR9IHCurqVHpC821NVcW6g	1	NothingToSay		2025-06-28
PLmo0yBiK8wAufdKZh6hmoaFGhCYd62u4A	UCiR9IHCurqVHpC821NVcW6g	1	Collapse		2025-06-28
PLmo0yBiK8wAuMF1Lz3xD_B25UcrJuVY_u	UCiR9IHCurqVHpC821NVcW6g	1	Miracle		2025-06-28
PLmo0yBiK8wAse9vfhdPX6iAckKpfstqM0	UCiR9IHCurqVHpC821NVcW6g	1	Short		2025-06-28
PLmo0yBiK8wAu4nhflrP3864UIq0Rx3reB	UCiR9IHCurqVHpC821NVcW6g	1	Random Games		2025-06-28
PLmo0yBiK8wAvW9gcOdic3WAO-mou4Uqze	UCiR9IHCurqVHpC821NVcW6g	1	23savage		2025-06-28
PLmo0yBiK8wAt1R-gcbKpTTEeb_kgTj4VS	UCiR9IHCurqVHpC821NVcW6g	1	iceiceice		2025-06-28
PLmo0yBiK8wAuQZ2rsSg29EMMiT2MvpwWI	UCiR9IHCurqVHpC821NVcW6g	1	Crystallis		2025-06-28
PLmo0yBiK8wAuUWvsqI8uk_cDa_uJNrmL8	UCiR9IHCurqVHpC821NVcW6g	1	ATF		2025-06-28
PLmo0yBiK8wAslqxhGz0Nazf2xiAtpHvm1	UCiR9IHCurqVHpC821NVcW6g	1	Dendi		2025-06-28
PLmo0yBiK8wAsz_CUJATEZagH9Mzmlh8ui	UCiR9IHCurqVHpC821NVcW6g	1	Timado		2025-06-28
PLmo0yBiK8wAvDGhlbq7ywxfl8HPBY3I8f	UCiR9IHCurqVHpC821NVcW6g	1	iLTW		2025-06-28
PLmo0yBiK8wAuTy_sfTNciD5g1MUdIypiQ	UCiR9IHCurqVHpC821NVcW6g	1	qojqva		2025-06-28
PLmo0yBiK8wAt5qyQgUNGfYD9Z09v1Dhgy	UCiR9IHCurqVHpC821NVcW6g	1	Yatoro		2025-06-28
PLmo0yBiK8wAs4HbrIvy8XktZ1qTfscHuU	UCiR9IHCurqVHpC821NVcW6g	1	Topson		2025-06-28
PLmo0yBiK8wAse6QvZ63SdWsCC9Pb-0E_g	UCiR9IHCurqVHpC821NVcW6g	1	Ame		2025-06-28
PLsUjekliC2iKPcFlh7k5-q-MMAEwyh9XE	UC72LSerSpu1y9y_BlDHWLGA	1	TOP 10 Dota 2 ABUSES and TRICKS of ALL TIME!		2025-06-28
PLsUjekliC2iIEc1pt52niLQPxg38LKCZ1	UC72LSerSpu1y9y_BlDHWLGA	1	Dota 2 Abusers		2025-06-28
PLsUjekliC2iKyYzfiGrKTuWhiMdX5Too4	UC72LSerSpu1y9y_BlDHWLGA	1	Dota 1 vs Dota 2		2025-06-28
PLsUjekliC2iI2jsWqqsfGc2b1dg_lnPX0	UC72LSerSpu1y9y_BlDHWLGA	1	Dota 2 Films [SFM]		2025-06-28
PLsUjekliC2iKDu-2WaYHLB3VgyAXycq2v	UC72LSerSpu1y9y_BlDHWLGA	1	New Dota 2 Patch (Update)		2025-06-28
PLsUjekliC2iIVU3oOuVbmosFjS-XQQL59	UC72LSerSpu1y9y_BlDHWLGA	1	Dota 2 Cheaters		2025-06-28
PLsUjekliC2iIDDQvrIsSpUzGLrV1TjF_c	UC72LSerSpu1y9y_BlDHWLGA	1	Dota 2 TOP 5 Unofficial Mods (Sets)		2025-06-28
PLsUjekliC2iISW9Qzvhx3E9FvZ0Bv99Nv	UC72LSerSpu1y9y_BlDHWLGA	1	Dota 2 Abusers		2025-06-28
PLsUjekliC2iIWM-w5T37CB4-Kw_wGabCa	UC72LSerSpu1y9y_BlDHWLGA	1	Last Uploads		2025-06-28
PLsUjekliC2iKAShBGwhdGos63z9Hs-idC	UC72LSerSpu1y9y_BlDHWLGA	1	Dota 2 - Bugs		2025-06-28
PLsUjekliC2iJ6IEo1BE-mi604jQp_Flf9	UC72LSerSpu1y9y_BlDHWLGA	1	Dota 2 Unreleased Heroes		2025-06-28
PLsUjekliC2iK6OrdiqhOcPRWas0q5H8F4	UC72LSerSpu1y9y_BlDHWLGA	1	Jungle Guides		2025-06-28
PLsUjekliC2iJ-MKVr7F65gvvjNfcA5XE2	UC72LSerSpu1y9y_BlDHWLGA	1	Ability Draft Builds		2025-06-28
PLsUjekliC2iL6fnz-rd_apPc4ETftZLHt	UC72LSerSpu1y9y_BlDHWLGA	1	Funny Dota Time		2025-06-28
PLsUjekliC2iKL7r3cyD4_IwpVPSjkV0mR	UC72LSerSpu1y9y_BlDHWLGA	1	Dota 2 Tips and Tricks		2025-06-28
PLsUjekliC2iLrl6sv1STTjvotsjhGZJbh	UC72LSerSpu1y9y_BlDHWLGA	1	The Best Dota 2 Tips and Tricks		2025-06-28
PLsUjekliC2iKKnxYvyOcUdW4Yq_JAEgiF	UC72LSerSpu1y9y_BlDHWLGA	1	Top 10 moments		2025-06-28
PLzd0ZYNB0Vf4U8eCGUkktyFedWrK0rHrg	UCMZwHuSN9ZqRXucscC_hnKA	1	Boom Esports		2025-06-28
PLzd0ZYNB0Vf7VJc-RnQSdD7mEARV--q6D	UCMZwHuSN9ZqRXucscC_hnKA	1	Secret		2025-06-28
PLzd0ZYNB0Vf5fq8poJ-Db53sf1e_KqTws	UCMZwHuSN9ZqRXucscC_hnKA	1	Nigma		2025-06-28
PLzd0ZYNB0Vf771HRPT1TQ9V6TRkCe1iU4	UCMZwHuSN9ZqRXucscC_hnKA	1	OG		2025-06-28
PLcf4exs59pmItXto-hjO1gjL9daBjY_DK	UCrrZzgPvpLdp0g285JPb7GQ	1	My Top Builds of The 2021		2025-06-28
PLcf4exs59pmJI30-wieLhjP3c4fvwq-Ek	UCrrZzgPvpLdp0g285JPb7GQ	1	Secret Builds (Without e-blade)!		2025-06-28
PLcf4exs59pmJ-Wkff8JiI8FBhJKem46Ds	UCrrZzgPvpLdp0g285JPb7GQ	1	E-blade Forever!		2025-06-28
PLvYljyh6us0gYZl4OR8LdDWMZUkOkSwAH	UCJOpcUMBPnayED1xGFlvQCg	1	Quinn The GIGACHAD of NA		2025-06-28
PLvYljyh6us0iDgc5uKIfTPuYAa6fZa1uL	UCJOpcUMBPnayED1xGFlvQCg	1	Timado The Savior of NA Dota		2025-06-28
PLvYljyh6us0i6r3M6U9Xk8u1KWiRMee-5	UCJOpcUMBPnayED1xGFlvQCg	1	Sumail The King of Dota 2		2025-06-28
PLvYljyh6us0h80fGUrLMFFnlvE88jqxbW	UCJOpcUMBPnayED1xGFlvQCg	1	Crit The Earth Spirit Monster		2025-06-28
PLvYljyh6us0jzYNNL5JorOwRneDO18pGE	UCJOpcUMBPnayED1xGFlvQCg	1	Jerax Chill Streams		2025-06-28
PLvYljyh6us0jciZHyU_Bq31SVtAH-fLth	UCJOpcUMBPnayED1xGFlvQCg	1	Nikobaby The Prison RTZ		2025-06-28
PLvYljyh6us0h1f0be0umwO6HY3xYSJSSO	UCJOpcUMBPnayED1xGFlvQCg	1	Mason The FACE of DOTA 2		2025-06-28
PLvYljyh6us0i3tTvduc6V6uyuJEcBCk92	UCJOpcUMBPnayED1xGFlvQCg	1	Best of the Week		2025-06-28
PLvYljyh6us0iP46W_aosfAU_tJi9OzIKb	UCJOpcUMBPnayED1xGFlvQCg	1	Golden Moments		2025-06-28
PLvYljyh6us0h4s7UIsLBfUhWxjgnqlPW6	UCJOpcUMBPnayED1xGFlvQCg	1	Dendi The Superman		2025-06-28
PLvYljyh6us0j6jTVXFhLlDvnlL4nb_chd	UCJOpcUMBPnayED1xGFlvQCg	1	AdmiralBulldog The Dong Master		2025-06-28
PLvYljyh6us0jeZ5AM1im28QpRMYSh7Jvb	UCJOpcUMBPnayED1xGFlvQCg	1	Arteezy The King of BabyRage		2025-06-28
PLvYljyh6us0iNUiS0aapjh6eeZeaMoHY9	UCJOpcUMBPnayED1xGFlvQCg	1	SingSing The BEAR WRESTLER		2025-06-28
PLvYljyh6us0h75TgZDBHHd7mydqC90i9g	UCJOpcUMBPnayED1xGFlvQCg	1	Dota Funny		2025-06-28
PLd1oK0vj3yd7l6M5dOCv6PEYD-R9xJNwq	UCiqBeZx-Jez6J6WK6-PXrew	1	MLBB GAMEPLAY		2025-06-28
PLd1oK0vj3yd4wRe27q7GSEu-ol31VcyBo	UCiqBeZx-Jez6J6WK6-PXrew	1	LIVE		2025-06-28
PLd1oK0vj3yd6-u4ZFXzlc4K31KgVC8s-J	UCiqBeZx-Jez6J6WK6-PXrew	1	SHORT MLBB		2025-06-28
PLd1oK0vj3yd4UW6DCkowielkFCt8Dsd9P	UCiqBeZx-Jez6J6WK6-PXrew	1	One Hit One Kill		2025-06-28
PLd1oK0vj3yd4DHRVzlVB2LGzOnk5VOpZu	UCiqBeZx-Jez6J6WK6-PXrew	1	Passive Build		2025-06-28
PLd1oK0vj3yd7aNValmOyAJAyj3Pbepswf	UCiqBeZx-Jez6J6WK6-PXrew	1	Combo Wombo		2025-06-28
PL5YS2y18Gtx_J2NDwmV65cao-arNrADQY	UC4HfMLhNP7oVmF0wJMAU_1g	1	CHIRA_JUNIOR Invoker Dota 2		2025-06-28
PL5YS2y18Gtx9PQ-IYvNsnn4NcYJa6exGI	UC4HfMLhNP7oVmF0wJMAU_1g	1	Kiyotaka Invoker Dota 2		2025-06-28
PL5YS2y18Gtx_ckKtW-_AIGLcO3URe9uHZ	UC4HfMLhNP7oVmF0wJMAU_1g	1	JimPark Invoker Dota 2		2025-06-28
PL5YS2y18Gtx-dV_rmaXwrcGKJbQyM6KXb	UC4HfMLhNP7oVmF0wJMAU_1g	1	Mvcmillan Invoker Dota 2		2025-06-28
PL5YS2y18Gtx_K370cwDG3Tp8mx6DauRAy	UC4HfMLhNP7oVmF0wJMAU_1g	1	Mikey Invoker Dota 2		2025-06-28
PL5YS2y18Gtx_e50qYEfcAr34Rq78POUMq	UC4HfMLhNP7oVmF0wJMAU_1g	1	Bzm Invoker Dota 2		2025-06-28
PL5YS2y18Gtx9lEmKbjliwiODgMdfuchRu	UC4HfMLhNP7oVmF0wJMAU_1g	1	Mary Day Invoker Dota 2		2025-06-28
PL5YS2y18Gtx8j6kSo56I7H6g-b1NBYgn8	UC4HfMLhNP7oVmF0wJMAU_1g	1	Mikoto Invoker Dota 2		2025-06-28
PL5YS2y18Gtx_6ByoCX_yXh4LvY99enls8	UC4HfMLhNP7oVmF0wJMAU_1g	1	gpk Invoker Dota 2		2025-06-28
PL5YS2y18Gtx8NC-SVsSo_IX3_jay4InDn	UC4HfMLhNP7oVmF0wJMAU_1g	1	Supream Invoker Dota 2		2025-06-28
PL5YS2y18Gtx82IEILkzCdLOH925mrCwBq	UC4HfMLhNP7oVmF0wJMAU_1g	1	CCNC Invoker Dota 2		2025-06-28
PL5YS2y18Gtx-B95ejL6aW1xlNiN1wnlyD	UC4HfMLhNP7oVmF0wJMAU_1g	1	Emo Invoker Dota 2		2025-06-28
PL5YS2y18Gtx-HET23be7z6TC0NcSaZUj7	UC4HfMLhNP7oVmF0wJMAU_1g	1	Quas Wex Invoker Dota 2		2025-06-28
PL5YS2y18Gtx81pMv0MzIBLQWC8P94qF9w	UC4HfMLhNP7oVmF0wJMAU_1g	1	Quedi Invoker Dota 2		2025-06-28
PL5YS2y18Gtx-EvLet8JMX_3IGSt2xXejZ	UC4HfMLhNP7oVmF0wJMAU_1g	1	Mage- Invoker Dota 2		2025-06-28
PL5YS2y18Gtx95BAjYhwMDwvAfqR3FzY-A	UC4HfMLhNP7oVmF0wJMAU_1g	1	First Invoker Dota 2		2025-06-28
PL5YS2y18Gtx9lzOUSrB4fAhpCZOmMUFeq	UC4HfMLhNP7oVmF0wJMAU_1g	1	Art Invoker Dota 2		2025-06-28
PL5YS2y18Gtx82CxFX40Bt4ZMpvLC7PHI3	UC4HfMLhNP7oVmF0wJMAU_1g	1	Denni Invoker Dota 2		2025-06-28
PL5YS2y18Gtx-uIJfp3l-lT2jAFZbyad0w	UC4HfMLhNP7oVmF0wJMAU_1g	1	Cty Invoker Dota 2		2025-06-28
PL5YS2y18Gtx8RZvZdCt-BI0zwFO5uUTgF	UC4HfMLhNP7oVmF0wJMAU_1g	1	23savage Invoker Dota 2		2025-06-28
PL5YS2y18Gtx-zzqPYnN8sclvT0X6EUE7I	UC4HfMLhNP7oVmF0wJMAU_1g	1	INBossik Invoker Dota 2		2025-06-28
PL5YS2y18Gtx93Awfy2Fh8AuIgcg53RDXO	UC4HfMLhNP7oVmF0wJMAU_1g	1	lortNoc Invoker Dota 2		2025-06-28
PL5YS2y18Gtx-Ld2uiRNbcVjMiWnQaCL64	UC4HfMLhNP7oVmF0wJMAU_1g	1	Gunnar Invoker Dota 2		2025-06-28
PL5YS2y18Gtx-TPN-U-QhzpLPIzcSZKAfu	UC4HfMLhNP7oVmF0wJMAU_1g	1	Sssako Invoker Dota 2		2025-06-28
PL5YS2y18Gtx_1B8GHmd_asPfnwzHQ1kw6	UC4HfMLhNP7oVmF0wJMAU_1g	1	Yowe Invoker Dota 2		2025-06-28
PL5YS2y18Gtx_O86RdxJagCI_jXYeHx7gy	UC4HfMLhNP7oVmF0wJMAU_1g	1	StormStormer Invoker Dota 2		2025-06-28
PL5YS2y18Gtx-Rw-C4ys4M0EmiPYbwpsZ3	UC4HfMLhNP7oVmF0wJMAU_1g	1	Invoker Girl Dota 2		2025-06-28
PL5YS2y18Gtx8zFsFP4AYyuQaTlNWxPBAV	UC4HfMLhNP7oVmF0wJMAU_1g	1	Ferrari_430 Invoker Dota 2		2025-06-28
PL5YS2y18Gtx9CsDxye6d69ormvF3dOxq9	UC4HfMLhNP7oVmF0wJMAU_1g	1	Dendi Invoker Dota 2		2025-06-28
PL5YS2y18Gtx-J19KSJvA2e6DptiB8qfHq	UC4HfMLhNP7oVmF0wJMAU_1g	1	MidOne Invoker Dota 2		2025-06-28
PL5YS2y18Gtx_3qDasu3vQS-o4Qkk-qfrb	UC4HfMLhNP7oVmF0wJMAU_1g	1	Xxs Dota 2 Invoker		2025-06-28
PL5YS2y18Gtx-j-Ro3OY8w9m-Hzps3QSXI	UC4HfMLhNP7oVmF0wJMAU_1g	1	Dstones Invoker Dota 2		2025-06-28
PL5YS2y18Gtx9RxoQ6hrCAoKiZMseraXFt	UC4HfMLhNP7oVmF0wJMAU_1g	1	GeneRal Invoker Dota 2		2025-06-28
PL5YS2y18Gtx-EGbF6E6rMLi9o59u8OSvP	UC4HfMLhNP7oVmF0wJMAU_1g	1	Abed Invoker Dota 2		2025-06-28
PL5YS2y18Gtx-1k7jiQC_rB_e21rORDueW	UC4HfMLhNP7oVmF0wJMAU_1g	1	AlaCrity Invoker Dota 2		2025-06-28
PL5YS2y18Gtx_b1K3sKZ2eiwPTVZUM16bz	UC4HfMLhNP7oVmF0wJMAU_1g	1	ChYuan Invoker Dota 2		2025-06-28
PL5YS2y18Gtx9w83xmJEXJdIA8TPdLm86F	UC4HfMLhNP7oVmF0wJMAU_1g	1	Sccc Invoker Dota 2		2025-06-28
PL5YS2y18Gtx-AtMl73G72iZ9PnXLsVxtY	UC4HfMLhNP7oVmF0wJMAU_1g	1	Somnus`M Invoker Dota 2		2025-06-28
PL5YS2y18Gtx-7oTOGySEAYA7SUDuv92m_	UC4HfMLhNP7oVmF0wJMAU_1g	1	INYOURDREAM Invoker Dota 2		2025-06-28
PL5YS2y18Gtx9xPHJs8Qcr91KAkVb2cs0G	UC4HfMLhNP7oVmF0wJMAU_1g	1	CARL CLASSROOM		2025-06-28
PL5YS2y18Gtx-84qA3h25Ip2tN-GvZhtWL	UC4HfMLhNP7oVmF0wJMAU_1g	1	Armel Invoker Dota 2		2025-06-28
PL5YS2y18Gtx9ztRoVyJDqVrydy5GE7Exh	UC4HfMLhNP7oVmF0wJMAU_1g	1	Ana Invoker Dota 2		2025-06-28
PL5YS2y18Gtx8pu0QY0iOKwcriTIRmA_5G	UC4HfMLhNP7oVmF0wJMAU_1g	1	Bryle Invoker Dota 2		2025-06-28
PL5YS2y18Gtx_dvHxQSFCvxTkDD_19xtH2	UC4HfMLhNP7oVmF0wJMAU_1g	1	Noone Invoker Dota 2		2025-06-28
PL5YS2y18Gtx_C5oA7ZldNCrHhnq--3orz	UC4HfMLhNP7oVmF0wJMAU_1g	1	canceL^^ Invoker Dota 2		2025-06-28
PL5YS2y18Gtx_QpZFHjoEoGFS8lHLsEshe	UC4HfMLhNP7oVmF0wJMAU_1g	1	Topson Invoker Dota 2		2025-06-28
PL5YS2y18Gtx8nAObxbQnzdSAIvQ3N1FPN	UC4HfMLhNP7oVmF0wJMAU_1g	1	Vurtune Invoker Dota 2		2025-06-28
PL5YS2y18Gtx-uS4jKPvM64PUwCOuKBvz2	UC4HfMLhNP7oVmF0wJMAU_1g	1	w33 Invoker Dota 2		2025-06-28
PL5YS2y18Gtx93MRAK-eoCs9MC8U_wd0A_	UC4HfMLhNP7oVmF0wJMAU_1g	1	Dota 2 Invoker Movie		2025-06-28
PL5YS2y18Gtx-fMnNp2wNOIncQtaJ7Q2YD	UC4HfMLhNP7oVmF0wJMAU_1g	1	Miracle- Invoker Dota 2		2025-06-28
PL5YS2y18Gtx90jxRQ-vItXhlRIpL1tagB	UC4HfMLhNP7oVmF0wJMAU_1g	1	Daily Invoker Dota 2		2025-06-28
PL5YS2y18Gtx9eO3sNe-Cps1F_hz51HsMb	UC4HfMLhNP7oVmF0wJMAU_1g	1	Sumail Invoker Dota 2		2025-06-28
PL5YS2y18Gtx_w02F821SLXUOedViwtc2p	UC4HfMLhNP7oVmF0wJMAU_1g	1	Sumiya Invoker Dota 2		2025-06-28
PLtJl-g3US42bXrnQ7CelS4VZgLO6xc3KQ	UCeaSnulFHX9xqkKejnIvyxA	1	TaiLung Perspective		2025-06-28
PLtJl-g3US42ZDM2LHJFMc6ECJb7ErK7ap	UCeaSnulFHX9xqkKejnIvyxA	1	CRYSTALLIS		2025-06-28
PLtJl-g3US42akAxzrdxNQH6y3qWgsISv9	UCeaSnulFHX9xqkKejnIvyxA	1	Niku Perspective		2025-06-28
PLtJl-g3US42Y7Pd9jw6kXo6OwBrZiv4Wl	UCeaSnulFHX9xqkKejnIvyxA	1	Pure Perspective		2025-06-28
PLtJl-g3US42b5RM2NMQmWncp9UpLa41I7	UCeaSnulFHX9xqkKejnIvyxA	1	Collapse Perspective		2025-06-28
PLtJl-g3US42ZYQnnseW8ts8hZyHOyCVEr	UCeaSnulFHX9xqkKejnIvyxA	1	Mikoto Perspective		2025-06-28
PLtJl-g3US42b_ohflZgfgHAND1oY7NiHw	UCeaSnulFHX9xqkKejnIvyxA	1	Malr1ne Perspective		2025-06-28
PLtJl-g3US42YLEoyMCPyTTR86V3ecBhZg	UCeaSnulFHX9xqkKejnIvyxA	1	Yatoro Perspective		2025-06-28
PLtJl-g3US42Zc8T77p6bO0daHbnUgx5qM	UCeaSnulFHX9xqkKejnIvyxA	1	SATANIC		2025-06-28
PLtJl-g3US42ZXfu28QrBKRQoE4AeGUjl5	UCeaSnulFHX9xqkKejnIvyxA	1	Me, Playing Classic Dota		2025-06-28
PLtJl-g3US42ZYWoHCk-t5iUm_JlILygFX	UCeaSnulFHX9xqkKejnIvyxA	1	Taiga Perspective (POV)		2025-06-28
PLtJl-g3US42YzOyskiv8CJCEPBF2S3AWx	UCeaSnulFHX9xqkKejnIvyxA	1	Yuragi Perspective (POV)		2025-06-28
PLtJl-g3US42ZjAMWOIkMzB8r8alz5rp79	UCeaSnulFHX9xqkKejnIvyxA	1	BZM Perspective (POV)		2025-06-28
PLtJl-g3US42bNoRLGBqUjJPOLY4sPvp9W	UCeaSnulFHX9xqkKejnIvyxA	1	ATF Perspective (POV)		2025-06-28
PLtJl-g3US42aedF0nkcuoLWJb3mYVpGRI	UCeaSnulFHX9xqkKejnIvyxA	1	HOW TO COUNTER HEROES		2025-06-28
PLtJl-g3US42YJd-apRSwhZ7kAO7jJNJWd	UCeaSnulFHX9xqkKejnIvyxA	1	Miracle Perspective (POV)		2025-06-28
PLtJl-g3US42ZqvWAQuWA3jzKplSCG3T4b	UCeaSnulFHX9xqkKejnIvyxA	1	HIGHEST MMR GAMEPLAY		2025-06-28
PLtJl-g3US42ZSa0Nxr9wdAhABy79ztyHF	UCeaSnulFHX9xqkKejnIvyxA	1	SumaiL Perspective (POV)		2025-06-28
PLtJl-g3US42Y3w4Lia3nlgdw3-3dH6GuS	UCeaSnulFHX9xqkKejnIvyxA	1	Abed Perspective (POV)		2025-06-28
PLtJl-g3US42aWytF7FFKsf1sgneFJZI_C	UCeaSnulFHX9xqkKejnIvyxA	1	Saksa Perspective (POV)		2025-06-28
PLtJl-g3US42Y2gX7Dfazdj1d5TKRPAJU3	UCeaSnulFHX9xqkKejnIvyxA	1	ana Perspective (POV)		2025-06-28
PLtJl-g3US42be5Zd7ZhY__oyK0tjGjRmT	UCeaSnulFHX9xqkKejnIvyxA	1	N0taiLPerspective (POV)		2025-06-28
PLtJl-g3US42aSn9Q9a5Zwi2k28xZAh3nZ	UCeaSnulFHX9xqkKejnIvyxA	1	Ceb Perspective (POV)		2025-06-28
PLtJl-g3US42YWyuGOCfVo3q7867Oh1hEn	UCeaSnulFHX9xqkKejnIvyxA	1	JerAx Perspective (POV)		2025-06-28
PLtJl-g3US42a9TSVI2tJJ_hz-6DOm_vE8	UCeaSnulFHX9xqkKejnIvyxA	1	Topson Perspective (POV)		2025-06-28
PLWUjiESVQRfmI_PR-RnN3gfskI4rSyfy7	UCr6cJRQ6EBchbTI-NlLBwww	1	Jamside		2025-06-28
PLWUjiESVQRfnJwKf_SkcwD0vvapV4CLDN	UCr6cJRQ6EBchbTI-NlLBwww	1	Solist		2025-06-28
PLWUjiESVQRfm_q3qgeYIgxMVxVseQFrH_	UCr6cJRQ6EBchbTI-NlLBwww	1	LaroKashi		2025-06-28
PLWUjiESVQRfnAw2sGhOKoTEq4bVXmWftj	UCr6cJRQ6EBchbTI-NlLBwww	1	PlayWithMe		2025-06-28
PLWUjiESVQRfmBnUzOZx00LH21jHojX63o	UCr6cJRQ6EBchbTI-NlLBwww	1	Hoot		2025-06-28
PLWUjiESVQRflkgN8cLhgqaNOYCJkajzvk	UCr6cJRQ6EBchbTI-NlLBwww	1	Saf		2025-06-28
PLWUjiESVQRfkLIpM18Zf5Uf-rl7gBx_FI	UCr6cJRQ6EBchbTI-NlLBwww	1	Zerggy		2025-06-28
PLWUjiESVQRfnrndJ-2p4mzmWfiuS1OQPd	UCr6cJRQ6EBchbTI-NlLBwww	1	Carbattery		2025-06-28
PLWUjiESVQRfntubFIXyIgzIoo1uYfsalR	UCr6cJRQ6EBchbTI-NlLBwww	1	Game of Thrones		2025-06-28
PLWUjiESVQRfkTOLGMGA5wP0uWVwW0VRPM	UCr6cJRQ6EBchbTI-NlLBwww	1	Pctt		2025-06-28
PLWUjiESVQRfksgHYZPWX0zwn5a-X3Srkm	UCr6cJRQ6EBchbTI-NlLBwww	1	Wulfee		2025-06-28
PLWUjiESVQRflseX7WBLpHLG3tIbMX7giO	UCr6cJRQ6EBchbTI-NlLBwww	1	Dimov		2025-06-28
PLWUjiESVQRfmsJg2sGcI76DtHuoD04tz9	UCr6cJRQ6EBchbTI-NlLBwww	1	Lystic		2025-06-28
PLWUjiESVQRfkM5efqYbNpYKBtBsfFeR44	UCr6cJRQ6EBchbTI-NlLBwww	1	Holliday		2025-06-28
PLWUjiESVQRfk5eLmzx8OMbF3G9xWji5sE	UCr6cJRQ6EBchbTI-NlLBwww	1	Vyper		2025-06-28
PLWUjiESVQRfnMdebDD5HvDrZ6okz41cSr	UCr6cJRQ6EBchbTI-NlLBwww	1	Calico		2025-06-28
PLWUjiESVQRfm8Gifvo-ZUba_wRc-2XhIy	UCr6cJRQ6EBchbTI-NlLBwww	1	Sinclair		2025-06-28
PLWUjiESVQRfkP13isekaLON5OkGh9Uyas	UCr6cJRQ6EBchbTI-NlLBwww	1	McGinnis		2025-06-28
PLWUjiESVQRfkOREDmVZBjcxiBTQc-FsAq	UCr6cJRQ6EBchbTI-NlLBwww	1	Hydration		2025-06-28
PLWUjiESVQRfmezN4jCBYjXZCY5zla9Vvr	UCr6cJRQ6EBchbTI-NlLBwww	1	Kelvin		2025-06-28
PLWUjiESVQRfnmHGVcVm6y1hzxQPjsfxZX	UCr6cJRQ6EBchbTI-NlLBwww	1	Lady Geist		2025-06-28
PLWUjiESVQRfmkH6PKNH6j2tXK6TecM-u_	UCr6cJRQ6EBchbTI-NlLBwww	1	Ivy		2025-06-28
PLWUjiESVQRflEsQPdexyUIqhXv3ICYu2b	UCr6cJRQ6EBchbTI-NlLBwww	1	Mirage		2025-06-28
PLWUjiESVQRfkRymSfVFkiISJpJKCPqJc8	UCr6cJRQ6EBchbTI-NlLBwww	1	Paradox		2025-06-28
PLWUjiESVQRfk6pHf8uJ4B3hbBH57SlwPX	UCr6cJRQ6EBchbTI-NlLBwww	1	Shiv		2025-06-28
PLWUjiESVQRfnCCgIMhTjIj-Pd024rWrll	UCr6cJRQ6EBchbTI-NlLBwww	1	Haze		2025-06-28
PLWUjiESVQRfmgqZtrIFniLI5cwM8ZSbPu	UCr6cJRQ6EBchbTI-NlLBwww	1	Mo&Krill		2025-06-28
PLWUjiESVQRfn3z1mcRr19Hl946pjMWSV5	UCr6cJRQ6EBchbTI-NlLBwww	1	Yamato		2025-06-28
PLWUjiESVQRfm5c00Dtf4ogbRWonc3WrI_	UCr6cJRQ6EBchbTI-NlLBwww	1	Infernus		2025-06-28
PLWUjiESVQRflnldE9pWlXf2qdC7cJAwTU	UCr6cJRQ6EBchbTI-NlLBwww	1	Lash		2025-06-28
PLWUjiESVQRfm1y0mirtaGWDH7HkuRV1Zz	UCr6cJRQ6EBchbTI-NlLBwww	1	Bebop		2025-06-28
PLWUjiESVQRfmkYobKrIeJfqNjADkmQ52U	UCr6cJRQ6EBchbTI-NlLBwww	1	Abrams		2025-06-28
PLWUjiESVQRfl8s4KYBbXve2_q17BsLOHT	UCr6cJRQ6EBchbTI-NlLBwww	1	Wraith		2025-06-28
PLWUjiESVQRfllbkfT0EgK1WWB8lg3gRUo	UCr6cJRQ6EBchbTI-NlLBwww	1	Dynamo		2025-06-28
PLWUjiESVQRfmKk6W0J4rOcLUi74-FEQxV	UCr6cJRQ6EBchbTI-NlLBwww	1	Warden		2025-06-28
PLWUjiESVQRfmw34w9NfOwQfHag1JFs95E	UCr6cJRQ6EBchbTI-NlLBwww	1	Pocket		2025-06-28
PLWUjiESVQRfnBYSZ6MUcggBAeeWNAps5P	UCr6cJRQ6EBchbTI-NlLBwww	1	Viscous		2025-06-28
PLWUjiESVQRfkcaRbGJAg8edjhj4yQRugr	UCr6cJRQ6EBchbTI-NlLBwww	1	Seven		2025-06-28
PLWUjiESVQRfl5Hx2Rf7oh75gTxZP87vp4	UCr6cJRQ6EBchbTI-NlLBwww	1	Grey Talon		2025-06-28
PLWUjiESVQRfnDAwjiLFfhQdMvIdM48pZB	UCr6cJRQ6EBchbTI-NlLBwww	1	Vindicta		2025-06-28
PLWUjiESVQRfk77GUkSFXBXac1MfyGi8_H	UCr6cJRQ6EBchbTI-NlLBwww	1	Mikaels		2025-06-28
PL1qW0cAWkWEL7lMp9D20d-hxCwEveOXKS	UCXjx9yYZ55-kl2J54efE8bg	1	Dawn of War - Dota 2 Arcade Game		2025-06-28
PL1qW0cAWkWEKb9Qa5rBBVWgLCEvYPQNwU	UCXjx9yYZ55-kl2J54efE8bg	1	Ranked		2025-06-28
PL1qW0cAWkWEJFRTg7nzQKxukmFUC9SQDK	UCXjx9yYZ55-kl2J54efE8bg	1	Duo Q Ranked with Dendi		2025-06-28
PL1qW0cAWkWEIp8pIDVJz3jLZym4sO_C1q	UCXjx9yYZ55-kl2J54efE8bg	1	Ability Arena		2025-06-28
PL1qW0cAWkWELhylhVASVEB-fvO6vvK3n3	UCXjx9yYZ55-kl2J54efE8bg	1	CHARITY SHOWMATCH FOR UKRAINE		2025-06-28
PL1qW0cAWkWEJQrEatUbbtugUaGEmXIboO	UCXjx9yYZ55-kl2J54efE8bg	1	Nemestice		2025-06-28
PL1qW0cAWkWEJkBMBgxZ5ka7dGzEeNJS1M	UCXjx9yYZ55-kl2J54efE8bg	1	Patch notes		2025-06-28
PL1qW0cAWkWEJQcy1RwRzjtlhl8kSVJ1q9	UCXjx9yYZ55-kl2J54efE8bg	1	Slay The Spire		2025-06-28
PL1qW0cAWkWEI6DpAsbmUfNq5y-e6ZpLR9	UCXjx9yYZ55-kl2J54efE8bg	1	LOTV games		2025-06-28
PL1qW0cAWkWEJcyXGB9H4M8q9ZfkcZL9Ep	UCXjx9yYZ55-kl2J54efE8bg	1	Improve your laning (Tutorial!)		2025-06-28
PL1qW0cAWkWEJSpfRzDoQc602XuNsfP8R5	UCXjx9yYZ55-kl2J54efE8bg	1	Full Ranked MM games!		2025-06-28
PL1qW0cAWkWEJ4KpavyXQh7-PmLm906V0N	UCXjx9yYZ55-kl2J54efE8bg	1	Waga Talks (Theorycrafting and giving opinion on things)		2025-06-28
PL1qW0cAWkWELHNxzUKML4o9pka1j2dZCz	UCXjx9yYZ55-kl2J54efE8bg	1	Wagamama stream-highlights		2025-06-28
PL1qW0cAWkWEIUOblOim1TRWNaAwnljMuu	UCXjx9yYZ55-kl2J54efE8bg	1	WagaGaming - One Special Game		2025-06-28
PL8amTY_ZekmjoVUhwfYOD8p4rbko9_HV7	UCrRlDvN5Ea2OauDLtNBMyfw	1	Interesting Dota 2 Strategies		2025-06-28
PL8amTY_Zekmh0KXIba9luKXI5EHDoIXVa	UCrRlDvN5Ea2OauDLtNBMyfw	1	Dota 2 Nerd Mode Analysis		2025-06-28
PL8amTY_Zekmi0tJqQMDwqjoxVW2VlVpbS	UCrRlDvN5Ea2OauDLtNBMyfw	1	When You Meet Dota 2 Players		2025-06-28
PL8amTY_ZekmgMvcwjQY7N1NTycdFUbA4y	UCrRlDvN5Ea2OauDLtNBMyfw	1	strim		2025-06-28
PL8amTY_ZekmixbBDcgf5FuPOqTs6BcXU-	UCrRlDvN5Ea2OauDLtNBMyfw	1	Dota 2 Shorts		2025-06-28
PL8amTY_ZekmicTC7mHqDgVFF-oJLoNZ8n	UCrRlDvN5Ea2OauDLtNBMyfw	1	10 Things You Should Know in Dota 2		2025-06-28
PL8amTY_ZekmjKS6spVsCLvZ8SlK6hVDyd	UCrRlDvN5Ea2OauDLtNBMyfw	1	Tatolon Explains		2025-06-28
PL8amTY_ZekmjrR_3wGyHEF5fme6JYDQQ1	UCrRlDvN5Ea2OauDLtNBMyfw	1	Learn this and WIN DOTA!!		2025-06-28
PL8amTY_Zekmiyk8Z1aLFtXdqCedUXhq0Y	UCrRlDvN5Ea2OauDLtNBMyfw	1	Dota2 Funny Moments by DATOHLEONG		2025-06-28
PL8amTY_ZekmjgRsZrZNaLhRaie1F8O8JM	UCrRlDvN5Ea2OauDLtNBMyfw	1	Inside the Mind of an Immortal Rank DOTA2		2025-06-28
PL8amTY_ZekmhuauOcIhzdCd1r3Hveci_g	UCrRlDvN5Ea2OauDLtNBMyfw	1	10 Hero Tricks You Should Know in Dota 2		2025-06-28
PL7rzmuXopUYUbUJ6PBEjCwN5KNpAjk15C	UCokHQ6IhiqeYuy-TqQthi4w	1	7.38 Pro Scene		2025-06-28
PL7rzmuXopUYWpc64uXiJqe9pN_NxYifkW	UCokHQ6IhiqeYuy-TqQthi4w	1	7.38 Bug Abuse		2025-06-28
PL7rzmuXopUYW4bGNne_pOR9NyFnyqSuA6	UCokHQ6IhiqeYuy-TqQthi4w	1	7.38 Funny Interaction		2025-06-28
PL7rzmuXopUYWYTvHlTDBhrCnnztdRn7sy	UCokHQ6IhiqeYuy-TqQthi4w	1	Dota 2 7.38 Best Moments		2025-06-28
PL7rzmuXopUYWiPUQ1qm3MSAYnbu6JcLiB	UCokHQ6IhiqeYuy-TqQthi4w	1	RAMPAGE Dota 2		2025-06-28
PL7rzmuXopUYU58LUnMWH_5jx2-OMBDkFj	UCokHQ6IhiqeYuy-TqQthi4w	1	Daily Rampage		2025-06-28
PL7rzmuXopUYVmVjY4IaTX_y9fhlm2QEiX	UCokHQ6IhiqeYuy-TqQthi4w	1	Dota 2 Rampage		2025-06-28
PL7rzmuXopUYWdWgQlui7qzJk6vtAKx9XI	UCokHQ6IhiqeYuy-TqQthi4w	1	Dota 2 Pango		2025-06-28
PL7rzmuXopUYUP1476W7OLt_mw57MmbX0K	UCokHQ6IhiqeYuy-TqQthi4w	1	Dota 2 Shorts		2025-06-28
PL7YBhaR4-HuxHoGoP_TsLlyy94e2jFhHc	UC4aVD0WIvfFsiICZy5Wo22w	1	Gunnar		2025-06-28
PL7YBhaR4-Huz1XHJYlQGnBwQc6KJbG4hI	UC4aVD0WIvfFsiICZy5Wo22w	1	Qojqva		2025-06-28
PL7YBhaR4-Huy3tQBacy24Kx3Hz73j00Vk	UC4aVD0WIvfFsiICZy5Wo22w	1	Ace		2025-06-28
PL7YBhaR4-HuyKMzFcJrADCMe2QIeLJNSJ	UC4aVD0WIvfFsiICZy5Wo22w	1	Yatoro		2025-06-28
PL7YBhaR4-HuxuzaxE0XsFSC4cQZaSY6zj	UC4aVD0WIvfFsiICZy5Wo22w	1	niu		2025-06-28
PL7YBhaR4-Hux31mv2VU7Jd3tRuZRuT2WW	UC4aVD0WIvfFsiICZy5Wo22w	1	Boxi		2025-06-28
PL7YBhaR4-Huy6mVLFVJTz9Nsyct9da62R	UC4aVD0WIvfFsiICZy5Wo22w	1	Boom		2025-06-28
PL7YBhaR4-HuwduYQtAFxSxFNOGZII5N39	UC4aVD0WIvfFsiICZy5Wo22w	1	Miero		2025-06-28
PL7YBhaR4-HuzDL3GIM_v-5uuCIwnIVcsh	UC4aVD0WIvfFsiICZy5Wo22w	1	Saberlight-		2025-06-28
PL7YBhaR4-Huz8wgQpX2xt8TUYOYJxj2pN	UC4aVD0WIvfFsiICZy5Wo22w	1	Ame		2025-06-28
PL7YBhaR4-HuxNc6dTEf-4cZwROu7hSAFZ	UC4aVD0WIvfFsiICZy5Wo22w	1	Nine		2025-06-28
PL7YBhaR4-HuyFx-GYFeW-JbeUj6wz7tr3	UC4aVD0WIvfFsiICZy5Wo22w	1	w33		2025-06-28
PL7YBhaR4-Huz2B9Ki9n1DQhaN7IkPrZfR	UC4aVD0WIvfFsiICZy5Wo22w	1	ws		2025-06-28
PL7YBhaR4-HuynxSInXAdkgkbVlSYOYrPY	UC4aVD0WIvfFsiICZy5Wo22w	1	Sacred		2025-06-28
PL7YBhaR4-HuyK7cGuHiNfqjxZjA78B4a7	UC4aVD0WIvfFsiICZy5Wo22w	1	xxs		2025-06-28
PL7YBhaR4-HuxZvCvMG8kWj3FPrjUOuWAB	UC4aVD0WIvfFsiICZy5Wo22w	1	RodJeR		2025-06-28
PL7YBhaR4-Huz1ZPgTZKJA6Qs_hfEjuNqw	UC4aVD0WIvfFsiICZy5Wo22w	1	Chalice		2025-06-28
PL7YBhaR4-HuzsPuaQY4bCypDh5r6TQRIU	UC4aVD0WIvfFsiICZy5Wo22w	1	XinQ		2025-06-28
PL7YBhaR4-HuzIcTNlWFbnPHF-Dcr0a3h0	UC4aVD0WIvfFsiICZy5Wo22w	1	fy		2025-06-28
PL7YBhaR4-HuyE8kIUYgC7IC59pR2FLzqe	UC4aVD0WIvfFsiICZy5Wo22w	1	Raven		2025-06-28
PL7YBhaR4-Huzw46akaJGEH7en69KihUVH	UC4aVD0WIvfFsiICZy5Wo22w	1	Noticed		2025-06-28
PL7YBhaR4-HuxXkOQ8cl8_rK41Lz5q-LmX	UC4aVD0WIvfFsiICZy5Wo22w	1	ATF		2025-06-28
PL7YBhaR4-HuzAKme5QngS1XyQ4C-GMGtv	UC4aVD0WIvfFsiICZy5Wo22w	1	Nightfall		2025-06-28
PL7YBhaR4-HuzgmYnA1CDTf3f5gn4UjT_F	UC4aVD0WIvfFsiICZy5Wo22w	1	Collapse		2025-06-28
PL7YBhaR4-Huz-hAgHM3yoPGeJA7CYT6vt	UC4aVD0WIvfFsiICZy5Wo22w	1	DM		2025-06-28
PL7YBhaR4-HuyIQtNTyKnCTAvJyGWUcrAE	UC4aVD0WIvfFsiICZy5Wo22w	1	Lelis		2025-06-28
PL7YBhaR4-Huz_CNXgHLL5y79t5ODpgvug	UC4aVD0WIvfFsiICZy5Wo22w	1	Fbz		2025-06-28
PL7YBhaR4-HuwmcGx5GDUPdnQUdmoVFdSP	UC4aVD0WIvfFsiICZy5Wo22w	1	GeneRaL		2025-06-28
PL7YBhaR4-Huyjh5uqcGJyEWORZAVCn1Rx	UC4aVD0WIvfFsiICZy5Wo22w	1	old eLeVeN		2025-06-28
PL7YBhaR4-HuyDGvLxFk9OpsrjRkHIr8hK	UC4aVD0WIvfFsiICZy5Wo22w	1	Moo		2025-06-28
PL7YBhaR4-HuywuF8CzcO4dn-fmb_abv8z	UC4aVD0WIvfFsiICZy5Wo22w	1	Attacker		2025-06-28
PL7YBhaR4-HuwiehvjON19bGEMARw4xaRX	UC4aVD0WIvfFsiICZy5Wo22w	1	Yang		2025-06-28
PL7YBhaR4-HuxKVBuxwlQfqz-_ilurZr8j	UC4aVD0WIvfFsiICZy5Wo22w	1	Faith_bian		2025-06-28
PL7YBhaR4-HuykGC-bn_JmwuMJUVh-UJh_	UC4aVD0WIvfFsiICZy5Wo22w	1	Miracle-		2025-06-28
PL7YBhaR4-HuyL6wK55Or1zjsTLT1-lrRx	UC4aVD0WIvfFsiICZy5Wo22w	1	No[o]ne		2025-06-28
PL7YBhaR4-HuynHOXnblZcf334LrEjAE8V	UC4aVD0WIvfFsiICZy5Wo22w	1	Wisper		2025-06-28
PL7YBhaR4-HuwCbtqCAhk4ZawHremM4fPf	UC4aVD0WIvfFsiICZy5Wo22w	1	RAMZES666		2025-06-28
PL7YBhaR4-HuyCmQmOy29Vzv4iXTclC1sA	UC4aVD0WIvfFsiICZy5Wo22w	1	ana		2025-06-28
PL7YBhaR4-HuxDQKfP0YC1mC-lrbRdqHPl	UC4aVD0WIvfFsiICZy5Wo22w	1	Zayac		2025-06-28
PL7YBhaR4-Huz8YFRQwOUgN5nuhpkjQ9Lw	UC4aVD0WIvfFsiICZy5Wo22w	1	Fly		2025-06-28
PL7YBhaR4-Huy1mpMtCreBAUXEMwI79kGj	UC4aVD0WIvfFsiICZy5Wo22w	1	Cr1t-		2025-06-28
PL7YBhaR4-Huxa7oU7-9-tceHcJNTcmGis	UC4aVD0WIvfFsiICZy5Wo22w	1	Gh		2025-06-28
PL7YBhaR4-HuyFR6fyNOtNfG43WG8AESNk	UC4aVD0WIvfFsiICZy5Wo22w	1	s4		2025-06-28
PL7YBhaR4-Huw7nDeiVCF3rJdhULW_D07d	UC4aVD0WIvfFsiICZy5Wo22w	1	Resolut1on		2025-06-28
PL7YBhaR4-Huyxq8y3DJI7mEWn1GZ8R2_5	UC4aVD0WIvfFsiICZy5Wo22w	1	9pasha		2025-06-28
PL7YBhaR4-HuzU0n8Qegn8gLq8aXT66uXH	UC4aVD0WIvfFsiICZy5Wo22w	1	33		2025-06-28
PL7YBhaR4-Huw6FO0Rtoi-aNscCBqkMpou	UC4aVD0WIvfFsiICZy5Wo22w	1	MinD COntRoL		2025-06-28
PL7YBhaR4-HuxouOWVZ_81yNX_EGcaK3eR	UC4aVD0WIvfFsiICZy5Wo22w	1	Zai		2025-06-28
PL7YBhaR4-HuxmEQ-DsLmjMLnycTG35230	UC4aVD0WIvfFsiICZy5Wo22w	1	Ceb		2025-06-28
PLTeNOoyLCmVWJC6jwn20f2ZBB5k1OwHbc	UCK2t7qm88e6ZsKS3Pbg-C3Q	1	Omniknight		2025-06-28
PLTeNOoyLCmVU2_wUiiKYnxtD19VAVs7ZC	UCK2t7qm88e6ZsKS3Pbg-C3Q	1	Bane		2025-06-28
PLTeNOoyLCmVX1lnRgj3NdSptF6a7_EX3D	UCK2t7qm88e6ZsKS3Pbg-C3Q	1	Nyx		2025-06-28
PLTeNOoyLCmVVqJ8h_VRWbgd4hKbneGg6g	UCK2t7qm88e6ZsKS3Pbg-C3Q	1	Chaos Knight		2025-06-28
PLTeNOoyLCmVXR9WTBaz__J2FlpGof2afE	UCK2t7qm88e6ZsKS3Pbg-C3Q	1	Luna		2025-06-28
PLTeNOoyLCmVXDorQO7h4Q3-EtUReRV8wH	UCK2t7qm88e6ZsKS3Pbg-C3Q	1	Necrophos		2025-06-28
PLTeNOoyLCmVXf2sVfJhIra_arjzexXLr7	UCK2t7qm88e6ZsKS3Pbg-C3Q	1	Spectre		2025-06-28
PLTeNOoyLCmVW2P7Jh_PGNGraeidxgiBj7	UCK2t7qm88e6ZsKS3Pbg-C3Q	1	Windranger		2025-06-28
PLTeNOoyLCmVUaVB7oTTA5HLSr2YkOYTyz	UCK2t7qm88e6ZsKS3Pbg-C3Q	1	Bloodseeker		2025-06-28
PLTeNOoyLCmVWi7e-yR0s5B9XQ2R981Lz6	UCK2t7qm88e6ZsKS3Pbg-C3Q	1	Slardar		2025-06-28
PLTeNOoyLCmVWSrVv8B1_nO40RLIm5U37b	UCK2t7qm88e6ZsKS3Pbg-C3Q	1	Riki		2025-06-28
PLTeNOoyLCmVX7qD3SEucP7HXubUOrvMLN	UCK2t7qm88e6ZsKS3Pbg-C3Q	1	Ursa		2025-06-28
PLTeNOoyLCmVVA2GYMWo5ldml11z9-YV4g	UCK2t7qm88e6ZsKS3Pbg-C3Q	1	Nisha		2025-06-28
PLhm-DtnIjs6uuZcni-uLEDXr07BNqE-tW	UCW2Ew5V3I2z1jXvsZEkKtUQ	1	Rigwarl, the Bristleback		2025-06-28
PLhm-DtnIjs6spip6-E6J1DvytU2BTBea0	UCW2Ew5V3I2z1jXvsZEkKtUQ	1	Zeus, the Lord of Heaven		2025-06-28
PLhm-DtnIjs6tVJRvSrSCruvwbZfw1S1_S	UCW2Ew5V3I2z1jXvsZEkKtUQ	1	Akasha, the Queen of Pain		2025-06-28
PLhm-DtnIjs6v7_Kk0Y1GHJ7DhUlMyzpxy	UCW2Ew5V3I2z1jXvsZEkKtUQ	1	Harbinger, the Outworld Destroyer		2025-06-28
PLhm-DtnIjs6twNzQZvxxq3BJsZmwuv_cF	UCW2Ew5V3I2z1jXvsZEkKtUQ	1	Slardar, the Slithereen Guard		2025-06-28
PLhm-DtnIjs6szXuBfwq3KpOdeyrkFKVdo	UCW2Ew5V3I2z1jXvsZEkKtUQ	1	Meepo, the Geomancer		2025-06-28
PLhm-DtnIjs6v865xVBvgaxf_5K4G71RkK	UCW2Ew5V3I2z1jXvsZEkKtUQ	1	Razzil Darkbrew, the Alchemist		2025-06-28
PLhm-DtnIjs6vwulsy_Qa1AltPpfyiAWE6	UCW2Ew5V3I2z1jXvsZEkKtUQ	1	Krobelus, the Death Prophet		2025-06-28
PLhm-DtnIjs6s46N-DBlMQzHjX-WgNS4-q	UCW2Ew5V3I2z1jXvsZEkKtUQ	1	Zharvakko, the Witch Doctor		2025-06-28
PLhm-DtnIjs6sLrSAwlgb9b_Kp4xxORoYd	UCW2Ew5V3I2z1jXvsZEkKtUQ	1	Bradwarden, the Centaur Warrunner		2025-06-28
PLhm-DtnIjs6sL4zlwvxJUzPZrk7AqPoUR	UCW2Ew5V3I2z1jXvsZEkKtUQ	1	Slithice, the Naga Siren		2025-06-28
PLhm-DtnIjs6sRG16JPXBckoaw7QpPzR5D	UCW2Ew5V3I2z1jXvsZEkKtUQ	1	Chaos Knight		2025-06-28
PLhm-DtnIjs6vk0Ii-D3atWTK0YTS4IQA2	UCW2Ew5V3I2z1jXvsZEkKtUQ	1	Huskar, the Sacred Warrior		2025-06-28
PLhm-DtnIjs6vNKZJEFPkTkKyK4-tx0pr-	UCW2Ew5V3I2z1jXvsZEkKtUQ	1	Puck, the Faerie Dragon		2025-06-28
PLhm-DtnIjs6vWulvGPhjgVwazp0twJ8-I	UCW2Ew5V3I2z1jXvsZEkKtUQ	1	Rizzrack, the Timbersaw		2025-06-28
PLhm-DtnIjs6tHwj8noBFXgn6g55Z9Zfgt	UCW2Ew5V3I2z1jXvsZEkKtUQ	1	Raijin Thunderkeg, the Storm Spirit		2025-06-28
PLhm-DtnIjs6tndqej0HDEZ7T3xLzViJoN	UCW2Ew5V3I2z1jXvsZEkKtUQ	1	Riki, the Stealth Assassin		2025-06-28
PLhm-DtnIjs6tWeM72Vd2kLgWjv22M_ucJ	UCW2Ew5V3I2z1jXvsZEkKtUQ	1	Raigor Stonehoof, the Earthshaker		2025-06-28
PLhm-DtnIjs6sazmh4sVdxJWPJTRCexibp	UCW2Ew5V3I2z1jXvsZEkKtUQ	1	Lucifer, the Doom		2025-06-28
PLhm-DtnIjs6v1q5PCHd5jR5zCQin8shha	UCW2Ew5V3I2z1jXvsZEkKtUQ	1	Luna, the Moon Rider		2025-06-28
PLhm-DtnIjs6tdKJy2qDFinU7hjco7adCx	UCW2Ew5V3I2z1jXvsZEkKtUQ	1	Donté Panlin, the Pangolier		2025-06-28
PLhm-DtnIjs6tJgEQ4q1Vs4VkXWQPHZ6lc	UCW2Ew5V3I2z1jXvsZEkKtUQ	1	Xin, the Ember Spirit		2025-06-28
PLhm-DtnIjs6sAjI8HX8oeEAO0cp9jlfjB	UCW2Ew5V3I2z1jXvsZEkKtUQ	1	Marci		2025-06-28
PLhm-DtnIjs6vZaCsFgp21n12v6b8eCAB8	UCW2Ew5V3I2z1jXvsZEkKtUQ	1	Morphling		2025-06-28
PLhm-DtnIjs6uSXcmzB61QFx_IKheG3v5c	UCW2Ew5V3I2z1jXvsZEkKtUQ	1	Aggron Stonebreak, the Ogre Magi		2025-06-28
PLhm-DtnIjs6vwX59fdriOMYuPAyz0XapI	UCW2Ew5V3I2z1jXvsZEkKtUQ	1	Medusa, the Gorgon		2025-06-28
PLhm-DtnIjs6vDvWMvgZenMw3Xj5TmGfcz	UCW2Ew5V3I2z1jXvsZEkKtUQ	1	Skitskurr, the Weaver		2025-06-28
PLhm-DtnIjs6t8m2spYAafL4Du_5l_lbFH	UCW2Ew5V3I2z1jXvsZEkKtUQ	1	Sun Wukong, the Monkey King		2025-06-28
PLhm-DtnIjs6vK61VCUwx9VGoL-zT_f9Qp	UCW2Ew5V3I2z1jXvsZEkKtUQ	1	Carl, the Invoker		2025-06-28
PLhm-DtnIjs6uipMCewRdyMXvkaKxOvD9L	UCW2Ew5V3I2z1jXvsZEkKtUQ	1	Abaddon, the Lord of Avernus		2025-06-28
PLhm-DtnIjs6sKU0R7bnYrQ3TfnAcV3L6T	UCW2Ew5V3I2z1jXvsZEkKtUQ	1	Gondar, the Bounty Hunter		2025-06-28
PLhm-DtnIjs6s5HRQK8S6dyhjmXB3cBaSV	UCW2Ew5V3I2z1jXvsZEkKtUQ	1	Aurel, the Gyrocopter		2025-06-28
PLhm-DtnIjs6t8GUxDyf1rzJ9NKUYKXDq8	UCW2Ew5V3I2z1jXvsZEkKtUQ	1	Muerta		2025-06-28
PLhm-DtnIjs6uMY64y3BmbxN9ndOCe8Gco	UCW2Ew5V3I2z1jXvsZEkKtUQ	1	Nevermore, the Shadow Fiend		2025-06-28
PLhm-DtnIjs6viHdGIPLhhjp4F4S53dq00	UCW2Ew5V3I2z1jXvsZEkKtUQ	1	Lanaya, the Templar Assassin		2025-06-28
PLhm-DtnIjs6tlf0u7G5Ir1C6FTEKzi2wj	UCW2Ew5V3I2z1jXvsZEkKtUQ	1	Clinkz, the Bone Fletcher		2025-06-28
PLhm-DtnIjs6s_HqfafEdLjorTuaZCPhDk	UCW2Ew5V3I2z1jXvsZEkKtUQ	1	Ostarion, the Wraith King		2025-06-28
PLhm-DtnIjs6v1yspzFI3jYjvwhjluGmxR	UCW2Ew5V3I2z1jXvsZEkKtUQ	1	Traxex, the Drow Ranger		2025-06-28
PLhm-DtnIjs6sIfDJa8XBftw3VmF9oLiRg	UCW2Ew5V3I2z1jXvsZEkKtUQ	1	Strygwyr, the Bloodseeker		2025-06-28
PLhm-DtnIjs6shaz0Fwa3qN5UCX9RmI-4J	UCW2Ew5V3I2z1jXvsZEkKtUQ	1	Zet, the Arc Warden		2025-06-28
PLhm-DtnIjs6tlL2iJCWPO_jI_BLu5UBqP	UCW2Ew5V3I2z1jXvsZEkKtUQ	1	Slark, the Nightcrawler		2025-06-28
PLhm-DtnIjs6uSgJF-R2mbKv8syS_e2321	UCW2Ew5V3I2z1jXvsZEkKtUQ	1	Kardel Sharpeye, the Sniper		2025-06-28
PLhm-DtnIjs6uUZAmDcR7x2LYqVuE8BxmT	UCW2Ew5V3I2z1jXvsZEkKtUQ	1	Sven, the Rogue Knight		2025-06-28
PLhm-DtnIjs6uijRGB31W7QeRYl15knoJy	UCW2Ew5V3I2z1jXvsZEkKtUQ	1	Mercurial, the Spectre		2025-06-28
PLhm-DtnIjs6vpztwQdBPBgRBhdA70Xgx_	UCW2Ew5V3I2z1jXvsZEkKtUQ	1	Yurnero, the Juggernaut		2025-06-28
PLhm-DtnIjs6v8j5btpKgi0c1-3TlsSLz3	UCW2Ew5V3I2z1jXvsZEkKtUQ	1	Boush, the Tinker		2025-06-28
PLhm-DtnIjs6ttwcbMwURmQ04SzG4b7Vf-	UCW2Ew5V3I2z1jXvsZEkKtUQ	1	Ulfsaar, the Ursa Warrior		2025-06-28
PLhm-DtnIjs6t8NWK4dEsxe_7dTF5_NRLr	UCW2Ew5V3I2z1jXvsZEkKtUQ	1	Terrorblade, the Demon Marauder		2025-06-28
PLhm-DtnIjs6vIB1zRU3cVteDesiVGIfrN	UCW2Ew5V3I2z1jXvsZEkKtUQ	1	Azwraith, the Phantom Lancer		2025-06-28
PLhm-DtnIjs6slk_B9jJvIhOlwE0gFqHfx	UCW2Ew5V3I2z1jXvsZEkKtUQ	1	Darkterror, the Faceless Void		2025-06-28
PLhm-DtnIjs6smm3ihLqsiLgj6UUG7PCD3	UCW2Ew5V3I2z1jXvsZEkKtUQ	1	Mortred, the Phantom Assassin		2025-06-28
PLhm-DtnIjs6v7wDSsDn6xWsy_vKXiI3_K	UCW2Ew5V3I2z1jXvsZEkKtUQ	1	Anti-Mage		2025-06-28
PLhm-DtnIjs6sueibvnKUWwmEda-9suAuP	UCW2Ew5V3I2z1jXvsZEkKtUQ	1	The International 11		2025-06-28
PLhm-DtnIjs6v0KB7d_Cli4HlWoA3jNz6r	UCW2Ew5V3I2z1jXvsZEkKtUQ	1	Divine Rapier Game Changer		2025-06-28
PLhm-DtnIjs6sSm9DFpeFSX7NE7iVy2jEa	UCW2Ew5V3I2z1jXvsZEkKtUQ	1	Epic RAMPAGE!!!		2025-06-28
PLhm-DtnIjs6ttblT9kGCt3ONvwb9uc4VQ	UCW2Ew5V3I2z1jXvsZEkKtUQ	1	TIER 5 ITEMS CRAZY GAME		2025-06-28
PLhm-DtnIjs6ukQbdEgB-p5H0abwYFZwW6	UCW2Ew5V3I2z1jXvsZEkKtUQ	1	Best Full Gameplay		2025-06-28
PLhm-DtnIjs6tAeIRm8iK3qOObx3Q2WeRV	UCW2Ew5V3I2z1jXvsZEkKtUQ	1	TOP-10 Rank Gameplay		2025-06-28
PLhm-DtnIjs6uDMzuJbsvGQlCf0izYErI5	UCW2Ew5V3I2z1jXvsZEkKtUQ	1	EPIC Fountain Dive		2025-06-28
PLhm-DtnIjs6sFQ35CtwztCGXfca_XCpve	UCW2Ew5V3I2z1jXvsZEkKtUQ	1	Best Highlights Gameplay		2025-06-28
PLhm-DtnIjs6sywkTxFpV6OiVs0lQYG7Mo	UCW2Ew5V3I2z1jXvsZEkKtUQ	1	Best Support Gameplay		2025-06-28
PLhm-DtnIjs6uQbY5EwAwlDYHax11lIC3s	UCW2Ew5V3I2z1jXvsZEkKtUQ	1	Best Offlane Gameplay		2025-06-28
PLhm-DtnIjs6vqDRLBHQvKxG9b0CE8D8iC	UCW2Ew5V3I2z1jXvsZEkKtUQ	1	Best Safelane Gameplay		2025-06-28
PLhm-DtnIjs6t7bjduxkAfrlbC5CweIK6J	UCW2Ew5V3I2z1jXvsZEkKtUQ	1	Best Midlane Gameplay		2025-06-28
PLhm-DtnIjs6u_YavG0Ns7DDtMZeT-0YQ6	UCW2Ew5V3I2z1jXvsZEkKtUQ	1	Megacreep Comeback		2025-06-28
PLhm-DtnIjs6vMocEe-tC4xuDT7AcJQbAD	UCW2Ew5V3I2z1jXvsZEkKtUQ	1	Intense Battle of Hard Carry		2025-06-28
PLHQyUE9yPrPMkElv6BWvssPntzXk3AzEu	UCS3_m4V1yExUC18ejJnd1IQ	1	Elden Ring		2025-06-28
PLHQyUE9yPrPO0cyJYtmlDvNS3dweAlO8i	UCS3_m4V1yExUC18ejJnd1IQ	1	Last Pick		2025-06-28
PLHQyUE9yPrPP0CD8DqEa3oHE4ROxARDv9	UCS3_m4V1yExUC18ejJnd1IQ	1	Warding		2025-06-28
PLHQyUE9yPrPNfT729pAg-mwnSQuWsqqtv	UCS3_m4V1yExUC18ejJnd1IQ	1	Eye Tracker Immortal Gameplay Commentary		2025-06-28
PLHQyUE9yPrPN4ija09g6dc3e04GvLQhCx	UCS3_m4V1yExUC18ejJnd1IQ	1	Support Spotlight		2025-06-28
PLHQyUE9yPrPOMtCsTwjzcXZqpmpXZZijr	UCS3_m4V1yExUC18ejJnd1IQ	1	Replay Analysis Highlights		2025-06-28
PLHQyUE9yPrPPLzyohQ89bG7AL2VcB3Gt_	UCS3_m4V1yExUC18ejJnd1IQ	1	Whose Fault Is It Anyways?		2025-06-28
PLHQyUE9yPrPMk8dEuUoMlhF054DumvkGe	UCS3_m4V1yExUC18ejJnd1IQ	1	Game Plan		2025-06-28
PLHQyUE9yPrPPtK-qqG3VMRPTOia8r2p15	UCS3_m4V1yExUC18ejJnd1IQ	1	Road to Top 1000		2025-06-28
PLHQyUE9yPrPNe0HC0k63jeyLqti4NWPm0	UCS3_m4V1yExUC18ejJnd1IQ	1	Dota 2 Beginner Videos		2025-06-28
PLHQyUE9yPrPMh47qUsMnl5JdlnjeyHuQB	UCS3_m4V1yExUC18ejJnd1IQ	1	On Pulling		2025-06-28
PLHQyUE9yPrPPvRZVy0Frd-9zp8Tt_Jz7M	UCS3_m4V1yExUC18ejJnd1IQ	1	Legitimate Dota 2 advice disguised as clickbait		2025-06-28
PLHQyUE9yPrPPdOyjtpskK2cc2lyF0TBde	UCS3_m4V1yExUC18ejJnd1IQ	1	Why Did I Lose?		2025-06-28
PLHQyUE9yPrPOGsXLQLXJaLTUwdyoXNhCY	UCS3_m4V1yExUC18ejJnd1IQ	1	Support Itemization		2025-06-28
PLHQyUE9yPrPMm_0_2yJYobT0HToPAlP8-	UCS3_m4V1yExUC18ejJnd1IQ	1	Hard Support Guide		2025-06-28
PLHQyUE9yPrPMA9A8I2-j_QhxrwfLl6Gv0	UCS3_m4V1yExUC18ejJnd1IQ	1	+1 MMR		2025-06-28
PLHQyUE9yPrPO6_tdSbD8UOfFdb6mwa4io	UCS3_m4V1yExUC18ejJnd1IQ	1	Thought Process Analysis		2025-06-28
PLHQyUE9yPrPNcnBceH-j_8HE0TxJC43Tb	UCS3_m4V1yExUC18ejJnd1IQ	1	Opening The Dawngate: For Beginners		2025-06-28
PLa1GcPqEaXg54X32G9UiRR7jqbTN9GZiQ	UC8rWMk2o4KHkoMWybi0rVlA	1	Educational Carry Coaching Series		2025-06-28
PLa1GcPqEaXg5jE9TDJHKueFw7aEuHTg9K	UC8rWMk2o4KHkoMWybi0rVlA	1	Exclusive Coaching Vods		2025-06-28
PLa1GcPqEaXg7bSOtOuhfNhQK5D9_MKfKL	UC8rWMk2o4KHkoMWybi0rVlA	1	PainDota		2025-06-28
PLa1GcPqEaXg5JBUz1f-ITO2OIqqU1ULyo	UC8rWMk2o4KHkoMWybi0rVlA	1	Dota Overexplained		2025-06-28
PLa1GcPqEaXg5DOhl-M4AVqNqEyAYCPvGJ	UC8rWMk2o4KHkoMWybi0rVlA	1	Entering The Mind Series		2025-06-28
PLkv2JjC9ElPZF-sTYF5wkY-YzTU8w4smO	UCpCG__ifmbaTPaQnpixkB4w	1	ability draft		2025-06-28
PLkv2JjC9ElPYAXxjXuEFAQwxckl8nbVT5	UCpCG__ifmbaTPaQnpixkB4w	1	Ability Draft Clips		2025-06-28
PLkv2JjC9ElPa7ENtXnEr6663FW1FdJYJX	UCpCG__ifmbaTPaQnpixkB4w	1	Dota 2 Ability Draft		2025-06-28
PLiixujFpk81SfOTxndr38xutLZdgEF-Ur	UCHky6L8_p73ujg9II9La_6A	1	COMEBACK MATCH		2025-06-28
PLiixujFpk81RzO82g2Rj-AWMbTjc9e_By	UCHky6L8_p73ujg9II9La_6A	1	SMURF GAMEPLAY		2025-06-28
PLiixujFpk81Q-PNKi0h6sbNIyNTVcgeVz	UCHky6L8_p73ujg9II9La_6A	1	ALL VIDEO		2025-06-28
PLiixujFpk81SuohayH8IbzLRV6CHcp8Q4	UCHky6L8_p73ujg9II9La_6A	1	Pro Mage Series		2025-06-28
PLiixujFpk81RJSPZvdu531BNq4TBFmhp6	UCHky6L8_p73ujg9II9La_6A	1	Pro Carry Series		2025-06-28
PLiixujFpk81QIjwh-Igpf1q9q1lz5KGRq	UCHky6L8_p73ujg9II9La_6A	1	New Videos		2025-06-28
PLH6DTK3rGj80Jm9SArHMYCav31_vvJPbZ	UCqsQG398BFcxNojHLg26L9g	1	Dota 2 Support Guide		2025-06-28
PLH6DTK3rGj80mQrXU1IbTJO09iCcOgeQU	UCqsQG398BFcxNojHLg26L9g	1	How to Play Pos 3 Offlane Players Perspective		2025-06-28
PLH6DTK3rGj80Ro001Td_Vme_PmZ-HdKyF	UCqsQG398BFcxNojHLg26L9g	1	Learn from My [Subscriber Playlist] DOTA 2		2025-06-28
PLH6DTK3rGj82NFZ4BSNau30XIHyAP6YPr	UCqsQG398BFcxNojHLg26L9g	1	How to Play Pos 2 Guide Dota 2 Pro Players Perspective		2025-06-28
PLH6DTK3rGj80TcWmyZRZ8QXuUHimul6lU	UCqsQG398BFcxNojHLg26L9g	1	How to Play Pos 1 Guide Dota 2 Pro Players Perspective		2025-06-28
PLH6DTK3rGj812GIDJKOAp2-mVann5o1TM	UCqsQG398BFcxNojHLg26L9g	1	Dota 2 Safelane Guide		2025-06-28
PLH6DTK3rGj80Z0UrN3TreI-aATsToE_0V	UCqsQG398BFcxNojHLg26L9g	1	Dota 2 Offlane Guide		2025-06-28
PLH6DTK3rGj80p3J4A4eKrigI8vBCEVpKV	UCqsQG398BFcxNojHLg26L9g	1	Dota 2 Midlane Guide		2025-06-28
PLuZukHwpRUbItyKsLViqSUEWyLUtPNSlg	UCdO3EenGrBpD7KCePa13c2A	1	Dota 2 7.38 Explained		2025-06-28
PLuZukHwpRUbJNFMwvFpHjipE5ldjBghs5	UCdO3EenGrBpD7KCePa13c2A	1	Pro Player Analysis		2025-06-28
PLuZukHwpRUbLQohOuk8k8M3AlQi2mhXql	UCdO3EenGrBpD7KCePa13c2A	1	Dota 2 Shorts		2025-06-28
PLuZukHwpRUbLD9YtW3lw7SfDePaxKv28K	UCdO3EenGrBpD7KCePa13c2A	1	Laning Stage Guides		2025-06-28
PLuZukHwpRUbKZIIks5drfbOHOj-_DmbCz	UCdO3EenGrBpD7KCePa13c2A	1	Dota 2 Funny Gameplays		2025-06-28
PLuZukHwpRUbL6S7wf0av9ekdDPhivtcP2	UCdO3EenGrBpD7KCePa13c2A	1	Dota 2 Short Guides		2025-06-28
PLuZukHwpRUbK5EEvaMIFw3BSuSBCrU7x5	UCdO3EenGrBpD7KCePa13c2A	1	Top Heroes To Gain MMR		2025-06-28
PLuZukHwpRUbKu8UfDcmpsEnwrtRdc0sCq	UCdO3EenGrBpD7KCePa13c2A	1	Coaching Sessions		2025-06-28
PLuZukHwpRUbIA04I1IdW2i5ZSAH1d_oG_	UCdO3EenGrBpD7KCePa13c2A	1	How To Gain MMR - Uncut Gameplays From Immortal Bracket		2025-06-28
PLuZukHwpRUbJA9nOJPkKIl7TsFlCZ4YXu	UCdO3EenGrBpD7KCePa13c2A	1	Dota 2 Support Guides		2025-06-28
PL2GeohMgo7U3Zm0blamHxLwXu05ql_H26	UCAi2SCg-RMzEB1sap7UKlvw	1	7.37d Tier Lists		2025-06-28
PL2GeohMgo7U0CdOE_26h008K8euVd9bT4	UCAi2SCg-RMzEB1sap7UKlvw	1	ULTIMATE Hero Guides		2025-06-28
PL2GeohMgo7U2LSSGrn-3dPVfNjwx9Tfu_	UCAi2SCg-RMzEB1sap7UKlvw	1	7.36c Tier Lists		2025-06-28
PL2GeohMgo7U2l8piNGz-HyBs0D15rmJ29	UCAi2SCg-RMzEB1sap7UKlvw	1	7.36b (FACET PATCH) Top 5 Heroes per Role		2025-06-28
PL2GeohMgo7U3Gbr1i8ZcppnPs63kbmfll	UCAi2SCg-RMzEB1sap7UKlvw	1	DOTA EXPLAINED		2025-06-28
PL2GeohMgo7U26qcGbaKT7XvokirMv6Rk7	UCAi2SCg-RMzEB1sap7UKlvw	1	TIER LISTS		2025-06-28
PL2GeohMgo7U2SdhomVie3j0H8zQ06EHDp	UCAi2SCg-RMzEB1sap7UKlvw	1	Coaching VODS		2025-06-28
PL2GeohMgo7U1GNvk8G2Pl3f9Lyd5248Hb	UCAi2SCg-RMzEB1sap7UKlvw	1	HOW TO PLAY HEROES		2025-06-28
PLPz-Cj9I6QGgmGYExWwlZAxpTCpo0Yer6	UCWBWm89MmoSHEXLoEeUbVTw	1	TI 10		2025-06-28
PLPz-Cj9I6QGiZ4sHm_oShQS9TnffD4_mj	UCWBWm89MmoSHEXLoEeUbVTw	1	Support		2025-06-28
PLPz-Cj9I6QGhPjX4vD49KU7ZzDmk-8AW6	UCWBWm89MmoSHEXLoEeUbVTw	1	Off Lane		2025-06-28
PLPz-Cj9I6QGgNQMGbnP4WT4LYXSYn8849	UCWBWm89MmoSHEXLoEeUbVTw	1	Safe Lane Carry		2025-06-28
PLPz-Cj9I6QGj8NbQiFc_rFVIVS2WoIBzP	UCWBWm89MmoSHEXLoEeUbVTw	1	Mid Lane		2025-06-28
PLU4HXQMvlS0wGno-QuWjAG37wC8I3zhpQ	UCIE4fk1t6sXYqszHLU-Tk5g	1	Stray		2025-06-28
PLU4HXQMvlS0y8nnesp_PgMhAH6ZeaEwc-	UCIE4fk1t6sXYqszHLU-Tk5g	1	Little Nightmare 2		2025-06-28
PLU4HXQMvlS0y90smDN5olRVJjO_GB-87z	UCIE4fk1t6sXYqszHLU-Tk5g	1	Resident 2		2025-06-28
PLU4HXQMvlS0xJtRtUaBU3fCLxt3qPlnZH	UCIE4fk1t6sXYqszHLU-Tk5g	1	Resident Evil 3		2025-06-28
PLTuWN0L3pVQXPTNL8S1UQDff9DEYna3CR	UCL7w4AbdEGE3UjzHI3AjXOg	1	pudge		2025-06-28
PLTuWN0L3pVQWts7ZrwxP9RvMM6TsE7bg2	UCL7w4AbdEGE3UjzHI3AjXOg	1	zeus		2025-06-28
PLTuWN0L3pVQUBUM63kyWb9ZuGg8fMglPs	UCL7w4AbdEGE3UjzHI3AjXOg	1	winter wyvern		2025-06-28
PLTuWN0L3pVQUSzP0HF8bTkn4uRBH_NlI8	UCL7w4AbdEGE3UjzHI3AjXOg	1	silencer		2025-06-28
PLTuWN0L3pVQXw15cXJTmeUMKImC_J3CgS	UCL7w4AbdEGE3UjzHI3AjXOg	1	hoodwink		2025-06-28
PLTuWN0L3pVQW1C7NrIYujomXAsjuht1c7	UCL7w4AbdEGE3UjzHI3AjXOg	1	undying		2025-06-28
PLTuWN0L3pVQWdUvnw6D1ZPxw-3IoBCeU6	UCL7w4AbdEGE3UjzHI3AjXOg	1	grimstroke		2025-06-28
PLTuWN0L3pVQXkGlYblMokB2-3ufbgh2CJ	UCL7w4AbdEGE3UjzHI3AjXOg	1	pugna		2025-06-28
PLTuWN0L3pVQUdaD-3ZAQHF6yctMXS2KH0	UCL7w4AbdEGE3UjzHI3AjXOg	1	earth spirit		2025-06-28
PLTuWN0L3pVQU_-9er2ngqXOZuNBTf8wyP	UCL7w4AbdEGE3UjzHI3AjXOg	1	rubick		2025-06-28
PLTuWN0L3pVQXpfHaUBhq6he84FbSrDnpe	UCL7w4AbdEGE3UjzHI3AjXOg	1	enigma		2025-06-28
PLTuWN0L3pVQVib-ZKomNc-LNeIDmOywKZ	UCL7w4AbdEGE3UjzHI3AjXOg	1	bristleback		2025-06-28
PLTuWN0L3pVQXMok6fPP-htqD71jeVMK9X	UCL7w4AbdEGE3UjzHI3AjXOg	1	spirit breaker		2025-06-28
PLTuWN0L3pVQX28V-L12QzjxfCYFlDuGcA	UCL7w4AbdEGE3UjzHI3AjXOg	1	windranger		2025-06-28
PLTuWN0L3pVQWrxEofqPBz-mWhmgfC0jwC	UCL7w4AbdEGE3UjzHI3AjXOg	1	lich		2025-06-28
PLTuWN0L3pVQUsSY-x2d9QUU_2QyJl9FlC	UCL7w4AbdEGE3UjzHI3AjXOg	1	axe		2025-06-28
PLTuWN0L3pVQXLRJlAAL4i6X6JZJyQOcFm	UCL7w4AbdEGE3UjzHI3AjXOg	1	earthshaker		2025-06-28
PLTuWN0L3pVQU_aV2fXl3-7J8GthKZkpKb	UCL7w4AbdEGE3UjzHI3AjXOg	1	techies		2025-06-28
PLTuWN0L3pVQUt6nfNSvPvG-7Rvkl4I5kk	UCL7w4AbdEGE3UjzHI3AjXOg	1	dota		2025-06-28
PL7BsA_GCNpAzfp7bLNqynFRtpyeX8UJgA	UCwD_AqoRMwOX6w0AiGWr4jA	1	TURBO -FAST GAME AND TRY NEW BUILD IN DOTA 2		2025-06-28
PL7BsA_GCNpAyMiPRySlb8jYmtyStZ0mgx	UCwD_AqoRMwOX6w0AiGWr4jA	1	RANK GAMEPLAY		2025-06-28
PL7BsA_GCNpAzGbuDnyp7xjsXOyoLWijCg	UCwD_AqoRMwOX6w0AiGWr4jA	1	FULL GAMEPLAY		2025-06-28
PLNtb6R9MQNMbZ5UCMOxF4Zx3CYvajaugz	UC8Rv6PXWZ5ERqoLlUsIyQ8w	1	Concepts You Need to Know to Gain Rank		2025-06-28
PLNtb6R9MQNMbOU0ms-LlA7JO8US8X-7lp	UC8Rv6PXWZ5ERqoLlUsIyQ8w	1	Short Tips		2025-06-28
PLNtb6R9MQNMbAu3BqLNwnsAocx_jk_U1-	UC8Rv6PXWZ5ERqoLlUsIyQ8w	1	High Level Map Movements		2025-06-28
PLNtb6R9MQNMYVSG1yqTvCJBEOdXJEVVlK	UC8Rv6PXWZ5ERqoLlUsIyQ8w	1	Hero-Specific Videos		2025-06-28
PLNtb6R9MQNMZ_DuI3o34AYodpesrPzL1g	UC8Rv6PXWZ5ERqoLlUsIyQ8w	1	BSJ Coaches Carbonyl		2025-06-28
PLNtb6R9MQNMZsGV91uDBNBgmR1RZzX0Ll	UC8Rv6PXWZ5ERqoLlUsIyQ8w	1	Competitive Match Analyses		2025-06-28
PLNtb6R9MQNMZo0W8RKZKfoynolzQfCsEl	UC8Rv6PXWZ5ERqoLlUsIyQ8w	1	Owning the Lane		2025-06-28
PLNtb6R9MQNMbSzQovgROJzVuBIyEi9Rj0	UC8Rv6PXWZ5ERqoLlUsIyQ8w	1	DotA Arcade Vids		2025-06-28
PLNtb6R9MQNMaRp21oz0eaCNysIJQ_fMon	UC8Rv6PXWZ5ERqoLlUsIyQ8w	1	Edu-Flame		2025-06-28
PLNtb6R9MQNMbMOYbgpReot1YXAtlLRKIS	UC8Rv6PXWZ5ERqoLlUsIyQ8w	1	Funny		2025-06-28
PLNtb6R9MQNMYjKK1Oh9QiFcTISkgZjFvL	UC8Rv6PXWZ5ERqoLlUsIyQ8w	1	Support Itemization		2025-06-28
PLNtb6R9MQNMbPTS8n1KWxVlcPH-zYRZ_y	UC8Rv6PXWZ5ERqoLlUsIyQ8w	1	DotA Knowledge		2025-06-28
PLNtb6R9MQNMb9bVtINJv9DgHwsr-Cffgy	UC8Rv6PXWZ5ERqoLlUsIyQ8w	1	Understanding Your Hero at a High Level		2025-06-28
PLNtb6R9MQNMbhkxZctxGBVl1MISkk8LrF	UC8Rv6PXWZ5ERqoLlUsIyQ8w	1	Replay Analyses of Pro Players		2025-06-28
PLNtb6R9MQNMb9s0auW-hyaPkhLpc2kwnh	UC8Rv6PXWZ5ERqoLlUsIyQ8w	1	Pos 5 Replay Analyses		2025-06-28
PLNtb6R9MQNMad4S_JtlGFLsAmnBi1LJte	UC8Rv6PXWZ5ERqoLlUsIyQ8w	1	Pos 4 Replay Analyses		2025-06-28
PLNtb6R9MQNMbGsFdGfEhEgMyncPpFVwtz	UC8Rv6PXWZ5ERqoLlUsIyQ8w	1	Pos3 Replay Analyses		2025-06-28
PLNtb6R9MQNMZk5JCL_d144s9TfVUQDrdF	UC8Rv6PXWZ5ERqoLlUsIyQ8w	1	Pos 2 Replay Analyses		2025-06-28
PLNtb6R9MQNMbh3gRQIaZjBlaFWJacT3It	UC8Rv6PXWZ5ERqoLlUsIyQ8w	1	Pos 1 Replay Analyses		2025-06-28
PLNtb6R9MQNMb-9ap11YtlxgJ6usik-bhs	UC8Rv6PXWZ5ERqoLlUsIyQ8w	1	Pos 5 Live Coaching		2025-06-28
PLNtb6R9MQNMYTXU0RDsJ4g_wlGL1Yp9TX	UC8Rv6PXWZ5ERqoLlUsIyQ8w	1	Pos 1 Live Coaching		2025-06-28
PLNtb6R9MQNMZfInAA27MlwkZMBGHmb0pJ	UC8Rv6PXWZ5ERqoLlUsIyQ8w	1	Live Game Recordings		2025-06-28
PLNtb6R9MQNMY9-0wN34dhOV5ozcfkb3zs	UC8Rv6PXWZ5ERqoLlUsIyQ8w	1	Making a Plan for Your Lane		2025-06-28
PLNtb6R9MQNMZgLg9jou-10yKlsdj0stis	UC8Rv6PXWZ5ERqoLlUsIyQ8w	1	Pos 3 Live Coaching		2025-06-28
PLNtb6R9MQNMbGRmqTr2GZiqIz8jJHoTQ2	UC8Rv6PXWZ5ERqoLlUsIyQ8w	1	Pos 4 Live Coaching		2025-06-28
PLNtb6R9MQNMbq_PZxX57tOKxCZkdWOo2d	UC8Rv6PXWZ5ERqoLlUsIyQ8w	1	Casting VODS		2025-06-28
PLNtb6R9MQNMYFkpgFnHZK-tc1zEfee6k4	UC8Rv6PXWZ5ERqoLlUsIyQ8w	1	Replay Analyses - My Own Games		2025-06-28
PLNtb6R9MQNMaQQG3Bj5qMyqaiXv5cCkKi	UC8Rv6PXWZ5ERqoLlUsIyQ8w	1	High Level Educational Videos		2025-06-28
PLNtb6R9MQNMbB8koR8tr8gLrhgZO2N4ca	UC8Rv6PXWZ5ERqoLlUsIyQ8w	1	Pos 2 Live Coaching		2025-06-28
PL_k6nRnkLOl5RG3A6yMgZ6FLgY5pgo6U9	UCBzrhVhJUaOI0dtpZqGeB2Q	1	Dota 2 videos by 4fun		2025-06-28
PL9E7875EF457478F7	UCBzrhVhJUaOI0dtpZqGeB2Q	1	4fun beatz production		2025-06-28
PL7FF503F9CDBE6A8D	UCBzrhVhJUaOI0dtpZqGeB2Q	1	Dota Movies		2025-06-28
PLbRMnP3sOxXtlYflosBxAiH5uX4w2nMHG	UCnUgUdncVcxVaqMvQSD_DuA	1	Invoker guide		2025-06-28
PLxkyNsoBqOdAAJ-4VPSpjcKU8ADzYGOTE	UCTQKT5QqO3h7y32G8VzuySQ	1	The International 2024 - Content		2025-06-28
PLxkyNsoBqOdAREYp7AVaKLCNGvUKHZBu5	UCTQKT5QqO3h7y32G8VzuySQ	1	[CN] The International 2024		2025-06-28
PLxkyNsoBqOdCiLbb23xNv64dF8F0Je2SG	UCTQKT5QqO3h7y32G8VzuySQ	1	[ES] The International 2024		2025-06-28
PLxkyNsoBqOdDAsgf-2wlHd_3pzkai0uCM	UCTQKT5QqO3h7y32G8VzuySQ	1	[RU] The International 2024		2025-06-28
PLxkyNsoBqOdB6R4SAp84JwzcDlOjwyJc9	UCTQKT5QqO3h7y32G8VzuySQ	1	The International 2024		2025-06-28
PLxkyNsoBqOdDOwAxlJW3A9R2AcBCon3z0	UCTQKT5QqO3h7y32G8VzuySQ	1	The International 2024 - Playoffs		2025-06-28
PLxkyNsoBqOdDOJcC2lRNu89Rdag1AtPWO	UCTQKT5QqO3h7y32G8VzuySQ	1	The International 2024 - Playoffs		2025-06-28
PLxkyNsoBqOdBHX3FWzEl62lzH99ClobES	UCTQKT5QqO3h7y32G8VzuySQ	1	[CN] ROAD TO TI 2024: PLAYOFFS		2025-06-28
PLxkyNsoBqOdA3VbgwsZD042OKjvA9_Nfs	UCTQKT5QqO3h7y32G8VzuySQ	1	[ES] ROAD TO TI 2024: PLAYOFFS		2025-06-28
PLxkyNsoBqOdBnSWS101sYxMnHK4DUonh9	UCTQKT5QqO3h7y32G8VzuySQ	1	[RU] ROAD TO TI 2024: PLAYOFFS		2025-06-28
PLxkyNsoBqOdCIDPGFiV50tv3_l9yvybbX	UCTQKT5QqO3h7y32G8VzuySQ	1	ROAD TO TI 2024: PLAYOFFS		2025-06-28
PLxkyNsoBqOdD8Be39Rm3ENe3bAYMtoux5	UCTQKT5QqO3h7y32G8VzuySQ	1	The International 2024 - Group D		2025-06-28
PLxkyNsoBqOdCtCunaeKvPnVq-J4V_bVR9	UCTQKT5QqO3h7y32G8VzuySQ	1	The International 2024 - Group D		2025-06-28
PLxkyNsoBqOdAcQwoajeOfDy4Wfs0Hf6e7	UCTQKT5QqO3h7y32G8VzuySQ	1	The International 2024 - Group C		2025-06-28
PLxkyNsoBqOdDTb12PUcnOqqdhX30m389y	UCTQKT5QqO3h7y32G8VzuySQ	1	The International 2024 - Group C		2025-06-28
PLxkyNsoBqOdDTMsg95LMU1NOybJH4ailw	UCTQKT5QqO3h7y32G8VzuySQ	1	The International 2024 - Group A		2025-06-28
PLxkyNsoBqOdCyexFyTaYS57PCzr0ql6Mz	UCTQKT5QqO3h7y32G8VzuySQ	1	The International 2024 - Group B		2025-06-28
PLxkyNsoBqOdCVKKWbq6T05is1tC_VzUkz	UCTQKT5QqO3h7y32G8VzuySQ	1	The International 2024 - Group B		2025-06-28
PLxkyNsoBqOdArcLn1XowA79Ak_4RaM7Cu	UCTQKT5QqO3h7y32G8VzuySQ	1	The International 2024 - Group A		2025-06-28
PLxkyNsoBqOdCa0VIkP2EA4byKqEY9GVfi	UCTQKT5QqO3h7y32G8VzuySQ	1	[CN] ROAD TO TI 2024: GROUP STAGE		2025-06-28
PLxkyNsoBqOdD98cCvb9m5oFwtgokV4Frs	UCTQKT5QqO3h7y32G8VzuySQ	1	[ES] ROAD TO TI 2024: GROUP STAGE		2025-06-28
PLxkyNsoBqOdB9fij5QeQG-yv1AMVBkJTT	UCTQKT5QqO3h7y32G8VzuySQ	1	[RU] ROAD TO TI 2024: GROUP STAGE		2025-06-28
PLxkyNsoBqOdD01XTSjTEO5zs8M8gNJ6cV	UCTQKT5QqO3h7y32G8VzuySQ	1	ROAD TO TI 2024: GROUP STAGE		2025-06-28
PLxkyNsoBqOdACJ6t95AeoIWDbTw32k5s0	UCTQKT5QqO3h7y32G8VzuySQ	1	The International 2023 - Finals		2025-06-28
PLxkyNsoBqOdB2-sQwPY_KwBMkgnbC4lnc	UCTQKT5QqO3h7y32G8VzuySQ	1	The International 2023 - PLAYOFFS		2025-06-28
PLxkyNsoBqOdDT4_IA7rPR4JMZLAmkeT16	UCTQKT5QqO3h7y32G8VzuySQ	1	[RU] The International 2023		2025-06-28
PLxkyNsoBqOdB5w_L92gan6yMvPgbOplpL	UCTQKT5QqO3h7y32G8VzuySQ	1	[ES] The International 2023		2025-06-28
PLxkyNsoBqOdD68FyLdCUsK1-TKSYDkXzi	UCTQKT5QqO3h7y32G8VzuySQ	1	Ti12 Group Stage Vignettes		2025-06-28
PLxkyNsoBqOdBZkCYvvGJjZvjYZtdI8G7k	UCTQKT5QqO3h7y32G8VzuySQ	1	The International 2023 - Playoffs		2025-06-28
PLxkyNsoBqOdCtn3yd56v3x87hPTnytzBo	UCTQKT5QqO3h7y32G8VzuySQ	1	[CN] The International 2023		2025-06-28
PLxkyNsoBqOdAyQIQ6eI_gjpZn9azRxSt1	UCTQKT5QqO3h7y32G8VzuySQ	1	The International 2023 - Group Stage		2025-06-28
PLxkyNsoBqOdC7gW6F_pM08ifj1prCUw_4	UCTQKT5QqO3h7y32G8VzuySQ	1	Dota 2 | Film Content		2025-06-28
PLxkyNsoBqOdDRxeR4S9b60M0hxEDx8nHp	UCTQKT5QqO3h7y32G8VzuySQ	1	The International #Shorts		2025-06-28
PLxkyNsoBqOdDSj6QkS4LQpdQ1ritAO95a	UCTQKT5QqO3h7y32G8VzuySQ	1	The International 2022 - Event Entertainment		2025-06-28
PLxkyNsoBqOdBonVPa5lbMh1C-6BWaCoI7	UCTQKT5QqO3h7y32G8VzuySQ	1	The International 2022 - Main Event		2025-06-28
PLxkyNsoBqOdALK6gG2ezE_AQQdnQigFhE	UCTQKT5QqO3h7y32G8VzuySQ	1	The International 2021 - Memories		2025-06-28
PLxkyNsoBqOdB-bi8XWvq6uQtyQWkF-_xP	UCTQKT5QqO3h7y32G8VzuySQ	1	The International 2021 - Rapid Fire Questions		2025-06-28
PLxkyNsoBqOdDhwxZ9jT2gEzzmS5FSoGSz	UCTQKT5QqO3h7y32G8VzuySQ	1	The International 2021 - Main Event		2025-06-28
PLxkyNsoBqOdBfJSCRdO7qPZrSsslw6kBi	UCTQKT5QqO3h7y32G8VzuySQ	1	The International 2021 -  Captain Interviews		2025-06-28
PLxkyNsoBqOdDeldpHpbb62WZribrSTeon	UCTQKT5QqO3h7y32G8VzuySQ	1	The International 2021 - DPC Recaps		2025-06-28
PLxkyNsoBqOdA5JA7aZpOhQ8XSGjR769Sx	UCTQKT5QqO3h7y32G8VzuySQ	1	The International 2021 - Event Entertainment		2025-06-28
PLxkyNsoBqOdBd03IvAMDxaIkig3ZmNlrB	UCTQKT5QqO3h7y32G8VzuySQ	1	The International 2021 - Group Stage		2025-06-28
PLxkyNsoBqOdCeU9PIsFDJx2DBx4hG39vR	UCTQKT5QqO3h7y32G8VzuySQ	1	[RU] The International 2021		2025-06-28
PLxkyNsoBqOdCh4AjTJJhyI7Q-79dKTJzL	UCTQKT5QqO3h7y32G8VzuySQ	1	[ES] The International 2021		2025-06-28
PLxkyNsoBqOdBoN6M1077J9d6bXC8bNIvb	UCTQKT5QqO3h7y32G8VzuySQ	1	[PT] The International 2021		2025-06-28
PLxkyNsoBqOdCB9QStrkmTZuYOVonn2-GN	UCTQKT5QqO3h7y32G8VzuySQ	1	[CN] The International 2021		2025-06-28
PLxkyNsoBqOdBvT8MaxDKwLCVKU4Q6rKPW	UCTQKT5QqO3h7y32G8VzuySQ	1	The International - Dota 2 Championships		2025-06-28
PLxkyNsoBqOdBlEwcb-97L2rpjTMIQMrzy	UCTQKT5QqO3h7y32G8VzuySQ	1	The International 2019 - Main Event Day 6		2025-06-28
PLxkyNsoBqOdAGcDMHsg9Rs-aQW3aUg-oX	UCTQKT5QqO3h7y32G8VzuySQ	1	The International 2019 - Main Event Day 5		2025-06-28
PLxkyNsoBqOdD5c4YLWV0rItmfJB0YnJtP	UCTQKT5QqO3h7y32G8VzuySQ	1	[CN] The International 2019 Main Event		2025-06-28
PLxkyNsoBqOdA6NzhToYTUJCwVdkonyL-r	UCTQKT5QqO3h7y32G8VzuySQ	1	The International 2019 - Main Event Day 4		2025-06-28
PLxkyNsoBqOdCJLzC5qLxO7BnG5-EKy-ZJ	UCTQKT5QqO3h7y32G8VzuySQ	1	The International 2019 - Main Event Day 3		2025-06-28
PLxkyNsoBqOdC0RDFFI0v1KJbaAdxt8vq0	UCTQKT5QqO3h7y32G8VzuySQ	1	[RU] The International 2019 Main Event		2025-06-28
PLxkyNsoBqOdAbw-F3D4rG2UqXmlxHkzcn	UCTQKT5QqO3h7y32G8VzuySQ	1	The International 2019 - Main Event Day 2		2025-06-28
PLxkyNsoBqOdDcEmdMUbDwS8eryyT6wMTu	UCTQKT5QqO3h7y32G8VzuySQ	1	The International 2019 - Team Interviews		2025-06-28
PLxkyNsoBqOdDTvgM9FDKxko1mrRHg9SDC	UCTQKT5QqO3h7y32G8VzuySQ	1	The International 2019 - Main Event Day 1		2025-06-28
PLxkyNsoBqOdCfIQTLHTmZH4TXggMqOI9t	UCTQKT5QqO3h7y32G8VzuySQ	1	The International 2019 - Event Entertainment		2025-06-28
PLxkyNsoBqOdBho_LtA-IEhVLEmUWcBOqd	UCTQKT5QqO3h7y32G8VzuySQ	1	The International 2019 Group Stage Day 4		2025-06-28
PLxkyNsoBqOdAvsQAZ1wU5Neh4Q0F4C8qW	UCTQKT5QqO3h7y32G8VzuySQ	1	The International 2019 Group Stage Day 3		2025-06-28
PLxkyNsoBqOdDjv-TRnG53WLhrffOP4pR-	UCTQKT5QqO3h7y32G8VzuySQ	1	The International 2019 Group Stage Day 2		2025-06-28
PLxkyNsoBqOdCQQBnQ2JJ73550WnH4UPKg	UCTQKT5QqO3h7y32G8VzuySQ	1	The International 2019 Group Stage Day 1		2025-06-28
PLxkyNsoBqOdBlyNZQ5VZsZ0aw26zGsF5y	UCTQKT5QqO3h7y32G8VzuySQ	1	TI8 - Team Interviews		2025-06-28
PLxkyNsoBqOdBiJmsLA5q1vE5nCybHhKSa	UCTQKT5QqO3h7y32G8VzuySQ	1	TI8 - Event Entertainment		2025-06-28
PLxkyNsoBqOdCucw-d85h_z2XtyTTwQwC9	UCTQKT5QqO3h7y32G8VzuySQ	1	The International 2018 Group Stage Day 4		2025-06-28
PLxkyNsoBqOdCHdl0lI7MZYwUsYeFUlX96	UCTQKT5QqO3h7y32G8VzuySQ	1	The International 2018 Group Stage Day 3		2025-06-28
PLxkyNsoBqOdDSE5jUQflNMSpN1956BLhv	UCTQKT5QqO3h7y32G8VzuySQ	1	The International 2018 Group Stage Day 2		2025-06-28
PLxkyNsoBqOdBaMqlNDj3dKojDjSG-7Uok	UCTQKT5QqO3h7y32G8VzuySQ	1	The International 2018 Group Stage Day 1		2025-06-28
PLxkyNsoBqOdBZElEzwP2B9HX3rsVuFz47	UCTQKT5QqO3h7y32G8VzuySQ	1	DPC Rewind and International Lowdown		2025-06-28
PLxkyNsoBqOdA1oiXd1XBJZriXbRccUvG3	UCTQKT5QqO3h7y32G8VzuySQ	1	TI7 - Event Entertainment		2025-06-28
PLxkyNsoBqOdBJgqp6AHXiebKmbgBy107v	UCTQKT5QqO3h7y32G8VzuySQ	1	True Sight		2025-06-28
PLxkyNsoBqOdCWsR-OUbJ6q2hAfEswNsTq	UCTQKT5QqO3h7y32G8VzuySQ	1	TI7 Team Graphics		2025-06-28
PLxkyNsoBqOdDSGhC-TFD7G0q0fGupt07-	UCTQKT5QqO3h7y32G8VzuySQ	1	TI7 Media - Official		2025-06-28
PLxkyNsoBqOdD0jbELbrryRwuAfeDPBa1R	UCTQKT5QqO3h7y32G8VzuySQ	1	TI6 Team Graphics		2025-06-28
PLxkyNsoBqOdBQr1cPDxGA00mzmRS94sNy	UCTQKT5QqO3h7y32G8VzuySQ	1	The International Archives Video Series		2025-06-28
PLxkyNsoBqOdCsJgsy1fEiK-jEh6gFPe1H	UCTQKT5QqO3h7y32G8VzuySQ	1	TI6 At the Event		2025-06-28
PLxkyNsoBqOdDima8WoXOWHZ4xdsoHaS1W	UCTQKT5QqO3h7y32G8VzuySQ	1	TI6 Media - Official		2025-06-28
PLxkyNsoBqOdBOU5OBzJaROgpwmtGNbekb	UCTQKT5QqO3h7y32G8VzuySQ	1	The Manila Major		2025-06-28
PLxkyNsoBqOdBDYhQ3npnuu8rSXZc5ta0w	UCTQKT5QqO3h7y32G8VzuySQ	1	The Frankfurt Major		2025-06-28
PLxkyNsoBqOdBGfqZNbJwcz5UiL7rhrk3h	UCTQKT5QqO3h7y32G8VzuySQ	1	DotA Roles		2025-06-28
PLxkyNsoBqOdDvk2pVoYClGERvRCxcHyNc	UCTQKT5QqO3h7y32G8VzuySQ	1	TI5 Group Stage - Day 3		2025-06-28
PLxkyNsoBqOdB1lFQV9TXO1oDhyRf2xRF-	UCTQKT5QqO3h7y32G8VzuySQ	1	TI5 Group Stage - Day 2		2025-06-28
PLxkyNsoBqOdDSBCNH9gQ2Zdg--_TUYWQv	UCTQKT5QqO3h7y32G8VzuySQ	1	TI5 Media - Official		2025-06-28
PLxkyNsoBqOdBSmuFw3nqlEoSTTbG3Sb6O	UCTQKT5QqO3h7y32G8VzuySQ	1	TI5 Group Stage - Day 1		2025-06-28
PLxkyNsoBqOdD3nPvoLHXKJjzzC_9x4AY8	UCTQKT5QqO3h7y32G8VzuySQ	1	TI5 Team Graphics		2025-06-28
PLxkyNsoBqOdDWxhZMxiJfXC77kpVHciTn	UCTQKT5QqO3h7y32G8VzuySQ	1	TI5 Community - English		2025-06-28
PLxkyNsoBqOdBYWIvWmQBAsM8IAbNlaPSO	UCTQKT5QqO3h7y32G8VzuySQ	1	TI4 - The International 2014		2025-06-28
PLxkyNsoBqOdBBk03Cuir6BOxi6r5mFT_8	UCTQKT5QqO3h7y32G8VzuySQ	1	TI4 Team Profiles - Russian		2025-06-28
PLxkyNsoBqOdBDJi7Q8A7TE1ia2ipknd2C	UCTQKT5QqO3h7y32G8VzuySQ	1	TI4 Team Profiles - Korean		2025-06-28
PLxkyNsoBqOdD7Dq3ns8ICmn2nt5Y4Pf_W	UCTQKT5QqO3h7y32G8VzuySQ	1	TI4 Team Profiles - Chinese		2025-06-28
PLxkyNsoBqOdBk016zTXgnYaLxP1Nem0PP	UCTQKT5QqO3h7y32G8VzuySQ	1	TI4 Team Profiles - English		2025-06-28
PLxkyNsoBqOdC8gYnOXhiSh772KHJNtCB4	UCTQKT5QqO3h7y32G8VzuySQ	1	TI4 Video News		2025-06-28
PLxkyNsoBqOdCLMBqT7sRRPw_4hBqVR0LY	UCTQKT5QqO3h7y32G8VzuySQ	1	The International 3 - Day Five Russian Commentary		2025-06-28
PLxkyNsoBqOdCogwkSiUCyQq5Oa7hT943W	UCTQKT5QqO3h7y32G8VzuySQ	1	The International 3 - Day Five Chinese Commentary		2025-06-28
PLxkyNsoBqOdAGT96lMckEkE6ZtGUXcP33	UCTQKT5QqO3h7y32G8VzuySQ	1	The International 3 - Day Five Korean Commentary		2025-06-28
PLxkyNsoBqOdDeAX056odt5W08a6caSAWS	UCTQKT5QqO3h7y32G8VzuySQ	1	The International 3 - Day Five English Commentary		2025-06-28
PLxkyNsoBqOdDQbE62kGTVoHCmnsGuy_LU	UCTQKT5QqO3h7y32G8VzuySQ	1	The International 3 - Day Four Chinese Commentary		2025-06-28
PLxkyNsoBqOdCKCXeElkjyQ7Wx7ONO8FEx	UCTQKT5QqO3h7y32G8VzuySQ	1	The International 3 - Day Four Korean Commentary		2025-06-28
PLxkyNsoBqOdDf29enF-2BvxrEAiXWd7_c	UCTQKT5QqO3h7y32G8VzuySQ	1	The International 3 - Day Four English Commentary		2025-06-28
PLxkyNsoBqOdBMomEMy_Ydi5iAoY2CsAMd	UCTQKT5QqO3h7y32G8VzuySQ	1	The International 3 - Day Four Russian Commentary		2025-06-28
PLxkyNsoBqOdA0OY19bJuH6CousQZ94lIm	UCTQKT5QqO3h7y32G8VzuySQ	1	The International 3 - Day Three Russian Commentary		2025-06-28
PLxkyNsoBqOdBN0kia_B9JL-leLnxTX1B9	UCTQKT5QqO3h7y32G8VzuySQ	1	The International 3 - Day Three Chinese Commentary		2025-06-28
PLxkyNsoBqOdDtBprWePkkmPckrYm9Q30k	UCTQKT5QqO3h7y32G8VzuySQ	1	The International 3 - Day Three Korean Commentary		2025-06-28
PLxkyNsoBqOdDjTmraa6uVHzSZKVWtlvb-	UCTQKT5QqO3h7y32G8VzuySQ	1	The International 3 - Day Three English Commentary		2025-06-28
PLxkyNsoBqOdAspH_7Hwp1FhC56p3sPONV	UCTQKT5QqO3h7y32G8VzuySQ	1	The International 3 - Day Two Russian Commentary		2025-06-28
PLxkyNsoBqOdAXhj1okOmyC0zgZRSVyxWo	UCTQKT5QqO3h7y32G8VzuySQ	1	The International 3 - Day Two Chinese Commentary		2025-06-28
PLxkyNsoBqOdAu96_Aern5Sh_PTFV0-yJq	UCTQKT5QqO3h7y32G8VzuySQ	1	The International 3 - Day Two Korean Commentary		2025-06-28
PLxkyNsoBqOdDon0uOhl_OrUWN9RVw9gIq	UCTQKT5QqO3h7y32G8VzuySQ	1	The International 3 - Day Two English Commentary		2025-06-28
PLxkyNsoBqOdBt4hbo4gv3YIHxM9mI17-j	UCTQKT5QqO3h7y32G8VzuySQ	1	The International 3 - Day One Korean Commentary		2025-06-28
PLxkyNsoBqOdDYwzf7L8Jqm285XPIOQ4Fj	UCTQKT5QqO3h7y32G8VzuySQ	1	The International 3 - Day One Chinese Commentary		2025-06-28
PLxkyNsoBqOdClhAjLKoOuAU_QBTVbzlFL	UCTQKT5QqO3h7y32G8VzuySQ	1	The International 3 - Day One Russian Commentary		2025-06-28
PLxkyNsoBqOdDIcoXC5rLhfkD7YOApaGXG	UCTQKT5QqO3h7y32G8VzuySQ	1	The International 3 - Day One English Commentary		2025-06-28
PLxkyNsoBqOdAnM8mo8_rv0tul67ycfK-k	UCTQKT5QqO3h7y32G8VzuySQ	1	Team Stories from The International 2012		2025-06-28
PL521991AD2E0F4EC4	UCTQKT5QqO3h7y32G8VzuySQ	1	The International 2012 Day Three - Russian Commentary		2025-06-28
PLFD6B60BCD84ACE84	UCTQKT5QqO3h7y32G8VzuySQ	1	The International 2012 Day Three - English Commentary		2025-06-28
PLC918605242FB8011	UCTQKT5QqO3h7y32G8VzuySQ	1	The International 2012 Day Two - Russian Commentary		2025-06-28
PL67038A673DA7B5E7	UCTQKT5QqO3h7y32G8VzuySQ	1	The International 2012 Day Two - English Commentary		2025-06-28
PL0DE426A67B0CE9FF	UCTQKT5QqO3h7y32G8VzuySQ	1	The International 2012 Day One - Russian Commentary		2025-06-28
PL6295232EFE2E2D9A	UCTQKT5QqO3h7y32G8VzuySQ	1	The International 2012 Day One - English Commentary		2025-06-28
PLBA3B17A3074999EE	UCTQKT5QqO3h7y32G8VzuySQ	1	The International 2011		2025-06-28
PLB31138203D342C35	UCTQKT5QqO3h7y32G8VzuySQ	1	The International 2011 - Grand Finals		2025-06-28
PLHroJCmC77feZyQyXEJ0emYFs4tz7laMD	UCyJfe8BMWqA2vJuYQ4PDOvw	1	The International 2022		2025-06-28
PLHroJCmC77fdHfSiS3BfEcIx8XpyTsjNy	UCyJfe8BMWqA2vJuYQ4PDOvw	1	The International 2021		2025-06-28
PLHroJCmC77fdK-johxAowpoKp-QyDbzgi	UCyJfe8BMWqA2vJuYQ4PDOvw	1	The International 2020		2025-06-28
PLHroJCmC77fdchiX6kJyjtxI9OwT2mpoL	UCyJfe8BMWqA2vJuYQ4PDOvw	1	The International 2019		2025-06-28
PLHroJCmC77fejO9wEMk0KNFIphawHTJwV	UCyJfe8BMWqA2vJuYQ4PDOvw	1	WTF builds that work		2025-06-28
PLHroJCmC77feJVkvT3o10RnqBnLSQZJ4f	UCyJfe8BMWqA2vJuYQ4PDOvw	1	The International 2018		2025-06-28
PLHroJCmC77fcyBJDmnMaOJrfxa8qUsE8y	UCyJfe8BMWqA2vJuYQ4PDOvw	1	Best Pro Plays weekly		2025-06-28
PLHroJCmC77feetkZZ5W9O0NXMjbU_aoLx	UCyJfe8BMWqA2vJuYQ4PDOvw	1	Dota PLUS		2025-06-28
PLHroJCmC77ffKL2j8OXvYwRdkB4t9IQNO	UCyJfe8BMWqA2vJuYQ4PDOvw	1	The International 2017		2025-06-28
PLHroJCmC77ffeKWMP1IXUu5ELw5_wrn2p	UCyJfe8BMWqA2vJuYQ4PDOvw	1	Kiev Major		2025-06-28
PLHroJCmC77ffsAAMDYrnE-oinosp_RJTQ	UCyJfe8BMWqA2vJuYQ4PDOvw	1	Boston Major 2016		2025-06-28
PLHroJCmC77feidi1tyteLu1fgRzOYRpsH	UCyJfe8BMWqA2vJuYQ4PDOvw	1	The International 2016		2025-06-28
PLHroJCmC77ffHcLUKc2fF8s8ck9s1jjMN	UCyJfe8BMWqA2vJuYQ4PDOvw	1	Manila Major		2025-06-28
PLHroJCmC77fdTnrDq4wCO7xyQqb8WotPy	UCyJfe8BMWqA2vJuYQ4PDOvw	1	Shanghai Major 2016		2025-06-28
PLHroJCmC77fcEd8S1E4pzCvxDhQjHdP90	UCyJfe8BMWqA2vJuYQ4PDOvw	1	Frankfurt Major 2015		2025-06-28
PLHroJCmC77ff999fXWD9I3TsAe7dpTBbF	UCyJfe8BMWqA2vJuYQ4PDOvw	1	Guides, tips, tricks		2025-06-28
PLHroJCmC77fcCfJs_buIuGYlHQ5uuXxnR	UCyJfe8BMWqA2vJuYQ4PDOvw	1	Epic Base Races and Comebacks		2025-06-28
PLHroJCmC77fcejCmiPWINE184xMQ3TQ4m	UCyJfe8BMWqA2vJuYQ4PDOvw	1	Beware of cheats/scripts/hacks		2025-06-28
PLHroJCmC77ff_gstVx8yM2svr4pcmrF6-	UCyJfe8BMWqA2vJuYQ4PDOvw	1	The International 2015		2025-06-28
PLHroJCmC77fehuIeuskyn-ttc2D3PZuns	UCyJfe8BMWqA2vJuYQ4PDOvw	1	Pro Fashion — pros cosmetic items choices		2025-06-28
PL24jljspU_FYRb7pJH0sAbUYR7KSHVnW0	UCUqLL4VcEy4mXcQL0O_H_bg	1	ELITE LEAGUE 2024 Dota 2 Highlights		2025-06-28
PL24jljspU_FarnAMe6f1gxb1Wx6z20MOU	UCUqLL4VcEy4mXcQL0O_H_bg	1	DotA Digest		2025-06-28
PL24jljspU_FYW_77oWm6HPgcDW_kjhkEA	UCUqLL4VcEy4mXcQL0O_H_bg	1	BB DACHA DUBAI 2024 Dota 2 Highlights		2025-06-28
PL24jljspU_FbJyqy5c9Tg0r8Ebl3_ooar	UCUqLL4VcEy4mXcQL0O_H_bg	1	KOBOLDS RAVE 2023 Dota 2 Highlights		2025-06-28
PL24jljspU_Fbh8IfiNFS4ul0k8GlvdpBX	UCUqLL4VcEy4mXcQL0O_H_bg	1	BB DACHA 2023 Dota 2 Highlights		2025-06-28
PL24jljspU_FZ3X_eJsAzYAVksYfuzBOHU	UCUqLL4VcEy4mXcQL0O_H_bg	1	RIYADH MASTERS 2023 Dota 2 Highlights		2025-06-28
PL24jljspU_FbFgXl5YqrFc_YzI1cbiuU0	UCUqLL4VcEy4mXcQL0O_H_bg	1	MALTA VIBES #1 2023 Dota 2 Highlights		2025-06-28
PL24jljspU_FaQ9pq2x7fnzBS7wF8St7ya	UCUqLL4VcEy4mXcQL0O_H_bg	1	LIMA MAJOR 2023 Dota 2 Highlights		2025-06-28
PL24jljspU_FZpmwGLuZFCkRKfRof3g3Nf	UCUqLL4VcEy4mXcQL0O_H_bg	1	BB UNIVERSE 2023 Dota 2 Highlights		2025-06-28
PL24jljspU_FYgwun3IKB6aSQC5iT3BQnu	UCUqLL4VcEy4mXcQL0O_H_bg	1	BTS PRO SERIES 2023 S14 Dota 2 Highlights		2025-06-28
PL24jljspU_FZ8D32i9Y0_Ur8ReqTIOsKf	UCUqLL4VcEy4mXcQL0O_H_bg	1	MANSION INVITATIONAL 2023 Dota 2 Highlights		2025-06-28
PL24jljspU_FZ2rariPjDiOX34mWkbl6xh	UCUqLL4VcEy4mXcQL0O_H_bg	1	BTS Pro Series 2022 S13 Highlights Dota 2		2025-06-28
PL24jljspU_FYDTKtUJEZyX_lwcpFNoj4Y	UCUqLL4VcEy4mXcQL0O_H_bg	1	BTS Pro Series 2022 S12 Highlights Dota 2		2025-06-28
PL24jljspU_Fb2VJ2D-cqpg3L2lEIhaWxh	UCUqLL4VcEy4mXcQL0O_H_bg	1	RIYADH MASTERS 2022 Dota 2 Highlights		2025-06-28
PL24jljspU_FYXS3MCYl23vp-EDtakr0qO	UCUqLL4VcEy4mXcQL0O_H_bg	1	GAMERS WITHOUT BORDERS GWB 2022 Highlights Dota 2		2025-06-28
PL24jljspU_FYzIjIFAouB0lBcUUJRv749	UCUqLL4VcEy4mXcQL0O_H_bg	1	OGA DOTA PIT 2022 Dota 2 Highlights		2025-06-28
PL24jljspU_Faaeoi-Wztioengv3-vtrr2	UCUqLL4VcEy4mXcQL0O_H_bg	1	BTS Pro Series S10 2022 Highlights Dota 2		2025-06-28
PL24jljspU_FZAqmpfiK4Q2W_n_PIKeOkt	UCUqLL4VcEy4mXcQL0O_H_bg	1	BTS Pro Series S9 2021 Highlights Dota 2		2025-06-28
PL24jljspU_FYX2jI1y-qibSyaSaZFozHN	UCUqLL4VcEy4mXcQL0O_H_bg	1	BTS Pro Series S8 2021 Highlights Dota 2		2025-06-28
PL24jljspU_FZJ0lT1Ae7rp2hP-pdR55JB	UCUqLL4VcEy4mXcQL0O_H_bg	1	BTS Pro Series S7 2021 Highlights Dota 2		2025-06-28
PL24jljspU_FZU9y3SK5_z3geTHBulM31S	UCUqLL4VcEy4mXcQL0O_H_bg	1	i-League 2021 Dota 2 Highlights		2025-06-28
PL24jljspU_FYbfbeFA_dlfLqgeUqVItE8	UCUqLL4VcEy4mXcQL0O_H_bg	1	ANIMAJOR 2021 WePlay Kyiv Dota 2 Highlights		2025-06-28
PL24jljspU_FY3mOBI2N1TJJesh1g6eiop	UCUqLL4VcEy4mXcQL0O_H_bg	1	Asia Pacific Predator League 2021 Dota 2 Highlights		2025-06-28
PL24jljspU_FYR9GU1YlZbpUROJFTsGu29	UCUqLL4VcEy4mXcQL0O_H_bg	1	CDA-FDC PRO Dota 2 Highlights 2020		2025-06-28
PL24jljspU_Fb98H1_GG8TS8xSbBUESz2x	UCUqLL4VcEy4mXcQL0O_H_bg	1	EPIC LEAGUE Dota 2 Highlights 2020		2025-06-28
PL24jljspU_FYs0Q1y4N8ynO_Cxa9a_nRc	UCUqLL4VcEy4mXcQL0O_H_bg	1	DOTA Summit 13 Online 2020 Highlights Dota 2		2025-06-28
PL24jljspU_Fb7vwCFnqCszogyjSK_fHKj	UCUqLL4VcEy4mXcQL0O_H_bg	1	CHINA PRO CUP Dota 2 Highlights 2020		2025-06-28
PL24jljspU_FYU2OvivQ7HYasUQ6d6EmdJ	UCUqLL4VcEy4mXcQL0O_H_bg	1	BTS Pro Series 2020 Highlights Dota 2		2025-06-28
PL24jljspU_FYfGzX4rq-YSdzAlUMq4OHe	UCUqLL4VcEy4mXcQL0O_H_bg	1	OMEGA League Dota 2 Highlights 2020		2025-06-28
PL24jljspU_FaC_mrEuiS_iVhtf8pxKr9A	UCUqLL4VcEy4mXcQL0O_H_bg	1	BLAST Bounty Hunt 2020 Highlights Dota 2		2025-06-28
PL24jljspU_Fa4SzowpXCmKosTEWWLx0dA	UCUqLL4VcEy4mXcQL0O_H_bg	1	OGA Dota PIT 2020 Highlights Dota 2		2025-06-28
PL24jljspU_FZWFSR0FjCSVQ2j0E7_iAPf	UCUqLL4VcEy4mXcQL0O_H_bg	1	DPL-CDA Professional League 2020 Highlights Dota 2		2025-06-28
PL24jljspU_Fb_uTITIg5ThBR-iu-epObC	UCUqLL4VcEy4mXcQL0O_H_bg	1	BEYOND EPIC 2020 Highlights Dota 2		2025-06-28
PL24jljspU_FbTsYrrJz2lZjgojbf6PkEY	UCUqLL4VcEy4mXcQL0O_H_bg	1	DotA Digest [EPIC]		2025-06-28
PLOutcLOaeidtkfZtAPpTy-5OuNNdO-4Wk	UCzghsdg33rhnu-0CLhx_ttA	1	The Best of Best Ability Draft Moments		2025-06-28
PLOutcLOaeidsPuadhIhIzMQIWGOOh3p8C	UCzghsdg33rhnu-0CLhx_ttA	1	Ability Draft		2025-06-28
PLGwChZKCYoqOcKRkI06PyaKLhu1TXXHlW	UCqmJgdqMIWlrGCUdlEZBawg	1	Miracle- POV Tournament Games		2025-06-28
PLGwChZKCYoqPbtsk8dOASwpaOIogzg8oF	UCqmJgdqMIWlrGCUdlEZBawg	1	Miracle- Stream Dota		2025-06-28
PLip1Dmo22qplY65HwpnIUh64zwyU-XZnR	UCcwSIU_DxgUFjOXPRaztATw	1	Qojqva Teaches Dota 2		2025-06-28
PLip1Dmo22qplMlchWm-NEWKY35epGSyUY	UCcwSIU_DxgUFjOXPRaztATw	1	GamerzClass 2.0 - Pro Player Series		2025-06-28
PLip1Dmo22qpmCbXPT4TbdRkgFIQDNDool	UCcwSIU_DxgUFjOXPRaztATw	1	Nikobaby		2025-06-28
PLip1Dmo22qpn5n3qNNYExE_kNcOrtP02O	UCcwSIU_DxgUFjOXPRaztATw	1	Good or Naughty - GamerzClass Tribunal - Dota 2 Overwatch cases.		2025-06-28
PLip1Dmo22qpmoRb7iqNv8WrrzjbENlTvh	UCcwSIU_DxgUFjOXPRaztATw	1	GamerzClass Reviews		2025-06-28
PLip1Dmo22qplKjT9Ax0gigfCWgYUTS5dY	UCcwSIU_DxgUFjOXPRaztATw	1	Mid Lane Climbing Guide		2025-06-28
PLip1Dmo22qpkCXpERm6T4tI8xMRho7Q9R	UCcwSIU_DxgUFjOXPRaztATw	1	Dota 2 Item Guides: Get your Basics Right when it comes to Itemisation		2025-06-28
PLip1Dmo22qpkPKsSGEfVmkDD6IlBLpj3M	UCcwSIU_DxgUFjOXPRaztATw	1	Best Dota 2 Carry Climbing Guide. From Herald to Immortal		2025-06-28
PLip1Dmo22qplJfhxFALKJVHY3dUV58l6r	UCcwSIU_DxgUFjOXPRaztATw	1	The Best Dota 2 Guides to Increase your MMR by GamerzClass		2025-06-28
PLip1Dmo22qpmWvXbkUV7DH_JanMXKXd-u	UCcwSIU_DxgUFjOXPRaztATw	1	Dota 2 Better Mindset Videos		2025-06-28
PLip1Dmo22qplkuEbLq18Lt_Oa_S8rQTxD	UCcwSIU_DxgUFjOXPRaztATw	1	Topson		2025-06-28
PLip1Dmo22qpnvThoTnBLG9pj13PNHD31e	UCcwSIU_DxgUFjOXPRaztATw	1	Replay Analysis		2025-06-28
PLip1Dmo22qpluxfV9LiGfmNzPADBhqey_	UCcwSIU_DxgUFjOXPRaztATw	1	Announcements		2025-06-28
PLip1Dmo22qpnPQq01qOItG3VzgNxkRQSR	UCcwSIU_DxgUFjOXPRaztATw	1	Free Episodes		2025-06-28
PLIJ7KxX7jm3E56OZiBdmWHitltiCPDpP0	UCy7O1t8ZD5qe77sdkfBJ76A	1	DPC 2023 SEA Summer Tour Division 1		2025-06-28
PLIJ7KxX7jm3GCswCQKz1Dy5BD5ynVrwFr	UCy7O1t8ZD5qe77sdkfBJ76A	1	The Lima Major 2023 Playoff Vods		2025-06-28
PLIJ7KxX7jm3H5TNbW_siL7duN-EhuDf7R	UCy7O1t8ZD5qe77sdkfBJ76A	1	The Bali Major 2023 VOD		2025-06-28
PLIJ7KxX7jm3HuFd6nuxR-u1pyHgoN4jVT	UCy7O1t8ZD5qe77sdkfBJ76A	1	DPC 2023 SEA Spring Tour Division 1		2025-06-28
PLIJ7KxX7jm3H98Qh6ho4VCf0a-xk1cY_k	UCy7O1t8ZD5qe77sdkfBJ76A	1	[Winner Interview] DPC 2023 SEA Spring Tour		2025-06-28
PLIJ7KxX7jm3FVkvg8X35V3y4mchf-cyob	UCy7O1t8ZD5qe77sdkfBJ76A	1	DPC 2023 SEA Winter Tour Division 2		2025-06-28
PLIJ7KxX7jm3E21S3Uu7p2t_jLBXReh69e	UCy7O1t8ZD5qe77sdkfBJ76A	1	DPC 2023 SEA Winter Tour Division 1		2025-06-28
PLIJ7KxX7jm3GktFP9vMSxosQttRmOIee7	UCy7O1t8ZD5qe77sdkfBJ76A	1	[Player History] SEA DPC Winter 2023		2025-06-28
PLIJ7KxX7jm3H3FYIKxC2yv4zgLPlsE-l4	UCy7O1t8ZD5qe77sdkfBJ76A	1	[Winner Interviews] DPC SEA 2023 Winter Tour - Division I		2025-06-28
PLIJ7KxX7jm3GNwbfuOqz6NrfLPsmqyIno	UCy7O1t8ZD5qe77sdkfBJ76A	1	Longform Interviews SEA DPC		2025-06-28
PLIJ7KxX7jm3Ed3N49xPEQIx9bHCO5X0ob	UCy7O1t8ZD5qe77sdkfBJ76A	1	[Winner Interview] DPC SA - Tour II 2021/22		2025-06-28
PLIJ7KxX7jm3HNaT_wu8FTZCtUU_BhYfvJ	UCy7O1t8ZD5qe77sdkfBJ76A	1	[Winner Interviews] DPC SA - Tour III 2021/22		2025-06-28
PLIJ7KxX7jm3FDG2VKiC2rckViROv56wPM	UCy7O1t8ZD5qe77sdkfBJ76A	1	[Highlights] DPC SA - Tour III 2021/22		2025-06-28
PLIJ7KxX7jm3Ga6a5EbyOKPwF63tmpHhMQ	UCy7O1t8ZD5qe77sdkfBJ76A	1	DPC SA - Tour III 2021/22		2025-06-28
PLIJ7KxX7jm3HqS6iYR4_BKMIoiAAWAawb	UCy7O1t8ZD5qe77sdkfBJ76A	1	DPC SA - Tour II 2021/22		2025-06-28
PLIJ7KxX7jm3HqSPYCJeRFz_nb7AE-FdDb	UCy7O1t8ZD5qe77sdkfBJ76A	1	DPC SA - Tour I 2021/22 Highlights		2025-06-28
PLIJ7KxX7jm3HRQRHlvsSNPJCRfscPCgV0	UCy7O1t8ZD5qe77sdkfBJ76A	1	Valorant Royal SEA Challenge Highlights		2025-06-28
PLIJ7KxX7jm3HoF9d4QjHywyE_bQx0KOC2	UCy7O1t8ZD5qe77sdkfBJ76A	1	Valorant Royal SEA Challenge		2025-06-28
PLIJ7KxX7jm3G18oJ1iTzX9eDwHTcAxjnv	UCy7O1t8ZD5qe77sdkfBJ76A	1	DPC SA - Tour I 2021/22		2025-06-28
PLIJ7KxX7jm3Hudxu5WoW-qAn1pvguA9qc	UCy7O1t8ZD5qe77sdkfBJ76A	1	Mobius.bet Maestros		2025-06-28
PLIJ7KxX7jm3Fhae2W-7o7t9I2d1JHMXB1	UCy7O1t8ZD5qe77sdkfBJ76A	1	Do You Want To Continue?		2025-06-28
PLIJ7KxX7jm3HF0Tm3zuItdJjTRmJNIKSS	UCy7O1t8ZD5qe77sdkfBJ76A	1	VALORANT Royal SEA Cup		2025-06-28
PLIJ7KxX7jm3FuNeLdOKyx4c-dgvOHXN1X	UCy7O1t8ZD5qe77sdkfBJ76A	1	EPULZE Valorant Prodigies		2025-06-28
PLTnPepJKGC1sEV502YgkWP07gU-oO6t5M	UCCUR--YxwSYJ4QzuKsaAABw	1	Roaming Playlist [Dota 2 Pro]		2025-06-28
PLTnPepJKGC1ui0myoPjXeLLHhzYjnP9j5	UCCUR--YxwSYJ4QzuKsaAABw	1	Quinn Playlist [Dota 2 Pro]		2025-06-28
PLTnPepJKGC1uf74pMnZpTargEeX_2Nyan	UCCUR--YxwSYJ4QzuKsaAABw	1	Hellscream Playlist [Dota 2 Pro]		2025-06-28
PLTnPepJKGC1uJThvq7KA1DYNt4lAHOHRg	UCCUR--YxwSYJ4QzuKsaAABw	1	Kaori Playlist [Dota 2 Pro]		2025-06-28
PLTnPepJKGC1tgYDOqf30qhApN80dsNLqz	UCCUR--YxwSYJ4QzuKsaAABw	1	w33 Playlist [Dota 2 Pro]		2025-06-28
PLTnPepJKGC1vS2uDhw855JTRtGhvLWZ4z	UCCUR--YxwSYJ4QzuKsaAABw	1	Fly Playlist [Dota 2 Pro]		2025-06-28
PLTnPepJKGC1u0QoBGmw72t4KkfDsjkH8a	UCCUR--YxwSYJ4QzuKsaAABw	1	Malr1ne Playlist [Dota 2 Pro]		2025-06-28
PLTnPepJKGC1vtvHieZ5avBRHA7b31ackv	UCCUR--YxwSYJ4QzuKsaAABw	1	Miracle Playlist [Dota 2 Pro]		2025-06-28
PLTnPepJKGC1tRbu5KmSVh05nkWl2l3lDy	UCCUR--YxwSYJ4QzuKsaAABw	1	skiter Playlist [Dota 2 Pro]		2025-06-28
PLTnPepJKGC1tGFlNpU3UXtZQzq23Ffm2J	UCCUR--YxwSYJ4QzuKsaAABw	1	Puppey Playlist [Dota 2 Pro]		2025-06-28
PLTnPepJKGC1sGzhRCXG2pw0HLZH6T76v9	UCCUR--YxwSYJ4QzuKsaAABw	1	Insania Playlist [Dota 2 Pro]		2025-06-28
PLTnPepJKGC1usLY0X4Ujf_jkoUuXL_QIY	UCCUR--YxwSYJ4QzuKsaAABw	1	23savage Playlist [Dota 2 Pro]		2025-06-28
PLTnPepJKGC1ttNkAAuFdut9cs9OZsZHIF	UCCUR--YxwSYJ4QzuKsaAABw	1	Ramzes Playlist [Dota 2 Pro]		2025-06-28
PLTnPepJKGC1tfcxFOQxr1XVMk3h-b4miU	UCCUR--YxwSYJ4QzuKsaAABw	1	SumaiL Playlist [Dota 2 Pro]		2025-06-28
PLTnPepJKGC1v7mWEiVPGEqQmsJVr3GrCX	UCCUR--YxwSYJ4QzuKsaAABw	1	Yatoro Playlist [Dota 2 Pro]		2025-06-28
PLTnPepJKGC1t0VP3Sg5PUtEYfDxfsLPYL	UCCUR--YxwSYJ4QzuKsaAABw	1	Ceb Playlist [Dota 2 Pro]		2025-06-28
PLTnPepJKGC1vK_9YKf-RdJo0kxbbeJ-Py	UCCUR--YxwSYJ4QzuKsaAABw	1	Offlane Playlist [Dota 2 Pro]		2025-06-28
PLTnPepJKGC1tm9eUc2q5gJhDjJhH8zIkg	UCCUR--YxwSYJ4QzuKsaAABw	1	Safelane Playlist [Dota 2 Pro]		2025-06-28
PLTnPepJKGC1tRtF2NF8Uk1RKXgkseynBH	UCCUR--YxwSYJ4QzuKsaAABw	1	Arteezy Playlist [Dota 2 Pro]		2025-06-28
PLTnPepJKGC1vQWtx_B_dlY2WySoehPe3I	UCCUR--YxwSYJ4QzuKsaAABw	1	Midlane Playlist [Dota 2 Pro]		2025-06-28
PLTnPepJKGC1s1MfuXEVOdTqMC8mpZDGVJ	UCCUR--YxwSYJ4QzuKsaAABw	1	Topson Playlist [Dota 2 Pro]		2025-06-28
PLTnPepJKGC1uHoPUvFLPjXcEWxp5U5grp	UCCUR--YxwSYJ4QzuKsaAABw	1	SUPPORT Playlist [Dota 2 Pro]		2025-06-28
PLTnPepJKGC1sVNx-Tkl_CRfCadGd-nw9_	UCCUR--YxwSYJ4QzuKsaAABw	1	Dota 2 Pro MMR Playlist		2025-06-28
PLTnPepJKGC1tJtDGYEUXuavgFraYiz4jR	UCCUR--YxwSYJ4QzuKsaAABw	1	Partner with hOlyhexOr		2025-06-28
PLWobE5XIQD5-3UkI-aq1RnFJ_tjGsnxdt	UCbUX71arfjbI8R3jhgncwxg	1	SUMAIL🔥		2025-06-28
PLWobE5XIQD5-dns9ZylVBRaThpkcjdjpK	UCbUX71arfjbI8R3jhgncwxg	1	TOPSON🔥		2025-06-28
PLWobE5XIQD581GiArJuyeI9TmSLoqpRCG	UCbUX71arfjbI8R3jhgncwxg	1	ARTEEZY🔥		2025-06-28
PLWobE5XIQD5-nEDGjJzYPDqAqYBYdKkL8	UCbUX71arfjbI8R3jhgncwxg	1	MIRACLE🔥		2025-06-28
PLWobE5XIQD5-JfJqRn5Va0_NIziV4Lw46	UCbUX71arfjbI8R3jhgncwxg	1	ABED🔥		2025-06-28
PLWobE5XIQD59TvSHnVEb_jKPMJLo47W1Q	UCbUX71arfjbI8R3jhgncwxg	1	SUMAIL STREAM👑		2025-06-28
PLWobE5XIQD5_k5GxsiRTdA2wkwLayTAMO	UCbUX71arfjbI8R3jhgncwxg	1	ANA		2025-06-28
PLWobE5XIQD5-kBXxsvi7QUunI01yLCAGg	UCbUX71arfjbI8R3jhgncwxg	1	DENDI		2025-06-28
PLWobE5XIQD5_QwBnddy5tTaZqfY7LagfY	UCbUX71arfjbI8R3jhgncwxg	1	W33		2025-06-28
PLWobE5XIQD59Xwj0nQy_KRmy4c1bb_5TA	UCbUX71arfjbI8R3jhgncwxg	1	MATUMBAMAN		2025-06-28
PLWobE5XIQD589GkOXc0SaNRBpI4gW3iyl	UCbUX71arfjbI8R3jhgncwxg	1	NOONE		2025-06-28
PLWobE5XIQD5-c0eBnke6HD5N2b24JbWRv	UCbUX71arfjbI8R3jhgncwxg	1	RAMZES666		2025-06-28
PLWobE5XIQD595Kp2QHmT6EcgITKZ6Z0O8	UCbUX71arfjbI8R3jhgncwxg	1	23SAVAGE		2025-06-28
PLWobE5XIQD599RoghaCtqWj43IT9HphT_	UCbUX71arfjbI8R3jhgncwxg	1	INYOURDREAM		2025-06-28
PLWobE5XIQD59ouxq9rbrWBG_p3fSLgNsd	UCbUX71arfjbI8R3jhgncwxg	1	SCCC		2025-06-28
PLWobE5XIQD59wZ3Q5WjduFM7OFqqmZJmm	UCbUX71arfjbI8R3jhgncwxg	1	CR1T		2025-06-28
PLWobE5XIQD58zyKSKqI4a5U2uwO0E84wL	UCbUX71arfjbI8R3jhgncwxg	1	SafeLane		2025-06-28
PLWobE5XIQD5_TSDqbLhtXITFxAUDjBHG2	UCbUX71arfjbI8R3jhgncwxg	1	MidLane		2025-06-28
PLWobE5XIQD5_vbyjKyOzWaTMtF2fuNfNu	UCbUX71arfjbI8R3jhgncwxg	1	OffLane		2025-06-28
PLWobE5XIQD59B_vbJ91fneB94w80OFMgW	UCbUX71arfjbI8R3jhgncwxg	1	Roaming		2025-06-28
PL6SrXSU335XkRXNc_sww3OLfG2pRNVGOg	UC7l_lqR3T5Pkrjp2Uyc2dKQ	1	Squad1x Dota 2		2025-06-28
PL6SrXSU335Xl4tcfFQ_O5mgR_6PK7R4aj	UC7l_lqR3T5Pkrjp2Uyc2dKQ	1	Malr1ne Dota 2		2025-06-28
PL6SrXSU335XlYZubTrBK2yIHUcCKNr1Z_	UC7l_lqR3T5Pkrjp2Uyc2dKQ	1	Ramzes666 Dota 2		2025-06-28
PL6SrXSU335Xn1KRNF5bhb-ubuG9-EPYFG	UC7l_lqR3T5Pkrjp2Uyc2dKQ	1	Ame Dota 2		2025-06-28
PL6SrXSU335XmVtPD7w0LVOpJTjZ11ZMbW	UC7l_lqR3T5Pkrjp2Uyc2dKQ	1	Arteezy Dota 2		2025-06-28
PL6SrXSU335XkCkXWmRRqHjpv0YRtnXHJG	UC7l_lqR3T5Pkrjp2Uyc2dKQ	1	Ana Dota 2		2025-06-28
PL6SrXSU335XlXqHZ855bscewd611-Aj7j	UC7l_lqR3T5Pkrjp2Uyc2dKQ	1	Paparazi Dota 2		2025-06-28
PL6SrXSU335XkLRNpaz4bZ-T436_M6JSSn	UC7l_lqR3T5Pkrjp2Uyc2dKQ	1	Abed Dota 2		2025-06-28
PL6SrXSU335Xn0R55dPKcdqdQydT7osHBZ	UC7l_lqR3T5Pkrjp2Uyc2dKQ	1	Ghost Dota 2		2025-06-28
PL6SrXSU335XlMwSV1-qdTlTsZMKyYgqsw	UC7l_lqR3T5Pkrjp2Uyc2dKQ	1	Crystallis Dota 2		2025-06-28
PL6SrXSU335Xl8gGS1GcWGCdv8j-BMIi7u	UC7l_lqR3T5Pkrjp2Uyc2dKQ	1	Raven Dota 2		2025-06-28
PL6SrXSU335Xnn53VQfFQMIwBUnad1HwIU	UC7l_lqR3T5Pkrjp2Uyc2dKQ	1	Yopaj Dota 2		2025-06-28
PL6SrXSU335XkcfBMfUtx9ydPbm21jpiqk	UC7l_lqR3T5Pkrjp2Uyc2dKQ	1	Timado Dota 2		2025-06-28
PL6SrXSU335XnYq3yqLArvk_oBkMsHAspz	UC7l_lqR3T5Pkrjp2Uyc2dKQ	1	Pakazs Dota 2		2025-06-28
PL6SrXSU335Xk-00e9QxFVYz0Y_bQeP_CC	UC7l_lqR3T5Pkrjp2Uyc2dKQ	1	Larl Dota 2		2025-06-28
PL6SrXSU335XnN8HgJcH7PemvPwXB75hji	UC7l_lqR3T5Pkrjp2Uyc2dKQ	1	JACKBOYS Dota 2		2025-06-28
PL6SrXSU335XnT6gzhvM7jMRedQXfZ2YmS	UC7l_lqR3T5Pkrjp2Uyc2dKQ	1	Alberkaaa Dota 2		2025-06-28
PL6SrXSU335Xla7kdxgiu1k5f-zW6sLMg8	UC7l_lqR3T5Pkrjp2Uyc2dKQ	1	V-Tune Dota 2		2025-06-28
PL6SrXSU335XnPGJrJ-VwOtUvXoba-dfQt	UC7l_lqR3T5Pkrjp2Uyc2dKQ	1	Pure Dota 2		2025-06-28
PL6SrXSU335Xlbvwmt4xk5QHkHcmRMfk8x	UC7l_lqR3T5Pkrjp2Uyc2dKQ	1	Daxak Dota 2		2025-06-28
PL6SrXSU335XmBijPzO_oq78qtpeLYQNMJ	UC7l_lqR3T5Pkrjp2Uyc2dKQ	1	NikoBaby Dota 2		2025-06-28
PL6SrXSU335XmEZKD9ZVSnhrgrEhfmPF0_	UC7l_lqR3T5Pkrjp2Uyc2dKQ	1	GPK Dota 2		2025-06-28
PL6SrXSU335XmlvvoZZz07IvudVgkRhdH9	UC7l_lqR3T5Pkrjp2Uyc2dKQ	1	Iceiceice Dota 2		2025-06-28
PL6SrXSU335XlAKHUhtkFsztZc2Tb9FRb_	UC7l_lqR3T5Pkrjp2Uyc2dKQ	1	Collapse Dota 2		2025-06-28
PL6SrXSU335XmX2LeGaeokAw6C75_uB_5E	UC7l_lqR3T5Pkrjp2Uyc2dKQ	1	DyrachYO Dota 2		2025-06-28
PL6SrXSU335Xm5zghokRvN3_Vadf8ZVaNg	UC7l_lqR3T5Pkrjp2Uyc2dKQ	1	Skiter Dota 2		2025-06-28
PL6SrXSU335Xn8qEZSf4AmVasg3U6pcCHh	UC7l_lqR3T5Pkrjp2Uyc2dKQ	1	Nine Dota 2		2025-06-28
PL6SrXSU335XkSghNYZo8oDbb4xM37xw6Q	UC7l_lqR3T5Pkrjp2Uyc2dKQ	1	SumaiL Dota 2		2025-06-28
PL6SrXSU335XmDVqi-8Zj-BMTIRB76KJ1z	UC7l_lqR3T5Pkrjp2Uyc2dKQ	1	Nisha Dota 2		2025-06-28
PL6SrXSU335Xkifvq2ytwQkjMNsoBF5i2r	UC7l_lqR3T5Pkrjp2Uyc2dKQ	1	BOOM Dota 2		2025-06-28
PL6SrXSU335XkVjQ62ewr3OmJdSkUHVdWX	UC7l_lqR3T5Pkrjp2Uyc2dKQ	1	Zai Dota 2		2025-06-28
PL6SrXSU335XkLthY2y_7huPDZ-Qk4v4tA	UC7l_lqR3T5Pkrjp2Uyc2dKQ	1	miCKe Dota 2		2025-06-28
PL6SrXSU335XmIRHRpomwJR6N1g91E5VOW	UC7l_lqR3T5Pkrjp2Uyc2dKQ	1	Sylar Dota 2		2025-06-28
PL6SrXSU335XlK1WhbyZesmZIO1XDsXEKk	UC7l_lqR3T5Pkrjp2Uyc2dKQ	1	NothingToSay Dota 2		2025-06-28
PL6SrXSU335XldAPwZQ_Dc4ICZH1lo8pI8	UC7l_lqR3T5Pkrjp2Uyc2dKQ	1	Iceberg Dota 2		2025-06-28
PL6SrXSU335Xl9lysEjRuulqetsNp9NU8j	UC7l_lqR3T5Pkrjp2Uyc2dKQ	1	Mikoto Dota 2		2025-06-28
PL6SrXSU335XnG6czPNIO2fdnto4d6YVGY	UC7l_lqR3T5Pkrjp2Uyc2dKQ	1	Deth Dota 2		2025-06-28
PL6SrXSU335XmzIEMjjm6da1ad3KttYssS	UC7l_lqR3T5Pkrjp2Uyc2dKQ	1	QUPE Dota 2		2025-06-28
PL6SrXSU335XkUPQaK3wmPs0kIRLyzkPXY	UC7l_lqR3T5Pkrjp2Uyc2dKQ	1	Yowe Dota 2		2025-06-28
PL6SrXSU335Xm63MJsyjPhEcgUhQ76E3Zr	UC7l_lqR3T5Pkrjp2Uyc2dKQ	1	Matumbaman Dota 2		2025-06-28
PL6SrXSU335Xmac4tP8C8JtLTIl6r57Ysf	UC7l_lqR3T5Pkrjp2Uyc2dKQ	1	!Attacker Dota 2		2025-06-28
PL6SrXSU335XkpaSx1GUO3nefrAyGchI-6	UC7l_lqR3T5Pkrjp2Uyc2dKQ	1	Mind_Control Dota 2		2025-06-28
PL6SrXSU335XlYZu5XTL0XSqxBMLLbf0Qh	UC7l_lqR3T5Pkrjp2Uyc2dKQ	1	Gh Dota 2		2025-06-28
PL6SrXSU335XnP-5VbqqK3P6zcSVDL2L63	UC7l_lqR3T5Pkrjp2Uyc2dKQ	1	Yuragi Dota 2		2025-06-28
PL6SrXSU335Xle60VDre4xUgUPEbESKMh4	UC7l_lqR3T5Pkrjp2Uyc2dKQ	1	Dreamocel Dota 2		2025-06-28
PL6SrXSU335XkCD2Wsb8Wst9U9sEkm725l	UC7l_lqR3T5Pkrjp2Uyc2dKQ	1	Supream^ Dota 2		2025-06-28
PL6SrXSU335Xk6LH9Mg6SsK_Zcgxk3s2gr	UC7l_lqR3T5Pkrjp2Uyc2dKQ	1	K1 Hector Dota 2		2025-06-28
PL6SrXSU335XlcfLFjh6HEaY1AtWgpljKz	UC7l_lqR3T5Pkrjp2Uyc2dKQ	1	Gabbi Dota 2		2025-06-28
PL6SrXSU335XnAzNev2Y7kjay1rcurrEzt	UC7l_lqR3T5Pkrjp2Uyc2dKQ	1	Armel Dota 2		2025-06-28
PL6SrXSU335XmkLnFDYg8iOkpOWGWZ6BlQ	UC7l_lqR3T5Pkrjp2Uyc2dKQ	1	Cooman Dota 2		2025-06-28
PL6SrXSU335Xk-dbEylUFVY15TTFbL4Iz7	UC7l_lqR3T5Pkrjp2Uyc2dKQ	1	AlaCrity- Dota 2		2025-06-28
PL6SrXSU335Xk7yMrAH_86LR6Zmqk0loiW	UC7l_lqR3T5Pkrjp2Uyc2dKQ	1	InYourDream Dota 2		2025-06-28
PL6SrXSU335XndCVQpOItx3GjxhJ14_aYB	UC7l_lqR3T5Pkrjp2Uyc2dKQ	1	ATF Dota 2		2025-06-28
PL6SrXSU335XnQqXiCQx38i-Jpou2a28Fr	UC7l_lqR3T5Pkrjp2Uyc2dKQ	1	23Savage Dota 2		2025-06-28
PL6SrXSU335Xng0EQ_MpfxUqI4x8VSBI51	UC7l_lqR3T5Pkrjp2Uyc2dKQ	1	BZM Dota 2		2025-06-28
PL6SrXSU335XlwerJNXhuPvyJKf3AXDnC-	UC7l_lqR3T5Pkrjp2Uyc2dKQ	1	Miracle- Dota 2		2025-06-28
PL6SrXSU335XkBE5R6P_SBK4LPhwhuIgC_	UC7l_lqR3T5Pkrjp2Uyc2dKQ	1	Topson Dota 2		2025-06-28
PL6SrXSU335XlaQ_wKFZIvKq0ps6fQS7YY	UC7l_lqR3T5Pkrjp2Uyc2dKQ	1	TorontoTokyo Dota 2		2025-06-28
PL6SrXSU335XkAiqBoWCwtGSqTTZGlta6B	UC7l_lqR3T5Pkrjp2Uyc2dKQ	1	Best of Dota 2		2025-06-28
PL6SrXSU335XlUboc6NGYkAh0AhZ_2SXpf	UC7l_lqR3T5Pkrjp2Uyc2dKQ	1	Yatoro Dota 2		2025-06-28
PL6SrXSU335Xle9HyfMOQYt9DRXOD-ugkc	UC7l_lqR3T5Pkrjp2Uyc2dKQ	1	W33 Dota 2		2025-06-28
PL6SrXSU335Xla7jtdwF30qaFDMbkMXa-h	UC7l_lqR3T5Pkrjp2Uyc2dKQ	1	iLTW Dota 2		2025-06-28
PLrReuJ-DuMnBLRz86jeH45o_3IW7V9vFt	UCkkKxVIv_6EJsfRMJ-7ILaQ	1	Ceb		2025-06-28
PLrReuJ-DuMnD5SXXzKiNbYGnruZJQdAAH	UCkkKxVIv_6EJsfRMJ-7ILaQ	1	w33.haa dota		2025-06-28
PLrReuJ-DuMnDZuAEhaJ0A39-Y_-9vBdir	UCkkKxVIv_6EJsfRMJ-7ILaQ	1	qojqva		2025-06-28
PLrReuJ-DuMnB-LUYwLx3M8STI7daE4N25	UCkkKxVIv_6EJsfRMJ-7ILaQ	1	zai dota		2025-06-28
PLrReuJ-DuMnCX-g5ckpIV1vOMIIy3In1H	UCkkKxVIv_6EJsfRMJ-7ILaQ	1	iceiceice		2025-06-28
PLrReuJ-DuMnAjOPpqKQ-gmi4sumfcctQe	UCkkKxVIv_6EJsfRMJ-7ILaQ	1	Cr1t Dota		2025-06-28
PLrReuJ-DuMnCxkyNDbYIKxECREzE5NH86	UCkkKxVIv_6EJsfRMJ-7ILaQ	1	Slacks		2025-06-28
PLrReuJ-DuMnC-9DrXO9c-BuCHtMNATLQC	UCkkKxVIv_6EJsfRMJ-7ILaQ	1	singsing		2025-06-28
PLrReuJ-DuMnDiNa-rVQXwtaITo4ajnIYc	UCkkKxVIv_6EJsfRMJ-7ILaQ	1	The International 10		2025-06-28
PLrReuJ-DuMnBSpM6tZLWEEC6pxCjT-4Pq	UCkkKxVIv_6EJsfRMJ-7ILaQ	1	cr1t dota		2025-06-28
PLrReuJ-DuMnDkJFr1-TLKMMjZrBqOwgs9	UCkkKxVIv_6EJsfRMJ-7ILaQ	1	Xcalibur Dota		2025-06-28
PLrReuJ-DuMnC4Iia25D9ItJiSvYxvfqmP	UCkkKxVIv_6EJsfRMJ-7ILaQ	1	Big Daddy Notail		2025-06-28
PLrReuJ-DuMnDiUB72dlx30JAV68hvzfSz	UCkkKxVIv_6EJsfRMJ-7ILaQ	1	NothingToSay		2025-06-28
PLrReuJ-DuMnB3TQGAB16MWnDoRLrWeenY	UCkkKxVIv_6EJsfRMJ-7ILaQ	1	Febbydota		2025-06-28
PLrReuJ-DuMnBKA1Srcx2KjGT8XPUz_2kp	UCkkKxVIv_6EJsfRMJ-7ILaQ	1	Attackerdota		2025-06-28
PLrReuJ-DuMnDHEljrHTl8sUQgN2POPzR7	UCkkKxVIv_6EJsfRMJ-7ILaQ	1	BSJ Dota		2025-06-28
PLrReuJ-DuMnACCnNckBdXnjpTEZPZ5SrB	UCkkKxVIv_6EJsfRMJ-7ILaQ	1	Jenkins Dota		2025-06-28
PLrReuJ-DuMnD-eYzCcyMqkSPEGKrsOsyx	UCkkKxVIv_6EJsfRMJ-7ILaQ	1	Gunnar Dota		2025-06-28
PLrReuJ-DuMnB1a1D2cp0ISk4_33xGmxKy	UCkkKxVIv_6EJsfRMJ-7ILaQ	1	Purge The WeatherMan		2025-06-28
PLrReuJ-DuMnDEgFRJk_FeAT6tdfONs4Fd	UCkkKxVIv_6EJsfRMJ-7ILaQ	1	Raeyei		2025-06-28
PLrReuJ-DuMnAKrXoEy828u2NVGjGktMSU	UCkkKxVIv_6EJsfRMJ-7ILaQ	1	Luki Luki		2025-06-28
PLrReuJ-DuMnANvLGOqhbRm1YbKaHdm_uP	UCkkKxVIv_6EJsfRMJ-7ILaQ	1	SUMAIL THE KING		2025-06-28
PLrReuJ-DuMnAQcHgUWnERKN5pK8nqVZmI	UCkkKxVIv_6EJsfRMJ-7ILaQ	1	EternaLEnVy a.k.a. EE-Sama		2025-06-28
PLrReuJ-DuMnDbe8CfFWXXTxWV98n3VFu6	UCkkKxVIv_6EJsfRMJ-7ILaQ	1	Dota 2 - Mason		2025-06-28
PLrReuJ-DuMnAhAZYs3XPE6P3BRqcFOMU0	UCkkKxVIv_6EJsfRMJ-7ILaQ	1	Dota 2 - Nikobaby		2025-06-28
PLrReuJ-DuMnBa08kL0ooHpBghy0RVt81M	UCkkKxVIv_6EJsfRMJ-7ILaQ	1	The Best of Miracle-		2025-06-28
PLrReuJ-DuMnBDjGCo2JhDDhG0WRaH43c9	UCkkKxVIv_6EJsfRMJ-7ILaQ	1	Gorgc Gorp		2025-06-28
PLrReuJ-DuMnC18zTo6M_8X0mDqtN20aI7	UCkkKxVIv_6EJsfRMJ-7ILaQ	1	The 2 Time TI Winner TOPSON!		2025-06-28
PLrReuJ-DuMnDBSGVyI1v4uD7pnx31NcX6	UCkkKxVIv_6EJsfRMJ-7ILaQ	1	Best of ARTEEZY		2025-06-28
PLfbtTGxUlcCdUcpmC1qqMjij4b8-O0vp-	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Miracle Invoker #1		2025-06-28
PLfbtTGxUlcCeRWouXn7Qy8wCNu2N6E6uy	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Invoker Dota #1		2025-06-28
PLfbtTGxUlcCdAOZ4VzCzhpCTZzMgzbjmW	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Dota Major Gameplay		2025-06-28
PLfbtTGxUlcCcpMLSrHNC3WxnL1LTH8nxj	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Enchantress Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCf9zXv9yw0XptdXKFH7Cfl7	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Riyadh Masters		2025-06-28
PLfbtTGxUlcCcuZg5Rpj5JZfEF7wnVB8R6	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Lycan Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCfmmpB4gwz86k3nwPKShBjz	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Bali Major Replay		2025-06-28
PLfbtTGxUlcCdMP7dA0Ag4jkkvg7H0ndgR	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Winter Wyvern Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCcWxVrhGVutLDc_YO9Kzg3J	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Dazzle Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCdzcwiD1TBOkZzFs-ri3Xi5	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Doom Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCejU34SwRuj0jAmHsrTCuOY	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Ogre Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCffOrgl4ISw7XezLG4h2KzF	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Bali Major Dota 2		2025-06-28
PLfbtTGxUlcCf54ix4i9Sc0D_YAyg4Cp-Y	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Ancient Apparition Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCcWf9RWl23eBghAK1dSrAaq	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Dreamleague Dota 2		2025-06-28
PLfbtTGxUlcCeR9Dt8aHSegyU9ruCVFbmt	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Necrophos Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCebDpc6bBhxpqP3AMJb8-ap	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Nyx Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCd-AR2xjhb51edH6ff5uWHM	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Clockwerk Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCcG9xC3GIKKxqZE7Yuo4q-3	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Abaddon Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCed51lToxsJR96PwZ4QjrUW	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Dragon Knight Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCdSsIHCY4tajt3emMlc4NfF	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Muerta Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCeWMx9ipnYNsyaxKgRUcTra	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Berlin Major		2025-06-28
PLfbtTGxUlcCcaowt1d15W7dK9jBses6fm	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Centaur Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCeLuQ4N6CmxHVpstYJCTSAu	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Nightstalker Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCdNyle8yRRJgbKhoS-wNuOK	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Broodmother Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCeCqwvGTvg534EPgufGBuVC	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Dota 2 Gameplay Pure		2025-06-28
PLfbtTGxUlcCc_ylTO9AUNWIJ9Hw4B5CPr	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Rubick Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCdfe5WC78BbBWrbVNkK25ut	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Oracle Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCfUYZs5zWCZ_cNlbXaRERpD	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Dota 2 Gameplay Pakazs		2025-06-28
PLfbtTGxUlcCf4W1gpbqpaZMa64wUrYhsO	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Dota 2 Gameplay Yuragi		2025-06-28
PLfbtTGxUlcCfFVI1tUeQ8b4-vCkPwJGSW	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Skywrath Mage Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCf4oASXoI-kz5zAbI9eO0wD	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Dota 2 Gameplay Nisha		2025-06-28
PLfbtTGxUlcCdyAshMbhQHviPR2vCi2Mth	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Io Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCfzsMmaF9jOk8NACgEXUrMG	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Medusa Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCdHbUnbPfER7_p3tohnWEcF	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Axe Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCcd8z-AO0m7Kx_B3U5VA25h	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Dawnbreaker Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCey_3DfcDAwuPKRs6KX8vHd	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Phantom Lancer		2025-06-28
PLfbtTGxUlcCfvJQJw3oI4yZuC0tdw8WuR	UCk0Ns16byYxp5P4aJ6C_AQQ	1	DPC 2023		2025-06-28
PLfbtTGxUlcCckxjL4RPwF9LPEvPmNz4B4	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Dota 2 Gameplay Ceb		2025-06-28
PLfbtTGxUlcCewIVWcmY8d7dW0VL8Tc6k7	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Elder Titan Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCcI7zpkz81EFn6KttTOMen5	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Earth Spirit Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCeJSlbtCeiL9Q8o03YYbLR7	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Dota 2 Gameplay Noone		2025-06-28
PLfbtTGxUlcCf1AqAZr7QW9YdnhnlLU4Zg	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Dota 2 Gameplay Ammar		2025-06-28
PLfbtTGxUlcCde7wMOAYf1tK44kzzhZyxs	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Hoodwink Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCc31Z-zykMdWmr5n_v2lr0D	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Wraith King Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCcJfFaLoX1Rr6K_XCIrkyk9	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Viper Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCd1z_GUsB-DKV8YwBikrmIl	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Omniknight Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCdzQLKO3imgu6S80D04Gpwf	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Naga Siren Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCdoP2LeQYMtjBiXfnidHp4J	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Snapfire Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCczvmxpSjtUC7GEHhVQ2baZ	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Lion Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCeNzsbIuOhM6CJA60BKCsg2	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Puck Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCeCe-iQ9OTGiCyoNVNbbWIM	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Arc Warden Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCef3ta-pEOdHaER-Bigue0R	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Luna Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCdDDrWJzGWKMZ-u_yU4MK_B	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Razor Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCcTZfjDvcdtqwuLpPtb06AT	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Slardar Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCcYLY88KBL7FIK7Zb6brylq	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Kunkka Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCdxkvfVGMUGBE4wadPujNBf	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Lifestealer Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCcmi_yfkWZuu7MZANT5Qaxi	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Windranger Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCee6kzAkqtLB8LeXgRMm0b8	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Dota 2 Gameplay BZM		2025-06-28
PLfbtTGxUlcCcSrKWEYV1xJnqqOVm2Lww7	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Queen of Pain Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCe1xESDaL1y4o8XEkujtA7C	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Templar Assassin Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCe2b7_v0BZtrhsgyJngqYk-	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Pangolier Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCdOMiOtgPS3l-I1vssd804R	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Huskar Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCfsmHQLfLDOx9bf0UFkQH1l	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Storm Spirit Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCdqpfpDAhBRpMhIzHYxe0GU	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Lima Major		2025-06-28
PLfbtTGxUlcCe9UMSDRGuJvbzKN5Vp1nIt	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Mars Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCeGSBglOxLA2MpWCq5Oz9Pc	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Spirit Breaker Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCcOaXUbeuDDQkFziLpYRZOm	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Weaver Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCfscHCwVvs6CE1vHbAHZMjA	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Troll Warlord Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCeGZCM_Zdh8tweLa7qmu9Zj	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Tiny Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCe_3XmHDYKcNr5IAuvobWjp	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Tusk Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCfgKw4Xfdreh7je6uRdujOy	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Lina Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCfmGGz2ULgYN5gklX2BbVxi	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Void Spirit Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCe-6C4c8pnzDc0QaO-7e6iP	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Bloodseeker Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCfI6Erp9KYSy0QLygxUnx-_	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Ember Spirit Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCfVTxRt85e1rfFwSSPbqyv7	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Mirana Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCeNanO92oquyLfRtkza99hi	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Clinkz Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCeQw2hRcqFRPutj5Jn5z05I	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Morphling Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCcX-vN5rJA5UsQa2u3Cqcak	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Leshrac Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCevooQ4AzJUB9fhKbh-ZJGQ	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Marci Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCeRg448RiGH9uFO0OJz6fZM	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Zeus Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCeRDOkUAAvDPlgrHrgKMdTQ	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Earthshaker Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCef23OXvs7ZyVmgOSU0rbg5	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Batrider Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCeo9DIOkJ3N7KAi839dy3oo	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Techies Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCfCijAouExKBv5iL8oE-zf1	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Terrorblade Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCfvhV10rvpZgDER2G13tO8E	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Nine Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCeHZ14LHggoDM-3HPfIizty	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Primal Beast Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCfDsd_36r4haw5OvLbNbEom	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Gyrocopter Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCdSy1gJkowT11ZuRA8r_04P	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Monkey King Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCcO5PzP859_0oHS-RB1iP2A	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Chaos Knight Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCed0C3jMalnAacR1oJRcmJ-	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Dota 2 Gameplay - Skiter		2025-06-28
PLfbtTGxUlcCeYcsaUYogTPWw2z8kDgLed	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Crystal Maiden Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCdCeMSTbdMiQl19NeG71uwz	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Outworld Destroyer Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCeN3HRn8GRNIdZzf2CFmqSH	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Dota 2 Gameplay Ame		2025-06-28
PLfbtTGxUlcCeOo9-VOoYEufRiTP3flR13	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Ursa Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCcCY2akskVqmd8xkvpsnFOc	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Sven Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCdIjuQ0_3ocHfktB_ZOh9fZ	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Dota 2 Gameplay Arteezy		2025-06-28
PLfbtTGxUlcCeHtgJkGZlUEVKWdBIncEnB	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Dota 2 Gameplay Topson		2025-06-28
PLfbtTGxUlcCfWwd0YPN_kwkpTJzHNz_kJ	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Dota 2 Gameplay Sumail		2025-06-28
PLfbtTGxUlcCeEwVbQbOz9GjTWI2k_tlDf	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Dota 2 Gameplay Yatoro		2025-06-28
PLfbtTGxUlcCdbcmxxj_quydMhOL5u8vzt	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Dota 2 Gameplay Miracle		2025-06-28
PLfbtTGxUlcCeBevZ5virr7pSGZ8aFuWwA	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Dota 2 Gameplay Ana		2025-06-28
PLfbtTGxUlcCcyRjI1k_G7wajmBQqGBlul	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Tinker Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCc0uNBUIFRDEM-Tz6GE0FDU	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Spectre Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCdQeYmXJzzFaJ6txNijaEGX	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Sniper Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCfnOE9cuIeAKSAmOCVbg_ur	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Slark Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCd2rDXTR9cL0rppZS0L4krx	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Shadow Fiend Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCddo_bJsehxx-OetX-fPgFs	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Riki Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCcQwxe5kQTBBAFSLrwVrd7d	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Pudge Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCeUeNynXIALwaD5mALwsMEQ	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Phantom Assassin Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCdXHbRgBFetTdo0Kt8w2H-d	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Meepo Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCcJAMjAptoKGB8MpXrpv5C4	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Legion Commander Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCd4fH9V1mFcwgkxuiQlraTC	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Juggernaut Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCcEHIhrJbdSIXOUXkmSNI-E	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Invoker Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCdNbg4zkqex9M5AVXuvQBXX	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Faceless Void Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCcFY7jdFx0n1keQb8pTh3QG	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Drow Ranger Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCd4Nejcv2dpX5Xn-VRhWous	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Bounty Hunter Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCf_tSyjYbJsc3q1kxLgnONS	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Anti-Mage Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCcoF6h2_pgsyAaxy9doHWS_	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Alchemist Dota 2 Gameplay		2025-06-28
PLfbtTGxUlcCdq2UKxi200cWzn1CYY3ckX	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Dota 2 Gameplay - Carry		2025-06-28
PLfbtTGxUlcCdYRvn2CGnu8lY3CNfwrBC3	UCk0Ns16byYxp5P4aJ6C_AQQ	1	TI11		2025-06-28
PLfbtTGxUlcCe-sWm-RR8j0dLnYF42rMFk	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Kardel Live		2025-06-28
PLfbtTGxUlcCcKm-lxihQhZPETW4sBU7B2	UCk0Ns16byYxp5P4aJ6C_AQQ	1	ROAD TO TI11		2025-06-28
PLfbtTGxUlcCcWy2QOOsyx2uq35zSIMVYM	UCk0Ns16byYxp5P4aJ6C_AQQ	1	Road to Arlington Major Dota 2		2025-06-28
PL_4tlvwvMgI5YDGyoVMSQE8-Az1E7jCOW	UC75nwKcny3G8YzDQDbRQGxA	1	DreamLeague		2025-06-28
PL_4tlvwvMgI5PT7fIE6fvuxoNk2XeZvUM	UC75nwKcny3G8YzDQDbRQGxA	1	Pinnacle Cup		2025-06-28
PL_4tlvwvMgI4pIEKhL4QjkaBRYpIBzeFg	UC75nwKcny3G8YzDQDbRQGxA	1	ViperSpin		2025-06-28
PL_4tlvwvMgI6EvDJI9zv_4TbfGq0T9E5a	UC75nwKcny3G8YzDQDbRQGxA	1	GameWorld Web		2025-06-28
PL_4tlvwvMgI6_1K_plgYKkYBjYDtt3j5m	UC75nwKcny3G8YzDQDbRQGxA	1	Skyesports		2025-06-28
PL_4tlvwvMgI5biKSyGNSpxvIOw8XyQvOn	UC75nwKcny3G8YzDQDbRQGxA	1	Apu League		2025-06-28
PL_4tlvwvMgI63RnKSZ8pIo0GFutXIB4Tl	UC75nwKcny3G8YzDQDbRQGxA	1	1X BET		2025-06-28
PL_4tlvwvMgI60C3klGQX_1K9pnoC9y_Pf	UC75nwKcny3G8YzDQDbRQGxA	1	European Pro League		2025-06-28
PL_4tlvwvMgI6V061DBBfH9bvmJXbG7JUu	UC75nwKcny3G8YzDQDbRQGxA	1	EGL One		2025-06-28
PL_4tlvwvMgI73dJrr1VXlkYw6mwLklqF5	UC75nwKcny3G8YzDQDbRQGxA	1	TodayPay		2025-06-28
PL_4tlvwvMgI7XhwumVIayqXdOBctJYiGW	UC75nwKcny3G8YzDQDbRQGxA	1	Masters		2025-06-28
PL_4tlvwvMgI5zsX03iAp_Xxz-dywPQqTC	UC75nwKcny3G8YzDQDbRQGxA	1	Asian Tiger		2025-06-28
PL_4tlvwvMgI4z61Q8ZuWOvsZqv_KO5r7d	UC75nwKcny3G8YzDQDbRQGxA	1	Fissure		2025-06-28
PL_4tlvwvMgI5k2FwLonGFpAfUfFBwfMpx	UC75nwKcny3G8YzDQDbRQGxA	1	Khaz Modan		2025-06-28
PL_4tlvwvMgI4iXP4p-C__PqrX6iZ5xHbm	UC75nwKcny3G8YzDQDbRQGxA	1	Dota 2 Major		2025-06-28
PL_4tlvwvMgI4Joe_Vihh9Wp6X5ANKc0Yv	UC75nwKcny3G8YzDQDbRQGxA	1	Gamers Without Borders		2025-06-28
PL_4tlvwvMgI6JI-Vrx1Rhuo34Fu43hT-E	UC75nwKcny3G8YzDQDbRQGxA	1	Gamers Galaxy		2025-06-28
PL_4tlvwvMgI54PiVGW5xVP5miJLx10Oak	UC75nwKcny3G8YzDQDbRQGxA	1	Dota 2 Champions League		2025-06-28
PL_4tlvwvMgI4BSYapNNIvxSp-rc6TLxQ1	UC75nwKcny3G8YzDQDbRQGxA	1	Player Perspective		2025-06-28
PL_4tlvwvMgI5W_2gKR344YlClKXiYqNxZ	UC75nwKcny3G8YzDQDbRQGxA	1	Bitsler Cup		2025-06-28
PL_4tlvwvMgI7O1i7kh7iuQEG6T4pa2wGA	UC75nwKcny3G8YzDQDbRQGxA	1	Oceanic Esports Dota Championships		2025-06-28
PL_4tlvwvMgI4q-Nz_azmhNISxquir8Kwu	UC75nwKcny3G8YzDQDbRQGxA	1	HUYA DOTA 2		2025-06-28
PL_4tlvwvMgI7N_DJ3N-r0v2JkCPMPpWQX	UC75nwKcny3G8YzDQDbRQGxA	1	DPC Western Europe Region		2025-06-28
PL_4tlvwvMgI5_KJpm00uz9Z3n2t5U6SKL	UC75nwKcny3G8YzDQDbRQGxA	1	DPC South America Region		2025-06-28
PL_4tlvwvMgI5jEtuAk_P1zSNFn8dfh-l0	UC75nwKcny3G8YzDQDbRQGxA	1	DPC North America Region		2025-06-28
PL_4tlvwvMgI43H2V3tnHthrMKsUc2Ps0Y	UC75nwKcny3G8YzDQDbRQGxA	1	DPC Eastern Europe Region		2025-06-28
PL_4tlvwvMgI5e-4LvCkLSbHL_-4_91-7i	UC75nwKcny3G8YzDQDbRQGxA	1	DPC Southeast Asia Region		2025-06-28
PL_4tlvwvMgI6N55hdLraSdW8EnsPgV15k	UC75nwKcny3G8YzDQDbRQGxA	1	DPC China Region		2025-06-28
PL_4tlvwvMgI6X8B09ajnQtGj35btq0Z_k	UC75nwKcny3G8YzDQDbRQGxA	1	The International		2025-06-28
PL_4tlvwvMgI6NFzTKNG8Aq0JNVQx5lZlK	UC75nwKcny3G8YzDQDbRQGxA	1	Dota 2 Scrim Highlights		2025-06-28
PL_4tlvwvMgI7bn5Wsfpxo8iCn2Wx9OjQx	UC75nwKcny3G8YzDQDbRQGxA	1	Dota 2 Best Highlights		2025-06-28
PL_4tlvwvMgI7cJQSJqKgsE0RkQReZj_dh	UC75nwKcny3G8YzDQDbRQGxA	1	BTS Pro Series		2025-06-28
PL_4tlvwvMgI5813VNJu5nhjr6gWnrm_rv	UC75nwKcny3G8YzDQDbRQGxA	1	Dota 2		2025-06-28
PL_4tlvwvMgI76RFbuJc6zU-SQBePmA-xT	UC75nwKcny3G8YzDQDbRQGxA	1	Omega League		2025-06-28
PL_4tlvwvMgI4RoAs-SZQVv4grETytgyEX	UC75nwKcny3G8YzDQDbRQGxA	1	ESL One		2025-06-28
PL_4tlvwvMgI5tzaLxv5Za-Xx1ivSN8KCD	UC75nwKcny3G8YzDQDbRQGxA	1	OGA Dota Pit		2025-06-28
PL_4tlvwvMgI44nQbFP-wEc1oUsh1O1FT5	UC75nwKcny3G8YzDQDbRQGxA	1	One Esports SEA League		2025-06-28
PL_4tlvwvMgI4Q2Wr3kL04bf3YXcAwxAg_	UC75nwKcny3G8YzDQDbRQGxA	1	Moon Studio Asian League		2025-06-28
PLjoV_Kp8hEgsCwgJ4pw2WNra1lBj6kMU4	UC3v9jm_gJl80V7D1bXSQUbg	1	Item Data-Leak Analysis		2025-06-28
PLjoV_Kp8hEgsyUqGkAJ_czBBn5Oo0IyHo	UC3v9jm_gJl80V7D1bXSQUbg	1	Muerta Related Videos		2025-06-28
PLjoV_Kp8hEgu7Z4HzDXHtVb_ZhW7enAUQ	UC3v9jm_gJl80V7D1bXSQUbg	1	Dota Theory : Great Confluence Into the Dota-Verse [Theory Series]		2025-06-28
PLjoV_Kp8hEgsouLnHslGC3WQzZx75CqOG	UC3v9jm_gJl80V7D1bXSQUbg	1	Shorts		2025-06-28
PLjoV_Kp8hEgvkLsBPtQtE_5UpRV9SvbYi	UC3v9jm_gJl80V7D1bXSQUbg	1	Hero Data-Leak Analysis [2021]		2025-06-28
PLjoV_Kp8hEgsRhAWLCXpGMX8Qu3MOY0CZ	UC3v9jm_gJl80V7D1bXSQUbg	1	Hero Data-Leak Analysis [2020]		2025-06-28
PLjoV_Kp8hEgvCc76w1Z89csg_R4WTQ-3y	UC3v9jm_gJl80V7D1bXSQUbg	1	Dota Theory : The Ancient Stones [Theory Series]		2025-06-28
PLzGR0Qu1MSiGdJ-WqkZnOoHkWsHAL8jgt	UCbEKR2sUvjXpCv9bHdeu_kA	1	KARL Gameplay		2025-06-28
PLzGR0Qu1MSiEo9dr62cO0a907knUZfoiq	UCbEKR2sUvjXpCv9bHdeu_kA	1	ARTEEZY Gameplay		2025-06-28
PLzGR0Qu1MSiE4cYalwrdU-qrTqJMqiVRm	UCbEKR2sUvjXpCv9bHdeu_kA	1	ABED Gameplay		2025-06-28
PLzGR0Qu1MSiFyBR-5Zb5WB7Ux39Frlf7X	UCbEKR2sUvjXpCv9bHdeu_kA	1	DOTA 2 Pros Full Gameplay		2025-06-28
PLwsvKEvkGAMkw3Zgn0ef1hCwGrgyzsiip	UCN3TsZ85XxxJWVjOd3Au7Tg	1	Dota 2 Documentary		2025-06-28
PLkTn9R82r8rBg35aMHIVYLbPZGEv9MfhJ	UCPInitFCnCdPeXhYTtu_1Mg	1	Mega Creeps Comeback		2025-06-28
PLkTn9R82r8rDtGWExyhMhf8MHMRvg8379	UCPInitFCnCdPeXhYTtu_1Mg	1	MIRACLE		2025-06-28
PL0GJnVKAkziWz4Fu50fjA62btpqSlnAM6	UCKQVOWuuZB0ZGViUHSIbRgg	1	STILL DOTA 2		2025-06-28
PL0-p9IPGGP8QURzWBL27nsViJFyRSIzxQ	UC37QwXQO8jF_b7QUOWASYPw	1	SF Highlights		2025-06-28
PL0-p9IPGGP8Q9Jsm6MZC9OcWyLOlw2jtS	UC37QwXQO8jF_b7QUOWASYPw	1	Visage Highlights		2025-06-28
PL0-p9IPGGP8SJTqtmP1Fv4O-kl2xUZuzQ	UC37QwXQO8jF_b7QUOWASYPw	1	ProDota		2025-06-28
PL0-p9IPGGP8Rp5ZkT2I6NlAEVy1XKTrC5	UC37QwXQO8jF_b7QUOWASYPw	1	Hoodwink Highlights		2025-06-28
PL0-p9IPGGP8TIZ3b8cUtkElHJ77dLB3GG	UC37QwXQO8jF_b7QUOWASYPw	1	Bugs, Tips and Tricks		2025-06-28
PL0-p9IPGGP8S7siuvaahV4Wr0404GT4P9	UC37QwXQO8jF_b7QUOWASYPw	1	Invoker Highlights		2025-06-28
PL0-p9IPGGP8Rd_zvpCnTCf8LWxpV6rroG	UC37QwXQO8jF_b7QUOWASYPw	1	SEA Cancer		2025-06-28
PLSf-MQHpRjPmAnipsAldcQh7748PYs5vH	UCM05DDwIjT7rbTStUiDtDKQ	1	RAMZES666		2025-06-28
PLSf-MQHpRjPnxtcD0tO6h2krVWtkx9VV2	UCM05DDwIjT7rbTStUiDtDKQ	1	bzm		2025-06-28
PLSf-MQHpRjPlr1EjJ3astMKaJvByz4I9x	UCM05DDwIjT7rbTStUiDtDKQ	1	Iceiceice		2025-06-28
PLSf-MQHpRjPmlhwwQLGr7Ax7zfLW4BOQL	UCM05DDwIjT7rbTStUiDtDKQ	1	Topson		2025-06-28
PLSf-MQHpRjPk1RSyV53OAJVjBSFh8pac9	UCM05DDwIjT7rbTStUiDtDKQ	1	Miracle		2025-06-28
PLSf-MQHpRjPm95wcrCIUdiwXjc-C05VFZ	UCM05DDwIjT7rbTStUiDtDKQ	1	SumaiL		2025-06-28
PLSf-MQHpRjPkvbn3VTbGLoW5n-Wd_v1mL	UCM05DDwIjT7rbTStUiDtDKQ	1	NothingToSay		2025-06-28
PLSf-MQHpRjPkuM-CEymNJ1eDaE-7p5qHl	UCM05DDwIjT7rbTStUiDtDKQ	1	Ana		2025-06-28
PLSf-MQHpRjPkD56z1kHWoVkjBf3i3isb4	UCM05DDwIjT7rbTStUiDtDKQ	1	CEB		2025-06-28
PLSf-MQHpRjPkypSgTzKTpFDZ6YHgj8NKf	UCM05DDwIjT7rbTStUiDtDKQ	1	Nisha		2025-06-28
PLSf-MQHpRjPmZay3YKg2SMrXg84KdpcZb	UCM05DDwIjT7rbTStUiDtDKQ	1	LESLAO		2025-06-28
PLSf-MQHpRjPllOCL-CYyYeWHYKx4p7ci2	UCM05DDwIjT7rbTStUiDtDKQ	1	Moo		2025-06-28
PLSf-MQHpRjPlQm7pMSyaRZErxniIh3D6R	UCM05DDwIjT7rbTStUiDtDKQ	1	Abed		2025-06-28
PLSf-MQHpRjPmWx08PJ0E6T_E1Fvl4fxBp	UCM05DDwIjT7rbTStUiDtDKQ	1	TORONTOTOKYO		2025-06-28
PLSf-MQHpRjPkDwTjVCZx_OXOIYoZC8BK5	UCM05DDwIjT7rbTStUiDtDKQ	1	Paparazi		2025-06-28
PLSf-MQHpRjPku-K9wmJSFwSQngkRKC4tQ	UCM05DDwIjT7rbTStUiDtDKQ	1	miCKe		2025-06-28
PLSf-MQHpRjPlmLkAZBhuhX8b83h7EvTW-	UCM05DDwIjT7rbTStUiDtDKQ	1	MagicaL		2025-06-28
PLSf-MQHpRjPmxUgCJAUS-jo3-G9GODUv5	UCM05DDwIjT7rbTStUiDtDKQ	1	w33		2025-06-28
PLSf-MQHpRjPk85fPYI-7F3qWu3mvrRyme	UCM05DDwIjT7rbTStUiDtDKQ	1	iLTW		2025-06-28
PLSf-MQHpRjPmEfXJfldUVOo8eTdbVHfd-	UCM05DDwIjT7rbTStUiDtDKQ	1	!Attacker		2025-06-28
PLSf-MQHpRjPnZGPFzHShl1BWAktrDUUY_	UCM05DDwIjT7rbTStUiDtDKQ	1	Arteezy		2025-06-28
PLSf-MQHpRjPmyAcYLmqOMOu1RdeCR99iJ	UCM05DDwIjT7rbTStUiDtDKQ	1	Dendi		2025-06-28
PLSf-MQHpRjPlkTtwWd0-zQ_umoNAeIJ0u	UCM05DDwIjT7rbTStUiDtDKQ	1	Yatoro		2025-06-28
PLXA0g1LJZtcrZPf0BenhURLQ1pKKbaHI7	UCAsJY3XcyPLePV-m-SGBPdQ	1	Soft Support		2025-06-28
PLXA0g1LJZtcp9BEq049SgZWR2y0ywPOKj	UCAsJY3XcyPLePV-m-SGBPdQ	1	Hard Support		2025-06-28
PLXA0g1LJZtcryNzp0JDkLSvmtdFe8Ws0d	UCAsJY3XcyPLePV-m-SGBPdQ	1	Offlane		2025-06-28
PLXA0g1LJZtcqXbgttQRgKYObSnOs9J832	UCAsJY3XcyPLePV-m-SGBPdQ	1	Midlaner		2025-06-28
PLXA0g1LJZtcraAtxmT75DBqKKK-VUJWwk	UCAsJY3XcyPLePV-m-SGBPdQ	1	Carry		2025-06-28
PLaiV02wzc-vD7lp5e0uksXsjFQCQQCz4n	UCgfMMDA5Am2fuAyoFXGQoYA	1	Dota 2		2025-06-28
PLozRc0hZ6FPBnXAiyLQhhSur0KsM8eaJk	UCKz9sZPT4AvbdhkLWyHJIIA	1	Mikey		2025-06-28
PLozRc0hZ6FPB7AS0C-Im0sI4V-pzCHLXl	UCKz9sZPT4AvbdhkLWyHJIIA	1	mellojul		2025-06-28
PLozRc0hZ6FPBdJjHtPmXyGP8u9t_Nhgc_	UCKz9sZPT4AvbdhkLWyHJIIA	1	Sccc		2025-06-28
PLozRc0hZ6FPA5JLFcr88GiHW3boq1WPLn	UCKz9sZPT4AvbdhkLWyHJIIA	1	Lou		2025-06-28
PLozRc0hZ6FPBe2FXCZQ3VYVa2se3EWdWK	UCKz9sZPT4AvbdhkLWyHJIIA	1	Sonneiko		2025-06-28
PLozRc0hZ6FPAo45EpalbEERn-a8LX6TV0	UCKz9sZPT4AvbdhkLWyHJIIA	1	Collapse		2025-06-28
PLozRc0hZ6FPCQV1VCp4UjFEJZFn40CAsS	UCKz9sZPT4AvbdhkLWyHJIIA	1	Karl		2025-06-28
PLozRc0hZ6FPBzSGhdLY2ko6BVNWz2iuCF	UCKz9sZPT4AvbdhkLWyHJIIA	1	Pakazs		2025-06-28
PLozRc0hZ6FPCkZOcLNh-8jGtHu3bRejop	UCKz9sZPT4AvbdhkLWyHJIIA	1	Ceb/7ckngMad		2025-06-28
PLozRc0hZ6FPCC5WMOHYhv2i4CxyNafLVy	UCKz9sZPT4AvbdhkLWyHJIIA	1	Nine		2025-06-28
PLozRc0hZ6FPCCz2C63c12BgsfMhxgSvOY	UCKz9sZPT4AvbdhkLWyHJIIA	1	Crystallis		2025-06-28
PLozRc0hZ6FPCINZbfnQzpb0gJ10pqnObR	UCKz9sZPT4AvbdhkLWyHJIIA	1	Skiter		2025-06-28
PLozRc0hZ6FPC7x0VD5a_b_qT3CUjQnRTh	UCKz9sZPT4AvbdhkLWyHJIIA	1	7jesu		2025-06-28
PLozRc0hZ6FPDPl6D7chQ_jvZqpkmDyJJU	UCKz9sZPT4AvbdhkLWyHJIIA	1	CharlieDota		2025-06-28
PLozRc0hZ6FPC2wtoFrQOBXxTF_ydkanA0	UCKz9sZPT4AvbdhkLWyHJIIA	1	Malady		2025-06-28
PLozRc0hZ6FPCAqJl0ojDTMZPzxG2sy7e0	UCKz9sZPT4AvbdhkLWyHJIIA	1	support		2025-06-28
PLozRc0hZ6FPA6-VtcJlB5uVTmG2jM3zSq	UCKz9sZPT4AvbdhkLWyHJIIA	1	Xcalibur		2025-06-28
PLozRc0hZ6FPCzxWEpgI-bhv6pzrHm5rdb	UCKz9sZPT4AvbdhkLWyHJIIA	1	MidOne		2025-06-28
PLozRc0hZ6FPCn6GdGSGYOqXg3WH2KZ-tp	UCKz9sZPT4AvbdhkLWyHJIIA	1	Matumbaman		2025-06-28
PLozRc0hZ6FPCH7DCAdarRwuK2U4ohShuR	UCKz9sZPT4AvbdhkLWyHJIIA	1	Mikoto		2025-06-28
PLozRc0hZ6FPDLYPOns45LvAEsWcYlwnBz	UCKz9sZPT4AvbdhkLWyHJIIA	1	gpk		2025-06-28
PLozRc0hZ6FPCYc1MS9OLmEA5MmVG6R6O0	UCKz9sZPT4AvbdhkLWyHJIIA	1	Watson		2025-06-28
PLozRc0hZ6FPAO2m645Uh5O-7-ax4JkBgA	UCKz9sZPT4AvbdhkLWyHJIIA	1	Ana		2025-06-28
PLozRc0hZ6FPB_KHXBvHJbRe9XHXmG3vOy	UCKz9sZPT4AvbdhkLWyHJIIA	1	FULL		2025-06-28
PLozRc0hZ6FPAGxuyg823lDv2NoJnj4_Sk	UCKz9sZPT4AvbdhkLWyHJIIA	1	Timado		2025-06-28
PLozRc0hZ6FPDh1QoNum9mtje9xdClagLS	UCKz9sZPT4AvbdhkLWyHJIIA	1	Yuragi		2025-06-28
PLozRc0hZ6FPCs2cDiB2Vc1Z6aaXHWQ6oz	UCKz9sZPT4AvbdhkLWyHJIIA	1	EternaLEnVy		2025-06-28
PLozRc0hZ6FPCqpKMb6QWtly2WI8Z2L5T8	UCKz9sZPT4AvbdhkLWyHJIIA	1	StormStormer		2025-06-28
PLozRc0hZ6FPCfSZ6FxrTnxqVwc6_iD3p7	UCKz9sZPT4AvbdhkLWyHJIIA	1	NothingToSay		2025-06-28
PLozRc0hZ6FPDkEDsYvKfpAyye7HRbvQPq	UCKz9sZPT4AvbdhkLWyHJIIA	1	Ame		2025-06-28
PLozRc0hZ6FPC_tggS55Q7m16DM-T7BBpO	UCKz9sZPT4AvbdhkLWyHJIIA	1	W33		2025-06-28
PLozRc0hZ6FPCkSwcBEIGfd4ugFvX-2LXG	UCKz9sZPT4AvbdhkLWyHJIIA	1	Noone		2025-06-28
PLozRc0hZ6FPCCbdfm-z3p5QQeV6yzxglj	UCKz9sZPT4AvbdhkLWyHJIIA	1	Wisper		2025-06-28
PLozRc0hZ6FPBxizMhF1gQ5xYten5OTXs-	UCKz9sZPT4AvbdhkLWyHJIIA	1	POS 3		2025-06-28
PLozRc0hZ6FPAfCmM68IyVzjuLbAHHFh53	UCKz9sZPT4AvbdhkLWyHJIIA	1	POS 5		2025-06-28
PLozRc0hZ6FPAfiCrARDUu1vy5I2rkh5B4	UCKz9sZPT4AvbdhkLWyHJIIA	1	Puppey		2025-06-28
PLozRc0hZ6FPBUxU85bwLLNmOqusAkD0GO	UCKz9sZPT4AvbdhkLWyHJIIA	1	POS 2 MID		2025-06-28
PLozRc0hZ6FPA39vnmOiFwCTshOzHYJgG0	UCKz9sZPT4AvbdhkLWyHJIIA	1	POS 1 CARRY		2025-06-28
PLozRc0hZ6FPD44MExdex6p2SmfePEYug8	UCKz9sZPT4AvbdhkLWyHJIIA	1	Arteezy		2025-06-28
PLozRc0hZ6FPB1-1VdQ4XR6ZkMVWDh3jkj	UCKz9sZPT4AvbdhkLWyHJIIA	1	Topson		2025-06-28
PLozRc0hZ6FPArfn3wJRMFcW8mRCF6yapJ	UCKz9sZPT4AvbdhkLWyHJIIA	1	Miracle-		2025-06-28
PLozRc0hZ6FPAOe42VCr_vuRnjhDZ9IxQA	UCKz9sZPT4AvbdhkLWyHJIIA	1	Sumail		2025-06-28
PLozRc0hZ6FPCNXC_PDgPG9odM58XDUomZ	UCKz9sZPT4AvbdhkLWyHJIIA	1	23savage		2025-06-28
PLozRc0hZ6FPDNdi2ccxcxqCLNzIjW72Xo	UCKz9sZPT4AvbdhkLWyHJIIA	1	shorts		2025-06-28
PLozRc0hZ6FPA6K--XvMhqgP_GcNQhJeGp	UCKz9sZPT4AvbdhkLWyHJIIA	1	Gorgc		2025-06-28
PLozRc0hZ6FPDcHNY22HdWRI0qEtnajwie	UCKz9sZPT4AvbdhkLWyHJIIA	1	Yatoro		2025-06-28
PLozRc0hZ6FPClkfNVe6vu1WDDuk4l7ZVP	UCKz9sZPT4AvbdhkLWyHJIIA	1	Top Dotabuff		2025-06-28
PLozRc0hZ6FPAoBFHvfzIj23mvV52vGaer	UCKz9sZPT4AvbdhkLWyHJIIA	1	General		2025-06-28
PLozRc0hZ6FPBEEHao9iiCyky-I3GXH_xd	UCKz9sZPT4AvbdhkLWyHJIIA	1	Dendi		2025-06-28
PLmH1Hx_ogt64Mjq8lbGHYGCs8c4CULD-h	UCgT3aLbI2qNYcYFWtmntxZQ	1	Offlane Carry		2025-06-28
PLmH1Hx_ogt66LnXYZYyjr6Mbf5SmP-bk8	UCgT3aLbI2qNYcYFWtmntxZQ	1	Midlane Carry		2025-06-28
PLmH1Hx_ogt64MSuQRAJE7X8WadNEU3KgJ	UCgT3aLbI2qNYcYFWtmntxZQ	1	Safelane Carry		2025-06-28
PLioysc5rfJvTpQYsKOVMQfxSu7OPEmPmz	UClxwL5BvlIBT0aSygQV1OBw	1	Guess The Final Pick Series		2025-06-28
PLioysc5rfJvSR8odtXJ5Kia1C3hYjn14Y	UClxwL5BvlIBT0aSygQV1OBw	1	Pro Full Video Gameplay		2025-06-28
PLioysc5rfJvSo2iIXS9pDydHb_-qagX5n	UClxwL5BvlIBT0aSygQV1OBw	1	Pro Highlights		2025-06-28
PL-y7mnqpjyngX5qUY4hCGYyKVrvr5nsjt	UCq1SlO7vuzA1Rr1UbsVX1Cw	1	Trash bin		2025-06-28
PL-y7mnqpjyni-i3arlzJppoih3-APELZL	UCq1SlO7vuzA1Rr1UbsVX1Cw	1	New Meta Amazing Builds		2025-06-28
PL-y7mnqpjynhgEjvtNya3OlaRuYAePrmv	UCq1SlO7vuzA1Rr1UbsVX1Cw	1	Cheats / scripts  / Hacks		2025-06-28
PL-y7mnqpjynhpNKVRb0h-HF87FArNAPoM	UCq1SlO7vuzA1Rr1UbsVX1Cw	1	Support Heroes GamePlay		2025-06-28
PL-y7mnqpjynhcDnhbI_L8QUjwV0MYkUf2	UCq1SlO7vuzA1Rr1UbsVX1Cw	1	Core Heroes GamePlay		2025-06-28
PL-y7mnqpjyng0V2JhGnPd-MChPc3jWw6B	UCq1SlO7vuzA1Rr1UbsVX1Cw	1	Dota 2 Updates / Deatails		2025-06-28
PL-y7mnqpjynh2Yk2kbOVdYCdBdoeXZ80S	UCq1SlO7vuzA1Rr1UbsVX1Cw	1	Dota 2 Custom Games - Dota 2 Arcade		2025-06-28
PL-y7mnqpjynjnkKms0C3lW_XWdDQu59cM	UCq1SlO7vuzA1Rr1UbsVX1Cw	1	Dota 2 Pro GamePlay | Dota 2 Mastery		2025-06-28
PL-y7mnqpjynhOxX0ig3JBXqp8XllN-Nau	UCq1SlO7vuzA1Rr1UbsVX1Cw	1	Dota 2 Mastery #SHORTS		2025-06-28
PL-y7mnqpjyniFG5JpBgXcN0OCSUlVLmoK	UCq1SlO7vuzA1Rr1UbsVX1Cw	1	Dota 2 Ti10 Replay Games		2025-06-28
PL-y7mnqpjynjPbwPoN79y9MV1pbkhuq6Y	UCq1SlO7vuzA1Rr1UbsVX1Cw	1	YAPHETS GAMEPLAY		2025-06-28
PL-y7mnqpjyngttJlGG5ZT6dhFoiqxrhno	UCq1SlO7vuzA1Rr1UbsVX1Cw	1	MIRACLE DOTA 2		2025-06-28
PLer5bZcTkpjgmIScfR50Bgmn8YlnpqnLM	UCHJL5WGh4KXyWs7zxcb8fRw	1	RAMPAGE Moment		2025-06-28
PLer5bZcTkpjisxzCvhOV-Rr3XsfqGoN6u	UCHJL5WGh4KXyWs7zxcb8fRw	1	Tournament Pro		2025-06-28
PLer5bZcTkpjhqp7jBxzwVnf0TOjLwzhO3	UCHJL5WGh4KXyWs7zxcb8fRw	1	Dota2 Pro Player		2025-06-28
PLXEd0Ox-ZknAewE1OpP0PEcH7GuNbV2ck	UCLA23mWwgSH8Co3ApS7JGyg	1	Dota 2 7.32D Zeus Replays		2025-06-28
PLXEd0Ox-ZknBTqJD7aN-lnanpyeFno3OM	UCLA23mWwgSH8Co3ApS7JGyg	1	Dota 2 7.32D Legion Commander Replays		2025-06-28
PLXEd0Ox-ZknBSM1j-6xPbx6IpkPco-NgY	UCLA23mWwgSH8Co3ApS7JGyg	1	Dota 2 7.32D Razor Replays		2025-06-28
PLXEd0Ox-ZknAzIKfhwxRmvq5FUj2OeTne	UCLA23mWwgSH8Co3ApS7JGyg	1	Dota 2 7.32D Lycan Replays		2025-06-28
PLXEd0Ox-ZknBczG660gCEqpcSvxZEFdnT	UCLA23mWwgSH8Co3ApS7JGyg	1	Dota 2 7.32D Beastmaster replays		2025-06-28
PLXEd0Ox-ZknAA2zuW8Hty-yrXzWjDVKQT	UCLA23mWwgSH8Co3ApS7JGyg	1	Dota 2 7.32D Spectre replays		2025-06-28
PLXEd0Ox-ZknB2cqjJJFLDKTRczzkXw5l0	UCLA23mWwgSH8Co3ApS7JGyg	1	Dota 2 7.32C Tidehunter replays		2025-06-28
PLXEd0Ox-ZknDUFi-0LTHcnTmAvl2KmfT5	UCLA23mWwgSH8Co3ApS7JGyg	1	Dota 2 7.32C Lycan Replays		2025-06-28
PLXEd0Ox-ZknA7K8Q_1Z3y9VY6fmoYVYGw	UCLA23mWwgSH8Co3ApS7JGyg	1	Dota 2 7.32C Crystal Maiden Replays		2025-06-28
PLXEd0Ox-ZknBReCReDf62QvJP_4JZ6SOS	UCLA23mWwgSH8Co3ApS7JGyg	1	Dota 2 7.32C Mirana replays		2025-06-28
PLXEd0Ox-ZknDjh5QKqU5HkWQrLrWUtPEy	UCLA23mWwgSH8Co3ApS7JGyg	1	Dota 2 7.32C Silencer Replays		2025-06-28
PLXEd0Ox-ZknChVbbW2lVi2EgMBh5haNUL	UCLA23mWwgSH8Co3ApS7JGyg	1	Dota 2 7.32C Enigma Replays		2025-06-28
PLaA0RQHDm2BZ1CMvp4h5-fp4G0uMN-Rqf	UCcns7kcCEC2p8CJ3bfYQoog	1	How to Leshrac Safelane		2025-06-28
PLaA0RQHDm2BYRbJvkk5xuqDy9VwfGqkSQ	UCcns7kcCEC2p8CJ3bfYQoog	1	How to Templar Assassin Safelane		2025-06-28
PLaA0RQHDm2BaK2MIGI5vdzE_ZNgjvxeYk	UCcns7kcCEC2p8CJ3bfYQoog	1	How to Sven Safelane		2025-06-28
PLaA0RQHDm2BbBjjSOpDVbhPny0bIH9eCm	UCcns7kcCEC2p8CJ3bfYQoog	1	How to Shadow Fiend Safelane		2025-06-28
PLaA0RQHDm2BYNNSalkbx9erjyN9Js9KQ3	UCcns7kcCEC2p8CJ3bfYQoog	1	How to Faceless Void Safelane		2025-06-28
PLaA0RQHDm2BaCfN1Rx8tOgnAJysfwkYIx	UCcns7kcCEC2p8CJ3bfYQoog	1	How to Bristleback Safelane		2025-06-28
PLaA0RQHDm2BZi9FxJ8LWBtmQzBu-Dd6HE	UCcns7kcCEC2p8CJ3bfYQoog	1	How to Terrorblade Safelane		2025-06-28
PLaA0RQHDm2BZMFqOFQj5dtQDOvKrDLJkT	UCcns7kcCEC2p8CJ3bfYQoog	1	How to Io Safelane		2025-06-28
PLaA0RQHDm2BZ5U37ZiORCz0-eJmjXCCfO	UCcns7kcCEC2p8CJ3bfYQoog	1	How to Void Spirit Safelane		2025-06-28
PLaA0RQHDm2BZXExbvfEDs6NidXeIgH-E1	UCcns7kcCEC2p8CJ3bfYQoog	1	How to Lone Druid Safelane		2025-06-28
PLaA0RQHDm2BYUO5d7NqWE-tnI2hNh0Ivo	UCcns7kcCEC2p8CJ3bfYQoog	1	How to Chaos Knight Safelane		2025-06-28
PLaA0RQHDm2BbBJluvihbffc-he_g7Lvhe	UCcns7kcCEC2p8CJ3bfYQoog	1	How to Sniper Safelane		2025-06-28
PLaA0RQHDm2BYKV4hH3gScQLOC3Qrb5Wrs	UCcns7kcCEC2p8CJ3bfYQoog	1	How to Beastmaster Safelane		2025-06-28
PLaA0RQHDm2BaDfd56qHHwnnUeJeHhKRd8	UCcns7kcCEC2p8CJ3bfYQoog	1	How to Pangolier Safelane		2025-06-28
PLaA0RQHDm2BZ6d3a0zOk906dJW6Z0UTMB	UCcns7kcCEC2p8CJ3bfYQoog	1	How to Hoodwink Safelane		2025-06-28
PLaA0RQHDm2BZKpyy5sz6_kGskzsnj_GRC	UCcns7kcCEC2p8CJ3bfYQoog	1	How to Outworld Destroyer Safelane		2025-06-28
PLaA0RQHDm2BYHzncWEbJOTbko0YuC_d_H	UCcns7kcCEC2p8CJ3bfYQoog	1	How to Weaver Safelane		2025-06-28
PLaA0RQHDm2BYjQNBOquD3r1_LAk5ZPR0t	UCcns7kcCEC2p8CJ3bfYQoog	1	How to Alchemist Safelane		2025-06-28
PLaA0RQHDm2Ba6NW0hwoFxZ34z3gf0sD9m	UCcns7kcCEC2p8CJ3bfYQoog	1	How to Gyrocopter Safelane		2025-06-28
PLaA0RQHDm2Ba4evpNaRLcWemWfGVYwZGn	UCcns7kcCEC2p8CJ3bfYQoog	1	How to Lycan Safelane		2025-06-28
PLaA0RQHDm2BbstYGDIYZCzNwAHOC9JDBp	UCcns7kcCEC2p8CJ3bfYQoog	1	How to Luna Safelane		2025-06-28
PLaA0RQHDm2BY5eB_n-eNYIcv0dPHBhOKE	UCcns7kcCEC2p8CJ3bfYQoog	1	How to Medusa Safelane		2025-06-28
PLaA0RQHDm2BZacLdkRDT4c7pZdWN_oEwZ	UCcns7kcCEC2p8CJ3bfYQoog	1	How to Bloodseeker Safelane		2025-06-28
PLaA0RQHDm2BYU7ncLcTnxwtqvXIilPV4T	UCcns7kcCEC2p8CJ3bfYQoog	1	How to Phantom Lancer Safelane		2025-06-28
PLaA0RQHDm2BaxsyRZEDiQ3u1JNPXpfRpv	UCcns7kcCEC2p8CJ3bfYQoog	1	How to Clinkz Safelane		2025-06-28
PLaA0RQHDm2BZjFhGAmjaKp2XvmoZqMeV6	UCcns7kcCEC2p8CJ3bfYQoog	1	How to Arc Warden Safelane		2025-06-28
PLaA0RQHDm2BYyoO38YuIFRYIpI1xXUq0O	UCcns7kcCEC2p8CJ3bfYQoog	1	How to Riki Safelane		2025-06-28
PLaA0RQHDm2BYaAFJHHAuL6yGyTJocq3yD	UCcns7kcCEC2p8CJ3bfYQoog	1	How to Phantom Assassin Safelane		2025-06-28
PLaA0RQHDm2BbSdcx0axbG3gSME2X9THlX	UCcns7kcCEC2p8CJ3bfYQoog	1	How to Troll Warlord Safelane		2025-06-28
PLaA0RQHDm2BbGn6yvg3e1zJD4fHR2kyRX	UCcns7kcCEC2p8CJ3bfYQoog	1	How to Monkey King Safelane		2025-06-28
PLaA0RQHDm2BYxbUFkStwCaxXS0wEQFCp8	UCcns7kcCEC2p8CJ3bfYQoog	1	How to Drow Ranger Safelane		2025-06-28
PLaA0RQHDm2BYgrQPcqAyv3o2DBTge8YU6	UCcns7kcCEC2p8CJ3bfYQoog	1	How to Ursa Safelane		2025-06-28
PLaA0RQHDm2BaKFpL6fD1pXEPMdiEXMzzj	UCcns7kcCEC2p8CJ3bfYQoog	1	How to Mars Safelane		2025-06-28
PLaA0RQHDm2BZB9OmZd_-qqFwou_RopOki	UCcns7kcCEC2p8CJ3bfYQoog	1	How to Wraith King Safelane		2025-06-28
PLaA0RQHDm2BZeUnSDH9cEBjtPo61Ekcze	UCcns7kcCEC2p8CJ3bfYQoog	1	How to Slark Safelane		2025-06-28
PLaA0RQHDm2BZdDCCdSWcK_yM_ElR1KEJx	UCcns7kcCEC2p8CJ3bfYQoog	1	How to Morphling Safelane		2025-06-28
PLaA0RQHDm2Bag2MY_C_60oW6_iQ6rVO0s	UCcns7kcCEC2p8CJ3bfYQoog	1	How to Juggernaut Safelane		2025-06-28
PLaA0RQHDm2BbV0IfsfndHPi19nLq1OhTu	UCcns7kcCEC2p8CJ3bfYQoog	1	How to Antimage Safelane		2025-06-28
PLepBXTdL-AMG3xnSVCy8IEGxyj8Sua10C	UC4Vy0bSRfaI2Qlz4id9WS6g	1	How to Weaver Offlane		2025-06-28
PLepBXTdL-AMGKmIHGYh11sP5ow2fc3Cxo	UC4Vy0bSRfaI2Qlz4id9WS6g	1	How to Broodmother Offlane		2025-06-28
PLepBXTdL-AMEp4mpudTjV3VRGz8XsdoZw	UC4Vy0bSRfaI2Qlz4id9WS6g	1	How to Tinker Offlane		2025-06-28
PLepBXTdL-AMEQrPwWqw9xJcsZe4JMYN-q	UC4Vy0bSRfaI2Qlz4id9WS6g	1	How to Naga Siren Offlane		2025-06-28
PLepBXTdL-AMFUfVlsQs-SPi6JtnebJCC1	UC4Vy0bSRfaI2Qlz4id9WS6g	1	How to Tusk Offlane		2025-06-28
PLepBXTdL-AMGBiYmO3pcCOQosMud9T7Wf	UC4Vy0bSRfaI2Qlz4id9WS6g	1	How to Earth Spirit Offlane		2025-06-28
PLepBXTdL-AMHgfrOEVcDrFkU-7QMooLVE	UC4Vy0bSRfaI2Qlz4id9WS6g	1	How to Sand King Offlane		2025-06-28
PLepBXTdL-AMGTQISri1pQZO_M7BHZzCVE	UC4Vy0bSRfaI2Qlz4id9WS6g	1	How to Clockwerk Offlane		2025-06-28
PLepBXTdL-AMFvBeWhNBnJ7o5IR5usEBsB	UC4Vy0bSRfaI2Qlz4id9WS6g	1	How to Bounty Hunter Offlane		2025-06-28
PLepBXTdL-AMEXl0f4dOjLtC3qQ-5zg9l_	UC4Vy0bSRfaI2Qlz4id9WS6g	1	How to Earthshaker Offlane		2025-06-28
PLepBXTdL-AMF_jsm0s7sXRnxvliSxEiCf	UC4Vy0bSRfaI2Qlz4id9WS6g	1	How to Silencer Offlane		2025-06-28
PLepBXTdL-AMELy0Jaly_SgBEnGSHPNiWN	UC4Vy0bSRfaI2Qlz4id9WS6g	1	How to Razor Offlane		2025-06-28
PLepBXTdL-AMFUfk6gow8dD8XxNHj_tRbL	UC4Vy0bSRfaI2Qlz4id9WS6g	1	How to Phantom Assassin Offlane		2025-06-28
PLepBXTdL-AMHOX6hTveD4I3lw-b6qWefR	UC4Vy0bSRfaI2Qlz4id9WS6g	1	How to Viper Offlane		2025-06-28
PLepBXTdL-AMHokp4bUXG1eLSlR8gmk5XH	UC4Vy0bSRfaI2Qlz4id9WS6g	1	How to Grimstroke Offlane		2025-06-28
PLepBXTdL-AMFv5XzpMy2BTKBqJVyvVUkg	UC4Vy0bSRfaI2Qlz4id9WS6g	1	How to Slardar Offlane		2025-06-28
PLepBXTdL-AMHT9CHAwy7xM2Unq6AbFCA9	UC4Vy0bSRfaI2Qlz4id9WS6g	1	How to Enchantress Offlane		2025-06-28
PLepBXTdL-AMEnP2QhDdj39c5Q_pdCpwQK	UC4Vy0bSRfaI2Qlz4id9WS6g	1	How to Medusa Offlane		2025-06-28
PLepBXTdL-AMHdDQjrQx_95EvCYbti0Gq0	UC4Vy0bSRfaI2Qlz4id9WS6g	1	How to Death Prophet Offlane		2025-06-28
PLepBXTdL-AMGWCij0kUMqLBn0QFj6gHPi	UC4Vy0bSRfaI2Qlz4id9WS6g	1	How to Doom Offlane		2025-06-28
PLepBXTdL-AMGYYgsTLrjd0-Uq68xyVfBx	UC4Vy0bSRfaI2Qlz4id9WS6g	1	How to Tidehunter Offlane		2025-06-28
PLepBXTdL-AMHd_91B0b2I3nAz6fL8mmgW	UC4Vy0bSRfaI2Qlz4id9WS6g	1	How to Troll Warlord Offlane		2025-06-28
PLepBXTdL-AMEvoHh4XLhXV5xltSYgqsEY	UC4Vy0bSRfaI2Qlz4id9WS6g	1	How to Legion Commander Offlane		2025-06-28
PLepBXTdL-AMFVyIzoy9NUNtOFQbKzpN9j	UC4Vy0bSRfaI2Qlz4id9WS6g	1	How to Elder Titan Offlane		2025-06-28
PLepBXTdL-AMFeCP-eul7z5axfcmTcfR4T	UC4Vy0bSRfaI2Qlz4id9WS6g	1	How to Outworld Destroyer Offlane		2025-06-28
PLepBXTdL-AMEolkkhP41cSAwAm-7Ao7iS	UC4Vy0bSRfaI2Qlz4id9WS6g	1	How to Tiny Offlane		2025-06-28
PLepBXTdL-AMHhb_hm9kXa1oAnMfwkzW_Z	UC4Vy0bSRfaI2Qlz4id9WS6g	1	How to Void Spirit Offlane		2025-06-28
PLepBXTdL-AMFq3_kB9KGY8HPjk-q1a_jO	UC4Vy0bSRfaI2Qlz4id9WS6g	1	How to Timbersaw Offlane		2025-06-28
PLepBXTdL-AMFR1DosHnmqjA76CEox8tcN	UC4Vy0bSRfaI2Qlz4id9WS6g	1	How to Magnus Offlane		2025-06-28
PLepBXTdL-AMENVPnrjpZPdCNbJ9-9IvrO	UC4Vy0bSRfaI2Qlz4id9WS6g	1	How to Lycan Offlane		2025-06-28
PLepBXTdL-AMGXnVza2lfw48rMzPoVHOXX	UC4Vy0bSRfaI2Qlz4id9WS6g	1	How to Nyx Assassin Offlane		2025-06-28
PLepBXTdL-AMEWNQj0pItQQzun_m7RnDDG	UC4Vy0bSRfaI2Qlz4id9WS6g	1	How to Visage Offlane		2025-06-28
PLepBXTdL-AMGES3rVGYzJbrHpcsPo4Eap	UC4Vy0bSRfaI2Qlz4id9WS6g	1	How to Axe Offlane		2025-06-28
PLepBXTdL-AMHIk0LTwzGlERNiS-ZxSdCd	UC4Vy0bSRfaI2Qlz4id9WS6g	1	How to Bloodseeker Offlane		2025-06-28
PLepBXTdL-AMHMhptUqq-UWo7O7QNpPmso	UC4Vy0bSRfaI2Qlz4id9WS6g	1	How to Windranger Offlane		2025-06-28
PLepBXTdL-AMEuqrEOU1vRain9iEt-9DMA	UC4Vy0bSRfaI2Qlz4id9WS6g	1	How to Mirana Offlane		2025-06-28
PLepBXTdL-AMEt67u9eLrcym3wppOxmsZ4	UC4Vy0bSRfaI2Qlz4id9WS6g	1	How to Mars Offlane		2025-06-28
PLepBXTdL-AMGzX7QOFxGHqqbtExlLQos7	UC4Vy0bSRfaI2Qlz4id9WS6g	1	How to Phoenix Offlane		2025-06-28
PLepBXTdL-AMEJL4gtxVa9S71R8JdYJVkT	UC4Vy0bSRfaI2Qlz4id9WS6g	1	How to Venomancer Offlane		2025-06-28
PLepBXTdL-AMEjHYIdfj49iqEa6Z_nLC58	UC4Vy0bSRfaI2Qlz4id9WS6g	1	How to Beastmaster Offlane		2025-06-28
PLepBXTdL-AMEtoJYe7rueSIXy2zD_r-5a	UC4Vy0bSRfaI2Qlz4id9WS6g	1	How to Brewmaster Offlane		2025-06-28
PLepBXTdL-AMEVR_SZrwZfa3dSJY6Hn5EB	UC4Vy0bSRfaI2Qlz4id9WS6g	1	How to Chaos Knight Offlane		2025-06-28
PLepBXTdL-AMFpHKVUC69NrK4o8rYXvXsl	UC4Vy0bSRfaI2Qlz4id9WS6g	1	How to Pangolier Offlane		2025-06-28
PLepBXTdL-AMEpiMONvugBeOgErrgG0TAQ	UC4Vy0bSRfaI2Qlz4id9WS6g	1	How to Monkey King Offlane		2025-06-28
PLepBXTdL-AMFhCA3E_MsrrdYn82ewaBRr	UC4Vy0bSRfaI2Qlz4id9WS6g	1	How to Night Stalker Offlane		2025-06-28
PLepBXTdL-AMFZJyFDmd6S9pG8zm0S-8-b	UC4Vy0bSRfaI2Qlz4id9WS6g	1	How to Enigma Offlane		2025-06-28
PLepBXTdL-AME4TBalCL27PVG_Xbxe_1yK	UC4Vy0bSRfaI2Qlz4id9WS6g	1	How to Batrider Offlane		2025-06-28
PLepBXTdL-AMGCXzXWbKEkYqjw5nsG9_Ec	UC4Vy0bSRfaI2Qlz4id9WS6g	1	How to Leshrac Offlane		2025-06-28
PLepBXTdL-AMG3kFtPGIPd-2zu-414KqsJ	UC4Vy0bSRfaI2Qlz4id9WS6g	1	How to Wraith King Offlane		2025-06-28
PLnCSPS-47bzUVnlTHBTr538zhfJ8tCj7H	UClLLxh4LXkDEeQVd7qJkI4A	1	Attacker Gameplay		2025-06-28
PLnCSPS-47bzXp14eIdIXYtFd9kAwxW_e0	UClLLxh4LXkDEeQVd7qJkI4A	1	Ar1se Gameplay		2025-06-28
PLnCSPS-47bzW1JT-kKdLpFd0diT-mnQCy	UClLLxh4LXkDEeQVd7qJkI4A	1	Abed on Tournaments		2025-06-28
PLnCSPS-47bzUuJ6u8njtFKYq85NXm-E_Y	UClLLxh4LXkDEeQVd7qJkI4A	1	Armel Gameplay		2025-06-28
PLnCSPS-47bzUw1FAeaEOIurpZWuiLldjm	UClLLxh4LXkDEeQVd7qJkI4A	1	Yuragi Gameplay		2025-06-28
PLnCSPS-47bzVX2SgH6dIzXYcZLthg9zsV	UClLLxh4LXkDEeQVd7qJkI4A	1	TOP-NOTCH PLAYS		2025-06-28
PLnCSPS-47bzXEfl10PQD6WaQJ7IAQl4-N	UClLLxh4LXkDEeQVd7qJkI4A	1	Crystallis Gameplay		2025-06-28
PLnCSPS-47bzXU7nCk_YY_g1rK7RXaJnYM	UClLLxh4LXkDEeQVd7qJkI4A	1	Nine Gameplay		2025-06-28
PLnCSPS-47bzWdp6EWGWX6bJ3NrF_fd8Mt	UClLLxh4LXkDEeQVd7qJkI4A	1	Pro vs Pro		2025-06-28
PLnCSPS-47bzWbNdj98qwAxkLrSfHH6W4n	UClLLxh4LXkDEeQVd7qJkI4A	1	N0tail Gameplay		2025-06-28
PLnCSPS-47bzWWFdCFBB-dMJRUouF_JtXn	UClLLxh4LXkDEeQVd7qJkI4A	1	Top 1 MMR		2025-06-28
PLnCSPS-47bzWcs326phQHBNv5xpDWA59L	UClLLxh4LXkDEeQVd7qJkI4A	1	Yopaj Gameplay		2025-06-28
PLnCSPS-47bzVwu4HbH9_xOn_vvTqNI_aY	UClLLxh4LXkDEeQVd7qJkI4A	1	bzm Gameplay		2025-06-28
PLnCSPS-47bzU2STYdIXbIoHZj9CF2cHNQ	UClLLxh4LXkDEeQVd7qJkI4A	1	Midone Gameplay		2025-06-28
PLnCSPS-47bzVUYz1XDIOMlOLngWkrfvQQ	UClLLxh4LXkDEeQVd7qJkI4A	1	NothingToSay Gameplay		2025-06-28
PLnCSPS-47bzWtnlwT_CQVZQ9StemE4U8M	UClLLxh4LXkDEeQVd7qJkI4A	1	ATF Gameplay		2025-06-28
PLnCSPS-47bzUeMX9qOIBzH56T3tyQxC8M	UClLLxh4LXkDEeQVd7qJkI4A	1	gpk Gameplay		2025-06-28
PLnCSPS-47bzVLnlR1QVROP3yur6mhEWy1	UClLLxh4LXkDEeQVd7qJkI4A	1	Ana Gameplay		2025-06-28
PLnCSPS-47bzXVIC9JYoWxir8BakYhWeVP	UClLLxh4LXkDEeQVd7qJkI4A	1	Somnus (Maybe) Gameplay		2025-06-28
PLnCSPS-47bzXbL4abqKWBljsmhlgVQ8ow	UClLLxh4LXkDEeQVd7qJkI4A	1	Yatoro Gameplay		2025-06-28
PLnCSPS-47bzUkZ_gMmG1yK5Vu7FtDFqfT	UClLLxh4LXkDEeQVd7qJkI4A	1	Eurus (Paparazi) Gameplay		2025-06-28
PLnCSPS-47bzWQXe6B-ENlkSrkKF2JGNl1	UClLLxh4LXkDEeQVd7qJkI4A	1	W33 Gameplay		2025-06-28
PLnCSPS-47bzVwxdp8bBuPqZO8vJ8iUvcM	UClLLxh4LXkDEeQVd7qJkI4A	1	Abed Gameplay		2025-06-28
PLnCSPS-47bzVgIWChkHdsSgYezHqvwta-	UClLLxh4LXkDEeQVd7qJkI4A	1	Ame Gameplay		2025-06-28
PLnCSPS-47bzUaSH_VNyp5kbgsfIZ_TfD9	UClLLxh4LXkDEeQVd7qJkI4A	1	Matumbaman Gameplay		2025-06-28
PLnCSPS-47bzU15IaYjZRo3VQUAf6qvVws	UClLLxh4LXkDEeQVd7qJkI4A	1	Nisha Gameplay		2025-06-28
PLnCSPS-47bzVUCMV7gsSkj4wTLADtF9Mu	UClLLxh4LXkDEeQVd7qJkI4A	1	23savage Gameplay		2025-06-28
PLnCSPS-47bzXQZUrwLNUxE83r58_VASrU	UClLLxh4LXkDEeQVd7qJkI4A	1	iLTW Gameplay		2025-06-28
PLnCSPS-47bzW_rAvQRaq0jngD5exW4KYx	UClLLxh4LXkDEeQVd7qJkI4A	1	Arteezy Gameplay		2025-06-28
PLnCSPS-47bzWtYdfA3G4PpIeENcWYtNYh	UClLLxh4LXkDEeQVd7qJkI4A	1	Tournaments		2025-06-28
PLnCSPS-47bzWoLvDG97rYNi5JP7d-Cx0P	UClLLxh4LXkDEeQVd7qJkI4A	1	Miracle Gameplay		2025-06-28
PLnCSPS-47bzW2FHcSsPY3F-7qdO54FrLF	UClLLxh4LXkDEeQVd7qJkI4A	1	Topson Gameplay		2025-06-28
PLnCSPS-47bzWsuC3R-31n8Hz8UH5DcuvX	UClLLxh4LXkDEeQVd7qJkI4A	1	Sumail Gameplay		2025-06-28
PLnCSPS-47bzXG7Vy_PV-l4cjlq0G7LrUF	UClLLxh4LXkDEeQVd7qJkI4A	1	Dendi Gameplay		2025-06-28
PL1Fcbz-YuHWKtBay1zvpSKW1kf3PGzkZe	UC65QddVO1zGnePbcoQKJzXw	1	How to Marci Mid		2025-06-28
PL1Fcbz-YuHWK1TnaRbqpcJeqtkMm4RXv6	UC65QddVO1zGnePbcoQKJzXw	1	How to Dawnbreaker Mid		2025-06-28
PL1Fcbz-YuHWJAx3XddgpH-tK9Zh1aMTDr	UC65QddVO1zGnePbcoQKJzXw	1	How to Bounty Hunter Mid		2025-06-28
PL1Fcbz-YuHWLXyB7UsvXc6eaWtnUgLjF3	UC65QddVO1zGnePbcoQKJzXw	1	How to Necrophos Mid		2025-06-28
PL1Fcbz-YuHWJMxNHDvXVqyvJPMXD_ux-c	UC65QddVO1zGnePbcoQKJzXw	1	How to Earthshaker Mid		2025-06-28
PL1Fcbz-YuHWKUiyN1Q6mjXQJ3siEMizFZ	UC65QddVO1zGnePbcoQKJzXw	1	How to Drow Ranger Mid		2025-06-28
PL1Fcbz-YuHWL34TGJoQY3av2v86C5mh1Z	UC65QddVO1zGnePbcoQKJzXw	1	How to Dark Willow Mid		2025-06-28
PL1Fcbz-YuHWIjxyQeK4FkMnKe0q4WaiOG	UC65QddVO1zGnePbcoQKJzXw	1	How to Naga Siren Mid		2025-06-28
PL1Fcbz-YuHWKV32N_WmLFKF6DPnmEHUN8	UC65QddVO1zGnePbcoQKJzXw	1	How to Weaver Mid		2025-06-28
PL1Fcbz-YuHWI-am3ahu5vMLT-Zgm8DSCd	UC65QddVO1zGnePbcoQKJzXw	1	How to Razor Mid		2025-06-28
PL1Fcbz-YuHWK2CUGaoog5_BqbhhsgfWys	UC65QddVO1zGnePbcoQKJzXw	1	How to Enigma Mid		2025-06-28
PL1Fcbz-YuHWJkSKpKDwIsYVgsVvyQi8vg	UC65QddVO1zGnePbcoQKJzXw	1	How to Io Mid		2025-06-28
PL1Fcbz-YuHWIfcAoGKuLCq8SsgZQhvJC2	UC65QddVO1zGnePbcoQKJzXw	1	How to Visage Mid		2025-06-28
PL1Fcbz-YuHWLbnwo_XcNGUgNISRZoc4TS	UC65QddVO1zGnePbcoQKJzXw	1	How to Sniper Mid		2025-06-28
PL1Fcbz-YuHWJXZYI13QELzPrqJWPVBkhO	UC65QddVO1zGnePbcoQKJzXw	1	How to Alchemist Mid		2025-06-28
PL1Fcbz-YuHWItXU3K-P2fURyVWes9xb6n	UC65QddVO1zGnePbcoQKJzXw	1	How to Troll Warlord Mid		2025-06-28
PL1Fcbz-YuHWJQ20e3hD0P98yQZ42RjWXa	UC65QddVO1zGnePbcoQKJzXw	1	How to Clinkz Mid		2025-06-28
PL1Fcbz-YuHWIt4UiKD3_Q1R6Vy6mSswJe	UC65QddVO1zGnePbcoQKJzXw	1	How to Beastmaster Mid		2025-06-28
PL1Fcbz-YuHWJ5qS5nPtiX5KgsMT6dDsh-	UC65QddVO1zGnePbcoQKJzXw	1	How to Lycan Mid		2025-06-28
PL1Fcbz-YuHWIXsS7m_oL_z1vuf1XSrX6L	UC65QddVO1zGnePbcoQKJzXw	1	How to Riki Mid		2025-06-28
PL1Fcbz-YuHWKLTPPX_gtbbSI1Z8klSArc	UC65QddVO1zGnePbcoQKJzXw	1	How to Grimstroke Mid		2025-06-28
PL1Fcbz-YuHWKU7lH0f0bQxNhKRXzFcpcT	UC65QddVO1zGnePbcoQKJzXw	1	How to Mars Mid		2025-06-28
PL1Fcbz-YuHWJ0W1mEqA-47_-CIM_nytYu	UC65QddVO1zGnePbcoQKJzXw	1	How to Viper Mid		2025-06-28
PL1Fcbz-YuHWKRgLDFXe4f9-UGYGjoX1LH	UC65QddVO1zGnePbcoQKJzXw	1	How to Puck Mid		2025-06-28
PL1Fcbz-YuHWIDnIUsD_8Sjsp4WSEt1_D8	UC65QddVO1zGnePbcoQKJzXw	1	How to Outworld Devourer Mid		2025-06-28
PL1Fcbz-YuHWJcWrbjpwhTIql90_LGB0jh	UC65QddVO1zGnePbcoQKJzXw	1	How to Skywrath Mage Mid		2025-06-28
PL1Fcbz-YuHWI1tm1xaIByQvQD_S_661vi	UC65QddVO1zGnePbcoQKJzXw	1	How to Timbersaw Mid		2025-06-28
PL1Fcbz-YuHWIg-7UjgBqHRrN9qBCwJ2Up	UC65QddVO1zGnePbcoQKJzXw	1	How to Morphling Mid		2025-06-28
PL1Fcbz-YuHWL03IlRTNr9QrutIGHo-1yr	UC65QddVO1zGnePbcoQKJzXw	1	How to Death Prophet Mid		2025-06-28
PL1Fcbz-YuHWIfREXnXJBo0HJ5woy-a4zo	UC65QddVO1zGnePbcoQKJzXw	1	How to Broodmother Mid		2025-06-28
PL1Fcbz-YuHWJbybheJwMjMsZWop40LTAh	UC65QddVO1zGnePbcoQKJzXw	1	How to Kunkka Mid		2025-06-28
PL1Fcbz-YuHWIIYcRWN4YmtujzxSZ2CuaJ	UC65QddVO1zGnePbcoQKJzXw	1	How to Tinker Mid		2025-06-28
PL1Fcbz-YuHWJIg5i9SZ9YXkfUxfbqIxCf	UC65QddVO1zGnePbcoQKJzXw	1	How to Snapfire Mid		2025-06-28
PL1Fcbz-YuHWLGm9_qZZC_SzuJJp493_by	UC65QddVO1zGnePbcoQKJzXw	1	How to Monkey King Mid		2025-06-28
PL1Fcbz-YuHWLPEeaOVM_mOYEDkgEK52_5	UC65QddVO1zGnePbcoQKJzXw	1	How to Pugna Mid		2025-06-28
PL1Fcbz-YuHWJ_SfVxRozLlkJvJtXOl24K	UC65QddVO1zGnePbcoQKJzXw	1	How to Huskar Mid		2025-06-28
PL1Fcbz-YuHWJQxc6ndT89VZZIvkfCUC7W	UC65QddVO1zGnePbcoQKJzXw	1	How to Doom Mid		2025-06-28
PL1Fcbz-YuHWLMarP24sHQ8gBMsdgORzfo	UC65QddVO1zGnePbcoQKJzXw	1	How to Shadow Fiend Mid		2025-06-28
PL1Fcbz-YuHWI-zhQXBS4axRMzCGc5rd5Y	UC65QddVO1zGnePbcoQKJzXw	1	How to Arc Warden Mid		2025-06-28
PL1Fcbz-YuHWJqUYNOdvxd53TZYXQb_0gR	UC65QddVO1zGnePbcoQKJzXw	1	How to Ember Spirit Mid		2025-06-28
PL1Fcbz-YuHWLhPzBDwsuwuqOzB9e7jNHs	UC65QddVO1zGnePbcoQKJzXw	1	How to Phoenix Mid		2025-06-28
PL1Fcbz-YuHWInOZJ70H3XRLIvx3776SZz	UC65QddVO1zGnePbcoQKJzXw	1	How to Windranger Mid		2025-06-28
PL1Fcbz-YuHWIgpWxYyJx87ULrZr7to2-W	UC65QddVO1zGnePbcoQKJzXw	1	How to Leshrac Mid		2025-06-28
PL1Fcbz-YuHWJOMnQ3lCjwxbqlMQIrI7dc	UC65QddVO1zGnePbcoQKJzXw	1	How to Templar Assassin Mid		2025-06-28
PL1Fcbz-YuHWJ4fv4joaNR2l1ze7ng_WQ6	UC65QddVO1zGnePbcoQKJzXw	1	How to Pangolier Mid		2025-06-28
PL1Fcbz-YuHWISp-LJFqLpq1wDBYy4r9D2	UC65QddVO1zGnePbcoQKJzXw	1	How to Batrider Mid		2025-06-28
PL1Fcbz-YuHWI77sAWVAUmOm6vx7w6V1BR	UC65QddVO1zGnePbcoQKJzXw	1	How to Zeus Mid		2025-06-28
PL1Fcbz-YuHWLEft4UGOJ02inIT8rkcAWs	UC65QddVO1zGnePbcoQKJzXw	1	How to Void Spirit Mid		2025-06-28
PL1Fcbz-YuHWLrZ2IUECIs0_SHdUz4ixVn	UC65QddVO1zGnePbcoQKJzXw	1	How to Tiny Mid		2025-06-28
PL1Fcbz-YuHWLwLlIzknTci8SM8_6W3Q1n	UC65QddVO1zGnePbcoQKJzXw	1	How to Storm Spirit Mid		2025-06-28
PL1Fcbz-YuHWITlvoIPRkUwBz2_NYT5Kqg	UC65QddVO1zGnePbcoQKJzXw	1	How to Gyrocopter Mid		2025-06-28
PL1Fcbz-YuHWIrTEWz8nr0SN-h8Qm7o2ku	UC65QddVO1zGnePbcoQKJzXw	1	How to Queen of Pain Mid		2025-06-28
PL1Fcbz-YuHWLI7RNKLvg_-UEKcP8olD93	UC65QddVO1zGnePbcoQKJzXw	1	How to Lina Mid		2025-06-28
PL1Fcbz-YuHWKCIZkaxojiZSZ2r0QWcXjN	UC65QddVO1zGnePbcoQKJzXw	1	How to Magnus Mid		2025-06-28
PL1Fcbz-YuHWLBrIsni2sXlW-cPAWZc4lQ	UC65QddVO1zGnePbcoQKJzXw	1	How to Invoker Mid		2025-06-28
PL1Fcbz-YuHWJh8sVfXpfak9R6RMe_aF5Y	UC65QddVO1zGnePbcoQKJzXw	1	How to Earth Spirit Mid		2025-06-28
PLnX9Ub6VIPMA_Md2MUXSUlIgW0nO4ZJpH	UC0NM4tKT5s9szqnK3jp6dEw	1	PGL WALLACHIA SEASON 5		2025-06-28
PLnX9Ub6VIPMBC4IbT9j9uH1broGXhRfGn	UC0NM4tKT5s9szqnK3jp6dEw	1	EWC 2025 DOTA 2		2025-06-28
PLnX9Ub6VIPMBx9SSIkr_tr-h5nfPUeJth	UC0NM4tKT5s9szqnK3jp6dEw	1	TI14 - THE INTERNATIONAL 2025		2025-06-28
PLnX9Ub6VIPMBhI17PrWMjgskqTiLKQP2y	UC0NM4tKT5s9szqnK3jp6dEw	1	DREAM LEAGUE 26		2025-06-28
PLnX9Ub6VIPMDtqv24mu0mPTJ21MSetALD	UC0NM4tKT5s9szqnK3jp6dEw	1	FISSURE UNIVERSE 5 PLAYIN		2025-06-28
PLnX9Ub6VIPMARj_1d1zZ2RK0ROpNFQ0Hh	UC0NM4tKT5s9szqnK3jp6dEw	1	BLAST SLAM 3 DOTA 2		2025-06-28
PLnX9Ub6VIPMAONo4oiTEEftp0mRb1BMxW	UC0NM4tKT5s9szqnK3jp6dEw	1	ESL One Raleigh 2025 Dota 2 Rapier		2025-06-28
PLnX9Ub6VIPMAg1BK5CX7Xw5lA6Z-XU6p5	UC0NM4tKT5s9szqnK3jp6dEw	1	FISSURE Special 2025 DOTA 2		2025-06-28
PLnX9Ub6VIPMCIuNJ2dfrTegnTm0AfrrPB	UC0NM4tKT5s9szqnK3jp6dEw	1	DREAMLEAGUE SEASON 26 DOTA 2		2025-06-28
PLnX9Ub6VIPMAvPBXvrM992DuZDvUyAPrX	UC0NM4tKT5s9szqnK3jp6dEw	1	DREAMLEAGUE 25 DOTA 2		2025-06-28
PLnX9Ub6VIPMBF4g_82KYYFH_CzZFD7z5l	UC0NM4tKT5s9szqnK3jp6dEw	1	FISSURE UNIVERSE EPISODE 4 DOTA 2 2025		2025-06-28
PLnX9Ub6VIPMCe8YJlNwDRpDLpFa7Rbf6q	UC0NM4tKT5s9szqnK3jp6dEw	1	PGL WALLACHIA SEASON 4		2025-06-28
PLnX9Ub6VIPMDP5JEzQ60JU5CFrqO15AdL	UC0NM4tKT5s9szqnK3jp6dEw	1	ASIAN DRAGON SERIES DOTA 2		2025-06-28
PLnX9Ub6VIPMBwsNGXiXlgXhUHMBgtGcf6	UC0NM4tKT5s9szqnK3jp6dEw	1	BLAST SLAM 2 DOTA 2		2025-06-28
PLnX9Ub6VIPMCmNBaBSwBnpUs1VrtkfNML	UC0NM4tKT5s9szqnK3jp6dEw	1	ESL ONE RALEIGH 2025 DOTA 2		2025-06-28
PLnX9Ub6VIPMD87CpevrDEdoW-E9xJh21n	UC0NM4tKT5s9szqnK3jp6dEw	1	PGL WALLACHIA SS3		2025-06-28
PLnX9Ub6VIPMCUDBx9jl-NZFpfg1D23by7	UC0NM4tKT5s9szqnK3jp6dEw	1	DREAMLEAGUE SEASON 25		2025-06-28
PLnX9Ub6VIPMDVWvF4lo-wb_ZRals94zMQ	UC0NM4tKT5s9szqnK3jp6dEw	1	MESA Invitational 2024 DOTA 2		2025-06-28
PLnX9Ub6VIPMDHhRPjeQQs1cnQZZVKvx6n	UC0NM4tKT5s9szqnK3jp6dEw	1	BLAST SLAM 1 DOTA 2		2025-06-28
PLnX9Ub6VIPMCLSJem-4cHiH-OuicRNGeG	UC0NM4tKT5s9szqnK3jp6dEw	1	1WIN SERIES FALL 2024		2025-06-28
PLnX9Ub6VIPMBXhqkF_m287u7V4F2pIcEA	UC0NM4tKT5s9szqnK3jp6dEw	1	ESL ONE BANGKOK 2024 DOTA 2		2025-06-28
PLnX9Ub6VIPMCXLrc4oArB0-TZsrpge2qk	UC0NM4tKT5s9szqnK3jp6dEw	1	DREAM LEAGUE ss24 2024 DOTA 2		2025-06-28
PLnX9Ub6VIPMAzXGmOhCulQOZG40ChSRKQ	UC0NM4tKT5s9szqnK3jp6dEw	1	WALLACHIA 2024 DOTA 2		2025-06-28
PLnX9Ub6VIPMBNlEv0a0-kt5h3WGtMI_Hm	UC0NM4tKT5s9szqnK3jp6dEw	1	BetBoom Dacha Belgrade 2024 Dota 2		2025-06-28
PLnX9Ub6VIPMCzWYtHPhTZVL7FOEk0zQcV	UC0NM4tKT5s9szqnK3jp6dEw	1	TI13 DOTA THE INTERNATIONAL 2024		2025-06-28
PLnX9Ub6VIPMDgx4sYRLE7hTAS1-aQawem	UC0NM4tKT5s9szqnK3jp6dEw	1	CCT SERIES 3		2025-06-28
PLnX9Ub6VIPMBoLbFlbA_EQYkXxb0VktLV	UC0NM4tKT5s9szqnK3jp6dEw	1	FISSURE UNIVERSE EPISODE 3 DOTA 2		2025-06-28
PLnX9Ub6VIPMA0QXPT5PkS43C_mUUr1STg	UC0NM4tKT5s9szqnK3jp6dEw	1	CLAVISION SNOW RUYI DOTA 2		2025-06-28
PLnX9Ub6VIPMDiJP6Dbl3ha5Wmhk98GPK-	UC0NM4tKT5s9szqnK3jp6dEw	1	ELITE LEAGUE SEASON DOTA 2		2025-06-28
PLnX9Ub6VIPMCZ6fUx2V_m4o5GF_eeHx9i	UC0NM4tKT5s9szqnK3jp6dEw	1	RES REGIONAL SERIES 2024 DOTA 2		2025-06-28
PLnX9Ub6VIPMD1_LXzJO_9ifTAeuv_EMYr	UC0NM4tKT5s9szqnK3jp6dEw	1	EPL World Series		2025-06-28
PLnX9Ub6VIPMDJ5vFU1Wzps8DjwvcqfwfG	UC0NM4tKT5s9szqnK3jp6dEw	1	Riyadh Master 2024 Dota 2		2025-06-28
PLnX9Ub6VIPMBgy6BjzjPtN9FNPYXzoBXs	UC0NM4tKT5s9szqnK3jp6dEw	1	1win Series Dota 2 Summer		2025-06-28
PLnX9Ub6VIPMBqfIqwmeaX2NYvwvBmk8uz	UC0NM4tKT5s9szqnK3jp6dEw	1	TI13 CLOSED QUALIFIER		2025-06-28
PLnX9Ub6VIPMAVtaK0oXIZAF_7FY4io9DD	UC0NM4tKT5s9szqnK3jp6dEw	1	RES Regional Series: SEA #3		2025-06-28
PLnX9Ub6VIPMDMEQSI9SdKz5e6u0625bVN	UC0NM4tKT5s9szqnK3jp6dEw	1	TI 13 THE INTERNATIONAL 2014 OPEN QUALIFIER		2025-06-28
PLnX9Ub6VIPMCxP5I-LpuWRe6t7XeLXMoR	UC0NM4tKT5s9szqnK3jp6dEw	1	ELITE LEAGUE DOTA 2		2025-06-28
PLnX9Ub6VIPMD5YhthmWYVoCMZy_msBEwl	UC0NM4tKT5s9szqnK3jp6dEw	1	1win Series Dota 2 Spring		2025-06-28
PLnX9Ub6VIPMDXwgaa1X04EJ5Uk9l8K0_E	UC0NM4tKT5s9szqnK3jp6dEw	1	ELITE LEAGUE DOTA 2024		2025-06-28
PLnX9Ub6VIPMDs30gtFVPQ6MQmLmIDn8J_	UC0NM4tKT5s9szqnK3jp6dEw	1	GAMES OF THE FUTURE 2024 DOTA 2		2025-06-28
PLnX9Ub6VIPMDSeYN7j8VnweP9jeymV0WC	UC0NM4tKT5s9szqnK3jp6dEw	1	EPL SEASON 16 DOTA		2025-06-28
PLnX9Ub6VIPMAbWoiQxa5S4nJpNx3Aq31o	UC0NM4tKT5s9szqnK3jp6dEw	1	BetBoom Dacha Dubai 2024		2025-06-28
PLnX9Ub6VIPMArEK_K0Kr8LRTFmTW7oWU3	UC0NM4tKT5s9szqnK3jp6dEw	1	Pinnacle: 25 Year Anniversary Show		2025-06-28
PLnX9Ub6VIPMAG8YbvFWESYce0KDT-r8ur	UC0NM4tKT5s9szqnK3jp6dEw	1	TI12 - THE INTERNATIONAL 2023 Dota 2		2025-06-28
PLnX9Ub6VIPMD0B58SwLNqCNaVfTTMr4Ze	UC0NM4tKT5s9szqnK3jp6dEw	1	BETBOOM DACHA 2023		2025-06-28
PLnX9Ub6VIPMBPZhSuS7nHpDvJ8YGOh3sM	UC0NM4tKT5s9szqnK3jp6dEw	1	BETBOOM DACHA 2023		2025-06-28
PLnX9Ub6VIPMB7ksHaqtsdkYMpWMN0Rhf3	UC0NM4tKT5s9szqnK3jp6dEw	1	BALIMAJOR 2023		2025-06-28
PLnX9Ub6VIPMA7Fuv6kfpZjohtgRc0KMTd	UC0NM4tKT5s9szqnK3jp6dEw	1	DREAMLEAGUE SEASON 20 2023		2025-06-28
PLnX9Ub6VIPMCxSIVo0r_w6uFJiyfXlGwC	UC0NM4tKT5s9szqnK3jp6dEw	1	SA DPC SUMMER TOUR 2023 DOTA 2		2025-06-28
PLnX9Ub6VIPMCZmZM4_vmVLiV5QTW7jbKm	UC0NM4tKT5s9szqnK3jp6dEw	1	SUMMER TOUR 2023 DOTA 2		2025-06-28
PLnX9Ub6VIPMCQjQdNe27uwL5BYQuQBTYx	UC0NM4tKT5s9szqnK3jp6dEw	1	SEA DPC SUMMER TOUR 2023 DOTA		2025-06-28
PLnX9Ub6VIPMBLr_4ppYmIEYTxnCS9EFWv	UC0NM4tKT5s9szqnK3jp6dEw	1	Pinnacle Cup: Malta Vibes #1		2025-06-28
PLnX9Ub6VIPMCH3tBJ8_yBo2pk7XXRGyCV	UC0NM4tKT5s9szqnK3jp6dEw	1	SA DPC SPRING TOUR 2023 DOTA		2025-06-28
PLnX9Ub6VIPMC22S6aKTHTGfzR1ymBKBHw	UC0NM4tKT5s9szqnK3jp6dEw	1	EEU DPC SPRING TOUR 2023 DOTA		2025-06-28
PLnX9Ub6VIPMC5TOxcDUdfHh4KNdSOK_6Y	UC0NM4tKT5s9szqnK3jp6dEw	1	CHINA DPC SPRING TOUR 2023 DOTA		2025-06-28
PLnX9Ub6VIPMBpAn6wYlTiBgKjMnkRdBLQ	UC0NM4tKT5s9szqnK3jp6dEw	1	WEU DPC SPRING TOUR 2023 DOTA		2025-06-28
PLnX9Ub6VIPMDKR3olS9hsUNvFwHQnQ0mX	UC0NM4tKT5s9szqnK3jp6dEw	1	SEA DPC SPRING TOUR 2023 DOTA		2025-06-28
PLnX9Ub6VIPMDwTUwhgj5v5KfqsSYG9c4_	UC0NM4tKT5s9szqnK3jp6dEw	1	7.32 DOTA UPDATE		2025-06-28
PLnX9Ub6VIPMBqR-7aiZUQ8UXvIzOIGVXa	UC0NM4tKT5s9szqnK3jp6dEw	1	LIMA MAJOR DOTA 2 RAPIER		2025-06-28
PLnX9Ub6VIPMC8ta3HaMq2cDmaMPIUg4bM	UC0NM4tKT5s9szqnK3jp6dEw	1	OLD G Dota 2		2025-06-28
PLnX9Ub6VIPMD8krQNYtDqb4IGomXnKlLX	UC0NM4tKT5s9szqnK3jp6dEw	1	Tundra.NINE TI11 Winner		2025-06-28
PLnX9Ub6VIPMA8hzh1DGukmWU9SP7Kc4fS	UC0NM4tKT5s9szqnK3jp6dEw	1	TI11 MAIN EVENT DOTA 2		2025-06-28
PLnX9Ub6VIPMCDYBcIWegtiZeP6MgA1HCd	UC0NM4tKT5s9szqnK3jp6dEw	1	TI11 - THE INTERNATIONAL 2022		2025-06-28
PLnX9Ub6VIPMA0L_es3DdTFBD679-wUfH3	UC0NM4tKT5s9szqnK3jp6dEw	1	The International 2022: Eastern Europe Qualifier		2025-06-28
PLnX9Ub6VIPMCb37Tf4WKS6yJTD8uBlU79	UC0NM4tKT5s9szqnK3jp6dEw	1	7.32 Dota Gameplay		2025-06-28
PLnX9Ub6VIPMD7Fk290mO_4-86N1XWOTcp	UC0NM4tKT5s9szqnK3jp6dEw	1	Riyadh Masters 2022 - All Match with Dota 2 Rapier		2025-06-28
PLnX9Ub6VIPMBdm9VnaijKl6XsTwSySsJJ	UC0NM4tKT5s9szqnK3jp6dEw	1	7.31d Patch Dota Gameplay		2025-06-28
PLnX9Ub6VIPMC1qTa8gSdE8ODl_y9LYk2V	UC0NM4tKT5s9szqnK3jp6dEw	1	Yopaj Mid MVP of BOOM Esport		2025-06-28
PLnX9Ub6VIPMAQBSl7aQaTnrhdSA9ynI0U	UC0NM4tKT5s9szqnK3jp6dEw	1	GAMERS GALAXY: Invitational Series Dubai 2022 Dota Highlights		2025-06-28
PLnX9Ub6VIPMBjk6-GDsrudCuUTyhqwqaT	UC0NM4tKT5s9szqnK3jp6dEw	1	7.31 Dota Patch		2025-06-28
PLnX9Ub6VIPMC1nvYd-AivI_mo_JtXk6Ym	UC0NM4tKT5s9szqnK3jp6dEw	1	Yuragi Dota Prodigy Carry		2025-06-28
PLnX9Ub6VIPMA4e1oEQ4AleJsOzAu0BxOE	UC0NM4tKT5s9szqnK3jp6dEw	1	Collapse GOD		2025-06-28
PLnX9Ub6VIPMBOLrp-ZHtQjmHuonNc9jvD	UC0NM4tKT5s9szqnK3jp6dEw	1	OG.ATF the BEST Timbersaw		2025-06-28
PLnX9Ub6VIPMAleuoWmkFz6WOlqodAf0z5	UC0NM4tKT5s9szqnK3jp6dEw	1	OG.Bizem 16yo Prodigy		2025-06-28
PLnX9Ub6VIPMCmBxP882a-LWSAgYtSxjOc	UC0NM4tKT5s9szqnK3jp6dEw	1	Hansha 16yo Prodigy		2025-06-28
PLnX9Ub6VIPMBPdOtZQ6n8cguRpV5nCzmc	UC0NM4tKT5s9szqnK3jp6dEw	1	TORONTOTOKYO TI10 Winner		2025-06-28
PLnX9Ub6VIPMBOOSkNUnROmG711nHoRpcd	UC0NM4tKT5s9szqnK3jp6dEw	1	7.30e Dota		2025-06-28
PLnX9Ub6VIPMAlC0ibMPssFlRtff-8M8l4	UC0NM4tKT5s9szqnK3jp6dEw	1	Marci Dota 2 Higlights		2025-06-28
PLnX9Ub6VIPMA3Rf_9oG0Dq-gmgGMi6Qs_	UC0NM4tKT5s9szqnK3jp6dEw	1	Yatoro - TI10 Winner		2025-06-28
PLnX9Ub6VIPMA9KX4MYnsrOuAOwFz24T-f	UC0NM4tKT5s9szqnK3jp6dEw	1	TI10 MAIN EVENT		2025-06-28
PLnX9Ub6VIPMBpdPIrEB6WfeVpl_ufHCcl	UC0NM4tKT5s9szqnK3jp6dEw	1	TI10 Day 4 - Dota 2		2025-06-28
PLnX9Ub6VIPMDkH0VSr3muTHjC1bwr1YVd	UC0NM4tKT5s9szqnK3jp6dEw	1	EG Dota TI10		2025-06-28
PLnX9Ub6VIPMBkrb9fwXyfnrfYb91bsuLc	UC0NM4tKT5s9szqnK3jp6dEw	1	OG TI10 - Dota 2		2025-06-28
PLnX9Ub6VIPMBFEmzhc4Uj_YCvH7he3Nyq	UC0NM4tKT5s9szqnK3jp6dEw	1	TI10 Day 2 - THE INTERNATIONAL 2021		2025-06-28
PLnX9Ub6VIPMC2SqhjFrskpx4Vt74SnNBF	UC0NM4tKT5s9szqnK3jp6dEw	1	GPK Top 1 Immortal		2025-06-28
PLnX9Ub6VIPMB8lVglheDLdpW3oiS6c6di	UC0NM4tKT5s9szqnK3jp6dEw	1	7.30 DOTA PATCH		2025-06-28
PLnX9Ub6VIPMCYBR90mepVsgNf9Ws5R4EH	UC0NM4tKT5s9szqnK3jp6dEw	1	OG.SAKSA Dota 2		2025-06-28
PLnX9Ub6VIPMALn91YvKZgX5yd7KcUN5IR	UC0NM4tKT5s9szqnK3jp6dEw	1	CEB and THE CALL OF HIS LIFE!		2025-06-28
PLnX9Ub6VIPMCraGTPxzxxgEABcOnqSUEC	UC0NM4tKT5s9szqnK3jp6dEw	1	iLTW the MASTER Tier		2025-06-28
PLnX9Ub6VIPMA81PtPxpW-kMumUM4PcqWx	UC0NM4tKT5s9szqnK3jp6dEw	1	Topson 2 TI Winner		2025-06-28
PLnX9Ub6VIPMDZ8O5Ums8rhdmkrXN6b2qb	UC0NM4tKT5s9szqnK3jp6dEw	1	Raven Filipino professional Dota 2		2025-06-28
PLnX9Ub6VIPMBGOeujP6xgMCLGfmqTkJFg	UC0NM4tKT5s9szqnK3jp6dEw	1	23SAVAGE 13000 MMR PLAYER		2025-06-28
PLnX9Ub6VIPMB_mugd66t37K0tNOgTrh0L	UC0NM4tKT5s9szqnK3jp6dEw	1	Nikobaby full Tattoo DotA Player		2025-06-28
PLnX9Ub6VIPMD6Ue9byN7QKxkf6F01VF2J	UC0NM4tKT5s9szqnK3jp6dEw	1	DOTA 2 TI10 - THE INTERNATIONAL 2021		2025-06-28
PLnX9Ub6VIPMDsErw5VZGjshLdQkxHuiLQ	UC0NM4tKT5s9szqnK3jp6dEw	1	NIGMA.iLTW Dota 2		2025-06-28
PLnX9Ub6VIPMAqqztAF-DUGTWe9Tqcm43v	UC0NM4tKT5s9szqnK3jp6dEw	1	Nigma players Dota 2		2025-06-28
PLnX9Ub6VIPMCrFoe0pr4kyJVpM1wSwH1k	UC0NM4tKT5s9szqnK3jp6dEw	1	Kuala Lumpur Major 2018		2025-06-28
PLnX9Ub6VIPMAVtIGim7IcdR8V0apfCv0w	UC0NM4tKT5s9szqnK3jp6dEw	1	TI8 - THE INTERNATIONAL 2018		2025-06-28
PLnX9Ub6VIPMDub8h03EaDMVmx_Y6d4o5b	UC0NM4tKT5s9szqnK3jp6dEw	1	THE INTERNATIONAL 2018		2025-06-28
PLnX9Ub6VIPMAyYHVIh2t8D1jew1ITIj7r	UC0NM4tKT5s9szqnK3jp6dEw	1	THE INTERNATIONAL 2018		2025-06-28
PLnX9Ub6VIPMBTvOH8ZCOJV5cN3OFQfz_v	UC0NM4tKT5s9szqnK3jp6dEw	1	EG - Evil Geniuses		2025-06-28
PLnX9Ub6VIPMDbH7eetWsO_PbTIvS-yVmr	UC0NM4tKT5s9szqnK3jp6dEw	1	Dota 2 7.16 Patch		2025-06-28
PLnX9Ub6VIPMCleafqEGfAJo6RLhX_ZS90	UC0NM4tKT5s9szqnK3jp6dEw	1	Dota 2 7.15 New Patch		2025-06-28
PLnX9Ub6VIPMBpwKNOHMdBz72rEz6CCdYC	UC0NM4tKT5s9szqnK3jp6dEw	1	DOTA EPICENTER XL 2018		2025-06-28
PLnX9Ub6VIPMDm3AYMxGxe6csKiF9-H2q-	UC0NM4tKT5s9szqnK3jp6dEw	1	Dota 2 7.14 New Patch		2025-06-28
PLnX9Ub6VIPMCnVQPYhO41I4VciF-GcC1u	UC0NM4tKT5s9szqnK3jp6dEw	1	Dota 2 7.13b		2025-06-28
PLnX9Ub6VIPMDiutR6wlpgjCUAV9nPkCtJ	UC0NM4tKT5s9szqnK3jp6dEw	1	Dota 2 7.12		2025-06-28
PLnX9Ub6VIPMCFdCHI_lG0pOWVqmLA9o2t	UC0NM4tKT5s9szqnK3jp6dEw	1	Dota 2 7.11		2025-06-28
PLnX9Ub6VIPMDpkhS_kMcDXa8ToAZhcWpj	UC0NM4tKT5s9szqnK3jp6dEw	1	Dota 2 7.10		2025-06-28
PLnX9Ub6VIPMAMXVtlUjZjA-vQrXeDEBUc	UC0NM4tKT5s9szqnK3jp6dEw	1	IceIceIce - 冰冰冰		2025-06-28
PLnX9Ub6VIPMD45VB4Q2RCL1OGmZoRShVv	UC0NM4tKT5s9szqnK3jp6dEw	1	DOTA 2 Bucharest Major 2018		2025-06-28
PLnX9Ub6VIPMA6cPvSo2c14_dusU9Zu76-	UC0NM4tKT5s9szqnK3jp6dEw	1	Mind_ControL		2025-06-28
PLnX9Ub6VIPMDBgpRwm4VC29ei4h4pI0FY	UC0NM4tKT5s9szqnK3jp6dEw	1	Dota Rampage Moment		2025-06-28
PLnX9Ub6VIPMBeiIKOr0x8O1GnSog9DoRv	UC0NM4tKT5s9szqnK3jp6dEw	1	BurNIng Best Antimage		2025-06-28
PLnX9Ub6VIPMDRE62ps9c09nD3Qt9CV4cX	UC0NM4tKT5s9szqnK3jp6dEw	1	No[O]ne-		2025-06-28
PLnX9Ub6VIPMC-BpybZhW3yDa6DYGQl40c	UC0NM4tKT5s9szqnK3jp6dEw	1	Dota 7.07 Dueling Fates Update		2025-06-28
PLnX9Ub6VIPMCGX18dEXlG-L0FYrb604fr	UC0NM4tKT5s9szqnK3jp6dEw	1	Team Liquid		2025-06-28
PLnX9Ub6VIPMDMoAOkW1YZbhumnz9yhglN	UC0NM4tKT5s9szqnK3jp6dEw	1	Burning The Best Anti-Mage		2025-06-28
PLnX9Ub6VIPMADbM4aYmMTLeoTwPG4mrij	UC0NM4tKT5s9szqnK3jp6dEw	1	Miracle- Stream Videos		2025-06-28
PLnX9Ub6VIPMDJyUbL2G69T5CaBG_ZLhBC	UC0NM4tKT5s9szqnK3jp6dEw	1	Ti7 - The International 2017 - Dota 2		2025-06-28
PLnX9Ub6VIPMA6B1u1ZSzlRF1yfSz2-F9c	UC0NM4tKT5s9szqnK3jp6dEw	1	Paparazi Best Solo Mid Player		2025-06-28
PLnX9Ub6VIPMDay_4LdtzadeSfeqSgOJdF	UC0NM4tKT5s9szqnK3jp6dEw	1	InYourdreaM the first 9k In SEA		2025-06-28
PLnX9Ub6VIPMAu058D-uE-Nm3QCEvki5wo	UC0NM4tKT5s9szqnK3jp6dEw	1	Sumiya - The Best China Invoker Player		2025-06-28
PLnX9Ub6VIPMCwIcrEyQtmncyLtT31dt8U	UC0NM4tKT5s9szqnK3jp6dEw	1	MATUMBAMAN		2025-06-28
PLnX9Ub6VIPMDDnkEhMgVo_0gbYLBON79t	UC0NM4tKT5s9szqnK3jp6dEw	1	Gh god		2025-06-28
PLnX9Ub6VIPMA7sE2udJyDJnJWwFggM99e	UC0NM4tKT5s9szqnK3jp6dEw	1	Ana Dota		2025-06-28
PLnX9Ub6VIPMA_2F1LLMpE1FKCCH0ppb_o	UC0NM4tKT5s9szqnK3jp6dEw	1	SumaiL		2025-06-28
PLnX9Ub6VIPMBopt_p9zJS0LpJt02zYB9x	UC0NM4tKT5s9szqnK3jp6dEw	1	Arteezy Babyrage		2025-06-28
PLnX9Ub6VIPMAB44dFenywQYuSjjdLSl1B	UC0NM4tKT5s9szqnK3jp6dEw	1	Puppey		2025-06-28
PLnX9Ub6VIPMChpeS1rZUnS3lnXmLgRpwZ	UC0NM4tKT5s9szqnK3jp6dEw	1	Yaphets		2025-06-28
PLnX9Ub6VIPMCxXh1CTVm6FlO9yd604Xm5	UC0NM4tKT5s9szqnK3jp6dEw	1	Crit		2025-06-28
PLnX9Ub6VIPMCil8edBmCmqU2XlL7HXtzu	UC0NM4tKT5s9szqnK3jp6dEw	1	MidOne		2025-06-28
PLnX9Ub6VIPMAvyE1WQLNZwiclmBN1J7Ca	UC0NM4tKT5s9szqnK3jp6dEw	1	Live Archive Videos		2025-06-28
PLnX9Ub6VIPMBCIEdJIvTENj2BG6rrrN0W	UC0NM4tKT5s9szqnK3jp6dEw	1	The International 6		2025-06-28
PLnX9Ub6VIPMB77L6SCo_2qvy7b_WfVGmB	UC0NM4tKT5s9szqnK3jp6dEw	1	Illidan		2025-06-28
PLnX9Ub6VIPMDjJrWtFahIUEStvfdG0vkB	UC0NM4tKT5s9szqnK3jp6dEw	1	BadMan		2025-06-28
PLnX9Ub6VIPMATUzCkGlu7bN2fx3OTRCbE	UC0NM4tKT5s9szqnK3jp6dEw	1	EternaLEnVy		2025-06-28
PLnX9Ub6VIPMCWOPRm3FU1KMf2C3p463RP	UC0NM4tKT5s9szqnK3jp6dEw	1	!Attacker		2025-06-28
PLnX9Ub6VIPMB1awY3pkovMGl-wtV5y0d_	UC0NM4tKT5s9szqnK3jp6dEw	1	S4		2025-06-28
PLnX9Ub6VIPMDXmx2g6kUph4s03QIZOZnj	UC0NM4tKT5s9szqnK3jp6dEw	1	W33		2025-06-28
PLnX9Ub6VIPMDHrQ-Mb_-BaqrMiiwjStLB	UC0NM4tKT5s9szqnK3jp6dEw	1	Meracle		2025-06-28
PLnX9Ub6VIPMAXoXtULMs0XK_ldNfbRtSk	UC0NM4tKT5s9szqnK3jp6dEw	1	KuroKy		2025-06-28
PLnX9Ub6VIPMCp_xswvcgcXzdL9nGkMp4f	UC0NM4tKT5s9szqnK3jp6dEw	1	funn1k		2025-06-28
PLnX9Ub6VIPMCRI5poAJLwoaF4rr9xzhbR	UC0NM4tKT5s9szqnK3jp6dEw	1	Dread		2025-06-28
PLnX9Ub6VIPMCtU3xzUcNxnsSG0I8XhWiX	UC0NM4tKT5s9szqnK3jp6dEw	1	Draskyl		2025-06-28
PLnX9Ub6VIPMAU2MbJD5JfUiPiilSPlIob	UC0NM4tKT5s9szqnK3jp6dEw	1	Black^		2025-06-28
PLnX9Ub6VIPMC_LOT54wpcBNB4AsGXR6wl	UC0NM4tKT5s9szqnK3jp6dEw	1	Wagamama		2025-06-28
PLnX9Ub6VIPMDjexjeYJH0zHbym0DR4poR	UC0NM4tKT5s9szqnK3jp6dEw	1	Merlini		2025-06-28
PLnX9Ub6VIPMCtVYIHD-DkT3JZritLX9xU	UC0NM4tKT5s9szqnK3jp6dEw	1	AdmiralBulldog Come To PaPa Dong		2025-06-28
PLnX9Ub6VIPMDEUL4XBu_kkfAwRvZ4uH0s	UC0NM4tKT5s9szqnK3jp6dEw	1	Miracle-		2025-06-28
PLnX9Ub6VIPMC7lO2IvsxzamUQL8enR9Cr	UC0NM4tKT5s9szqnK3jp6dEw	1	MMR Gameplay		2025-06-28
PLnX9Ub6VIPMBVBqz1xOqYVWivV3W9z4Qk	UC0NM4tKT5s9szqnK3jp6dEw	1	Dendi Dota 2		2025-06-28
PLnX9Ub6VIPMD6S_Q0wOh8QTGv6Iwin45Q	UC0NM4tKT5s9szqnK3jp6dEw	1	Black - Team Tinker		2025-06-28
PLnX9Ub6VIPMCouo_7zgfR4S1uuGpND5XM	UC0NM4tKT5s9szqnK3jp6dEw	1	SingSing Funny Player		2025-06-28
PL5pSpxVDhiJRhY6nm51dOQzhOrp1X5qch	UClC3oNbnI-zYTOWuyfmfNpg	1	Topson		2025-06-28
PL5pSpxVDhiJQhOUp3TRv1FzVdKlNqWGaM	UClC3oNbnI-zYTOWuyfmfNpg	1	Gorgc		2025-06-28
PL5pSpxVDhiJR1fZS24TMPOMu50fTqe8hl	UClC3oNbnI-zYTOWuyfmfNpg	1	Qojqva		2025-06-28
PLhKrxBPJDk9TMs4eXdW5ZrdiFhn22JGAk	UCCMnUQ2whiAs2xZDPFECMuQ	1	DreamLeague Season 21 2023		2025-06-28
PLhKrxBPJDk9QKhPe34zNXGan-TAJi7Poh	UCCMnUQ2whiAs2xZDPFECMuQ	1	The International 12 - Regional Qual.		2025-06-28
PLhKrxBPJDk9TIkCzgZS9sxlNm-1X-kc0c	UCCMnUQ2whiAs2xZDPFECMuQ	1	BetBoom Dacha 2023		2025-06-28
PLhKrxBPJDk9Tyf5rR6XPmp0Xp7XEC1DOe	UCCMnUQ2whiAs2xZDPFECMuQ	1	Riyadh Masters 2023		2025-06-28
PLhKrxBPJDk9QGvtWV-ezoxRMXuz6S145X	UCCMnUQ2whiAs2xZDPFECMuQ	1	The International 11		2025-06-28
PLhKrxBPJDk9SkMJbeBNykvPayLEzF55wf	UCCMnUQ2whiAs2xZDPFECMuQ	1	The International 10		2025-06-28
PLhKrxBPJDk9QVf0ussDTDN5sxBOX9Iz5D	UCCMnUQ2whiAs2xZDPFECMuQ	1	Shorts		2025-06-28
PLhKrxBPJDk9TQWjJTD21-aUI-TNOr5spo	UCCMnUQ2whiAs2xZDPFECMuQ	1	Hard Support/Support/Pos 5		2025-06-28
PLhKrxBPJDk9QO6Gp0Cw8dRtfDL_bSbrwC	UCCMnUQ2whiAs2xZDPFECMuQ	1	Soft Support/Roam/Pos 4		2025-06-28
PLhKrxBPJDk9Rbm1d2E2FKxrCTFlt3jGce	UCCMnUQ2whiAs2xZDPFECMuQ	1	Offlane/Pos 3		2025-06-28
PLhKrxBPJDk9TE7ZTz1oQlwwp6xy7mqUXe	UCCMnUQ2whiAs2xZDPFECMuQ	1	Mid/Pos 2		2025-06-28
PLhKrxBPJDk9SdCJ92rloadbVWg4Aeydd9	UCCMnUQ2whiAs2xZDPFECMuQ	1	Carry/Hard Carry/Pos 1		2025-06-28
PLCT8gu5vmNWGhfMbNJob2XEam-XmqzxS1	UCbfRmqP0RKbrcYO_3DkC4aw	1	World Cyber Arena 2015		2025-06-28
PLCT8gu5vmNWG5PGI6fahO1ekiO_mqf4ST	UCbfRmqP0RKbrcYO_3DkC4aw	1	JoinDota MLG Pro League Season 2		2025-06-28
PLCT8gu5vmNWGGnec8W1xhzkON4lqHC6Ag	UCbfRmqP0RKbrcYO_3DkC4aw	1	The International 2015		2025-06-28
PLCT8gu5vmNWGWED-erYLNagvnle7avIoa	UCbfRmqP0RKbrcYO_3DkC4aw	1	Dream League Season 3		2025-06-28
PLCT8gu5vmNWE1gopQFlNdn4NYFMY7oFGE	UCbfRmqP0RKbrcYO_3DkC4aw	1	Red Bull Battle Grounds		2025-06-28
PLCT8gu5vmNWGFfnOTPD39PcRM7hOkhu7e	UCbfRmqP0RKbrcYO_3DkC4aw	1	I-League Season 3		2025-06-28
PLCT8gu5vmNWGgYZIsV-cEGG09vZaTUwf6	UCbfRmqP0RKbrcYO_3DkC4aw	1	ESL One Frankfurt 2015		2025-06-28
PLCT8gu5vmNWF5cl4g0ZWb8EICn7hlA_l8	UCbfRmqP0RKbrcYO_3DkC4aw	1	Major All Stars Tournament		2025-06-28
PLCT8gu5vmNWGNQ-4zrkLTaOdcX4gO6bAP	UCbfRmqP0RKbrcYO_3DkC4aw	1	Starladder Season 12		2025-06-28
PLCT8gu5vmNWGJ_xI5W_qIeq_BCFArEN4J	UCbfRmqP0RKbrcYO_3DkC4aw	1	Dota 2 Champions League Season 5		2025-06-28
PLCT8gu5vmNWEI-ZwoTgRgreCOpVjBV289	UCbfRmqP0RKbrcYO_3DkC4aw	1	The Summit 3		2025-06-28
PLCT8gu5vmNWG62NWXAjyZ-RgFK9XZ2usA	UCbfRmqP0RKbrcYO_3DkC4aw	1	Dota Pit Season 3		2025-06-28
PLCT8gu5vmNWGrphV1d_dqr9BlEqptb8z3	UCbfRmqP0RKbrcYO_3DkC4aw	1	JoinDota MLG Pro League Season 1		2025-06-28
PLCT8gu5vmNWH9KLIQ_wtJ0wvjObadDjQO	UCbfRmqP0RKbrcYO_3DkC4aw	1	Asia Championship 2015		2025-06-28
PLCT8gu5vmNWFq2EwQ4RFJcNXiTQ8_Fk7_	UCbfRmqP0RKbrcYO_3DkC4aw	1	I-Legaue Season 2		2025-06-28
PLCT8gu5vmNWEk8EbGRpP0el_-Q2djjD1m	UCbfRmqP0RKbrcYO_3DkC4aw	1	G-League 2014		2025-06-28
PLCT8gu5vmNWE_9FwwDSTJQitBbCAOJC7H	UCbfRmqP0RKbrcYO_3DkC4aw	1	StarLadder Season 11		2025-06-28
PLCT8gu5vmNWETDHfhT4dj2_036qWyM4o9	UCbfRmqP0RKbrcYO_3DkC4aw	1	HyperX D2L Season 5		2025-06-28
PLCT8gu5vmNWHf6pHjhApft9KJ2yNSI9Z3	UCbfRmqP0RKbrcYO_3DkC4aw	1	The Summit 2		2025-06-28
PLCT8gu5vmNWEAWBynAvj05phpK-5c8k0q	UCbfRmqP0RKbrcYO_3DkC4aw	1	StarLadder Season 10		2025-06-28
PLCT8gu5vmNWEJ2QWn4oTpqf5DgIwcgA86	UCbfRmqP0RKbrcYO_3DkC4aw	1	Excellent Moscow Cup - Season 2		2025-06-28
PLz-osAzOKMGjMmWDiizBLDnaydLDuVIfm	UCV_VKaOKtp_P-a85nk8OAVw	1	The International 2024		2025-06-28
PLz-osAzOKMGjqKdbFEpWcTlOYJpgh-Ix4	UCV_VKaOKtp_P-a85nk8OAVw	1	Shorts		2025-06-28
PLVjJ2_D-FQikhHR_Vx_X2on2nQdFjjIpF	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Dont Let Her In		2025-06-28
PLVjJ2_D-FQinBqMpR4iOG1fRkFclLL_4O	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Selfishness		2025-06-28
PLVjJ2_D-FQimtw9lvVs9k-v7urhaDs273	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Lost in the Desert Abu Fanous		2025-06-28
PLVjJ2_D-FQinzZ-BPTiKJuWJzTkjS2-M3	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Grow A Garden Horror Alpha		2025-06-28
PLVjJ2_D-FQikvCo-P82sTsyspqVn0Tc05	UCPS3VX1sNiPnpPOXb8EBZ-A	1	マイ・ゲーム [MY GAME]		2025-06-28
PLVjJ2_D-FQillOCv68nhPul4KtY_rcbHH	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Gojira Alpha		2025-06-28
PLVjJ2_D-FQikCf15YuKDn6EwXU5mdVGEM	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Jurassic Horror		2025-06-28
PLVjJ2_D-FQimJ2DonKF7K_JPvnJuybCY3	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Escape The Gubby		2025-06-28
PLVjJ2_D-FQiluKDQKbD7cNMbhWJHrSILx	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Isabelle Horror		2025-06-28
PLVjJ2_D-FQilP9p697Vy0cQOmSgnOBdPz	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Labubu Horror		2025-06-28
PLVjJ2_D-FQimOZZwt5ZjwHOAldrB8dSz4	UCPS3VX1sNiPnpPOXb8EBZ-A	1	99 Nights In The Forest		2025-06-28
PLVjJ2_D-FQimjPkDoqLnvxDPsdFAnohfz	UCPS3VX1sNiPnpPOXb8EBZ-A	1	The Butchery		2025-06-28
PLVjJ2_D-FQimagrmrnf-uGvAWxoifymvE	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Night Shift		2025-06-28
PLVjJ2_D-FQimJjiQhfFsBhtmEtQ1PIEuL	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Anime Rails Alpha		2025-06-28
PLVjJ2_D-FQimqEarQsX_DFIwBUF2FcJN_	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Break The Prison		2025-06-28
PLVjJ2_D-FQikGA1WeBJhLC4_j_ETAreiq	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Nyctophobia [Alpha]		2025-06-28
PLVjJ2_D-FQinGnQUBQ6LBozM7NE1ooy1E	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Locked In		2025-06-28
PLVjJ2_D-FQilfDdqt_M0hhcZF0vgjjIiN	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Lost Toy Factory		2025-06-28
PLVjJ2_D-FQimibDI4fzECxzZwUvWS2W96	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Peta Peta School Of Nightmares		2025-06-28
PLVjJ2_D-FQilvVBabAaTFASXTWZHWYuvM	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Dark Journey Alpha		2025-06-28
PLVjJ2_D-FQimhILO8-mcBztns80b5rIZC	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Silent Countdown		2025-06-28
PLVjJ2_D-FQinOarULaHayGORzkJVYIFBg	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Skinwalkers		2025-06-28
PLVjJ2_D-FQinKh-0S0MrvIiIg6g19DdiN	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Forbidden Hunt		2025-06-28
PLVjJ2_D-FQimJoxsX9RFyGMPmolfddg-7	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Pyscho Horror		2025-06-28
PLVjJ2_D-FQiljzSYlVUwpfp1dOst8AEen	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Survive Overnight in a Mega Store		2025-06-28
PLVjJ2_D-FQilKCGCjR4pKjU2RZ3GsAggJ	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Stitch Horror		2025-06-28
PLVjJ2_D-FQimGAmeTstcOZX4CuhHjnEFx	UCPS3VX1sNiPnpPOXb8EBZ-A	1	AOONI Nightmare		2025-06-28
PLVjJ2_D-FQikA_gXC5qYDdVOo-K5oP27g	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Yeti Ice Village Run		2025-06-28
PLVjJ2_D-FQilWp__1GMwSlFwHQRuSsn3K	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Midnight Fnaf		2025-06-28
PLVjJ2_D-FQilnrHwFXJpVrf0et3TXdC0p	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Three Little Pigs		2025-06-28
PLVjJ2_D-FQilmrGPm23NPLIL-CJ17Uauq	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Dead Planets		2025-06-28
PLVjJ2_D-FQim71fYiTwVX4WAXYmXOE33y	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Dead Spells		2025-06-28
PLVjJ2_D-FQimKZc0IRa_4NANEO5TrJTg-	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Forgetten Wounds		2025-06-28
PLVjJ2_D-FQilqbjgty7caH9Ut1Uj8sAvD	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Sesame Nightmare		2025-06-28
PLVjJ2_D-FQilMoT_1HhesqclknL8_91zS	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Angry Granny		2025-06-28
PLVjJ2_D-FQik3v9yCmHRVygoHc-_t9Peh	UCPS3VX1sNiPnpPOXb8EBZ-A	1	A Mita		2025-06-28
PLVjJ2_D-FQil7yUlKLGW6UlZDgvm3Mbtt	UCPS3VX1sNiPnpPOXb8EBZ-A	1	SpongeBob Horror		2025-06-28
PLVjJ2_D-FQikKN5sV2P-3P_y0HSoSPtcN	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Tralalero Tralala Family Prison Obby		2025-06-28
PLVjJ2_D-FQiltJrHzVgTy8PQXrtsBUbXT	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Tung Sahur		2025-06-28
PLVjJ2_D-FQikLmFSDXVcAMbchLplN0G8h	UCPS3VX1sNiPnpPOXb8EBZ-A	1	School Time Horror		2025-06-28
PLVjJ2_D-FQinSrNR_SzGfjhJz_ImNKIZ9	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Midnight Sprunki		2025-06-28
PLVjJ2_D-FQikqhDk6zgA70l3QYLLAH9Li	UCPS3VX1sNiPnpPOXb8EBZ-A	1	The Panic		2025-06-28
PLVjJ2_D-FQim3XHQLOJodG5A1ek2On4ti	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Sinister Bus		2025-06-28
PLVjJ2_D-FQimFVIFX5humusnhJPx6J_xn	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Gertude Series		2025-06-28
PLVjJ2_D-FQilMy5crexzSQlffpHix0lBM	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Blox Fruits		2025-06-28
PLVjJ2_D-FQikVReITumb0gIyISbr2Ug4F	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Threadville		2025-06-28
PLVjJ2_D-FQimIqBe4BaW3eEuxj9wzxUjA	UCPS3VX1sNiPnpPOXb8EBZ-A	1	The Mimic		2025-06-28
PLVjJ2_D-FQik8T8SDjS3yd4lVLZl0Tngd	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Peta Peta		2025-06-28
PLVjJ2_D-FQik3NnN6uQXRJ5DaRLmPn5X9	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Doors The Foundation Fanmade		2025-06-28
PLVjJ2_D-FQiky2rb8fup27KfBxPhtHDrS	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Rat Stapler		2025-06-28
PLVjJ2_D-FQimMAXq51RzJTvmRRZYdIGLm	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Midnight Family Guy		2025-06-28
PLVjJ2_D-FQil08mODMKV8kBD1jlExEezo	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Break In 2		2025-06-28
PLVjJ2_D-FQik8Fjgm_qr_Sko7IRUzcW9e	UCPS3VX1sNiPnpPOXb8EBZ-A	1	S.E.I.Z.E		2025-06-28
PLVjJ2_D-FQimVh5q3KgL4dKSQKaMHcDqd	UCPS3VX1sNiPnpPOXb8EBZ-A	1	E.R.P.O		2025-06-28
PLVjJ2_D-FQiltgp--uvztfSrX0siN7yaZ	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Crazy Skidlets		2025-06-28
PLVjJ2_D-FQilffuBP-W0RBpZ7UOBetNKL	UCPS3VX1sNiPnpPOXb8EBZ-A	1	SQUID GAME FAMILY PRISON RUN ESCAPE		2025-06-28
PLVjJ2_D-FQikZk81gjEXkpowhaUpLWUeK	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Scary Tails Story		2025-06-28
PLVjJ2_D-FQinFVTH6XhgZPn7pboptlqdm	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Deadly Rails To Canada		2025-06-28
PLVjJ2_D-FQimG9aHl-MUSWXtVAPuFtwRC	UCPS3VX1sNiPnpPOXb8EBZ-A	1	White House		2025-06-28
PLVjJ2_D-FQinjQMi-0YS4wJvDxROhiUYm	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Freaky Gojo		2025-06-28
PLVjJ2_D-FQimRY6xMPLAWjD8bd1zfXvei	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Dead Sail Alpha		2025-06-28
PLVjJ2_D-FQin910QWhtvFoi32-9bqJcKb	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Midnight Flight		2025-06-28
PLVjJ2_D-FQinSCzbWhoXR9hesNzXInODv	UCPS3VX1sNiPnpPOXb8EBZ-A	1	A.O.T.A Pre Alpha		2025-06-28
PLVjJ2_D-FQinENkLd8G35R6gmpD_69BpC	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Midnight Toy Story		2025-06-28
PLVjJ2_D-FQikvWf6oLtex7bvpXf_ZAA-z	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Beyong The Shelf		2025-06-28
PLVjJ2_D-FQinK364cTh1oCkwqDLrE_7Bj	UCPS3VX1sNiPnpPOXb8EBZ-A	1	A Dusty Trip		2025-06-28
PLVjJ2_D-FQila3Q3NlbXkh1pCZwj5TIai	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Mr Mix		2025-06-28
PLVjJ2_D-FQimquHM_w8nXWHUZGyDQMskV	UCPS3VX1sNiPnpPOXb8EBZ-A	1	The Hunt Mega Edition Series		2025-06-28
PLVjJ2_D-FQinO3pgnECS-F3RoHN_ERG4N	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Need More Poops		2025-06-28
PLVjJ2_D-FQik8zhQoBp7CGqllbD7-x0OK	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Midnight Sonic		2025-06-28
PLVjJ2_D-FQimCyUcY-N4OcL7MErsYh5Da	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Dead Rails Alpha		2025-06-28
PLVjJ2_D-FQimc-FopdqqeyQEDsT2t2_9I	UCPS3VX1sNiPnpPOXb8EBZ-A	1	The Armature		2025-06-28
PLVjJ2_D-FQinWuOEDmkL2V3AdJH1z3P6j	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Box Of Horror		2025-06-28
PLVjJ2_D-FQim8re0VJXxct8tQNsZiYPkd	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Garten Of Banban [Re-port]		2025-06-28
PLVjJ2_D-FQikbT_pKeT_yEvJZQBnjhF6p	UCPS3VX1sNiPnpPOXb8EBZ-A	1	The Missing Scientist		2025-06-28
PLVjJ2_D-FQil4v0pIrrhTu_HrsthR-6Px	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Garten Of Poncik		2025-06-28
PLVjJ2_D-FQinauN0Zce6vTbDU53jDtnVg	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Judgement Day		2025-06-28
PLVjJ2_D-FQinyVJVjkBuKny0eBIoDyWf8	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Mega Escape All Series Roblox		2025-06-28
PLVjJ2_D-FQim9PGLQbmwG2BiP-UV3EuHe	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Cute Girl 555		2025-06-28
PLVjJ2_D-FQimr2gQrjr62DllBwubLmvc8	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Emily Horror		2025-06-28
PLVjJ2_D-FQikSG8hJNunlWyPCOG9Mwg9-	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Skipper Roblox Horror Game		2025-06-28
PLVjJ2_D-FQil07AIesmLOoU9TUNW-BtBO	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Mega Escape:Squid Game		2025-06-28
PLVjJ2_D-FQin6kFOzXEbyLMKjCoL_Y2DA	UCPS3VX1sNiPnpPOXb8EBZ-A	1	The Kidnapper Story		2025-06-28
PLVjJ2_D-FQimfgEjz8UzSeCryc4m7UM5U	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Hello Kitty Horror		2025-06-28
PLVjJ2_D-FQik4hdDo8lXMrEmO8hNnKGXd	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Escape Hyperpigmentatio		2025-06-28
PLVjJ2_D-FQimhfc7Vo2COQW4huJeJJuyp	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Sussy Wussy		2025-06-28
PLVjJ2_D-FQilfezdY1e3LVy04bEeO6HhR	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Nightmare Realm		2025-06-28
PLVjJ2_D-FQikLXqDHDiBHznolrNciTk3z	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Midnight Bikini Bottom		2025-06-28
PLVjJ2_D-FQimcrlLG-X8Q4IBPqxYwL3p9	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Survive Ash Trevino		2025-06-28
PLVjJ2_D-FQikRATbwFXb-4eh-qJQl8srx	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Exit 8		2025-06-28
PLVjJ2_D-FQimbZJ-61yYSsRtVtijQBAKl	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Squid Game Season 2		2025-06-28
PLVjJ2_D-FQinbCQARhRvlTkOVz7SsJjzY	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Horroremon		2025-06-28
PLVjJ2_D-FQimPTOAI7SpTOADF8P6TdbV3	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Paranormal Intrusion		2025-06-28
PLVjJ2_D-FQimbsK74CKuJt24JALoCuMii	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Burglary		2025-06-28
PLVjJ2_D-FQilxtKzI8tbNxl8ClW1J4WXv	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Squid Project		2025-06-28
PLVjJ2_D-FQinjU4MBEiSNd46uoUIr6xgN	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Dont Leave Your TV On		2025-06-28
PLVjJ2_D-FQilAv2UAHBroBYHDRf3VQ6PH	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Bennys Backrooms		2025-06-28
PLVjJ2_D-FQimH7Nzq5u6vV99AOYITJuXm	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Hotel 9		2025-06-28
PLVjJ2_D-FQimtV6AZt7mI90xlFa61QhVQ	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Level Below		2025-06-28
PLVjJ2_D-FQikoM1Lu7bDqIFmoEBfm2kTg	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Monster Metro		2025-06-28
PLVjJ2_D-FQil7tYjjVutRyxeyJ6CAfHsD	UCPS3VX1sNiPnpPOXb8EBZ-A	1	[🌈PENTA/🚪MINGLE] Squid Game X		2025-06-28
PLVjJ2_D-FQinaMqw65QKc2PFkq54o1VWN	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Let Him Go		2025-06-28
PLVjJ2_D-FQiliNu5IU-pwpu7NZH-LiGQo	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Subconscious		2025-06-28
PLVjJ2_D-FQinnjpL2nNV6WJsOPpBvKJkb	UCPS3VX1sNiPnpPOXb8EBZ-A	1	[Mingle] Shrimp Game		2025-06-28
PLVjJ2_D-FQilug5-rBNml63uFufJ39Jfa	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Gods Will		2025-06-28
PLVjJ2_D-FQinwNo9F78lyG6NYMXdymXbv	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Squid Game		2025-06-28
PLVjJ2_D-FQimciw_dWnmFlF3-Z0oK9_cA	UCPS3VX1sNiPnpPOXb8EBZ-A	1	The Daycare		2025-06-28
PLVjJ2_D-FQimHHMfBFmDkr89eeP9VVsTf	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Squid Game Horror		2025-06-28
PLVjJ2_D-FQik6gbkhv37J9bvPwPTblfP_	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Hell Kitchen		2025-06-28
PLVjJ2_D-FQikzpR71C8jkv9ohmsEbtnHE	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Dont Let Him In		2025-06-28
PLVjJ2_D-FQimN_5sK_s1yen4ZYYmAI5dd	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Midnight Christmas		2025-06-28
PLVjJ2_D-FQilNgn8NK7Zd4K8gEUxAFUEa	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Short Horror Game		2025-06-28
PLVjJ2_D-FQilLeS6_adL0VNBPhnSEaa9x	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Sinister Christmas		2025-06-28
PLVjJ2_D-FQilykyEkvaVtYipQO0gUHw7L	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Duolingo Game Hub		2025-06-28
PLVjJ2_D-FQilRiTXSmkFUfMgPKHUAJ246	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Grace		2025-06-28
PLVjJ2_D-FQikDmlImY3zgoTtL3Q3KfrbB	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Wacky Worlds		2025-06-28
PLVjJ2_D-FQilW8m1DidqBrRP4E6z2uWSP	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Night Before The Blizzard		2025-06-28
PLVjJ2_D-FQil2pplbzyU3ILiBABSRIfW3	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Panik		2025-06-28
PLVjJ2_D-FQilPHLiBATWKiSf9YDPLd-tv	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Inocs The Corrupted Beginning		2025-06-28
PLVjJ2_D-FQik8p6La32eD7V_1fqgM8jhg	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Shin Tapes Horror		2025-06-28
PLVjJ2_D-FQinCiZp23cPy8CX2a7NTKRph	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Challenge		2025-06-28
PLVjJ2_D-FQim-GZ-voImWyg0Cs4aBOT_A	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Weird Strict Teacher		2025-06-28
PLVjJ2_D-FQinZK_DIhCuHeDQHME9JGEQ1	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Quiet Escape		2025-06-28
PLVjJ2_D-FQimccig7QuYk5WxsuQMM4SaX	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Creepy Crawlers		2025-06-28
PLVjJ2_D-FQik19p6iaT_pn4mGAJczXi5B	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Pressure		2025-06-28
PLVjJ2_D-FQimbpqvb6vJ9kSAwhXJEnZsS	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Run From The Pony Factory		2025-06-28
PLVjJ2_D-FQinxP6bdyY45LfWSJtpKYGLF	UCPS3VX1sNiPnpPOXb8EBZ-A	1	The Curse		2025-06-28
PLVjJ2_D-FQilYxASL9v9Pry3UssFwTgmK	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Midnight Series		2025-06-28
PLVjJ2_D-FQilkd3SR04CE738vG1tX1qeW	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Charles Revenge [Horror]		2025-06-28
PLVjJ2_D-FQimOVrEs_vCyGR6zsx5YUqOv	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Doors		2025-06-28
PLVjJ2_D-FQinCKDYuvGAEhzcIqvzB1xG4	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Drive		2025-06-28
PLVjJ2_D-FQikaIgMFXRH7dapWk5euPt8W	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Taffy Tails		2025-06-28
PLVjJ2_D-FQimsaZdf2DBfElQoDHdrUy4Y	UCPS3VX1sNiPnpPOXb8EBZ-A	1	The Real Ingredients		2025-06-28
PLVjJ2_D-FQinOO63e7yHj2lWHlWJuFe5L	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Bou Revenge		2025-06-28
PLVjJ2_D-FQinbKMIho9LO21OriA7Z0wfY	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Beetle Juice		2025-06-28
PLVjJ2_D-FQilAi7nSMCBRcMbJI6xUyo63	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Mental (horror) Roblox		2025-06-28
PLVjJ2_D-FQilujhpScVU6mXOhbc8on9MR	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Scary Sushi		2025-06-28
PLVjJ2_D-FQikA643WIk50VQtrJlRPVfMG	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Interliminality Roblox		2025-06-28
PLVjJ2_D-FQimP-tMLWFn4VIiOBFfPVFwb	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Amanda The Adventurer		2025-06-28
PLVjJ2_D-FQilJ3Ev60YqJI7Wv-vmsOcUh	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Dread Camp		2025-06-28
PLVjJ2_D-FQilo1rmp4GafrClLGE6niYqE	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Trepasser		2025-06-28
PLVjJ2_D-FQimDwxsHIocjvbw7zKd8aTbr	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Weird Strict Karen		2025-06-28
PLVjJ2_D-FQim8jyf3lRCzzeodCayG5iCI	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Weird Strict Dad Roblox		2025-06-28
PLVjJ2_D-FQimC1y-k4iO5KYJX_Rkfe7AH	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Color or Die		2025-06-28
PLVjJ2_D-FQikw9WgVWI0fRc5IEUEMwh7-	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Roblox Horror		2025-06-28
PLVjJ2_D-FQild7qrcMYtdBJREba3Oi-C4	UCPS3VX1sNiPnpPOXb8EBZ-A	1	Rainbow Friends		2025-06-28
\.


--
-- Data for Name: playlist_movie; Type: TABLE DATA; Schema: public; Owner: usergameplay
--

COPY public.playlist_movie (id_movie, id_video, url, id_playlist, id_game, id_proplayer, id_hero, time_movie, register_date) FROM stdin;
\.


--
-- Data for Name: playlist_movie_historic; Type: TABLE DATA; Schema: public; Owner: usergameplay
--

COPY public.playlist_movie_historic (id_movie, titulo, description, likes, date_start, register_date, date_end) FROM stdin;
\.


--
-- Data for Name: playlist_movie_tumblr; Type: TABLE DATA; Schema: public; Owner: usergameplay
--

COPY public.playlist_movie_tumblr (id_movie, hash_tumblr, tumblr, register_date) FROM stdin;
\.


--
-- Data for Name: proplayers; Type: TABLE DATA; Schema: public; Owner: usergameplay
--

COPY public.proplayers (id_proplayer, "NOME", description, register_date) FROM stdin;
\.


--
-- Data for Name: proplayers_games; Type: TABLE DATA; Schema: public; Owner: usergameplay
--

COPY public.proplayers_games (id_proplayer, id_game, register_date) FROM stdin;
\.


--
-- Data for Name: proplayers_heroes; Type: TABLE DATA; Schema: public; Owner: usergameplay
--

COPY public.proplayers_heroes (id_proplayer, id_hero, register_date) FROM stdin;
\.


--
-- Data for Name: proplayers_heroes_build; Type: TABLE DATA; Schema: public; Owner: usergameplay
--

COPY public.proplayers_heroes_build (id_proplayer, id_hero, id_item_1, id_item_2, id_item_3, id_item_4, id_item_5, id_item_6, id_item_7, id_item_8, id_item_9, register_date) FROM stdin;
\.


--
-- Data for Name: proplayers_images; Type: TABLE DATA; Schema: public; Owner: usergameplay
--

COPY public.proplayers_images (id_proplayer, hash_tumblr, image) FROM stdin;
\.


--
-- Data for Name: teams; Type: TABLE DATA; Schema: public; Owner: usergameplay
--

COPY public.teams (id_team, team, logo) FROM stdin;
\.


--
-- Data for Name: teams_game; Type: TABLE DATA; Schema: public; Owner: usergameplay
--

COPY public.teams_game (id_team, id_game, banner) FROM stdin;
\.


--
-- Data for Name: tumblr; Type: TABLE DATA; Schema: public; Owner: usergameplay
--

COPY public.tumblr (id_hero, description, hash_tumblr, image) FROM stdin;
\.


--
-- Name: channel_id_channel_seq; Type: SEQUENCE SET; Schema: public; Owner: usergameplay
--

SELECT pg_catalog.setval('public.channel_id_channel_seq', 126, true);


--
-- Name: events_id_event_seq; Type: SEQUENCE SET; Schema: public; Owner: usergameplay
--

SELECT pg_catalog.setval('public.events_id_event_seq', 1, false);


--
-- Name: games_id_game_seq; Type: SEQUENCE SET; Schema: public; Owner: usergameplay
--

SELECT pg_catalog.setval('public.games_id_game_seq', 3, true);


--
-- Name: heroes_id_hero_seq; Type: SEQUENCE SET; Schema: public; Owner: usergameplay
--

SELECT pg_catalog.setval('public.heroes_id_hero_seq', 1, false);


--
-- Name: itens_id_item_seq; Type: SEQUENCE SET; Schema: public; Owner: usergameplay
--

SELECT pg_catalog.setval('public.itens_id_item_seq', 1, false);


--
-- Name: playlist_movie_id_movie_seq; Type: SEQUENCE SET; Schema: public; Owner: usergameplay
--

SELECT pg_catalog.setval('public.playlist_movie_id_movie_seq', 1, false);


--
-- Name: proplayers_id_proplayer_seq; Type: SEQUENCE SET; Schema: public; Owner: usergameplay
--

SELECT pg_catalog.setval('public.proplayers_id_proplayer_seq', 1, false);


--
-- Name: teams_id_team_seq; Type: SEQUENCE SET; Schema: public; Owner: usergameplay
--

SELECT pg_catalog.setval('public.teams_id_team_seq', 1, false);


--
-- Name: channel_games channel_games_pkey; Type: CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.channel_games
    ADD CONSTRAINT channel_games_pkey PRIMARY KEY (id_youtube, id_game);


--
-- Name: channel_historic channel_historic_pkey; Type: CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.channel_historic
    ADD CONSTRAINT channel_historic_pkey PRIMARY KEY (id_youtube, register_date);


--
-- Name: channel_images channel_images_pkey; Type: CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.channel_images
    ADD CONSTRAINT channel_images_pkey PRIMARY KEY (id_youtube);


--
-- Name: channel channel_pkey; Type: CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.channel
    ADD CONSTRAINT channel_pkey PRIMARY KEY (id_youtube);


--
-- Name: events events_pkey; Type: CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT events_pkey PRIMARY KEY (id_event);


--
-- Name: games games_pkey; Type: CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.games
    ADD CONSTRAINT games_pkey PRIMARY KEY (id_game);


--
-- Name: heroes heroes_pkey; Type: CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.heroes
    ADD CONSTRAINT heroes_pkey PRIMARY KEY (id_hero);


--
-- Name: itens_images itens_images_pkey; Type: CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.itens_images
    ADD CONSTRAINT itens_images_pkey PRIMARY KEY (id_item);


--
-- Name: itens itens_pkey; Type: CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.itens
    ADD CONSTRAINT itens_pkey PRIMARY KEY (id_item);


--
-- Name: playlist_movie_historic playlist_movie_historic_pkey; Type: CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.playlist_movie_historic
    ADD CONSTRAINT playlist_movie_historic_pkey PRIMARY KEY (id_movie, date_start, register_date, date_end);


--
-- Name: playlist_movie playlist_movie_pkey; Type: CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.playlist_movie
    ADD CONSTRAINT playlist_movie_pkey PRIMARY KEY (id_movie);


--
-- Name: playlist_movie_tumblr playlist_movie_tumblr_pkey; Type: CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.playlist_movie_tumblr
    ADD CONSTRAINT playlist_movie_tumblr_pkey PRIMARY KEY (hash_tumblr);


--
-- Name: playlist playlist_pkey; Type: CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.playlist
    ADD CONSTRAINT playlist_pkey PRIMARY KEY (id_playlist);


--
-- Name: proplayers_games proplayers_games_pkey; Type: CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.proplayers_games
    ADD CONSTRAINT proplayers_games_pkey PRIMARY KEY (id_proplayer, id_game);


--
-- Name: proplayers_heroes_build proplayers_heroes_build_pkey; Type: CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.proplayers_heroes_build
    ADD CONSTRAINT proplayers_heroes_build_pkey PRIMARY KEY (id_proplayer, id_hero);


--
-- Name: proplayers_heroes proplayers_heroes_pkey; Type: CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.proplayers_heroes
    ADD CONSTRAINT proplayers_heroes_pkey PRIMARY KEY (id_proplayer, id_hero);


--
-- Name: proplayers_images proplayers_images_pkey; Type: CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.proplayers_images
    ADD CONSTRAINT proplayers_images_pkey PRIMARY KEY (id_proplayer, hash_tumblr);


--
-- Name: proplayers proplayers_pkey; Type: CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.proplayers
    ADD CONSTRAINT proplayers_pkey PRIMARY KEY (id_proplayer);


--
-- Name: teams_game teams_game_pkey; Type: CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.teams_game
    ADD CONSTRAINT teams_game_pkey PRIMARY KEY (id_team, id_game);


--
-- Name: teams teams_pkey; Type: CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.teams
    ADD CONSTRAINT teams_pkey PRIMARY KEY (id_team);


--
-- Name: tumblr tumblr_pkey; Type: CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.tumblr
    ADD CONSTRAINT tumblr_pkey PRIMARY KEY (id_hero, hash_tumblr);


--
-- Name: channel fk_channel_game; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.channel
    ADD CONSTRAINT fk_channel_game FOREIGN KEY (id_game) REFERENCES public.games(id_game);


--
-- Name: channel_games fk_channelgames_channel; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.channel_games
    ADD CONSTRAINT fk_channelgames_channel FOREIGN KEY (id_youtube) REFERENCES public.channel(id_youtube);


--
-- Name: channel_games fk_channelgames_game; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.channel_games
    ADD CONSTRAINT fk_channelgames_game FOREIGN KEY (id_game) REFERENCES public.games(id_game);


--
-- Name: channel_historic fk_channelhistoric_channel; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.channel_historic
    ADD CONSTRAINT fk_channelhistoric_channel FOREIGN KEY (id_youtube) REFERENCES public.channel(id_youtube);


--
-- Name: channel_images fk_channelimages_channel; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.channel_images
    ADD CONSTRAINT fk_channelimages_channel FOREIGN KEY (id_youtube) REFERENCES public.channel(id_youtube);


--
-- Name: events fk_events_game; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT fk_events_game FOREIGN KEY (id_game) REFERENCES public.games(id_game);


--
-- Name: heroes fk_heroes_game; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.heroes
    ADD CONSTRAINT fk_heroes_game FOREIGN KEY (id_game) REFERENCES public.games(id_game);


--
-- Name: itens fk_itens_game; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.itens
    ADD CONSTRAINT fk_itens_game FOREIGN KEY (id_game) REFERENCES public.games(id_game);


--
-- Name: itens_images fk_itensimages_item; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.itens_images
    ADD CONSTRAINT fk_itensimages_item FOREIGN KEY (id_item) REFERENCES public.itens(id_item);


--
-- Name: proplayers_heroes_build fk_phb_hero; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.proplayers_heroes_build
    ADD CONSTRAINT fk_phb_hero FOREIGN KEY (id_hero) REFERENCES public.heroes(id_hero);


--
-- Name: proplayers_heroes_build fk_phb_item1; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.proplayers_heroes_build
    ADD CONSTRAINT fk_phb_item1 FOREIGN KEY (id_item_1) REFERENCES public.itens(id_item);


--
-- Name: proplayers_heroes_build fk_phb_item2; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.proplayers_heroes_build
    ADD CONSTRAINT fk_phb_item2 FOREIGN KEY (id_item_2) REFERENCES public.itens(id_item);


--
-- Name: proplayers_heroes_build fk_phb_item3; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.proplayers_heroes_build
    ADD CONSTRAINT fk_phb_item3 FOREIGN KEY (id_item_3) REFERENCES public.itens(id_item);


--
-- Name: proplayers_heroes_build fk_phb_item4; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.proplayers_heroes_build
    ADD CONSTRAINT fk_phb_item4 FOREIGN KEY (id_item_4) REFERENCES public.itens(id_item);


--
-- Name: proplayers_heroes_build fk_phb_item5; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.proplayers_heroes_build
    ADD CONSTRAINT fk_phb_item5 FOREIGN KEY (id_item_5) REFERENCES public.itens(id_item);


--
-- Name: proplayers_heroes_build fk_phb_item6; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.proplayers_heroes_build
    ADD CONSTRAINT fk_phb_item6 FOREIGN KEY (id_item_6) REFERENCES public.itens(id_item);


--
-- Name: proplayers_heroes_build fk_phb_item7; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.proplayers_heroes_build
    ADD CONSTRAINT fk_phb_item7 FOREIGN KEY (id_item_7) REFERENCES public.itens(id_item);


--
-- Name: proplayers_heroes_build fk_phb_item8; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.proplayers_heroes_build
    ADD CONSTRAINT fk_phb_item8 FOREIGN KEY (id_item_8) REFERENCES public.itens(id_item);


--
-- Name: proplayers_heroes_build fk_phb_item9; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.proplayers_heroes_build
    ADD CONSTRAINT fk_phb_item9 FOREIGN KEY (id_item_9) REFERENCES public.itens(id_item);


--
-- Name: proplayers_heroes_build fk_phb_proplayer; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.proplayers_heroes_build
    ADD CONSTRAINT fk_phb_proplayer FOREIGN KEY (id_proplayer) REFERENCES public.proplayers(id_proplayer);


--
-- Name: playlist fk_playlist_channel; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.playlist
    ADD CONSTRAINT fk_playlist_channel FOREIGN KEY (id_youtube) REFERENCES public.channel(id_youtube);


--
-- Name: playlist fk_playlist_game; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.playlist
    ADD CONSTRAINT fk_playlist_game FOREIGN KEY (id_game) REFERENCES public.games(id_game);


--
-- Name: playlist_movie fk_playlistmovie_game; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.playlist_movie
    ADD CONSTRAINT fk_playlistmovie_game FOREIGN KEY (id_game) REFERENCES public.games(id_game);


--
-- Name: playlist_movie fk_playlistmovie_hero; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.playlist_movie
    ADD CONSTRAINT fk_playlistmovie_hero FOREIGN KEY (id_hero) REFERENCES public.heroes(id_hero);


--
-- Name: playlist_movie fk_playlistmovie_playlist; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.playlist_movie
    ADD CONSTRAINT fk_playlistmovie_playlist FOREIGN KEY (id_playlist) REFERENCES public.playlist(id_playlist);


--
-- Name: playlist_movie fk_playlistmovie_proplayer; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.playlist_movie
    ADD CONSTRAINT fk_playlistmovie_proplayer FOREIGN KEY (id_proplayer) REFERENCES public.proplayers(id_proplayer);


--
-- Name: playlist_movie_historic fk_playlistmoviehistoric_movie; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.playlist_movie_historic
    ADD CONSTRAINT fk_playlistmoviehistoric_movie FOREIGN KEY (id_movie) REFERENCES public.playlist_movie(id_movie);


--
-- Name: playlist_movie_tumblr fk_playlistmovietumblr_movie; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.playlist_movie_tumblr
    ADD CONSTRAINT fk_playlistmovietumblr_movie FOREIGN KEY (id_movie) REFERENCES public.playlist_movie(id_movie);


--
-- Name: proplayers_games fk_proplayersgames_game; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.proplayers_games
    ADD CONSTRAINT fk_proplayersgames_game FOREIGN KEY (id_game) REFERENCES public.games(id_game);


--
-- Name: proplayers_games fk_proplayersgames_proplayer; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.proplayers_games
    ADD CONSTRAINT fk_proplayersgames_proplayer FOREIGN KEY (id_proplayer) REFERENCES public.proplayers(id_proplayer);


--
-- Name: proplayers_heroes fk_proplayersheroes_hero; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.proplayers_heroes
    ADD CONSTRAINT fk_proplayersheroes_hero FOREIGN KEY (id_hero) REFERENCES public.heroes(id_hero);


--
-- Name: proplayers_heroes fk_proplayersheroes_proplayer; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.proplayers_heroes
    ADD CONSTRAINT fk_proplayersheroes_proplayer FOREIGN KEY (id_proplayer) REFERENCES public.proplayers(id_proplayer);


--
-- Name: proplayers_images fk_proplayersimages_proplayer; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.proplayers_images
    ADD CONSTRAINT fk_proplayersimages_proplayer FOREIGN KEY (id_proplayer) REFERENCES public.proplayers(id_proplayer);


--
-- Name: teams_game fk_teamsgame_game; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.teams_game
    ADD CONSTRAINT fk_teamsgame_game FOREIGN KEY (id_game) REFERENCES public.games(id_game);


--
-- Name: teams_game fk_teamsgame_team; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.teams_game
    ADD CONSTRAINT fk_teamsgame_team FOREIGN KEY (id_team) REFERENCES public.teams(id_team);


--
-- Name: tumblr fk_tumblr_hero; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.tumblr
    ADD CONSTRAINT fk_tumblr_hero FOREIGN KEY (id_hero) REFERENCES public.heroes(id_hero);


--
-- PostgreSQL database dump complete
--

