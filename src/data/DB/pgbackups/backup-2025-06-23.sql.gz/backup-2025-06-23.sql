--
-- PostgreSQL database dump
--

-- Dumped from database version 17.5
-- Dumped by pg_dump version 17.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: channel; Type: TABLE; Schema: public; Owner: usergameplay
--

CREATE TABLE public.channel (
    id_channel integer NOT NULL,
    id_youtube character varying(30) NOT NULL,
    url character varying(100) NOT NULL,
    title character varying(50) NOT NULL,
    description character varying(1000),
    description_snippet character varying(300),
    handle_name character varying(50) NOT NULL,
    handle character varying(50) NOT NULL,
    id_game integer,
    country character varying(30),
    register_date date,
    my_channel boolean DEFAULT false NOT NULL
);


ALTER TABLE public.channel OWNER TO usergameplay;

--
-- Name: channel_games; Type: TABLE; Schema: public; Owner: usergameplay
--

CREATE TABLE public.channel_games (
    id_youtube character varying(30) NOT NULL,
    id_game integer NOT NULL
);


ALTER TABLE public.channel_games OWNER TO usergameplay;

--
-- Name: channel_historic; Type: TABLE; Schema: public; Owner: usergameplay
--

CREATE TABLE public.channel_historic (
    id_youtube character varying(30) NOT NULL,
    views integer NOT NULL,
    subscribers integer NOT NULL,
    register_date date NOT NULL
);


ALTER TABLE public.channel_historic OWNER TO usergameplay;

--
-- Name: channel_id_channel_seq; Type: SEQUENCE; Schema: public; Owner: usergameplay
--

CREATE SEQUENCE public.channel_id_channel_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.channel_id_channel_seq OWNER TO usergameplay;

--
-- Name: channel_id_channel_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: usergameplay
--

ALTER SEQUENCE public.channel_id_channel_seq OWNED BY public.channel.id_channel;


--
-- Name: channel_images; Type: TABLE; Schema: public; Owner: usergameplay
--

CREATE TABLE public.channel_images (
    id_youtube character varying(30) NOT NULL,
    logo bytea,
    banner bytea,
    vanity bytea
);


ALTER TABLE public.channel_images OWNER TO usergameplay;

--
-- Name: events; Type: TABLE; Schema: public; Owner: usergameplay
--

CREATE TABLE public.events (
    id_event integer NOT NULL,
    name character varying(50) NOT NULL,
    id_game integer NOT NULL,
    date_start date,
    date_end date
);


ALTER TABLE public.events OWNER TO usergameplay;

--
-- Name: events_id_event_seq; Type: SEQUENCE; Schema: public; Owner: usergameplay
--

CREATE SEQUENCE public.events_id_event_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.events_id_event_seq OWNER TO usergameplay;

--
-- Name: events_id_event_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: usergameplay
--

ALTER SEQUENCE public.events_id_event_seq OWNED BY public.events.id_event;


--
-- Name: games; Type: TABLE; Schema: public; Owner: usergameplay
--

CREATE TABLE public.games (
    id_game integer NOT NULL,
    name character varying(50) NOT NULL,
    game character varying(25) NOT NULL,
    ico bytea
);


ALTER TABLE public.games OWNER TO usergameplay;

--
-- Name: games_id_game_seq; Type: SEQUENCE; Schema: public; Owner: usergameplay
--

CREATE SEQUENCE public.games_id_game_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.games_id_game_seq OWNER TO usergameplay;

--
-- Name: games_id_game_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: usergameplay
--

ALTER SEQUENCE public.games_id_game_seq OWNED BY public.games.id_game;


--
-- Name: heroes; Type: TABLE; Schema: public; Owner: usergameplay
--

CREATE TABLE public.heroes (
    id_hero integer NOT NULL,
    name character varying(50) NOT NULL,
    id_game integer NOT NULL,
    description character varying(1000),
    image bytea
);


ALTER TABLE public.heroes OWNER TO usergameplay;

--
-- Name: heroes_id_hero_seq; Type: SEQUENCE; Schema: public; Owner: usergameplay
--

CREATE SEQUENCE public.heroes_id_hero_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.heroes_id_hero_seq OWNER TO usergameplay;

--
-- Name: heroes_id_hero_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: usergameplay
--

ALTER SEQUENCE public.heroes_id_hero_seq OWNED BY public.heroes.id_hero;


--
-- Name: itens; Type: TABLE; Schema: public; Owner: usergameplay
--

CREATE TABLE public.itens (
    id_item integer NOT NULL,
    name character varying(50) NOT NULL,
    id_game integer NOT NULL,
    description character varying(1000),
    "VALUE" integer NOT NULL
);


ALTER TABLE public.itens OWNER TO usergameplay;

--
-- Name: itens_id_item_seq; Type: SEQUENCE; Schema: public; Owner: usergameplay
--

CREATE SEQUENCE public.itens_id_item_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.itens_id_item_seq OWNER TO usergameplay;

--
-- Name: itens_id_item_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: usergameplay
--

ALTER SEQUENCE public.itens_id_item_seq OWNED BY public.itens.id_item;


--
-- Name: itens_images; Type: TABLE; Schema: public; Owner: usergameplay
--

CREATE TABLE public.itens_images (
    id_item integer NOT NULL,
    image bytea
);


ALTER TABLE public.itens_images OWNER TO usergameplay;

--
-- Name: playlist; Type: TABLE; Schema: public; Owner: usergameplay
--

CREATE TABLE public.playlist (
    id_playlist integer NOT NULL,
    id_youtube character varying(30) NOT NULL,
    id_game integer NOT NULL,
    name character varying(50) NOT NULL,
    description character varying(1000),
    register_date date NOT NULL
);


ALTER TABLE public.playlist OWNER TO usergameplay;

--
-- Name: playlist_id_playlist_seq; Type: SEQUENCE; Schema: public; Owner: usergameplay
--

CREATE SEQUENCE public.playlist_id_playlist_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.playlist_id_playlist_seq OWNER TO usergameplay;

--
-- Name: playlist_id_playlist_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: usergameplay
--

ALTER SEQUENCE public.playlist_id_playlist_seq OWNED BY public.playlist.id_playlist;


--
-- Name: playlist_movie; Type: TABLE; Schema: public; Owner: usergameplay
--

CREATE TABLE public.playlist_movie (
    id_movie integer NOT NULL,
    id_video character varying(50) NOT NULL,
    url character varying(100) NOT NULL,
    id_playlist integer NOT NULL,
    id_game integer NOT NULL,
    id_proplayer integer NOT NULL,
    id_hero integer NOT NULL,
    time_movie integer NOT NULL,
    register_date date NOT NULL
);


ALTER TABLE public.playlist_movie OWNER TO usergameplay;

--
-- Name: playlist_movie_historic; Type: TABLE; Schema: public; Owner: usergameplay
--

CREATE TABLE public.playlist_movie_historic (
    id_movie integer NOT NULL,
    titulo character varying(50) NOT NULL,
    description character varying(1000),
    likes integer NOT NULL,
    date_start date NOT NULL,
    register_date date NOT NULL,
    date_end date NOT NULL
);


ALTER TABLE public.playlist_movie_historic OWNER TO usergameplay;

--
-- Name: playlist_movie_id_movie_seq; Type: SEQUENCE; Schema: public; Owner: usergameplay
--

CREATE SEQUENCE public.playlist_movie_id_movie_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.playlist_movie_id_movie_seq OWNER TO usergameplay;

--
-- Name: playlist_movie_id_movie_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: usergameplay
--

ALTER SEQUENCE public.playlist_movie_id_movie_seq OWNED BY public.playlist_movie.id_movie;


--
-- Name: playlist_movie_tumblr; Type: TABLE; Schema: public; Owner: usergameplay
--

CREATE TABLE public.playlist_movie_tumblr (
    id_movie integer NOT NULL,
    hash_tumblr character varying(64) NOT NULL,
    tumblr bytea NOT NULL,
    register_date date NOT NULL
);


ALTER TABLE public.playlist_movie_tumblr OWNER TO usergameplay;

--
-- Name: proplayers; Type: TABLE; Schema: public; Owner: usergameplay
--

CREATE TABLE public.proplayers (
    id_proplayer integer NOT NULL,
    "NOME" character varying(50) NOT NULL,
    description character varying(1000),
    register_date date NOT NULL
);


ALTER TABLE public.proplayers OWNER TO usergameplay;

--
-- Name: proplayers_games; Type: TABLE; Schema: public; Owner: usergameplay
--

CREATE TABLE public.proplayers_games (
    id_proplayer integer NOT NULL,
    id_game integer NOT NULL,
    register_date date NOT NULL
);


ALTER TABLE public.proplayers_games OWNER TO usergameplay;

--
-- Name: proplayers_heroes; Type: TABLE; Schema: public; Owner: usergameplay
--

CREATE TABLE public.proplayers_heroes (
    id_proplayer integer NOT NULL,
    id_hero integer NOT NULL,
    register_date date NOT NULL
);


ALTER TABLE public.proplayers_heroes OWNER TO usergameplay;

--
-- Name: proplayers_heroes_build; Type: TABLE; Schema: public; Owner: usergameplay
--

CREATE TABLE public.proplayers_heroes_build (
    id_proplayer integer NOT NULL,
    id_hero integer NOT NULL,
    id_item_1 integer,
    id_item_2 integer,
    id_item_3 integer,
    id_item_4 integer,
    id_item_5 integer,
    id_item_6 integer,
    id_item_7 integer,
    id_item_8 integer,
    id_item_9 integer,
    register_date date NOT NULL
);


ALTER TABLE public.proplayers_heroes_build OWNER TO usergameplay;

--
-- Name: proplayers_id_proplayer_seq; Type: SEQUENCE; Schema: public; Owner: usergameplay
--

CREATE SEQUENCE public.proplayers_id_proplayer_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.proplayers_id_proplayer_seq OWNER TO usergameplay;

--
-- Name: proplayers_id_proplayer_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: usergameplay
--

ALTER SEQUENCE public.proplayers_id_proplayer_seq OWNED BY public.proplayers.id_proplayer;


--
-- Name: proplayers_images; Type: TABLE; Schema: public; Owner: usergameplay
--

CREATE TABLE public.proplayers_images (
    id_proplayer integer NOT NULL,
    hash_tumblr character varying(64) NOT NULL,
    image bytea
);


ALTER TABLE public.proplayers_images OWNER TO usergameplay;

--
-- Name: teams; Type: TABLE; Schema: public; Owner: usergameplay
--

CREATE TABLE public.teams (
    id_team integer NOT NULL,
    team character varying(50) NOT NULL,
    logo bytea
);


ALTER TABLE public.teams OWNER TO usergameplay;

--
-- Name: teams_game; Type: TABLE; Schema: public; Owner: usergameplay
--

CREATE TABLE public.teams_game (
    id_team integer NOT NULL,
    id_game integer NOT NULL,
    banner bytea
);


ALTER TABLE public.teams_game OWNER TO usergameplay;

--
-- Name: teams_id_team_seq; Type: SEQUENCE; Schema: public; Owner: usergameplay
--

CREATE SEQUENCE public.teams_id_team_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.teams_id_team_seq OWNER TO usergameplay;

--
-- Name: teams_id_team_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: usergameplay
--

ALTER SEQUENCE public.teams_id_team_seq OWNED BY public.teams.id_team;


--
-- Name: tumblr; Type: TABLE; Schema: public; Owner: usergameplay
--

CREATE TABLE public.tumblr (
    id_hero integer NOT NULL,
    description character varying(1000),
    hash_tumblr character varying(64) NOT NULL,
    image bytea
);


ALTER TABLE public.tumblr OWNER TO usergameplay;

--
-- Name: channel id_channel; Type: DEFAULT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.channel ALTER COLUMN id_channel SET DEFAULT nextval('public.channel_id_channel_seq'::regclass);


--
-- Name: events id_event; Type: DEFAULT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.events ALTER COLUMN id_event SET DEFAULT nextval('public.events_id_event_seq'::regclass);


--
-- Name: games id_game; Type: DEFAULT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.games ALTER COLUMN id_game SET DEFAULT nextval('public.games_id_game_seq'::regclass);


--
-- Name: heroes id_hero; Type: DEFAULT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.heroes ALTER COLUMN id_hero SET DEFAULT nextval('public.heroes_id_hero_seq'::regclass);


--
-- Name: itens id_item; Type: DEFAULT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.itens ALTER COLUMN id_item SET DEFAULT nextval('public.itens_id_item_seq'::regclass);


--
-- Name: playlist id_playlist; Type: DEFAULT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.playlist ALTER COLUMN id_playlist SET DEFAULT nextval('public.playlist_id_playlist_seq'::regclass);


--
-- Name: playlist_movie id_movie; Type: DEFAULT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.playlist_movie ALTER COLUMN id_movie SET DEFAULT nextval('public.playlist_movie_id_movie_seq'::regclass);


--
-- Name: proplayers id_proplayer; Type: DEFAULT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.proplayers ALTER COLUMN id_proplayer SET DEFAULT nextval('public.proplayers_id_proplayer_seq'::regclass);


--
-- Name: teams id_team; Type: DEFAULT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.teams ALTER COLUMN id_team SET DEFAULT nextval('public.teams_id_team_seq'::regclass);


--
-- Data for Name: channel; Type: TABLE DATA; Schema: public; Owner: usergameplay
--

COPY public.channel (id_channel, id_youtube, url, title, description, description_snippet, handle_name, handle, id_game, country, register_date, my_channel) FROM stdin;
1	UCznPSdnBofe1ONMO0m2GSQQ	https://www.youtube.com/channel/UCznPSdnBofe1ONMO0m2GSQQ	Dota 2 Old School Show	Where legends shine and nostalgia is immortal!\n\nEN-US\nWelcome to the Dota 2 Old School Show!\n\nHere, you relive the greatest moments of Dota 2s golden era with legendary pro player gameplays, classic strategies, and historic plays.\nGet ready for an epic journey with the most iconic heroes and the builds that shaped the meta.\n\n🎮 Daily videos with epic matches\n🏆 Tributes to the legends of the competitive scene\n📅 New videos every week\n💬 Comment the next player or team youd like to see!\n\nOnde as lendas brilham e a nostalgia é imortal!\n\nPT-BR\nBem-vindo ao Dota 2 Old School Show!\n\nAqui você revive os melhores momentos da era dourada do Dota 2 com gameplays lendárias de pro players, estratégias clássicas e jogadas que marcaram história.\nPrepare-se para uma viagem épica com os heróis mais icônicos e as builds que moldaram o meta.\n\n🎮 Vídeos diários com partidas épicas\n🏆 Homenagens às lendas do cenário competitivo\n📅 Novos vídeos toda semana\n💬 Comente o próximo jogador ou time que quer ver!\n	Where legends shine and nostalgia is immortal! 	Dota2OldSchoolShow	@Dota2OldSchoolShow	1	\N	2025-06-23	t
3	UCDztxdy54wmTB17z9Vh8b3A	https://www.youtube.com/channel/UCDztxdy54wmTB17z9Vh8b3A	Dota Persona	Dota 2 Pro Support Gameplay Channel\n\nMostly support role gameplay from Pub and Tournament\n\nYou can request anything just comment on my video!\n\nTHANKS FOR COMING !\n\nVALVE VIDEO POLICY\nhttps://store.steampowered.com/video_policy\n	Dota 2 Pro Support Gameplay Channel 	DotaSupport	@DotaSupport	1	\N	2025-06-23	f
4	UCHZ7buu1amKXgpqCVsox1aA	https://www.youtube.com/channel/UCHZ7buu1amKXgpqCVsox1aA	Dota Gameplay	Welcome to Kardel Dota 2! Home of the best & updated Dota 2 gameplays!\n\nDont forget to like and subscribe as it helps the channel very much.\n\nLOOK FOR THE BEST GAMEPLAYS HERE:\nhttps://www.youtube.com/playlist?list=PLKJ2kg9FdH3rPQesQ1nep6sE-PvkuYEnR\n\nMY OTHER CHANNEL (Kardel Highlights) :\nhttps://www.youtube.com/channel/UCicDjmMP4Rw3mg-tWYVu7Fg \n\n	Welcome to Kardel Dota 2! Home of the best & updated Dota 2 gameplays! 	DotaGameplay	@DotaGameplay	1	\N	2025-06-23	f
5	UCwI9DhoGEziLUxTpK8H77jw	https://www.youtube.com/channel/UCwI9DhoGEziLUxTpK8H77jw	Dota 2 Pro Gameplay [Watch & Learn]	Top MMR Plays / Dota 2 Pro Gameplay is Educational Channel about e-sport Dota 2 competitive scene. Watch replays of professional players, highest MMR battles and LEARN from you favourite Pro players!\n\n► Remember to subscribe to be notified when we release new #Dota2 videos! \n\nWatch Pro, Learn from Pro, Play like Pro!\n\nVALVE VIDEO POLICY\nhttps://store.steampowered.com/video_policy\n	Top MMR Plays / Dota 2 Pro Gameplay is Educational Channel about e-sport Dota 2 competitive scene. Watch replays of professional players, highest MMR battles and LEARN from you favourite Pro players! 	ProGameplayDota2	@ProGameplayDota2	1	\N	2025-06-23	f
6	UC18NaGQLruOEw65eQE3bNbg	https://www.youtube.com/channel/UC18NaGQLruOEw65eQE3bNbg	Dota Watafak	We collect clips from thousands of dota players to show them to you. \n\nIf you want to be in one of the videos, send your WTF moment here:\nhttps://dotawatafak.com/category/sube-tu-jugada/\n\nOr click on the "Submit your Play" button below. GLHF!\n	We collect clips from thousands of dota players to show them to you. 	DotaWatafak	@DotaWatafak	1	\N	2025-06-23	f
7	UCTXCACeuoZJggkbuJ0w7_bg	https://www.youtube.com/channel/UCTXCACeuoZJggkbuJ0w7_bg	Rizpol	Welcome to Rizpol Dota\nIve always loved playing Dota and do some silly build, memes, or meta things. \n\nI used to only make dota 2 educational content (in bahasa), but now I make English content about SEA server. \nI also active on other social media Instagram and Facebook.	Welcome to Rizpol Dota 	Rizpol	@Rizpol	1	\N	2025-06-23	f
8	UC1YCxISkweN5vLsOJ0zElZQ	https://www.youtube.com/channel/UC1YCxISkweN5vLsOJ0zElZQ	hOlyhexOr	Official YouTube-Channel of hOlyhexOr, a professional Dota 2 movie maker and ex-professional Dota 2 player. Creating Dota 2 Videos with Passion.\n\n►► Currently searching for new Dota 2 Video Editors! Send over an E-Mail if youre interested!\n► For Business Inquiries + if you want any kind of video production, please contact: hexor@artofdota2.com\n\n►► Send me your BEST Dota 2 clips here: hexordota2clips@artofdota2.com\n\n► Become a VIP now and enjoy exclusive benefits:\nhttps://metafy.gg/@holyhexor\n\nImpressum\nDominik Buhmann, hOlyhexOr\nGetHero\nc/o Webedia GmbH\nCuvrystr. 3-4\n10997 Berlin\nE-Mail: hexor@artofdota2.com\nGeschäftsführer: Marc-Andreas Albert\nHRB 114531\n\nBusiness inquiries & E-Mail: hexor@artofdota2.com\nUmsatzsteuer-Identifikationsnummer: DE297797430\n\nVerantwortlich für den Inhalt iSv. § 18 Abs.2 MStV: Buhmann, Dominik\n	Official YouTube-Channel of hOlyhexOr, a professional Dota 2 movie maker and ex-professional Dota 2 player. Creating Dota 2 Videos with Passion. 	hOlyhexOr	@hOlyhexOr	1	\N	2025-06-23	f
9	UCYWvw17IQl_prkX93IhjuKQ	https://www.youtube.com/channel/UCYWvw17IQl_prkX93IhjuKQ	Dota 2 Enjoyer	Just a fellow Dota 2 Enjoyer	Just a fellow Dota 2 Enjoyer 	Dota2Enjoyer	@Dota2Enjoyer	1	\N	2025-06-23	f
10	UCdk_9kcWld5UvflPR3W7A2w	https://www.youtube.com/channel/UCdk_9kcWld5UvflPR3W7A2w	Dota2 HighSchool	Welcome to HighSchool of Dota 2.\nThanks for watching!!! Love you 9000 (MMR)	Welcome to HighSchool of Dota 2. 	Dota2HighSchool	@Dota2HighSchool	1	\N	2025-06-23	f
11	UCaYLBJfw6d8XqmNlL204lNg	https://www.youtube.com/channel/UCaYLBJfw6d8XqmNlL204lNg	ESL Dota 2	Welcome to the home of ESL Dota 2 on YouTube! Be sure to subscribe to keep up to date with all of the lates Dota 2 action from around the world.	Welcome to the home of ESL Dota 2 on YouTube! Be sure to subscribe to keep up to date with all of the lates Dota 2 action from around the world. 	ESLDota2	@ESLDota2	1	\N	2025-06-23	f
12	UC7sgoyC1VbMNlS1n7ChsBPQ	https://www.youtube.com/channel/UC7sgoyC1VbMNlS1n7ChsBPQ	Dota2 Galaxy	\n	More about this channel 	dota2galaxy	@dota2galaxy	1	\N	2025-06-23	f
14	UCfsOfLvadg89Bx8Sv_6WERg	https://www.youtube.com/channel/UCfsOfLvadg89Bx8Sv_6WERg	NoobFromUA	Dota 2 Channel NoobFromUA. \nDendi Pudge, Miracle-, SingSing and 2 ez 4 Arteezy.\n\nVALVE VIDEO POLICY► https://store.steampowered.com/video_policy\n\nDota 2 Best And Most EPIC GAME EVER!	Dota 2 Channel NoobFromUA. 	NoobFromUA	@NoobFromUA	1	\N	2025-06-23	f
17	UCPkaARl89RCckNE_D7tj-aA	https://www.youtube.com/channel/UCPkaARl89RCckNE_D7tj-aA	Gorgc	Official channel of Gorgc - professional Dota 2 player, streamer for OG, Midas Mode 2 Winner.\nHere you can find the highlights from streams as well as original content.	Official channel of Gorgc - professional Dota 2 player, streamer for OG, Midas Mode 2 Winner. 	Gorgc	@Gorgc	1	\N	2025-06-23	f
18	UCZsM8MOy0VC9blj_wBkbo-g	https://www.youtube.com/channel/UCZsM8MOy0VC9blj_wBkbo-g	Purge	Thanks for checking out my Dota 2 content! If you have any questions, the best way to get a hold of me is to tweet me!\n\nBusiness Inquiry: business@purgegamers.com	Thanks for checking out my Dota 2 content! If you have any questions, the best way to get a hold of me is to tweet me! 	PurgeGamers	@PurgeGamers	1	\N	2025-06-23	f
19	UCy0-ftAwxMHzZc74OhYT3PA	https://www.youtube.com/channel/UCy0-ftAwxMHzZc74OhYT3PA	GameLeap Dota 2 Pro Guides	For Business Inquiries, email support@game-leap.com\nGameLeap is the proven step-by-step platform to help you become a better gamer. You will learn directly from the best players in the world in hundreds of curated video courses. Visit our website at https://www.gameleap.com/	For Business Inquiries, email support@game-leap.com 	gameleapdota2	@gameleapdota2	1	\N	2025-06-23	f
21	UCI2vFNmkaj22Om3qO5J7qOg	https://www.youtube.com/channel/UCI2vFNmkaj22Om3qO5J7qOg	Kryptonill Gaming	👋Hello Guys. Im Kryptonill, a professional video editor and an old time Dota 2 player since 2014 with over 12500 hours total playtime on steam & decided to create this channel in 2017 with passion.\n\n► I only make fully edited educational videos that you cant find on other Channel such as item build, skill build, tips, tricks, how to play, map awareness and every single detail you should know to be a better player in DotA\nI also changed the terrain of the game to make it look better.\nDota 2 has over 124 heroes, its not easy to learn, so be sure to focus every move in my videos.\n\n► What do i record and edit videos with? I record with OBS studio and edit the video with Premier, Resolve, Sony Vegas Pro 15, Adobe After Effect and of course thumbnails with Photoshop.\nI spend hours and hours to edit each video, You better leave a like.\n\n    ⏰Upload Schedule⏰\n➤7:00AM \n➤11:00AM \n➤3:00PM\n➤7:00PM \n➤11:00PM\n\n  🙏PLEASE GIVE ME STRENGTH🙏\n           😜SUBSCRIBE NOW😜\n  💖Lets Make DotA Great Again💖	👋Hello Guys. Im Kryptonill, a professional video editor and an old time Dota 2 player since 2014 with over 12500 hours total playtime on steam & decided to create this channel in 2017 with passion. 	KryptonillGaming	@KryptonillGaming	1	\N	2025-06-23	f
23	UCKCC6yRZor2qsGbO_x7LpuA	https://www.youtube.com/channel/UCKCC6yRZor2qsGbO_x7LpuA	Dota 2 Meta	Meta - Uploading Only Professional Evolution Videos	Meta - Uploading Only Professional Evolution Videos 	metagamesevolution	@metagamesevolution	1	\N	2025-06-23	f
24	UCiR9IHCurqVHpC821NVcW6g	https://www.youtube.com/channel/UCiR9IHCurqVHpC821NVcW6g	Dota 2 Divine	Welcome to Dota 2 Divine! Have Fun when playing Dota.\n\nDota2 Gameplay, Highlight, Epic Moment, Amazing Build, Funny Stream moment\nDIVINE Idol: Dendi, Miracle-, Singsing, Arteezy, Admiralbulldog, w33, ABED, Puppey, Kuroky, Sumail\nDIVINE Favorite Hero: Invoker, Pudge, Meepo, Legion Commander, Phantom Assassin, Alchemist, Monkey King\n\nLooking for Sponsorship, inbox me if you are interested in DIVINE DOTA	Welcome to Dota 2 Divine! Have Fun when playing Dota. 	Dota2Divine	@Dota2Divine	1	\N	2025-06-23	f
25	UC72LSerSpu1y9y_BlDHWLGA	https://www.youtube.com/channel/UC72LSerSpu1y9y_BlDHWLGA	Dota 2 Tips	Dota 2 MOBA videos + gaming tips, gameplay, strategy, proplayer guides, tips and tricks! \nHeroes with their abilities, itembuilds, gameanalysis, gamebreaking bugs, gamechanging strategies, winningstrategies, mapawareness, farming, laning about teamfight, herocontrol, warding, smoke of deceit, ganking, pushingstrategies etc!\n	Dota 2 MOBA videos + gaming tips, gameplay, strategy, proplayer guides, tips and tricks! 	Dota2Tips	@Dota2Tips	1	\N	2025-06-23	f
26	UCMZwHuSN9ZqRXucscC_hnKA	https://www.youtube.com/channel/UCMZwHuSN9ZqRXucscC_hnKA	LeagueOfDota	Hello guys, welcome back to LeagueOfDota Youtube channel.\nThis channel provide most recent highlights with high quality stats preview before the match like head to head team, standings bracket, players heroes performances and etc. \nHope you enjoy the videos. Thank you.\n\n\nVALVE VIDEO POLICY https://store.steampowered.com/video_policy	Hello guys, welcome back to LeagueOfDota Youtube channel. 	LeagueOfDota	@LeagueOfDota	1	\N	2025-06-23	f
108	UCpLgMe1mjvvTrNgSQ28PHnw	https://www.youtube.com/channel/UCpLgMe1mjvvTrNgSQ28PHnw	Dota 2 Gameplay [Pro Leagues]	More about this channel 	More about this channel 	dota2proleagues	@dota2proleagues	1	\N	2025-06-23	f
27	UCrrZzgPvpLdp0g285JPb7GQ	https://www.youtube.com/channel/UCrrZzgPvpLdp0g285JPb7GQ	Holy E	😎 Who am I?\n\nIm Holy E, a Dota 2 player with 16 years of experience!!! but NOT a pro player!😁. Ive started with Dota 1 (6.43 patch) and Ive seen lots of builds, gameplays, and a mindset of playing Dota!\nIt brings me here to make Dota 2 funny videos, including educational tips!\n	😎 Who am I? 	HolyE	@HolyE	1	\N	2025-06-23	f
28	UCJOpcUMBPnayED1xGFlvQCg	https://www.youtube.com/channel/UCJOpcUMBPnayED1xGFlvQCg	Dota Shaman	Arteezy Positive Mental Atitude (PMA) and more Dota 2 stream moments!\n\nSubscribe for some laugh moments.\nHave fun guys ^^	Arteezy Positive Mental Atitude (PMA) and more Dota 2 stream moments! 	dotashaman	@dotashaman	1	\N	2025-06-23	f
29	UC4M1snKkcGvEVOBGC5LnGdQ	https://www.youtube.com/channel/UC4M1snKkcGvEVOBGC5LnGdQ	Qojqva	Dota 2 gameplay, tips, and strategies. Improve your skills and enjoy exciting matches!\n	Dota 2 gameplay, tips, and strategies. Improve your skills and enjoy exciting matches! 	qojqva6094	@qojqva6094	1	\N	2025-06-23	f
30	UCiqBeZx-Jez6J6WK6-PXrew	https://www.youtube.com/channel/UCiqBeZx-Jez6J6WK6-PXrew	WillDS	mungkin channel gaming\n\n	mungkin channel gaming 	WillDarkestSystem	@WillDarkestSystem	1	\N	2025-06-23	f
31	UC4HfMLhNP7oVmF0wJMAU_1g	https://www.youtube.com/channel/UC4HfMLhNP7oVmF0wJMAU_1g	Dota 2 Invoker	******  THIS CHANNEL IS ALL ABOUT INVOKER DOTA 2 ******\n\n****************************\n\nSUPPORT US BY SUBSCRIBE CHANNEL: https://www.youtube.com/@Dota2InvokerOfficial\n     \n****************************\n\n\n	******  THIS CHANNEL IS ALL ABOUT INVOKER DOTA 2 ****** 	Dota2InvokerOfficial	@Dota2InvokerOfficial	1	\N	2025-06-23	f
32	UCeaSnulFHX9xqkKejnIvyxA	https://www.youtube.com/channel/UCeaSnulFHX9xqkKejnIvyxA	PLAYER PERSPECTIVE DOTA 2	Hello guys, welcome to my channel!\n\nVALVE VIDEO POLICY: https://store.steampowered.com/video_policy\n	Hello guys, welcome to my channel! 	PPDota2	@PPDota2	1	\N	2025-06-23	f
33	UCr6cJRQ6EBchbTI-NlLBwww	https://www.youtube.com/channel/UCr6cJRQ6EBchbTI-NlLBwww	Deadlock Pro Gameplay [Watch & Learn]	We post spectacular Deadlock professional e-sport players gameplay. Watch pro players to improve your personal skill!\n\nVALVE VIDEO POLICY\nhttps://store.steampowered.com/video_policy\n	We post spectacular Deadlock professional e-sport players gameplay. Watch pro players to improve your personal skill! 	ProGameplayDeadlock	@ProGameplayDeadlock	1	\N	2025-06-23	f
34	UCXjx9yYZ55-kl2J54efE8bg	https://www.youtube.com/channel/UCXjx9yYZ55-kl2J54efE8bg	WagaGaming	Im Wagamama,  Dota 2 streamer!\n\nI play dota2 fulltime and I try to provide some fun and educational content on my stream and youtube!\nFollow me on twitter or facebook and youll know what Im up to :)	Im Wagamama,  Dota 2 streamer! 	WagaGaming	@WagaGaming	1	\N	2025-06-23	f
35	UCrRlDvN5Ea2OauDLtNBMyfw	https://www.youtube.com/channel/UCrRlDvN5Ea2OauDLtNBMyfw	DATOHLEONG	I make really cool dota 2 videos :D\n\nBased: Singapore\n\nContact me: contactdatohleong@gmail.com\nFor all Business Inquiries, please contact elizaah@emerge-esports.com\n	I make really cool dota 2 videos :D 	datohleonggez	@datohleonggez	1	\N	2025-06-23	f
36	UCokHQ6IhiqeYuy-TqQthi4w	https://www.youtube.com/channel/UCokHQ6IhiqeYuy-TqQthi4w	Dota 2 Pango	We capturing the best moments so you dont have to\n	We capturing the best moments so you dont have to 	Dota2Pango	@Dota2Pango	1	\N	2025-06-23	f
37	UC4aVD0WIvfFsiICZy5Wo22w	https://www.youtube.com/channel/UC4aVD0WIvfFsiICZy5Wo22w	DOTA empire	Dota 2  Gameplay Channel\n\nMostly offlane role gameplay from Pub and Tournament\n\nvalve credit: https://store.steampowered.com/video_policy\n\nif you own those videos and need to delete it just email me\n\nthanks for visiting here\n	Dota 2  Gameplay Channel 	dotaempire2505	@dotaempire2505	1	\N	2025-06-23	f
38	UCK2t7qm88e6ZsKS3Pbg-C3Q	https://www.youtube.com/channel/UCK2t7qm88e6ZsKS3Pbg-C3Q	Dota 2 Highlights & Guides TV	Welcome to your go-to educational channel for the competitive Dota 2 scene!\nDive into high-level gameplay, watch replays from top-ranked matches, and learn directly from the best professional players in the game.\n\n► Subscribe and stay updated with the latest #Dota2 videos!\nWatch the pros. Learn their moves. Play like a pro.\n\n🔗 Valve Video Policy:\nhttps://store.steampowered.com/video_policy\n	Welcome to your go-to educational channel for the competitive Dota 2 scene! 	Dota2HighlightsGuides	@Dota2HighlightsGuides	1	\N	2025-06-23	f
39	UCW2Ew5V3I2z1jXvsZEkKtUQ	https://www.youtube.com/channel/UCW2Ew5V3I2z1jXvsZEkKtUQ	Dota 2 Scepter	★Hey there! Welcome To Dota 2 Scepter. Its all about Dota 2.\n►We Uploading Highlight Dota 2 videos with passion.\n★My channel includes tips and tricks, guide, gameplay, and how to get better at Dota 2.\n★Everything about Dota 2, You can find it here on this channel.\n\n★How I Edit My Videos ? 100% Unique And Original Contents:\n1. Take replay from dotabuff.com or opendota.com\n2. Analytics which gameplays are interesting.\n3. Record in game client with Nvidia Shadowplay.\n4. Edit with adobe premiere pro cc 2018 and thumbnail create with adobe photoshop cc 2018.\n★We spent more than 15 hours everyday for uploading dota 2 videos with passion.\n\n►Valve - Dota 2 monetize video policy: https://store.steampowered.com/video_policy\n\n                          👊Need More Power👊\n                            😇Subscribe Now😇\n                                💖Lets Do It!💖\n	★Hey there! Welcome To Dota 2 Scepter. Its all about Dota 2. 	Dota2Scepter	@Dota2Scepter	1	\N	2025-06-23	f
40	UCS3_m4V1yExUC18ejJnd1IQ	https://www.youtube.com/channel/UCS3_m4V1yExUC18ejJnd1IQ	ZQuixotix	Hello friends, Im Zach. I mostly make Dota 2 videos about how to play the support roles, currently ~6.7K, Rank 1000ish in NA.\n\nIf some of the videos seem too long for you, check out the video descriptions! I try to add brief summaries/timestamps to important points (including a summary at the end of most videos). \n	Hello friends, Im Zach. I mostly make Dota 2 videos about how to play the support roles, currently ~6.7K, Rank 1000ish in NA. 	ZQuixotix	@ZQuixotix	1	\N	2025-06-23	f
41	UC8rWMk2o4KHkoMWybi0rVlA	https://www.youtube.com/channel/UC8rWMk2o4KHkoMWybi0rVlA	PainDota	10K MMR, Education Dota 2 Content. Coaching videos & Analysis on Pro Players. 	10K MMR, Education Dota 2 Content. Coaching videos & Analysis on Pro Players. 	PainDota	@PainDota	1	\N	2025-06-23	f
42	UCpCG__ifmbaTPaQnpixkB4w	https://www.youtube.com/channel/UCpCG__ifmbaTPaQnpixkB4w	evanescent dota 2	\n	More about this channel 	EvanescentDota2	@EvanescentDota2	1	\N	2025-06-23	f
70	UCWZSOq7SJedArFyc3SNRVvw	https://www.youtube.com/channel/UCWZSOq7SJedArFyc3SNRVvw	Spotnet Dota2	Spotnet Dota 2 Channel for Tournament gameplay and Top Plays\n\nI provide commentary for educational and entertain.\nWatching live non Official streaming Tournament with English Freelance Caster\n\nAll Gameplays are from Dota 2 Game produced by Valve\nValve, the Valve logo, Dota, the Dota 2 logo, and Defense of the Ancients are trademarks and/or registered trademarks of Valve Corporation. All other trademarks are property of their respective owners.\n\nValve video policy / License https://store.steampowered.com/video_policy\nDotaTV License : https://www.dota2.com/dotatv\n\n	Spotnet Dota 2 Channel for Tournament gameplay and Top Plays 	SpotnetDota2	@SpotnetDota2	1	\N	2025-06-23	f
43	UCHky6L8_p73ujg9II9La_6A	https://www.youtube.com/channel/UCHky6L8_p73ujg9II9La_6A	Dota 2 Adventure 	💖Welcome to Dota 2 Adventure! Its All About DOTA 2💖\nIf Youre DotA Lover Congratulations! Youre in The Right Place.\nIn Here You Can Relax and Enjoy Pro Player Perspective Gameplay.\nTHANK FOR WATCHING GUY. I HOPE YOU ENJOY THIS VIDEO.\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n⏰Upload Schedule⏰ 3Videos Every Single Day\n➤5:00PM \n➤7:00PM \n➤9:00PM\n\n     👊Need More Power👊\n        😇Subscribe Now😇\n            💖Lets Do It!💖\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\nDota2 is a multiplayer online battle arena (MOBA) video game in which two teams of five players compete to collectively destroy a large structure defended by the opposing team known as the "Ancient", whilst defending their own.\n\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n#Dota #Dota2 #Dota2Aventure\n	💖Welcome to Dota 2 Adventure! Its All About DOTA 2💖 	Dota2Adventure	@Dota2Adventure	1	\N	2025-06-23	f
44	UCqsQG398BFcxNojHLg26L9g	https://www.youtube.com/channel/UCqsQG398BFcxNojHLg26L9g	Dota 2 Pro Ranked Gameplay 	Welcome to Dota 2 Pro Ranked Gameplay!\n\nHi, I am one of the most commended players (14K) in Dota 2 Community. I am a commentator, entertainer, & video creator. \n\nThis channel is an Educational + Gaming Channel all about the e-sport game “Dota 2”.\n\nI will explain to you all the basic skills, guides, tips, & tricks, related to the latest meta, updates, & how pro players (at the top MMR) play through my commentary & highlight videos.\n\nBest way to increase your skills in any game is by watching & learning from pro players replays. So here, you can learn a lot from my daily videos, in which I explain my analysis of players perspectives. To win consecutively, and reach the Top MMR stages, you need to know the pro strategies like denying creeps, last hits, map control, items build, play style, and many more.\n\nMy Mission!\nWatch Pro, Learn from Pro, & Play like Pro!\n\nDont forget to like and subscribe as it helps the channel! \n\nVALVE VIDEO POLICY: https://store.steampowered.com/video_policy\n	Welcome to Dota 2 Pro Ranked Gameplay! 	dota2prorankedgameplay	@dota2prorankedgameplay	1	\N	2025-06-23	f
45	UCdO3EenGrBpD7KCePa13c2A	https://www.youtube.com/channel/UCdO3EenGrBpD7KCePa13c2A	Dota RollerCoaster	More about this channel 	More about this channel 	dotarollercoaster	@dotarollercoaster	1	\N	2025-06-23	f
46	UCAi2SCg-RMzEB1sap7UKlvw	https://www.youtube.com/channel/UCAi2SCg-RMzEB1sap7UKlvw	iAnnihilate	12k MMR mid player making educational content for Dota 2!	12k MMR mid player making educational content for Dota 2! 	iAnnihilate	@iAnnihilate	1	\N	2025-06-23	f
48	UCWBWm89MmoSHEXLoEeUbVTw	https://www.youtube.com/channel/UCWBWm89MmoSHEXLoEeUbVTw	DOTA 2 Immortal Plays	Dota 2 Replays of High MMR Matches\n\nUpload Every Single Day\n\nThank You for Watching!\n\n►Valve Video Policy: https://store.steampowered.com/video_policy\n	Dota 2 Replays of High MMR Matches 	dota2immortalplays661	@dota2immortalplays661	1	\N	2025-06-23	f
49	UCIE4fk1t6sXYqszHLU-Tk5g	https://www.youtube.com/channel/UCIE4fk1t6sXYqszHLU-Tk5g	Elacrity	I like to dota and sometimes other games to, relax, and have a good time.	I like to dota and sometimes other games to, relax, and have a good time. 	elacrityd2	@elacrityd2	1	\N	2025-06-23	f
51	UCL7w4AbdEGE3UjzHI3AjXOg	https://www.youtube.com/channel/UCL7w4AbdEGE3UjzHI3AjXOg	Tip Worthy - Dota 2	Gameplay videos for various heroes in Dota 2 played by lwaal (https://steamcommunity.com/profiles/76561198080681732/)	Gameplay videos for various heroes in Dota 2 played by lwaal (https://steamcommunity.com/profiles/76561198080681732/) 	tipworthy-dota2	@tipworthy-dota2	1	\N	2025-06-23	f
52	UCWAVnD2zizRENkqEnSC-I_A	https://www.youtube.com/channel/UCWAVnD2zizRENkqEnSC-I_A	SlashStrike	Hey hey 👋 Trying to improve at the fascinating game that is Dota 2?\n\nIm here to help you do exactly that! \n\nIve played competitively with big names such as MinD_ControL and Seleri, Ive coached over a thousand players with MMRs ranging from 50 to 9000, and now Im creating content to deliver all the knowledge Ive gathered over the years to you, in the form of:\n\n📜 Articles & In-depth Hero Guides\n\n✨ Infographics, Item Builds & Hero Grids\n\n🎧 Coaching, Replay Reviews & Interactive Courses\n\nIf you have any questions, dont hesitate to join my discord and ask me directly!\n	Hey hey 👋 Trying to improve at the fascinating game that is Dota 2? 	SlashStrikeDota	@SlashStrikeDota	1	\N	2025-06-23	f
53	UCwD_AqoRMwOX6w0AiGWr4jA	https://www.youtube.com/channel/UCwD_AqoRMwOX6w0AiGWr4jA	DOTA 2 -50a -A LEARNER  GAMEPLAY BY HAXY	TEAM GAME PLAYER -TEAMGAMER\nEA SPORTS-ELECTRONIC ARTS\nHOPE INDAN TEAM WILL  BE PARTICIPATE IN DOTA 2 TOURNAMENT\n\n DOTA 2 PLAYER WHO IS LEARNER \nFULL GAME PLAY \nWIN OR LOSS DOES NOT MATTER YOU LEARN EVERYTIME SOMETHING NEW\n\n Give me suggestions if you want any changes in my gameplay so I can understand and improve my self \nthank you for love and support 😊 	TEAM GAME PLAYER -TEAMGAMER 	50adota2LEARNER	@50adota2LEARNER	1	\N	2025-06-23	f
54	UC8Rv6PXWZ5ERqoLlUsIyQ8w	https://www.youtube.com/channel/UC8Rv6PXWZ5ERqoLlUsIyQ8w	Carbonyl DotA	Im Carbonyl DotA and Im a 7k mmr North American DotA player and coach. On this channel I post coaching VODs, educational videos, and other DotA related content.	Im Carbonyl DotA and Im a 7k mmr North American DotA player and coach. On this channel I post coaching VODs, educational videos, and other DotA related content. 	CarbonylDotA	@CarbonylDotA	1	\N	2025-06-23	f
55	UCXHp2CSy2pYGC9Ede8qvMpg	https://www.youtube.com/channel/UCXHp2CSy2pYGC9Ede8qvMpg	JFKs Unique Dota 2 Finds: Rare Items Showcase	Showcasing Dota 2 cosmetics, doing my best to stick to rare and exclusive unique items. feelsbadman for not recording all the stuff I ever owned. \n\nYou can easily reach me at: https://steamcommunity.com/id/ultimatejfk/\n	Showcasing Dota 2 cosmetics, doing my best to stick to rare and exclusive unique items. feelsbadman for not recording all the stuff I ever owned. 	JFK_Dota	@JFK_Dota	1	\N	2025-06-23	f
71	UCBzrhVhJUaOI0dtpZqGeB2Q	https://www.youtube.com/channel/UCBzrhVhJUaOI0dtpZqGeB2Q	4fun	Cinematic artist\n\n	Cinematic artist 	4fun911	@4fun911	1	\N	2025-06-23	f
56	UCnUgUdncVcxVaqMvQSD_DuA	https://www.youtube.com/channel/UCnUgUdncVcxVaqMvQSD_DuA	Gios Dota Experience	Greetings, my name is Cornelius, 7,6k mmr peak, I am from germany and  study Theology, enjoy dota, music and fitness.\nMy goal is to share parts of my journy as a player and as a coach and to give away some insights I made over the years.\nMy  foucs will be on the wonderfull world of  Dota 2 and will include philosophies both in game and in life, psychological apporaches to manipulate what we call "fate"  towards our own favor, a overall positive and optimistic but hopefully not naive  view on life, and of course many, many dota specific mechanics. \n\nIf you are lookig to get coached, to share Ideas, to get in touch, you can email directly.\nEmail: cornelius21doll@icloud.com\n	Greetings, my name is Cornelius, 7,6k mmr peak, I am from germany and  study Theology, enjoy dota, music and fitness. 	giosdotaexperience4833	@giosdotaexperience4833	1	\N	2025-06-23	f
57	UCK7aWn0h70vqc4QGExA3BBw	https://www.youtube.com/channel/UCK7aWn0h70vqc4QGExA3BBw	Henry Dota 2 - 2nd Channel	This is Henrys second channel mostly focused on personal content and gameplay. For guides and tips please check out his main channel.\n\nHenry is a renowned coach of over 1000 students and educator in the Dota 2 space. \n	This is Henrys second channel mostly focused on personal content and gameplay. For guides and tips please check out his main channel. 	Henrydota2	@Henrydota2	1	\N	2025-06-23	f
58	UCTQKT5QqO3h7y32G8VzuySQ	https://www.youtube.com/channel/UCTQKT5QqO3h7y32G8VzuySQ	dota2	Dota 2 is a competitive game of action and strategy, played both professionally and casually by millions of passionate fans worldwide. \n\nAvailable on Steam: http://store.steampowered.com/app/570/\n	Dota 2 is a competitive game of action and strategy, played both professionally and casually by millions of passionate fans worldwide. 	dota2	@dota2	1	\N	2025-06-23	f
59	UCyJfe8BMWqA2vJuYQ4PDOvw	https://www.youtube.com/channel/UCyJfe8BMWqA2vJuYQ4PDOvw	dotatvru	We love Dota 	We love Dota 	dotatvru	@dotatvru	1	\N	2025-06-23	f
60	UCcJFzYP0f9ZVDILH7HVyLcg	https://www.youtube.com/channel/UCcJFzYP0f9ZVDILH7HVyLcg	justwan	More about this channel 	More about this channel 	justwan	@justwan	1	\N	2025-06-23	f
61	UCUqLL4VcEy4mXcQL0O_H_bg	https://www.youtube.com/channel/UCUqLL4VcEy4mXcQL0O_H_bg	DotA Digest	DotA Digest - Dota 2 Highlights of Elite League 2024 and Dota 2 Tournaments 2024.\n\n⏺️ All videos on the DotA Digest channel are recorded by me in the game client Dota 2 with a unique camera work.\n\nVALVE VIDEO POLICY ► https://store.steampowered.com/video_policy\n"You are free to monetize your videos via the YouTube partner program and similar programs on other video sharing sites. Please dont ask us to write YouTube and tell them its fine with us to post a particular video using Valve content. Its not possible to respond to each such request. Point them to this page."\n	DotA Digest - Dota 2 Highlights of Elite League 2024 and Dota 2 Tournaments 2024. 	DotADigestDD	@DotADigestDD	1	\N	2025-06-23	f
62	UCzghsdg33rhnu-0CLhx_ttA	https://www.youtube.com/channel/UCzghsdg33rhnu-0CLhx_ttA	Dota 2 Regeneration	If you want to watch your interesting games here, you can send us GAME ID. https://www.instagram.com/dota2_abilitydraft/\n dota2abilitydraft11@gmail.com 	If you want to watch your interesting games here, you can send us GAME ID. https://www.instagram.com/dota2_abilitydraft/ 	DOTA2Regeneration	@DOTA2Regeneration	1	\N	2025-06-23	f
63	UCqmJgdqMIWlrGCUdlEZBawg	https://www.youtube.com/channel/UCqmJgdqMIWlrGCUdlEZBawg	Miracle-	Professional Dota 2 player currently playing for Nigma\nWinner of The International 2017.	Professional Dota 2 player currently playing for Nigma 	Miracledoto	@Miracledoto	1	\N	2025-06-23	f
64	UCcwSIU_DxgUFjOXPRaztATw	https://www.youtube.com/channel/UCcwSIU_DxgUFjOXPRaztATw	Metafy Dota 2	On Metafy you can get 1:1 online coaching from the best players in the world and watch amazing content about gaming. \n\nWebsite: https://metafy.gg\nDiscord: https://discord.gg/metafy\nTwitter: https://twitter.com/TryMetafy\nInstagram: https://www.instagram.com/trymetafy/\nFacebook: https://www.facebook.com/metafy.gg\nLinkedIn: https://www.linkedin.com/company/trymetafy/\nYouTube MetafyDota2: https://www.youtube.com/@MetafyDota2\nSnapChat: https://www.snapchat.com/add/metafy.gg\n\n---\n\nMetafy is the premier destination for learning about and improving at your favorite games. You can book 1-on-1 sessions with the top players in gaming, or send in pre-recorded footage and get detailed feedback from an Expert of your choice. You can also sign up for a Metafy Membership and access a mountain of content ranging from educational content, documentaries about pivotal moments in the scene, podcasts, and lots more. \n	On Metafy you can get 1:1 online coaching from the best players in the world and watch amazing content about gaming. 	MetafyDota2	@MetafyDota2	1	\N	2025-06-23	f
65	UCy7O1t8ZD5qe77sdkfBJ76A	https://www.youtube.com/channel/UCy7O1t8ZD5qe77sdkfBJ76A	EpulzeGaming	Follow your favorite teams across our pro-divisions and immerse yourself in the latest livestream productions.\n	Follow your favorite teams across our pro-divisions and immerse yourself in the latest livestream productions. 	EpulzeGaming	@EpulzeGaming	1	\N	2025-06-23	f
66	UCCUR--YxwSYJ4QzuKsaAABw	https://www.youtube.com/channel/UCCUR--YxwSYJ4QzuKsaAABw	Dota 2 Pro	Dota 2 Pro\nI provide commentary for educational and entertain.\nThis the right place to watch gameplay dota 2 from professional player\t\t\t\t\nYou can learn how to play like a pro :)\n\n\n	Dota 2 Pro 	Dota2Pro	@Dota2Pro	1	\N	2025-06-23	f
67	UCbUX71arfjbI8R3jhgncwxg	https://www.youtube.com/channel/UCbUX71arfjbI8R3jhgncwxg	Dota 2 Carry	🔥Welcome to Dota 2 Carry! This`s All About DOTA 2🔥\n\nEveryday we upload video gameplay of the Top Immortal Rank Like \nSumail, Arteezy, Abed, Miracle, Topson, Ana and many more.\n\nIf You`re Dota Lover Congratulations! You`re in The Right Place.\nIn Here You Can Relax and Enjoy Pro Player Perspective Gameplay. \n\nWhat do i record and edit videos with? \nI record with OBS studio and edit the video with Sony Vegas Pro 15, Adobe After Effect and of course thumbnails with Photoshop.\nI spend hours and hours to edit each video, You better leave a like.\n\nRemember to subscribe to be notified when we publish new videos or highlights!	🔥Welcome to Dota 2 Carry! This`s All About DOTA 2🔥 	Dota2Carry	@Dota2Carry	1	\N	2025-06-23	f
68	UC7l_lqR3T5Pkrjp2Uyc2dKQ	https://www.youtube.com/channel/UC7l_lqR3T5Pkrjp2Uyc2dKQ	VIFOR Dota 2	Best Dota 2 Content.	Best Dota 2 Content. 	VIFORDota2	@VIFORDota2	1	\N	2025-06-23	f
69	UCkkKxVIv_6EJsfRMJ-7ILaQ	https://www.youtube.com/channel/UCkkKxVIv_6EJsfRMJ-7ILaQ	DOTAKU	A Channel for Dota 2 Enjoyer!😁\nSUBSCRIBE TO KNOW ALL INFO ABOUT DOTA 2\n\nemail : dotakuchannel@gmail.com\n\n	A Channel for Dota 2 Enjoyer!😁 	dotakuu	@dotakuu	1	\N	2025-06-23	f
72	UCk0Ns16byYxp5P4aJ6C_AQQ	https://www.youtube.com/channel/UCk0Ns16byYxp5P4aJ6C_AQQ	Invoker Dota 2 7.36	#dota #dota2 #Invoker\n\nHello Dota fans and welcome to the Invoker Dota Channel. We provide the best Invoker Dota Gameplay, Invoker Dota 2 Highlights, Invoker Dota Guide and Invoker Dota Tutorials.\n\nThis game is played on this patch: Dota 2 7.36\n\nAccording to https://dota2.fandom.com/wiki/Invoker , A competent wizard knows perhaps two spells; an exceptional one, three or four. Wielding the elements of Quas, Wex and Exort, the Invoker surpasses them all. Forging Spirits of ice and fire to melt away the armor of enemies with great Alacrity while Snapping their heat-deprived cold bodies.\n	#dota #dota2 #Invoker 	invoker_dota_	@invoker_dota_	1	\N	2025-06-23	f
73	UC75nwKcny3G8YzDQDbRQGxA	https://www.youtube.com/channel/UC75nwKcny3G8YzDQDbRQGxA	Dota 2 Scrim	Home of extreme game highlights and entertainment.\n\nFor business inquiries please contact us at scrimesports.gg@gmail.com	Home of extreme game highlights and entertainment. 	Dota2Scrim	@Dota2Scrim	1	\N	2025-06-23	f
74	UCxhHKJ5gk0WE0hSXJ-cvdOA	https://www.youtube.com/channel/UCxhHKJ5gk0WE0hSXJ-cvdOA	Dota 2 Hub	Everything about Dota2\nSubscribe Please! :)\nDONT CLICK HERE: https://bit.ly/3nE967q\nValves video policy: https://store.steampowered.com/video_policy\n	Everything about Dota2 	Dota2Hub7	@Dota2Hub7	1	\N	2025-06-23	f
95	UC3v9jm_gJl80V7D1bXSQUbg	https://www.youtube.com/channel/UC3v9jm_gJl80V7D1bXSQUbg	LboyAx Gaming	Welcome to my Channel\nIn this channel i talk about the games i play, mostly about Dota\nI make guides, lore and theory videos, predictions and more.\n	Welcome to my Channel 	UnyQkXzGaming	@UnyQkXzGaming	1	\N	2025-06-23	f
96	UCbEKR2sUvjXpCv9bHdeu_kA	https://www.youtube.com/channel/UCbEKR2sUvjXpCv9bHdeu_kA	Meanwhile in Dota 2	Dota 2 Highlights, Dota 2 Pro Gameplays and Dota 2 Events and Updates.	Dota 2 Highlights, Dota 2 Pro Gameplays and Dota 2 Events and Updates. 	MeanwhileinDota2	@MeanwhileinDota2	1	\N	2025-06-23	f
97	UCN3TsZ85XxxJWVjOd3Au7Tg	https://www.youtube.com/channel/UCN3TsZ85XxxJWVjOd3Au7Tg	Dota 2 Documentary	I do storytelling and documentary-type videos for Dota 2.\nAll the script writing, thumbnail, and video editing are all done by me.\n\nOpen for sponsorship, contact on my email below.\n	I do storytelling and documentary-type videos for Dota 2. 	Dota2Documentary	@Dota2Documentary	1	\N	2025-06-23	f
98	UCPInitFCnCdPeXhYTtu_1Mg	https://www.youtube.com/channel/UCPInitFCnCdPeXhYTtu_1Mg	Dota 2 Legend	Dota 2 Legend - Dota 2 Highlights and Best videos of Dota 2 Tournaments	Dota 2 Legend - Dota 2 Highlights and Best videos of Dota 2 Tournaments 	dota2legend941	@dota2legend941	1	\N	2025-06-23	f
99	UCUo_5VlcTiq3-UJn57xbRRA	https://www.youtube.com/channel/UCUo_5VlcTiq3-UJn57xbRRA	Spirit of Dota 2	We post Dota 2 clips from streamers and replays of pro players.\nSubscribe if youre a Chad!\n\n►►► What is Dota 2 ?\nDota 2 is a multiplayer online battle arena video game developed and published by Valve Corporation. The game is a sequel to Defense of the Ancients, which was a community-created mod for Blizzard Entertainments Warcraft III: Reign of Chaos and its expansion pack, The Frozen Throne.\nInitial release date: July 9, 2013\nDeveloper: Valve Corporation\nDesigner: IceFrog\nGenre: Multiplayer online battle arena\nPublisher: Valve Corporation\nEngine: Source 2\n\nAll rights go to the original video owners, no copyright infringement intended. If you want to removed your clips, please send an email to spiritofdota2@gmail.com\n\nValve video policy ► https://store.steampowered.com/video_policy\n	We post Dota 2 clips from streamers and replays of pro players. 	spiritofdota2	@spiritofdota2	1	\N	2025-06-23	f
100	UCKQVOWuuZB0ZGViUHSIbRgg	https://www.youtube.com/channel/UCKQVOWuuZB0ZGViUHSIbRgg	STILL DOTA 2	Welcome guys, Im Still, a Dota 2 player with years of experience but still a god damn noob...\n\n-Subscribe to see more Dota2 Meme Content!\n	Welcome guys, Im Still, a Dota 2 player with years of experience but still a god damn noob... 	stilldota2	@stilldota2	1	\N	2025-06-23	f
101	UC37QwXQO8jF_b7QUOWASYPw	https://www.youtube.com/channel/UC37QwXQO8jF_b7QUOWASYPw	TouchMyAghs	✔ Original videos of an immortal ranked potato player\n✔ Tutorial, TIPS & TRICKS\n✔ Guides to Get Better at Dota\n✔ MEMES & Funny Clips\n\n	✔ Original videos of an immortal ranked potato player 	TouchMyAghs	@TouchMyAghs	1	\N	2025-06-23	f
102	UCM05DDwIjT7rbTStUiDtDKQ	https://www.youtube.com/channel/UCM05DDwIjT7rbTStUiDtDKQ	Dota 2 Pro Players	\n	More about this channel 	Dota2ProPlayers	@Dota2ProPlayers	1	\N	2025-06-23	f
103	UCAsJY3XcyPLePV-m-SGBPdQ	https://www.youtube.com/channel/UCAsJY3XcyPLePV-m-SGBPdQ	Dota 2 Thug Life	We upload dota 2 gameplay videos from pro players every day	We upload dota 2 gameplay videos from pro players every day 	dota2thuglife917	@dota2thuglife917	1	\N	2025-06-23	f
104	UCgfMMDA5Am2fuAyoFXGQoYA	https://www.youtube.com/channel/UCgfMMDA5Am2fuAyoFXGQoYA	Krevs Dota 2	More about this channel 	More about this channel 	krevsdota2	@krevsdota2	1	\N	2025-06-23	f
105	UCKz9sZPT4AvbdhkLWyHJIIA	https://www.youtube.com/channel/UCKz9sZPT4AvbdhkLWyHJIIA	Butcher Channel Dota 2 TV	Hello! This channel will collect the coolest moments of the Dota 2 game, most importantly, by professional players of this discipline. Good mood to everyone and a peaceful sky above your head!\nI will be very grateful for a like, comment and subscription.\n\nIf you want to support me. \nMy Patreon - https://www.patreon.com/ButcherChannelDota2TV\n	Hello! This channel will collect the coolest moments of the Dota 2 game, most importantly, by professional players of this discipline. Good mood to everyone and a peaceful sky above your head! 	bcd2tv	@bcd2tv	1	\N	2025-06-23	f
106	UCgT3aLbI2qNYcYFWtmntxZQ	https://www.youtube.com/channel/UCgT3aLbI2qNYcYFWtmntxZQ	Dota 2 Gameplay live	Welcome to Dota 2 Gameplay live! Have Fun when playing Dota 2.\n\nDota2 Gameplay live, Highlight, Epic Moment, Amazing Build, Funny Stream moment\nDIVINE Idol: Dendi, Miracle-, Singsing, Arteezy, Admiralbulldog, w33, ABED, Puppey, Kuroky, Sumail\nDIVINE Favorite Hero: Invoker, Pudge, Meepo, Legion Commander, Phantom Assassin, Alchemist, Monkey King\n\nLooking for Sponsorship, inbox me if you are interested in DIVINE DOTA	Welcome to Dota 2 Gameplay live! Have Fun when playing Dota 2. 	dota2gameplaylive	@dota2gameplaylive	1	\N	2025-06-23	f
107	UClxwL5BvlIBT0aSygQV1OBw	https://www.youtube.com/channel/UClxwL5BvlIBT0aSygQV1OBw	Unseen Dota 2 Pro Gameplay	Subscribe or -25 mmr\n\nhi im a dota lover 18 years and counting. please subscribe to support me tq.\n#dota2 #dota2highlights #dotawtf	Subscribe or -25 mmr 	unseendota8645	@unseendota8645	1	\N	2025-06-23	f
110	UC-M63nj_uaArEQyR11DQinA	https://www.youtube.com/channel/UC-M63nj_uaArEQyR11DQinA	Dota 2 Storm Spirit	More about this channel 	More about this channel 	dota2stormspirit214	@dota2stormspirit214	1	\N	2025-06-23	f
111	UCAY7ezW5YwDjJc9HZsphZjg	https://www.youtube.com/channel/UCAY7ezW5YwDjJc9HZsphZjg	Fradoz Dota 2	Hello guys !! I hope you guys happy and love watching my videos. Dont forget to like and leave a comment for any suggestion. Stay home and stay safe everyone. 	Hello guys !! I hope you guys happy and love watching my videos. Dont forget to like and leave a comment for any suggestion. Stay home and stay safe everyone. 	FradozDota2	@FradozDota2	1	\N	2025-06-23	f
112	UCZcEr35xjy8kRtYxwsGksDA	https://www.youtube.com/channel/UCZcEr35xjy8kRtYxwsGksDA	Dota 2 Live	Dota 2 Live\nAll about tournament dota 2 live streaming in Dota Pro Circuit and The International\n	Dota 2 Live 	dota2lives	@dota2lives	1	\N	2025-06-23	f
113	UCq1SlO7vuzA1Rr1UbsVX1Cw	https://www.youtube.com/channel/UCq1SlO7vuzA1Rr1UbsVX1Cw	Dota 2 Mastery	Official YouTube-Channel of Dota2Mastery professional Dota 2 movie maker and ex-professional Dota 2 player.\n\n► Creating Dota 2 Videos with Top songs.\n\n►► Currently searching for new Dota 2 gameplay replays! Send if youre interested!\n\n► For Business Inquiries please contact: dota2masteryy@gmail.com\n\nBusiness inquiries & E-Mail: dota2masteryy@gmail.come\n	Official YouTube-Channel of Dota2Mastery professional Dota 2 movie maker and ex-professional Dota 2 player. 	dota2mastery144	@dota2mastery144	1	\N	2025-06-23	f
114	UCHJL5WGh4KXyWs7zxcb8fRw	https://www.youtube.com/channel/UCHJL5WGh4KXyWs7zxcb8fRw	Dota 2 : Hero Chase	Welcome to Dota 2 : Hero Chase Channel\n--------------------------------------------------------------------------------------------------\n\nJust call me Roy! Im content creator for Dota2 lovers\nHere you can see some highlight of Dota2 gameplay from Pro player or something amazing youre rarely seen in Dota2 that im serving only the best clip of it.\nPlease subscribe, like and share if youre enjoy watching my video.\n\n--------------------------------------------------------------------------------------------------\nInstagram : https://www.instagram.com/dota2herochase/\nMy Instagram : @royhan_aldy\ncatch me up aldykuzut@gmail.com\n	Welcome to Dota 2 : Hero Chase Channel 	dota2herochase	@dota2herochase	1	\N	2025-06-23	f
115	UCLA23mWwgSH8Co3ApS7JGyg	https://www.youtube.com/channel/UCLA23mWwgSH8Co3ApS7JGyg	Dota 2 Rocks	More about this channel 	More about this channel 	dotarocks	@dotarocks	1	\N	2025-06-23	f
\.


--
-- Data for Name: channel_games; Type: TABLE DATA; Schema: public; Owner: usergameplay
--

COPY public.channel_games (id_youtube, id_game) FROM stdin;
\.


--
-- Data for Name: channel_historic; Type: TABLE DATA; Schema: public; Owner: usergameplay
--

COPY public.channel_historic (id_youtube, views, subscribers, register_date) FROM stdin;
\.


--
-- Data for Name: channel_images; Type: TABLE DATA; Schema: public; Owner: usergameplay
--

COPY public.channel_images (id_youtube, logo, banner, vanity) FROM stdin;
\.


--
-- Data for Name: events; Type: TABLE DATA; Schema: public; Owner: usergameplay
--

COPY public.events (id_event, name, id_game, date_start, date_end) FROM stdin;
\.


--
-- Data for Name: games; Type: TABLE DATA; Schema: public; Owner: usergameplay
--

COPY public.games (id_game, name, game, ico) FROM stdin;
1	Dota 2	Dota 2	\N
2	Counter-Strike: Global Offensive	CS:GO	\N
3	League of Legends	LOL	\N
\.


--
-- Data for Name: heroes; Type: TABLE DATA; Schema: public; Owner: usergameplay
--

COPY public.heroes (id_hero, name, id_game, description, image) FROM stdin;
\.


--
-- Data for Name: itens; Type: TABLE DATA; Schema: public; Owner: usergameplay
--

COPY public.itens (id_item, name, id_game, description, "VALUE") FROM stdin;
\.


--
-- Data for Name: itens_images; Type: TABLE DATA; Schema: public; Owner: usergameplay
--

COPY public.itens_images (id_item, image) FROM stdin;
\.


--
-- Data for Name: playlist; Type: TABLE DATA; Schema: public; Owner: usergameplay
--

COPY public.playlist (id_playlist, id_youtube, id_game, name, description, register_date) FROM stdin;
\.


--
-- Data for Name: playlist_movie; Type: TABLE DATA; Schema: public; Owner: usergameplay
--

COPY public.playlist_movie (id_movie, id_video, url, id_playlist, id_game, id_proplayer, id_hero, time_movie, register_date) FROM stdin;
\.


--
-- Data for Name: playlist_movie_historic; Type: TABLE DATA; Schema: public; Owner: usergameplay
--

COPY public.playlist_movie_historic (id_movie, titulo, description, likes, date_start, register_date, date_end) FROM stdin;
\.


--
-- Data for Name: playlist_movie_tumblr; Type: TABLE DATA; Schema: public; Owner: usergameplay
--

COPY public.playlist_movie_tumblr (id_movie, hash_tumblr, tumblr, register_date) FROM stdin;
\.


--
-- Data for Name: proplayers; Type: TABLE DATA; Schema: public; Owner: usergameplay
--

COPY public.proplayers (id_proplayer, "NOME", description, register_date) FROM stdin;
\.


--
-- Data for Name: proplayers_games; Type: TABLE DATA; Schema: public; Owner: usergameplay
--

COPY public.proplayers_games (id_proplayer, id_game, register_date) FROM stdin;
\.


--
-- Data for Name: proplayers_heroes; Type: TABLE DATA; Schema: public; Owner: usergameplay
--

COPY public.proplayers_heroes (id_proplayer, id_hero, register_date) FROM stdin;
\.


--
-- Data for Name: proplayers_heroes_build; Type: TABLE DATA; Schema: public; Owner: usergameplay
--

COPY public.proplayers_heroes_build (id_proplayer, id_hero, id_item_1, id_item_2, id_item_3, id_item_4, id_item_5, id_item_6, id_item_7, id_item_8, id_item_9, register_date) FROM stdin;
\.


--
-- Data for Name: proplayers_images; Type: TABLE DATA; Schema: public; Owner: usergameplay
--

COPY public.proplayers_images (id_proplayer, hash_tumblr, image) FROM stdin;
\.


--
-- Data for Name: teams; Type: TABLE DATA; Schema: public; Owner: usergameplay
--

COPY public.teams (id_team, team, logo) FROM stdin;
\.


--
-- Data for Name: teams_game; Type: TABLE DATA; Schema: public; Owner: usergameplay
--

COPY public.teams_game (id_team, id_game, banner) FROM stdin;
\.


--
-- Data for Name: tumblr; Type: TABLE DATA; Schema: public; Owner: usergameplay
--

COPY public.tumblr (id_hero, description, hash_tumblr, image) FROM stdin;
\.


--
-- Name: channel_id_channel_seq; Type: SEQUENCE SET; Schema: public; Owner: usergameplay
--

SELECT pg_catalog.setval('public.channel_id_channel_seq', 115, true);


--
-- Name: events_id_event_seq; Type: SEQUENCE SET; Schema: public; Owner: usergameplay
--

SELECT pg_catalog.setval('public.events_id_event_seq', 1, false);


--
-- Name: games_id_game_seq; Type: SEQUENCE SET; Schema: public; Owner: usergameplay
--

SELECT pg_catalog.setval('public.games_id_game_seq', 3, true);


--
-- Name: heroes_id_hero_seq; Type: SEQUENCE SET; Schema: public; Owner: usergameplay
--

SELECT pg_catalog.setval('public.heroes_id_hero_seq', 1, false);


--
-- Name: itens_id_item_seq; Type: SEQUENCE SET; Schema: public; Owner: usergameplay
--

SELECT pg_catalog.setval('public.itens_id_item_seq', 1, false);


--
-- Name: playlist_id_playlist_seq; Type: SEQUENCE SET; Schema: public; Owner: usergameplay
--

SELECT pg_catalog.setval('public.playlist_id_playlist_seq', 1, false);


--
-- Name: playlist_movie_id_movie_seq; Type: SEQUENCE SET; Schema: public; Owner: usergameplay
--

SELECT pg_catalog.setval('public.playlist_movie_id_movie_seq', 1, false);


--
-- Name: proplayers_id_proplayer_seq; Type: SEQUENCE SET; Schema: public; Owner: usergameplay
--

SELECT pg_catalog.setval('public.proplayers_id_proplayer_seq', 1, false);


--
-- Name: teams_id_team_seq; Type: SEQUENCE SET; Schema: public; Owner: usergameplay
--

SELECT pg_catalog.setval('public.teams_id_team_seq', 1, false);


--
-- Name: channel_games channel_games_pkey; Type: CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.channel_games
    ADD CONSTRAINT channel_games_pkey PRIMARY KEY (id_youtube, id_game);


--
-- Name: channel_historic channel_historic_pkey; Type: CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.channel_historic
    ADD CONSTRAINT channel_historic_pkey PRIMARY KEY (id_youtube, register_date);


--
-- Name: channel_images channel_images_pkey; Type: CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.channel_images
    ADD CONSTRAINT channel_images_pkey PRIMARY KEY (id_youtube);


--
-- Name: channel channel_pkey; Type: CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.channel
    ADD CONSTRAINT channel_pkey PRIMARY KEY (id_youtube);


--
-- Name: events events_pkey; Type: CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT events_pkey PRIMARY KEY (id_event);


--
-- Name: games games_pkey; Type: CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.games
    ADD CONSTRAINT games_pkey PRIMARY KEY (id_game);


--
-- Name: heroes heroes_pkey; Type: CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.heroes
    ADD CONSTRAINT heroes_pkey PRIMARY KEY (id_hero);


--
-- Name: itens_images itens_images_pkey; Type: CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.itens_images
    ADD CONSTRAINT itens_images_pkey PRIMARY KEY (id_item);


--
-- Name: itens itens_pkey; Type: CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.itens
    ADD CONSTRAINT itens_pkey PRIMARY KEY (id_item);


--
-- Name: playlist_movie_historic playlist_movie_historic_pkey; Type: CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.playlist_movie_historic
    ADD CONSTRAINT playlist_movie_historic_pkey PRIMARY KEY (id_movie, date_start, register_date, date_end);


--
-- Name: playlist_movie playlist_movie_pkey; Type: CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.playlist_movie
    ADD CONSTRAINT playlist_movie_pkey PRIMARY KEY (id_movie);


--
-- Name: playlist_movie_tumblr playlist_movie_tumblr_pkey; Type: CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.playlist_movie_tumblr
    ADD CONSTRAINT playlist_movie_tumblr_pkey PRIMARY KEY (hash_tumblr);


--
-- Name: playlist playlist_pkey; Type: CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.playlist
    ADD CONSTRAINT playlist_pkey PRIMARY KEY (id_playlist);


--
-- Name: proplayers_games proplayers_games_pkey; Type: CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.proplayers_games
    ADD CONSTRAINT proplayers_games_pkey PRIMARY KEY (id_proplayer, id_game);


--
-- Name: proplayers_heroes_build proplayers_heroes_build_pkey; Type: CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.proplayers_heroes_build
    ADD CONSTRAINT proplayers_heroes_build_pkey PRIMARY KEY (id_proplayer, id_hero);


--
-- Name: proplayers_heroes proplayers_heroes_pkey; Type: CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.proplayers_heroes
    ADD CONSTRAINT proplayers_heroes_pkey PRIMARY KEY (id_proplayer, id_hero);


--
-- Name: proplayers_images proplayers_images_pkey; Type: CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.proplayers_images
    ADD CONSTRAINT proplayers_images_pkey PRIMARY KEY (id_proplayer, hash_tumblr);


--
-- Name: proplayers proplayers_pkey; Type: CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.proplayers
    ADD CONSTRAINT proplayers_pkey PRIMARY KEY (id_proplayer);


--
-- Name: teams_game teams_game_pkey; Type: CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.teams_game
    ADD CONSTRAINT teams_game_pkey PRIMARY KEY (id_team, id_game);


--
-- Name: teams teams_pkey; Type: CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.teams
    ADD CONSTRAINT teams_pkey PRIMARY KEY (id_team);


--
-- Name: tumblr tumblr_pkey; Type: CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.tumblr
    ADD CONSTRAINT tumblr_pkey PRIMARY KEY (id_hero, hash_tumblr);


--
-- Name: channel fk_channel_game; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.channel
    ADD CONSTRAINT fk_channel_game FOREIGN KEY (id_game) REFERENCES public.games(id_game);


--
-- Name: channel_games fk_channelgames_channel; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.channel_games
    ADD CONSTRAINT fk_channelgames_channel FOREIGN KEY (id_youtube) REFERENCES public.channel(id_youtube);


--
-- Name: channel_games fk_channelgames_game; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.channel_games
    ADD CONSTRAINT fk_channelgames_game FOREIGN KEY (id_game) REFERENCES public.games(id_game);


--
-- Name: channel_historic fk_channelhistoric_channel; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.channel_historic
    ADD CONSTRAINT fk_channelhistoric_channel FOREIGN KEY (id_youtube) REFERENCES public.channel(id_youtube);


--
-- Name: channel_images fk_channelimages_channel; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.channel_images
    ADD CONSTRAINT fk_channelimages_channel FOREIGN KEY (id_youtube) REFERENCES public.channel(id_youtube);


--
-- Name: events fk_events_game; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT fk_events_game FOREIGN KEY (id_game) REFERENCES public.games(id_game);


--
-- Name: heroes fk_heroes_game; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.heroes
    ADD CONSTRAINT fk_heroes_game FOREIGN KEY (id_game) REFERENCES public.games(id_game);


--
-- Name: itens fk_itens_game; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.itens
    ADD CONSTRAINT fk_itens_game FOREIGN KEY (id_game) REFERENCES public.games(id_game);


--
-- Name: itens_images fk_itensimages_item; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.itens_images
    ADD CONSTRAINT fk_itensimages_item FOREIGN KEY (id_item) REFERENCES public.itens(id_item);


--
-- Name: proplayers_heroes_build fk_phb_hero; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.proplayers_heroes_build
    ADD CONSTRAINT fk_phb_hero FOREIGN KEY (id_hero) REFERENCES public.heroes(id_hero);


--
-- Name: proplayers_heroes_build fk_phb_item1; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.proplayers_heroes_build
    ADD CONSTRAINT fk_phb_item1 FOREIGN KEY (id_item_1) REFERENCES public.itens(id_item);


--
-- Name: proplayers_heroes_build fk_phb_item2; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.proplayers_heroes_build
    ADD CONSTRAINT fk_phb_item2 FOREIGN KEY (id_item_2) REFERENCES public.itens(id_item);


--
-- Name: proplayers_heroes_build fk_phb_item3; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.proplayers_heroes_build
    ADD CONSTRAINT fk_phb_item3 FOREIGN KEY (id_item_3) REFERENCES public.itens(id_item);


--
-- Name: proplayers_heroes_build fk_phb_item4; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.proplayers_heroes_build
    ADD CONSTRAINT fk_phb_item4 FOREIGN KEY (id_item_4) REFERENCES public.itens(id_item);


--
-- Name: proplayers_heroes_build fk_phb_item5; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.proplayers_heroes_build
    ADD CONSTRAINT fk_phb_item5 FOREIGN KEY (id_item_5) REFERENCES public.itens(id_item);


--
-- Name: proplayers_heroes_build fk_phb_item6; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.proplayers_heroes_build
    ADD CONSTRAINT fk_phb_item6 FOREIGN KEY (id_item_6) REFERENCES public.itens(id_item);


--
-- Name: proplayers_heroes_build fk_phb_item7; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.proplayers_heroes_build
    ADD CONSTRAINT fk_phb_item7 FOREIGN KEY (id_item_7) REFERENCES public.itens(id_item);


--
-- Name: proplayers_heroes_build fk_phb_item8; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.proplayers_heroes_build
    ADD CONSTRAINT fk_phb_item8 FOREIGN KEY (id_item_8) REFERENCES public.itens(id_item);


--
-- Name: proplayers_heroes_build fk_phb_item9; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.proplayers_heroes_build
    ADD CONSTRAINT fk_phb_item9 FOREIGN KEY (id_item_9) REFERENCES public.itens(id_item);


--
-- Name: proplayers_heroes_build fk_phb_proplayer; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.proplayers_heroes_build
    ADD CONSTRAINT fk_phb_proplayer FOREIGN KEY (id_proplayer) REFERENCES public.proplayers(id_proplayer);


--
-- Name: playlist fk_playlist_channel; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.playlist
    ADD CONSTRAINT fk_playlist_channel FOREIGN KEY (id_youtube) REFERENCES public.channel(id_youtube);


--
-- Name: playlist fk_playlist_game; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.playlist
    ADD CONSTRAINT fk_playlist_game FOREIGN KEY (id_game) REFERENCES public.games(id_game);


--
-- Name: playlist_movie fk_playlistmovie_game; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.playlist_movie
    ADD CONSTRAINT fk_playlistmovie_game FOREIGN KEY (id_game) REFERENCES public.games(id_game);


--
-- Name: playlist_movie fk_playlistmovie_hero; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.playlist_movie
    ADD CONSTRAINT fk_playlistmovie_hero FOREIGN KEY (id_hero) REFERENCES public.heroes(id_hero);


--
-- Name: playlist_movie fk_playlistmovie_playlist; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.playlist_movie
    ADD CONSTRAINT fk_playlistmovie_playlist FOREIGN KEY (id_playlist) REFERENCES public.playlist(id_playlist);


--
-- Name: playlist_movie fk_playlistmovie_proplayer; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.playlist_movie
    ADD CONSTRAINT fk_playlistmovie_proplayer FOREIGN KEY (id_proplayer) REFERENCES public.proplayers(id_proplayer);


--
-- Name: playlist_movie_historic fk_playlistmoviehistoric_movie; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.playlist_movie_historic
    ADD CONSTRAINT fk_playlistmoviehistoric_movie FOREIGN KEY (id_movie) REFERENCES public.playlist_movie(id_movie);


--
-- Name: playlist_movie_tumblr fk_playlistmovietumblr_movie; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.playlist_movie_tumblr
    ADD CONSTRAINT fk_playlistmovietumblr_movie FOREIGN KEY (id_movie) REFERENCES public.playlist_movie(id_movie);


--
-- Name: proplayers_games fk_proplayersgames_game; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.proplayers_games
    ADD CONSTRAINT fk_proplayersgames_game FOREIGN KEY (id_game) REFERENCES public.games(id_game);


--
-- Name: proplayers_games fk_proplayersgames_proplayer; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.proplayers_games
    ADD CONSTRAINT fk_proplayersgames_proplayer FOREIGN KEY (id_proplayer) REFERENCES public.proplayers(id_proplayer);


--
-- Name: proplayers_heroes fk_proplayersheroes_hero; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.proplayers_heroes
    ADD CONSTRAINT fk_proplayersheroes_hero FOREIGN KEY (id_hero) REFERENCES public.heroes(id_hero);


--
-- Name: proplayers_heroes fk_proplayersheroes_proplayer; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.proplayers_heroes
    ADD CONSTRAINT fk_proplayersheroes_proplayer FOREIGN KEY (id_proplayer) REFERENCES public.proplayers(id_proplayer);


--
-- Name: proplayers_images fk_proplayersimages_proplayer; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.proplayers_images
    ADD CONSTRAINT fk_proplayersimages_proplayer FOREIGN KEY (id_proplayer) REFERENCES public.proplayers(id_proplayer);


--
-- Name: teams_game fk_teamsgame_game; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.teams_game
    ADD CONSTRAINT fk_teamsgame_game FOREIGN KEY (id_game) REFERENCES public.games(id_game);


--
-- Name: teams_game fk_teamsgame_team; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.teams_game
    ADD CONSTRAINT fk_teamsgame_team FOREIGN KEY (id_team) REFERENCES public.teams(id_team);


--
-- Name: tumblr fk_tumblr_hero; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.tumblr
    ADD CONSTRAINT fk_tumblr_hero FOREIGN KEY (id_hero) REFERENCES public.heroes(id_hero);


--
-- PostgreSQL database dump complete
--

