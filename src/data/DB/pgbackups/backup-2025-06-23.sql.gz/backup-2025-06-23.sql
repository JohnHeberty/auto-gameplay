--
-- PostgreSQL database dump
--

-- Dumped from database version 17.5
-- Dumped by pg_dump version 17.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: channel; Type: TABLE; Schema: public; Owner: usergameplay
--

CREATE TABLE public.channel (
    id_channel integer NOT NULL,
    id_youtube character varying(30) NOT NULL,
    url character varying(100) NOT NULL,
    title character varying(50) NOT NULL,
    description character varying(1000),
    description_snippet character varying(200),
    handle_name character varying(50) NOT NULL,
    handle character varying(50) NOT NULL,
    id_game integer,
    country character varying(30),
    register_date date,
    my_channel boolean DEFAULT false NOT NULL
);


ALTER TABLE public.channel OWNER TO usergameplay;

--
-- Name: channel_games; Type: TABLE; Schema: public; Owner: usergameplay
--

CREATE TABLE public.channel_games (
    id_youtube character varying(30) NOT NULL,
    id_game integer NOT NULL
);


ALTER TABLE public.channel_games OWNER TO usergameplay;

--
-- Name: channel_historic; Type: TABLE; Schema: public; Owner: usergameplay
--

CREATE TABLE public.channel_historic (
    id_youtube character varying(30) NOT NULL,
    views integer NOT NULL,
    subscribers integer NOT NULL,
    register_date date NOT NULL
);


ALTER TABLE public.channel_historic OWNER TO usergameplay;

--
-- Name: channel_id_channel_seq; Type: SEQUENCE; Schema: public; Owner: usergameplay
--

CREATE SEQUENCE public.channel_id_channel_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.channel_id_channel_seq OWNER TO usergameplay;

--
-- Name: channel_id_channel_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: usergameplay
--

ALTER SEQUENCE public.channel_id_channel_seq OWNED BY public.channel.id_channel;


--
-- Name: channel_images; Type: TABLE; Schema: public; Owner: usergameplay
--

CREATE TABLE public.channel_images (
    id_youtube character varying(30) NOT NULL,
    logo bytea,
    banner bytea,
    vanity bytea
);


ALTER TABLE public.channel_images OWNER TO usergameplay;

--
-- Name: events; Type: TABLE; Schema: public; Owner: usergameplay
--

CREATE TABLE public.events (
    id_event integer NOT NULL,
    name character varying(50) NOT NULL,
    id_game integer NOT NULL,
    date_start date,
    date_end date
);


ALTER TABLE public.events OWNER TO usergameplay;

--
-- Name: events_id_event_seq; Type: SEQUENCE; Schema: public; Owner: usergameplay
--

CREATE SEQUENCE public.events_id_event_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.events_id_event_seq OWNER TO usergameplay;

--
-- Name: events_id_event_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: usergameplay
--

ALTER SEQUENCE public.events_id_event_seq OWNED BY public.events.id_event;


--
-- Name: games; Type: TABLE; Schema: public; Owner: usergameplay
--

CREATE TABLE public.games (
    id_game integer NOT NULL,
    name character varying(50) NOT NULL,
    game character varying(25) NOT NULL,
    ico bytea
);


ALTER TABLE public.games OWNER TO usergameplay;

--
-- Name: games_id_game_seq; Type: SEQUENCE; Schema: public; Owner: usergameplay
--

CREATE SEQUENCE public.games_id_game_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.games_id_game_seq OWNER TO usergameplay;

--
-- Name: games_id_game_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: usergameplay
--

ALTER SEQUENCE public.games_id_game_seq OWNED BY public.games.id_game;


--
-- Name: heroes; Type: TABLE; Schema: public; Owner: usergameplay
--

CREATE TABLE public.heroes (
    id_hero integer NOT NULL,
    name character varying(50) NOT NULL,
    id_game integer NOT NULL,
    description character varying(1000),
    image bytea
);


ALTER TABLE public.heroes OWNER TO usergameplay;

--
-- Name: heroes_id_hero_seq; Type: SEQUENCE; Schema: public; Owner: usergameplay
--

CREATE SEQUENCE public.heroes_id_hero_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.heroes_id_hero_seq OWNER TO usergameplay;

--
-- Name: heroes_id_hero_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: usergameplay
--

ALTER SEQUENCE public.heroes_id_hero_seq OWNED BY public.heroes.id_hero;


--
-- Name: itens; Type: TABLE; Schema: public; Owner: usergameplay
--

CREATE TABLE public.itens (
    id_item integer NOT NULL,
    name character varying(50) NOT NULL,
    id_game integer NOT NULL,
    description character varying(1000),
    "VALUE" integer NOT NULL
);


ALTER TABLE public.itens OWNER TO usergameplay;

--
-- Name: itens_id_item_seq; Type: SEQUENCE; Schema: public; Owner: usergameplay
--

CREATE SEQUENCE public.itens_id_item_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.itens_id_item_seq OWNER TO usergameplay;

--
-- Name: itens_id_item_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: usergameplay
--

ALTER SEQUENCE public.itens_id_item_seq OWNED BY public.itens.id_item;


--
-- Name: itens_images; Type: TABLE; Schema: public; Owner: usergameplay
--

CREATE TABLE public.itens_images (
    id_item integer NOT NULL,
    image bytea
);


ALTER TABLE public.itens_images OWNER TO usergameplay;

--
-- Name: playlist; Type: TABLE; Schema: public; Owner: usergameplay
--

CREATE TABLE public.playlist (
    id_playlist integer NOT NULL,
    id_youtube character varying(30) NOT NULL,
    id_game integer NOT NULL,
    name character varying(50) NOT NULL,
    description character varying(1000),
    register_date date NOT NULL
);


ALTER TABLE public.playlist OWNER TO usergameplay;

--
-- Name: playlist_id_playlist_seq; Type: SEQUENCE; Schema: public; Owner: usergameplay
--

CREATE SEQUENCE public.playlist_id_playlist_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.playlist_id_playlist_seq OWNER TO usergameplay;

--
-- Name: playlist_id_playlist_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: usergameplay
--

ALTER SEQUENCE public.playlist_id_playlist_seq OWNED BY public.playlist.id_playlist;


--
-- Name: playlist_movie; Type: TABLE; Schema: public; Owner: usergameplay
--

CREATE TABLE public.playlist_movie (
    id_movie integer NOT NULL,
    id_video character varying(50) NOT NULL,
    url character varying(100) NOT NULL,
    id_playlist integer NOT NULL,
    id_game integer NOT NULL,
    id_proplayer integer NOT NULL,
    id_hero integer NOT NULL,
    time_movie integer NOT NULL,
    register_date date NOT NULL
);


ALTER TABLE public.playlist_movie OWNER TO usergameplay;

--
-- Name: playlist_movie_historic; Type: TABLE; Schema: public; Owner: usergameplay
--

CREATE TABLE public.playlist_movie_historic (
    id_movie integer NOT NULL,
    titulo character varying(50) NOT NULL,
    description character varying(1000),
    likes integer NOT NULL,
    date_start date NOT NULL,
    register_date date NOT NULL,
    date_end date NOT NULL
);


ALTER TABLE public.playlist_movie_historic OWNER TO usergameplay;

--
-- Name: playlist_movie_id_movie_seq; Type: SEQUENCE; Schema: public; Owner: usergameplay
--

CREATE SEQUENCE public.playlist_movie_id_movie_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.playlist_movie_id_movie_seq OWNER TO usergameplay;

--
-- Name: playlist_movie_id_movie_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: usergameplay
--

ALTER SEQUENCE public.playlist_movie_id_movie_seq OWNED BY public.playlist_movie.id_movie;


--
-- Name: playlist_movie_tumblr; Type: TABLE; Schema: public; Owner: usergameplay
--

CREATE TABLE public.playlist_movie_tumblr (
    id_movie integer NOT NULL,
    hash_tumblr character varying(64) NOT NULL,
    tumblr bytea NOT NULL,
    register_date date NOT NULL
);


ALTER TABLE public.playlist_movie_tumblr OWNER TO usergameplay;

--
-- Name: proplayers; Type: TABLE; Schema: public; Owner: usergameplay
--

CREATE TABLE public.proplayers (
    id_proplayer integer NOT NULL,
    "NOME" character varying(50) NOT NULL,
    description character varying(1000),
    register_date date NOT NULL
);


ALTER TABLE public.proplayers OWNER TO usergameplay;

--
-- Name: proplayers_games; Type: TABLE; Schema: public; Owner: usergameplay
--

CREATE TABLE public.proplayers_games (
    id_proplayer integer NOT NULL,
    id_game integer NOT NULL,
    register_date date NOT NULL
);


ALTER TABLE public.proplayers_games OWNER TO usergameplay;

--
-- Name: proplayers_heroes; Type: TABLE; Schema: public; Owner: usergameplay
--

CREATE TABLE public.proplayers_heroes (
    id_proplayer integer NOT NULL,
    id_hero integer NOT NULL,
    register_date date NOT NULL
);


ALTER TABLE public.proplayers_heroes OWNER TO usergameplay;

--
-- Name: proplayers_heroes_build; Type: TABLE; Schema: public; Owner: usergameplay
--

CREATE TABLE public.proplayers_heroes_build (
    id_proplayer integer NOT NULL,
    id_hero integer NOT NULL,
    id_item_1 integer,
    id_item_2 integer,
    id_item_3 integer,
    id_item_4 integer,
    id_item_5 integer,
    id_item_6 integer,
    id_item_7 integer,
    id_item_8 integer,
    id_item_9 integer,
    register_date date NOT NULL
);


ALTER TABLE public.proplayers_heroes_build OWNER TO usergameplay;

--
-- Name: proplayers_id_proplayer_seq; Type: SEQUENCE; Schema: public; Owner: usergameplay
--

CREATE SEQUENCE public.proplayers_id_proplayer_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.proplayers_id_proplayer_seq OWNER TO usergameplay;

--
-- Name: proplayers_id_proplayer_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: usergameplay
--

ALTER SEQUENCE public.proplayers_id_proplayer_seq OWNED BY public.proplayers.id_proplayer;


--
-- Name: proplayers_images; Type: TABLE; Schema: public; Owner: usergameplay
--

CREATE TABLE public.proplayers_images (
    id_proplayer integer NOT NULL,
    hash_tumblr character varying(64) NOT NULL,
    image bytea
);


ALTER TABLE public.proplayers_images OWNER TO usergameplay;

--
-- Name: teams; Type: TABLE; Schema: public; Owner: usergameplay
--

CREATE TABLE public.teams (
    id_team integer NOT NULL,
    team character varying(50) NOT NULL,
    logo bytea
);


ALTER TABLE public.teams OWNER TO usergameplay;

--
-- Name: teams_game; Type: TABLE; Schema: public; Owner: usergameplay
--

CREATE TABLE public.teams_game (
    id_team integer NOT NULL,
    id_game integer NOT NULL,
    banner bytea
);


ALTER TABLE public.teams_game OWNER TO usergameplay;

--
-- Name: teams_id_team_seq; Type: SEQUENCE; Schema: public; Owner: usergameplay
--

CREATE SEQUENCE public.teams_id_team_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.teams_id_team_seq OWNER TO usergameplay;

--
-- Name: teams_id_team_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: usergameplay
--

ALTER SEQUENCE public.teams_id_team_seq OWNED BY public.teams.id_team;


--
-- Name: tumblr; Type: TABLE; Schema: public; Owner: usergameplay
--

CREATE TABLE public.tumblr (
    id_hero integer NOT NULL,
    description character varying(1000),
    hash_tumblr character varying(64) NOT NULL,
    image bytea
);


ALTER TABLE public.tumblr OWNER TO usergameplay;

--
-- Name: channel id_channel; Type: DEFAULT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.channel ALTER COLUMN id_channel SET DEFAULT nextval('public.channel_id_channel_seq'::regclass);


--
-- Name: events id_event; Type: DEFAULT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.events ALTER COLUMN id_event SET DEFAULT nextval('public.events_id_event_seq'::regclass);


--
-- Name: games id_game; Type: DEFAULT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.games ALTER COLUMN id_game SET DEFAULT nextval('public.games_id_game_seq'::regclass);


--
-- Name: heroes id_hero; Type: DEFAULT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.heroes ALTER COLUMN id_hero SET DEFAULT nextval('public.heroes_id_hero_seq'::regclass);


--
-- Name: itens id_item; Type: DEFAULT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.itens ALTER COLUMN id_item SET DEFAULT nextval('public.itens_id_item_seq'::regclass);


--
-- Name: playlist id_playlist; Type: DEFAULT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.playlist ALTER COLUMN id_playlist SET DEFAULT nextval('public.playlist_id_playlist_seq'::regclass);


--
-- Name: playlist_movie id_movie; Type: DEFAULT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.playlist_movie ALTER COLUMN id_movie SET DEFAULT nextval('public.playlist_movie_id_movie_seq'::regclass);


--
-- Name: proplayers id_proplayer; Type: DEFAULT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.proplayers ALTER COLUMN id_proplayer SET DEFAULT nextval('public.proplayers_id_proplayer_seq'::regclass);


--
-- Name: teams id_team; Type: DEFAULT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.teams ALTER COLUMN id_team SET DEFAULT nextval('public.teams_id_team_seq'::regclass);


--
-- Data for Name: channel; Type: TABLE DATA; Schema: public; Owner: usergameplay
--

COPY public.channel (id_channel, id_youtube, url, title, description, description_snippet, handle_name, handle, id_game, country, register_date, my_channel) FROM stdin;
\.


--
-- Data for Name: channel_games; Type: TABLE DATA; Schema: public; Owner: usergameplay
--

COPY public.channel_games (id_youtube, id_game) FROM stdin;
\.


--
-- Data for Name: channel_historic; Type: TABLE DATA; Schema: public; Owner: usergameplay
--

COPY public.channel_historic (id_youtube, views, subscribers, register_date) FROM stdin;
\.


--
-- Data for Name: channel_images; Type: TABLE DATA; Schema: public; Owner: usergameplay
--

COPY public.channel_images (id_youtube, logo, banner, vanity) FROM stdin;
\.


--
-- Data for Name: events; Type: TABLE DATA; Schema: public; Owner: usergameplay
--

COPY public.events (id_event, name, id_game, date_start, date_end) FROM stdin;
\.


--
-- Data for Name: games; Type: TABLE DATA; Schema: public; Owner: usergameplay
--

COPY public.games (id_game, name, game, ico) FROM stdin;
1	Dota 2	Dota 2	\N
2	Counter-Strike: Global Offensive	CS:GO	\N
3	League of Legends	LOL	\N
\.


--
-- Data for Name: heroes; Type: TABLE DATA; Schema: public; Owner: usergameplay
--

COPY public.heroes (id_hero, name, id_game, description, image) FROM stdin;
\.


--
-- Data for Name: itens; Type: TABLE DATA; Schema: public; Owner: usergameplay
--

COPY public.itens (id_item, name, id_game, description, "VALUE") FROM stdin;
\.


--
-- Data for Name: itens_images; Type: TABLE DATA; Schema: public; Owner: usergameplay
--

COPY public.itens_images (id_item, image) FROM stdin;
\.


--
-- Data for Name: playlist; Type: TABLE DATA; Schema: public; Owner: usergameplay
--

COPY public.playlist (id_playlist, id_youtube, id_game, name, description, register_date) FROM stdin;
\.


--
-- Data for Name: playlist_movie; Type: TABLE DATA; Schema: public; Owner: usergameplay
--

COPY public.playlist_movie (id_movie, id_video, url, id_playlist, id_game, id_proplayer, id_hero, time_movie, register_date) FROM stdin;
\.


--
-- Data for Name: playlist_movie_historic; Type: TABLE DATA; Schema: public; Owner: usergameplay
--

COPY public.playlist_movie_historic (id_movie, titulo, description, likes, date_start, register_date, date_end) FROM stdin;
\.


--
-- Data for Name: playlist_movie_tumblr; Type: TABLE DATA; Schema: public; Owner: usergameplay
--

COPY public.playlist_movie_tumblr (id_movie, hash_tumblr, tumblr, register_date) FROM stdin;
\.


--
-- Data for Name: proplayers; Type: TABLE DATA; Schema: public; Owner: usergameplay
--

COPY public.proplayers (id_proplayer, "NOME", description, register_date) FROM stdin;
\.


--
-- Data for Name: proplayers_games; Type: TABLE DATA; Schema: public; Owner: usergameplay
--

COPY public.proplayers_games (id_proplayer, id_game, register_date) FROM stdin;
\.


--
-- Data for Name: proplayers_heroes; Type: TABLE DATA; Schema: public; Owner: usergameplay
--

COPY public.proplayers_heroes (id_proplayer, id_hero, register_date) FROM stdin;
\.


--
-- Data for Name: proplayers_heroes_build; Type: TABLE DATA; Schema: public; Owner: usergameplay
--

COPY public.proplayers_heroes_build (id_proplayer, id_hero, id_item_1, id_item_2, id_item_3, id_item_4, id_item_5, id_item_6, id_item_7, id_item_8, id_item_9, register_date) FROM stdin;
\.


--
-- Data for Name: proplayers_images; Type: TABLE DATA; Schema: public; Owner: usergameplay
--

COPY public.proplayers_images (id_proplayer, hash_tumblr, image) FROM stdin;
\.


--
-- Data for Name: teams; Type: TABLE DATA; Schema: public; Owner: usergameplay
--

COPY public.teams (id_team, team, logo) FROM stdin;
\.


--
-- Data for Name: teams_game; Type: TABLE DATA; Schema: public; Owner: usergameplay
--

COPY public.teams_game (id_team, id_game, banner) FROM stdin;
\.


--
-- Data for Name: tumblr; Type: TABLE DATA; Schema: public; Owner: usergameplay
--

COPY public.tumblr (id_hero, description, hash_tumblr, image) FROM stdin;
\.


--
-- Name: channel_id_channel_seq; Type: SEQUENCE SET; Schema: public; Owner: usergameplay
--

SELECT pg_catalog.setval('public.channel_id_channel_seq', 1, false);


--
-- Name: events_id_event_seq; Type: SEQUENCE SET; Schema: public; Owner: usergameplay
--

SELECT pg_catalog.setval('public.events_id_event_seq', 1, false);


--
-- Name: games_id_game_seq; Type: SEQUENCE SET; Schema: public; Owner: usergameplay
--

SELECT pg_catalog.setval('public.games_id_game_seq', 3, true);


--
-- Name: heroes_id_hero_seq; Type: SEQUENCE SET; Schema: public; Owner: usergameplay
--

SELECT pg_catalog.setval('public.heroes_id_hero_seq', 1, false);


--
-- Name: itens_id_item_seq; Type: SEQUENCE SET; Schema: public; Owner: usergameplay
--

SELECT pg_catalog.setval('public.itens_id_item_seq', 1, false);


--
-- Name: playlist_id_playlist_seq; Type: SEQUENCE SET; Schema: public; Owner: usergameplay
--

SELECT pg_catalog.setval('public.playlist_id_playlist_seq', 1, false);


--
-- Name: playlist_movie_id_movie_seq; Type: SEQUENCE SET; Schema: public; Owner: usergameplay
--

SELECT pg_catalog.setval('public.playlist_movie_id_movie_seq', 1, false);


--
-- Name: proplayers_id_proplayer_seq; Type: SEQUENCE SET; Schema: public; Owner: usergameplay
--

SELECT pg_catalog.setval('public.proplayers_id_proplayer_seq', 1, false);


--
-- Name: teams_id_team_seq; Type: SEQUENCE SET; Schema: public; Owner: usergameplay
--

SELECT pg_catalog.setval('public.teams_id_team_seq', 1, false);


--
-- Name: channel_games channel_games_pkey; Type: CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.channel_games
    ADD CONSTRAINT channel_games_pkey PRIMARY KEY (id_youtube, id_game);


--
-- Name: channel_historic channel_historic_pkey; Type: CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.channel_historic
    ADD CONSTRAINT channel_historic_pkey PRIMARY KEY (id_youtube, register_date);


--
-- Name: channel_images channel_images_pkey; Type: CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.channel_images
    ADD CONSTRAINT channel_images_pkey PRIMARY KEY (id_youtube);


--
-- Name: channel channel_pkey; Type: CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.channel
    ADD CONSTRAINT channel_pkey PRIMARY KEY (id_youtube);


--
-- Name: events events_pkey; Type: CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT events_pkey PRIMARY KEY (id_event);


--
-- Name: games games_pkey; Type: CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.games
    ADD CONSTRAINT games_pkey PRIMARY KEY (id_game);


--
-- Name: heroes heroes_pkey; Type: CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.heroes
    ADD CONSTRAINT heroes_pkey PRIMARY KEY (id_hero);


--
-- Name: itens_images itens_images_pkey; Type: CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.itens_images
    ADD CONSTRAINT itens_images_pkey PRIMARY KEY (id_item);


--
-- Name: itens itens_pkey; Type: CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.itens
    ADD CONSTRAINT itens_pkey PRIMARY KEY (id_item);


--
-- Name: playlist_movie_historic playlist_movie_historic_pkey; Type: CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.playlist_movie_historic
    ADD CONSTRAINT playlist_movie_historic_pkey PRIMARY KEY (id_movie, date_start, register_date, date_end);


--
-- Name: playlist_movie playlist_movie_pkey; Type: CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.playlist_movie
    ADD CONSTRAINT playlist_movie_pkey PRIMARY KEY (id_movie);


--
-- Name: playlist_movie_tumblr playlist_movie_tumblr_pkey; Type: CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.playlist_movie_tumblr
    ADD CONSTRAINT playlist_movie_tumblr_pkey PRIMARY KEY (hash_tumblr);


--
-- Name: playlist playlist_pkey; Type: CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.playlist
    ADD CONSTRAINT playlist_pkey PRIMARY KEY (id_playlist);


--
-- Name: proplayers_games proplayers_games_pkey; Type: CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.proplayers_games
    ADD CONSTRAINT proplayers_games_pkey PRIMARY KEY (id_proplayer, id_game);


--
-- Name: proplayers_heroes_build proplayers_heroes_build_pkey; Type: CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.proplayers_heroes_build
    ADD CONSTRAINT proplayers_heroes_build_pkey PRIMARY KEY (id_proplayer, id_hero);


--
-- Name: proplayers_heroes proplayers_heroes_pkey; Type: CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.proplayers_heroes
    ADD CONSTRAINT proplayers_heroes_pkey PRIMARY KEY (id_proplayer, id_hero);


--
-- Name: proplayers_images proplayers_images_pkey; Type: CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.proplayers_images
    ADD CONSTRAINT proplayers_images_pkey PRIMARY KEY (id_proplayer, hash_tumblr);


--
-- Name: proplayers proplayers_pkey; Type: CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.proplayers
    ADD CONSTRAINT proplayers_pkey PRIMARY KEY (id_proplayer);


--
-- Name: teams_game teams_game_pkey; Type: CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.teams_game
    ADD CONSTRAINT teams_game_pkey PRIMARY KEY (id_team, id_game);


--
-- Name: teams teams_pkey; Type: CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.teams
    ADD CONSTRAINT teams_pkey PRIMARY KEY (id_team);


--
-- Name: tumblr tumblr_pkey; Type: CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.tumblr
    ADD CONSTRAINT tumblr_pkey PRIMARY KEY (id_hero, hash_tumblr);


--
-- Name: channel fk_channel_game; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.channel
    ADD CONSTRAINT fk_channel_game FOREIGN KEY (id_game) REFERENCES public.games(id_game);


--
-- Name: channel_games fk_channelgames_channel; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.channel_games
    ADD CONSTRAINT fk_channelgames_channel FOREIGN KEY (id_youtube) REFERENCES public.channel(id_youtube);


--
-- Name: channel_games fk_channelgames_game; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.channel_games
    ADD CONSTRAINT fk_channelgames_game FOREIGN KEY (id_game) REFERENCES public.games(id_game);


--
-- Name: channel_historic fk_channelhistoric_channel; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.channel_historic
    ADD CONSTRAINT fk_channelhistoric_channel FOREIGN KEY (id_youtube) REFERENCES public.channel(id_youtube);


--
-- Name: channel_images fk_channelimages_channel; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.channel_images
    ADD CONSTRAINT fk_channelimages_channel FOREIGN KEY (id_youtube) REFERENCES public.channel(id_youtube);


--
-- Name: events fk_events_game; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT fk_events_game FOREIGN KEY (id_game) REFERENCES public.games(id_game);


--
-- Name: heroes fk_heroes_game; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.heroes
    ADD CONSTRAINT fk_heroes_game FOREIGN KEY (id_game) REFERENCES public.games(id_game);


--
-- Name: itens fk_itens_game; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.itens
    ADD CONSTRAINT fk_itens_game FOREIGN KEY (id_game) REFERENCES public.games(id_game);


--
-- Name: itens_images fk_itensimages_item; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.itens_images
    ADD CONSTRAINT fk_itensimages_item FOREIGN KEY (id_item) REFERENCES public.itens(id_item);


--
-- Name: proplayers_heroes_build fk_phb_hero; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.proplayers_heroes_build
    ADD CONSTRAINT fk_phb_hero FOREIGN KEY (id_hero) REFERENCES public.heroes(id_hero);


--
-- Name: proplayers_heroes_build fk_phb_item1; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.proplayers_heroes_build
    ADD CONSTRAINT fk_phb_item1 FOREIGN KEY (id_item_1) REFERENCES public.itens(id_item);


--
-- Name: proplayers_heroes_build fk_phb_item2; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.proplayers_heroes_build
    ADD CONSTRAINT fk_phb_item2 FOREIGN KEY (id_item_2) REFERENCES public.itens(id_item);


--
-- Name: proplayers_heroes_build fk_phb_item3; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.proplayers_heroes_build
    ADD CONSTRAINT fk_phb_item3 FOREIGN KEY (id_item_3) REFERENCES public.itens(id_item);


--
-- Name: proplayers_heroes_build fk_phb_item4; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.proplayers_heroes_build
    ADD CONSTRAINT fk_phb_item4 FOREIGN KEY (id_item_4) REFERENCES public.itens(id_item);


--
-- Name: proplayers_heroes_build fk_phb_item5; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.proplayers_heroes_build
    ADD CONSTRAINT fk_phb_item5 FOREIGN KEY (id_item_5) REFERENCES public.itens(id_item);


--
-- Name: proplayers_heroes_build fk_phb_item6; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.proplayers_heroes_build
    ADD CONSTRAINT fk_phb_item6 FOREIGN KEY (id_item_6) REFERENCES public.itens(id_item);


--
-- Name: proplayers_heroes_build fk_phb_item7; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.proplayers_heroes_build
    ADD CONSTRAINT fk_phb_item7 FOREIGN KEY (id_item_7) REFERENCES public.itens(id_item);


--
-- Name: proplayers_heroes_build fk_phb_item8; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.proplayers_heroes_build
    ADD CONSTRAINT fk_phb_item8 FOREIGN KEY (id_item_8) REFERENCES public.itens(id_item);


--
-- Name: proplayers_heroes_build fk_phb_item9; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.proplayers_heroes_build
    ADD CONSTRAINT fk_phb_item9 FOREIGN KEY (id_item_9) REFERENCES public.itens(id_item);


--
-- Name: proplayers_heroes_build fk_phb_proplayer; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.proplayers_heroes_build
    ADD CONSTRAINT fk_phb_proplayer FOREIGN KEY (id_proplayer) REFERENCES public.proplayers(id_proplayer);


--
-- Name: playlist fk_playlist_channel; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.playlist
    ADD CONSTRAINT fk_playlist_channel FOREIGN KEY (id_youtube) REFERENCES public.channel(id_youtube);


--
-- Name: playlist fk_playlist_game; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.playlist
    ADD CONSTRAINT fk_playlist_game FOREIGN KEY (id_game) REFERENCES public.games(id_game);


--
-- Name: playlist_movie fk_playlistmovie_game; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.playlist_movie
    ADD CONSTRAINT fk_playlistmovie_game FOREIGN KEY (id_game) REFERENCES public.games(id_game);


--
-- Name: playlist_movie fk_playlistmovie_hero; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.playlist_movie
    ADD CONSTRAINT fk_playlistmovie_hero FOREIGN KEY (id_hero) REFERENCES public.heroes(id_hero);


--
-- Name: playlist_movie fk_playlistmovie_playlist; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.playlist_movie
    ADD CONSTRAINT fk_playlistmovie_playlist FOREIGN KEY (id_playlist) REFERENCES public.playlist(id_playlist);


--
-- Name: playlist_movie fk_playlistmovie_proplayer; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.playlist_movie
    ADD CONSTRAINT fk_playlistmovie_proplayer FOREIGN KEY (id_proplayer) REFERENCES public.proplayers(id_proplayer);


--
-- Name: playlist_movie_historic fk_playlistmoviehistoric_movie; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.playlist_movie_historic
    ADD CONSTRAINT fk_playlistmoviehistoric_movie FOREIGN KEY (id_movie) REFERENCES public.playlist_movie(id_movie);


--
-- Name: playlist_movie_tumblr fk_playlistmovietumblr_movie; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.playlist_movie_tumblr
    ADD CONSTRAINT fk_playlistmovietumblr_movie FOREIGN KEY (id_movie) REFERENCES public.playlist_movie(id_movie);


--
-- Name: proplayers_games fk_proplayersgames_game; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.proplayers_games
    ADD CONSTRAINT fk_proplayersgames_game FOREIGN KEY (id_game) REFERENCES public.games(id_game);


--
-- Name: proplayers_games fk_proplayersgames_proplayer; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.proplayers_games
    ADD CONSTRAINT fk_proplayersgames_proplayer FOREIGN KEY (id_proplayer) REFERENCES public.proplayers(id_proplayer);


--
-- Name: proplayers_heroes fk_proplayersheroes_hero; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.proplayers_heroes
    ADD CONSTRAINT fk_proplayersheroes_hero FOREIGN KEY (id_hero) REFERENCES public.heroes(id_hero);


--
-- Name: proplayers_heroes fk_proplayersheroes_proplayer; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.proplayers_heroes
    ADD CONSTRAINT fk_proplayersheroes_proplayer FOREIGN KEY (id_proplayer) REFERENCES public.proplayers(id_proplayer);


--
-- Name: proplayers_images fk_proplayersimages_proplayer; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.proplayers_images
    ADD CONSTRAINT fk_proplayersimages_proplayer FOREIGN KEY (id_proplayer) REFERENCES public.proplayers(id_proplayer);


--
-- Name: teams_game fk_teamsgame_game; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.teams_game
    ADD CONSTRAINT fk_teamsgame_game FOREIGN KEY (id_game) REFERENCES public.games(id_game);


--
-- Name: teams_game fk_teamsgame_team; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.teams_game
    ADD CONSTRAINT fk_teamsgame_team FOREIGN KEY (id_team) REFERENCES public.teams(id_team);


--
-- Name: tumblr fk_tumblr_hero; Type: FK CONSTRAINT; Schema: public; Owner: usergameplay
--

ALTER TABLE ONLY public.tumblr
    ADD CONSTRAINT fk_tumblr_hero FOREIGN KEY (id_hero) REFERENCES public.heroes(id_hero);


--
-- PostgreSQL database dump complete
--

